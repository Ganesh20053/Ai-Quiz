// Test frontend login connection to backend
const testFrontendLogin = async () => {
  console.log('🧪 Testing Frontend Login Connection');
  console.log('==================================');
  console.log('');

  try {
    // Test staff login
    console.log('📧 Testing staff login from frontend...');
    const response = await fetch('http://localhost:5000/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: 'staff@quizapp.com',
        password: 'staff123'
      })
    });

    const data = await response.json();
    
    if (response.ok) {
      console.log('✅ Frontend login successful!');
      console.log('Response:', JSON.stringify(data, null, 2));
    } else {
      console.log('❌ Frontend login failed:', data.message);
    }

  } catch (error) {
    console.error('❌ Connection error:', error.message);
    console.log('');
    console.log('🔧 Troubleshooting:');
    console.log('1. Make sure backend server is running on port 5000');
    console.log('2. Check if CORS is properly configured');
    console.log('3. Verify the API endpoint is correct');
  }
};

// Run the test
testFrontendLogin(); 