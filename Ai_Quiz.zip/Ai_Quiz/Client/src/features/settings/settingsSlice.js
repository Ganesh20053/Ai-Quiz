import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  // Accessibility Settings
  isDarkMode: false,
  isHighContrast: false,
  isDyslexiaFont: false,
  isAudioOnlyMode: false,
  fontSize: 'medium', // small, medium, large, xl
  
  // Language Settings
  currentLanguage: 'en', // en, hi, ta, etc.
  availableLanguages: [
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'hi', name: 'हिंदी', flag: '🇮🇳' },
    { code: 'ta', name: 'தமிழ்', flag: '🇮🇳' },
    { code: 'es', name: 'Español', flag: '🇪🇸' },
    { code: 'fr', name: 'Français', flag: '🇫🇷' },
  ],
  
  // Voice Settings
  voiceEnabled: true,
  voiceSpeed: 1.0,
  voiceVolume: 1.0,
  preferredVoice: null,
  
  // Quiz Settings
  autoTimer: true,
  timerDuration: 30, // seconds per question
  showHints: true,
  pronunciationCheck: true,
  
  // Notification Settings
  emailNotifications: true,
  voiceReminders: true,
  dailyGoalReminders: true,
}

const settingsSlice = createSlice({
  name: 'settings',
  initialState,
  reducers: {
    toggleDarkMode: (state) => {
      state.isDarkMode = !state.isDarkMode
    },
    toggleHighContrast: (state) => {
      state.isHighContrast = !state.isHighContrast
    },
    toggleDyslexiaFont: (state) => {
      state.isDyslexiaFont = !state.isDyslexiaFont
    },
    toggleAudioOnlyMode: (state) => {
      state.isAudioOnlyMode = !state.isAudioOnlyMode
    },
    setFontSize: (state, action) => {
      state.fontSize = action.payload
    },
    setLanguage: (state, action) => {
      state.currentLanguage = action.payload
    },
    setVoiceSettings: (state, action) => {
      state.voiceSpeed = action.payload.speed || state.voiceSpeed
      state.voiceVolume = action.payload.volume || state.voiceVolume
      state.preferredVoice = action.payload.voice || state.preferredVoice
    },
    toggleVoice: (state) => {
      state.voiceEnabled = !state.voiceEnabled
    },
    setTimerSettings: (state, action) => {
      state.autoTimer = action.payload.autoTimer ?? state.autoTimer
      state.timerDuration = action.payload.duration || state.timerDuration
    },
    toggleFeature: (state, action) => {
      const { feature } = action.payload
      if (state.hasOwnProperty(feature)) {
        state[feature] = !state[feature]
      }
    },
    updateSettings: (state, action) => {
      return { ...state, ...action.payload }
    },
    resetSettings: () => initialState,
  },
})

export const {
  toggleDarkMode,
  toggleHighContrast,
  toggleDyslexiaFont,
  toggleAudioOnlyMode,
  setFontSize,
  setLanguage,
  setVoiceSettings,
  toggleVoice,
  setTimerSettings,
  toggleFeature,
  updateSettings,
  resetSettings,
} = settingsSlice.actions

export default settingsSlice.reducer