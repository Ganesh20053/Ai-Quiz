import { useState, useEffect, useRef } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { fetchStudentAssignments } from '../classroom/classroomSlice'
import { selectUser } from '../auth/authSlice'
import { useTheme } from '../../contexts/ThemeContext'
import Button from '../../components/common/Button'
import Loader from '../../components/common/Loader'
import { ArrowLeft, Mic, BookOpen, Calendar, Play, Target, Award } from 'lucide-react'

const StudentAssignments = () => {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const user = useSelector(selectUser)
  const theme = useTheme()
  const { assignments, assignmentsLoading, error } = useSelector(state => state.classroom)

  const [filter, setFilter] = useState('all')

  // Voice Control State
  const [isListening, setIsListening] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [voiceError, setVoiceError] = useState('')
  const [currentFocus, setCurrentFocus] = useState(0)
  const [speechSupported, setSpeechSupported] = useState(false)
  const [interimTranscript, setInterimTranscript] = useState('')
  const [finalTranscript, setFinalTranscript] = useState('')
  const [debugInfo, setDebugInfo] = useState('')

  // Voice Control Refs
  const recognitionRef = useRef(null)
  const synthRef = useRef(null)
  const manuallyStoppedRef = useRef(false)
  const restartTimeoutRef = useRef(null)
  const speechQueueRef = useRef([])
  const speechProcessingRef = useRef(false)

  // Voice Control Functions
  const speak = (text, priority = false) => {
    if (!synthRef.current || !user?.isDisabled) return

    if (priority) {
      // Stop current speech and clear queue for high priority messages
      synthRef.current.cancel()
      speechQueueRef.current = []
      speechProcessingRef.current = false
    }

    speechQueueRef.current.push({ text, priority })
    if (!speechProcessingRef.current) {
      processNextSpeech()
    }
  }

  const processNextSpeech = () => {
    if (speechQueueRef.current.length === 0) {
      speechProcessingRef.current = false
      setIsSpeaking(false)
      return
    }

    speechProcessingRef.current = true
    const { text } = speechQueueRef.current.shift()

    if (synthRef.current.speaking) {
      synthRef.current.cancel()
    }

    const utterance = new SpeechSynthesisUtterance(text)
    utterance.rate = 0.8
    utterance.pitch = 1
    utterance.volume = 1

    utterance.onstart = () => {
      setIsSpeaking(true)
      setDebugInfo(`Speaking: ${text.substring(0, 30)}...`)
    }

    utterance.onend = () => {
      setTimeout(() => processNextSpeech(), 500)
    }

    utterance.onerror = () => {
      setTimeout(() => processNextSpeech(), 500)
    }

    synthRef.current.speak(utterance)
  }

  const requestMicrophonePermission = async () => {
    try {
      // First check if mediaDevices is available
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setVoiceError('Voice control is not supported in this browser. Please use Chrome, Firefox, or Edge.')
        return false
      }

      // Check for available audio input devices
      const devices = await navigator.mediaDevices.enumerateDevices()
      const audioInputs = devices.filter(device => device.kind === 'audioinput')

      if (audioInputs.length === 0) {
        setVoiceError('No microphone found. Please connect a microphone and refresh the page.')
        return false
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      stream.getTracks().forEach(track => track.stop()) // Stop the stream immediately
      return true
    } catch (error) {
      console.error('Microphone permission denied:', error)

      let errorMessage = ''
      switch (error.name) {
        case 'NotFoundError':
          errorMessage = 'No microphone found. Please connect a microphone and refresh the page.'
          break
        case 'NotAllowedError':
          errorMessage = 'Microphone access denied. Please allow microphone access and refresh the page.'
          break
        case 'NotSupportedError':
          errorMessage = 'Voice control is not supported in this browser.'
          break
        default:
          errorMessage = `Microphone error: ${error.message || error.name}`
      }

      setVoiceError(errorMessage)
      return false
    }
  }

  const initializeVoiceControl = async () => {
    if (!user?.isDisabled) return

    console.log('🎤 Initializing voice control for assignments...')

    // First, request microphone permission
    const hasPermission = await requestMicrophonePermission()
    if (!hasPermission) {
      speak('Microphone access is required for voice control. Please allow access and refresh the page.', true)
      return
    }

    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
      recognitionRef.current = new SpeechRecognition()

      recognitionRef.current.continuous = true
      recognitionRef.current.interimResults = true
      recognitionRef.current.lang = 'en-US'

      recognitionRef.current.onstart = () => {
        setIsListening(true)
        setVoiceError('')
        setDebugInfo('Voice recognition active')
      }

      recognitionRef.current.onresult = (event) => {
        let interimText = ''
        let finalText = ''

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript
          if (event.results[i].isFinal) {
            finalText += transcript
          } else {
            interimText += transcript
          }
        }

        setInterimTranscript(interimText)
        if (finalText) {
          setFinalTranscript(finalText)
          processVoiceCommand(finalText.toLowerCase().trim())
        }
      }

      recognitionRef.current.onerror = (event) => {
        console.error('Voice recognition error:', event.error)

        let errorMessage = ''
        switch (event.error) {
          case 'not-allowed':
            errorMessage = 'Microphone access denied. Please allow microphone access in your browser settings and refresh the page.'
            break
          case 'no-speech':
            errorMessage = 'No speech detected. Please try speaking again.'
            break
          case 'audio-capture':
            errorMessage = 'No microphone found. Please check your microphone connection.'
            break
          case 'network':
            errorMessage = 'Network error. Please check your internet connection.'
            break
          default:
            errorMessage = `Voice error: ${event.error}`
        }

        setVoiceError(errorMessage)
        if (event.error !== 'no-speech') {
          setIsListening(false)
        }

        // Show user-friendly message for permission issues
        if (event.error === 'not-allowed') {
          speak('Microphone access is required for voice control. Please allow microphone access in your browser and refresh the page.', true)
        }
      }

      recognitionRef.current.onend = () => {
        setIsListening(false)
        if (!manuallyStoppedRef.current && user?.isDisabled) {
          setTimeout(() => startListening(), 2000)
        }
      }

      setSpeechSupported(true)
      synthRef.current = window.speechSynthesis

      // Auto-start voice control
      setTimeout(() => startListening(), 1000)
    } else {
      setVoiceError('Voice control not supported in this browser')
    }
  }

  const startListening = () => {
    if (!recognitionRef.current || isListening) return

    manuallyStoppedRef.current = false
    try {
      recognitionRef.current.start()
    } catch (error) {
      console.error('Error starting voice recognition:', error)
    }
  }

  const stopListening = () => {
    manuallyStoppedRef.current = true
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop()
    }
  }

  const processVoiceCommand = (command) => {
    console.log('🎤 Voice command received:', command)
    setDebugInfo(`Command: ${command}`)

    // Help commands
    if (command.includes('help') || command.includes('commands')) {
      speak(`Voice commands available: Say "start quiz" followed by a number to begin a quiz. Say "next assignment" or "previous assignment" to navigate. Say "read assignments" to hear all available assignments. Say "stop listening" to turn off voice control.`, true)
      return
    }

    // Stop commands
    if (command.includes('stop listening') || command.includes('turn off voice')) {
      speak('Voice control stopped. Click the microphone button to restart.', true)
      stopListening()
      return
    }

    if (command.includes('stop speaking') || command.includes('quiet') || command.includes('silence')) {
      synthRef.current.cancel()
      speechQueueRef.current = []
      speechProcessingRef.current = false
      setIsSpeaking(false)
      return
    }

    // Navigation commands
    if (command.includes('next assignment') || command.includes('next')) {
      const filteredAssignments = getFilteredAssignments()
      if (currentFocus < filteredAssignments.length - 1) {
        const newFocus = currentFocus + 1
        setCurrentFocus(newFocus)
        const assignment = filteredAssignments[newFocus]
        const quizTitle = assignment.quiz?.title || 'Untitled Quiz'
        const classroomName = assignment.classroom?.name || 'Unknown Classroom'
        const status = getAssignmentStatus(assignment)
        const questionCount = assignment.quiz?.questions?.length || 0

        let announcement = `Assignment ${newFocus + 1}: ${quizTitle} from ${classroomName}. Status: ${status.label}. `
        if (questionCount > 0) {
          announcement += `${questionCount} questions. `
        }
        announcement += `Say "start quiz ${newFocus + 1}" to begin, or "current assignment" for more details.`

        speak(announcement)
      } else {
        speak('This is the last assignment.')
      }
      return
    }

    if (command.includes('previous assignment') || command.includes('previous') || command.includes('back')) {
      if (currentFocus > 0) {
        const newFocus = currentFocus - 1
        setCurrentFocus(newFocus)
        const filteredAssignments = getFilteredAssignments()
        const assignment = filteredAssignments[newFocus]
        const quizTitle = assignment.quiz?.title || 'Untitled Quiz'
        const classroomName = assignment.classroom?.name || 'Unknown Classroom'
        const status = getAssignmentStatus(assignment)
        const questionCount = assignment.quiz?.questions?.length || 0

        let announcement = `Assignment ${newFocus + 1}: ${quizTitle} from ${classroomName}. Status: ${status.label}. `
        if (questionCount > 0) {
          announcement += `${questionCount} questions. `
        }
        announcement += `Say "start quiz ${newFocus + 1}" to begin, or "current assignment" for more details.`

        speak(announcement)
      } else {
        speak('This is the first assignment.')
      }
      return
    }

    // Read assignments
    if (command.includes('read assignments') || command.includes('list assignments')) {
      const filteredAssignments = getFilteredAssignments()
      if (filteredAssignments.length === 0) {
        speak('No assignments available.')
        return
      }

      let text = `You have ${filteredAssignments.length} assignments. `
      filteredAssignments.forEach((assignment, index) => {
        const status = getAssignmentStatus(assignment)
        text += `Assignment ${index + 1}: ${assignment.quiz?.title || 'Untitled quiz'}, Status: ${status.label}. `
      })
      text += 'Say "start quiz" followed by a number to begin any quiz.'
      speak(text, true)
      return
    }

    // Start quiz commands
    if (command.includes('start quiz')) {
      const numbers = command.match(/\d+/)
      if (numbers) {
        const quizIndex = parseInt(numbers[0]) - 1
        const filteredAssignments = getFilteredAssignments()
        if (quizIndex >= 0 && quizIndex < filteredAssignments.length) {
          const assignment = filteredAssignments[quizIndex]
          const status = getAssignmentStatus(assignment)

          if (status.status === 'completed') {
            speak(`Assignment ${quizIndex + 1} is already completed. Would you like to retake it? Say "yes retake" to continue.`)
            return
          }

          const quizTitle = assignment.quiz?.title || 'Untitled Quiz'
          const questionCount = assignment.quiz?.questions?.length || 0
          const timeLimit = assignment.settings?.timeLimit || 'unlimited'

          let announcement = `Starting quiz: ${quizTitle}. `
          if (questionCount > 0) {
            announcement += `This quiz has ${questionCount} questions. `
          }
          if (timeLimit !== 'unlimited') {
            announcement += `Time limit: ${timeLimit} minutes. `
          }
          announcement += `You have full voice control. You can say "next question", "previous question", "select option A", "submit quiz", and other commands during the quiz. The quiz will start in 3 seconds.`

          speak(announcement, true)

          setTimeout(() => {
            handleStartQuiz(assignment, 'voice')
          }, 4000)
        } else {
          speak('Quiz number not found. Please try again with a valid number.')
        }
      } else {
        speak('Please specify a quiz number. For example, say "start quiz 1".')
      }
      return
    }

    // Retake confirmation
    if (command.includes('yes retake') || command.includes('retake yes')) {
      const filteredAssignments = getFilteredAssignments()
      const assignment = filteredAssignments[currentFocus]
      if (assignment) {
        const quizTitle = assignment.quiz?.title || 'Untitled Quiz'
        const questionCount = assignment.quiz?.questions?.length || 0

        let announcement = `Retaking quiz: ${quizTitle}. `
        if (questionCount > 0) {
          announcement += `This quiz has ${questionCount} questions. `
        }
        announcement += `Starting with full voice control in 2 seconds.`

        speak(announcement, true)
        setTimeout(() => {
          handleStartQuiz(assignment, 'voice')
        }, 3000)
      }
      return
    }

    // Current assignment info
    if (command.includes('current assignment') || command.includes('this assignment')) {
      const filteredAssignments = getFilteredAssignments()
      const assignment = filteredAssignments[currentFocus]
      if (assignment) {
        const status = getAssignmentStatus(assignment)
        const dueDate = assignment.settings?.dueDate ? new Date(assignment.settings.dueDate) : null
        const quizTitle = assignment.quiz?.title || 'Untitled Quiz'
        const classroomName = assignment.classroom?.name || 'Unknown Classroom'

        let info = `Current assignment: ${quizTitle} from ${classroomName}. Status: ${status.label}. `

        if (assignment.quiz?.description) {
          info += `Description: ${assignment.quiz.description}. `
        }

        if (assignment.quiz?.questions) {
          info += `This quiz contains ${assignment.quiz.questions.length} questions. `
        }

        if (assignment.settings?.timeLimit) {
          info += `Time limit: ${assignment.settings.timeLimit} minutes. `
        }

        if (dueDate) {
          info += `Due date: ${dueDate.toLocaleDateString()} at ${dueDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}. `
        }

        if (status.status === 'completed') {
          info += `You have already completed this quiz. Say "yes retake" if you want to retake it.`
        } else {
          info += `Say "start quiz ${currentFocus + 1}" to begin this quiz with voice control.`
        }

        speak(info, true)
      }
      return
    }

    // Unknown command
    speak('Command not recognized. Say "help" for available commands.')
  }

  useEffect(() => {
    console.log('🎯 StudentAssignments component mounted, fetching assignments...')
    dispatch(fetchStudentAssignments())

    // Initialize voice control for disabled users
    if (user?.isDisabled) {
      initializeVoiceControl()
    }

    return () => {
      // Cleanup
      if (recognitionRef.current) {
        recognitionRef.current.stop()
      }
      if (synthRef.current) {
        synthRef.current.cancel()
      }
      if (restartTimeoutRef.current) {
        clearTimeout(restartTimeoutRef.current)
      }
    }
  }, [dispatch, user?.isDisabled])

  // Announce assignments when they load for disabled users
  useEffect(() => {
    if (user?.isDisabled && !assignmentsLoading && assignments.length > 0 && speechSupported) {
      setTimeout(() => {
        const filteredAssignments = getFilteredAssignments()
        const pendingCount = filteredAssignments.filter(a => getAssignmentStatus(a).status === 'pending').length
        const completedCount = filteredAssignments.filter(a => getAssignmentStatus(a).status === 'completed').length

        if (filteredAssignments.length > 0) {
          speak(`Welcome to your accessible quiz center. You have ${filteredAssignments.length} total assignments. ${pendingCount} pending and ${completedCount} completed. Currently focused on assignment 1. Say "help" for voice commands, "start quiz 1" to begin the first quiz, or "read assignments" to hear all assignments.`, true)
        } else {
          speak('Welcome to your accessible quiz center. No assignments are currently available. Please contact your instructor.', true)
        }
      }, 3000) // Delay to ensure voice control is ready
    }
  }, [assignmentsLoading, assignments, user?.isDisabled, speechSupported])

  const getAssignmentStatus = (assignment) => {
    const now = new Date()
    const dueDate = assignment.settings?.dueDate ? new Date(assignment.settings.dueDate) : null
    const hasSubmissions = assignment.quiz?.submissions && assignment.quiz.submissions.length > 0

    if (hasSubmissions) {
      return {
        status: 'completed',
        label: 'Completed',
        color: 'text-green-700',
        bg: 'bg-green-100',
        icon: 'CheckCircle',
        borderColor: 'border-green-200'
      }
    }

    if (dueDate && now > dueDate) {
      return {
        status: 'overdue',
        label: 'Overdue',
        color: 'text-red-700',
        bg: 'bg-red-100',
        icon: 'AlertCircle',
        borderColor: 'border-red-200'
      }
    }

    if (assignment.status === 'active') {
      return {
        status: 'pending',
        label: 'Pending',
        color: 'text-blue-700',
        bg: 'bg-blue-100',
        icon: 'Clock',
        borderColor: 'border-blue-200'
      }
    }

    return {
      status: 'inactive',
      label: 'Inactive',
      color: 'text-gray-700',
      bg: 'bg-gray-100',
      icon: 'Clock',
      borderColor: 'border-gray-200'
    }
  }

  const getFilteredAssignments = () => {
    if (filter === 'all') return assignments
    return assignments.filter(assignment => {
      const status = getAssignmentStatus(assignment)
      return status.status === filter
    })
  }

  const handleStartQuiz = (assignment, mode = 'regular') => {
    const searchParams = new URLSearchParams()
    if (mode === 'voice') {
      searchParams.set('mode', 'voice')
    }
    const url = `/student/quiz/${assignment._id}${searchParams.toString() ? '?' + searchParams.toString() : ''}`
    navigate(url)
  }



  if (assignmentsLoading) {
    return (
      <div className={`min-h-screen ${theme.colors.bg.secondary}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex justify-center items-center h-64">
            <div className="text-center">
              <Loader size="lg" />
              <p className={`mt-4 text-lg ${theme.colors.text.secondary}`}>Loading your assignments...</p>
            </div>
          </div>
        </div>
      </div>
    )
  }

  const filteredAssignments = getFilteredAssignments()

  return (
    <div className={`min-h-screen ${theme.colors.bg.secondary}`}>
      {/* Header */}
      <div className={`${theme.colors.bg.card} ${theme.shadows.sm} border-b ${theme.colors.border.primary}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              {!user?.isDisabled && (
                <Button
                  onClick={() => navigate('/student/dashboard')}
                  className={`${theme.colors.button.secondary} p-2 rounded-lg`}
                >
                  <ArrowLeft className="w-5 h-5" />
                </Button>
              )}
              <div>
                <h1 className={`text-3xl font-bold ${theme.colors.text.primary}`}>
                  {user?.isDisabled ? '♿ Accessible Quiz Center' : 'My Assignments'}
                </h1>
                <p className={`${theme.colors.text.secondary}`}>
                  {user?.isDisabled
                    ? '🎯 Your personalized quiz experience with full accessibility support'
                    : 'Complete your quiz assignments to track progress'
                  }
                </p>
                {user?.isDisabled && (
                  <div className="mt-2 flex items-center space-x-2 text-sm text-purple-600 dark:text-purple-400">
                    <Mic className="w-4 h-4" />
                    <span>Voice control ready • Audio feedback enabled • Extended time available</span>
                  </div>
                )}
              </div>
            </div>

            {/* Voice Control Panel for Disabled Users */}
            {user?.isDisabled && (
              <div className="flex items-center space-x-4">
                {!voiceError ? (
                  <>
                    {/* Voice Status Indicator */}
                    <div className={`flex items-center space-x-2 px-4 py-2 rounded-xl border-2 transition-all ${
                      isListening
                        ? 'bg-green-50 border-green-300 text-green-800 dark:bg-green-900/20 dark:border-green-600 dark:text-green-300'
                        : 'bg-gray-50 border-gray-300 text-gray-600 dark:bg-gray-800 dark:border-gray-600 dark:text-gray-400'
                    }`}>
                      <div className={`w-3 h-3 rounded-full ${isListening ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`}></div>
                      <Mic className="w-4 h-4" />
                      <div className="flex flex-col">
                        <span className="text-sm font-medium">
                          {isSpeaking ? '🗣️ Speaking...' : isListening ? '👂 Listening...' : '🎤 Voice Ready'}
                        </span>
                        {isListening && interimTranscript && !isSpeaking && (
                          <span className="text-xs opacity-70 max-w-32 truncate">
                            "{interimTranscript}"
                          </span>
                        )}
                        {isSpeaking && (
                          <span className="text-xs opacity-70 text-blue-600">
                            Say "stop speaking" to interrupt
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Voice Control Buttons */}
                    <Button
                      onClick={isListening ? stopListening : startListening}
                      className={`px-4 py-2 rounded-xl font-medium transition-all ${
                        isListening
                          ? 'bg-red-600 hover:bg-red-700 text-white'
                          : 'bg-green-600 hover:bg-green-700 text-white'
                      }`}
                    >
                      {isListening ? '🛑 Stop Voice' : '🎤 Start Voice'}
                    </Button>

                    <Button
                      onClick={() => speak('Voice commands: Say "help" for all commands, "start quiz" with a number to begin, "next assignment" or "previous assignment" to navigate, "read assignments" to hear all assignments.', true)}
                      className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl font-medium"
                    >
                      📋 Help
                    </Button>
                  </>
                ) : (
                  /* Error State with Continue Option */
                  <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700 rounded-lg p-4 w-full">
                    <div className="flex items-start space-x-3">
                      <div className="text-red-600 text-sm flex-1">
                        <strong>Voice Control Error:</strong>
                        <br />
                        {voiceError}
                      </div>
                    </div>

                    {/* Continue without voice option */}
                    <div className="mt-3 p-3 bg-gray-50 dark:bg-gray-800 rounded border">
                      <p className="text-sm text-gray-700 dark:text-gray-300 font-medium mb-2">
                        ♿ Continue with Accessibility Features:
                      </p>
                      <p className="text-xs text-gray-600 dark:text-gray-400 mb-2">
                        You can still use the quiz system with keyboard navigation and screen reader support.
                      </p>
                      <Button
                        onClick={() => setVoiceError('')}
                        className="px-3 py-1 bg-purple-600 hover:bg-purple-700 text-white rounded text-sm"
                      >
                        ♿ Continue without Voice
                      </Button>
                    </div>

                    {voiceError.includes('Microphone access denied') && (
                      <div className="mt-3 p-3 bg-blue-50 dark:bg-blue-900/20 rounded border border-blue-200 dark:border-blue-700">
                        <p className="text-sm text-blue-800 dark:text-blue-200 font-medium mb-2">
                          📋 How to Enable Microphone Access:
                        </p>
                        <ol className="text-xs text-blue-700 dark:text-blue-300 space-y-1 ml-4">
                          <li>1. Click the 🔒 lock icon or 🎤 microphone icon in your browser's address bar</li>
                          <li>2. Set "Microphone" to "Allow"</li>
                          <li>3. Refresh this page</li>
                          <li>4. Click "Start Voice" again</li>
                        </ol>
                        <Button
                          onClick={() => window.location.reload()}
                          className="mt-2 px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded text-sm"
                        >
                          🔄 Refresh Page
                        </Button>
                      </div>
                    )}

                    {voiceError.includes('No microphone found') && (
                      <div className="mt-3 p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded border border-yellow-200 dark:border-yellow-700">
                        <p className="text-sm text-yellow-800 dark:text-yellow-200 font-medium mb-2">
                          🎤 No Microphone Detected:
                        </p>
                        <ol className="text-xs text-yellow-700 dark:text-yellow-300 space-y-1 ml-4">
                          <li>1. Connect a microphone or headset to your computer</li>
                          <li>2. Make sure it's properly plugged in (USB or 3.5mm jack)</li>
                          <li>3. Check your system's audio settings</li>
                          <li>4. Refresh this page and try again</li>
                        </ol>
                        <Button
                          onClick={() => window.location.reload()}
                          className="mt-2 px-3 py-1 bg-yellow-600 hover:bg-yellow-700 text-white rounded text-sm"
                        >
                          🔄 Refresh Page
                        </Button>
                      </div>
                    )}

                    {voiceError.includes('not supported') && (
                      <div className="mt-3 p-3 bg-orange-50 dark:bg-orange-900/20 rounded border border-orange-200 dark:border-orange-700">
                        <p className="text-sm text-orange-800 dark:text-orange-200 font-medium mb-2">
                          🌐 Browser Not Supported:
                        </p>
                        <p className="text-xs text-orange-700 dark:text-orange-300 mb-2">
                          Voice control requires a modern browser. Please use:
                        </p>
                        <ul className="text-xs text-orange-700 dark:text-orange-300 space-y-1 ml-4">
                          <li>• Google Chrome (recommended)</li>
                          <li>• Microsoft Edge</li>
                          <li>• Mozilla Firefox</li>
                        </ul>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Assignment Grid */}
        {filteredAssignments.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredAssignments.map((assignment, index) => {
              const status = getAssignmentStatus(assignment)
              const hasSubmission = assignment.quiz?.submissions && assignment.quiz.submissions.length > 0
              const dueDate = assignment.settings?.dueDate ? new Date(assignment.settings.dueDate) : null
              const StatusIcon = status.icon === 'CheckCircle' ? Award :
                                 status.icon === 'AlertCircle' ? Target :
                                 status.icon === 'Clock' ? Calendar : BookOpen
              const isCurrentFocus = user?.isDisabled && currentFocus === index

              return (
                <div
                  key={assignment._id}
                  className={`${theme.colors.bg.card} rounded-2xl ${theme.shadows.lg} border-l-4 ${status.borderColor} hover:shadow-xl transition-all duration-200 group relative ${
                    isCurrentFocus ? 'ring-4 ring-purple-400 ring-opacity-50 bg-purple-50 dark:bg-purple-900/20 scale-105' : ''
                  }`}
                >
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <div className={`p-2 rounded-lg ${status.bg}`}>
                            <StatusIcon className={`w-5 h-5 ${status.color}`} />
                          </div>
                          <div>
                            <h3 className={`text-xl font-bold ${theme.colors.text.primary} group-hover:text-blue-600 transition-colors`}>
                              {assignment.quiz?.title || 'Untitled Quiz'}
                            </h3>
                            <p className={`text-sm ${theme.colors.text.secondary}`}>
                              {assignment.classroom?.name || 'Unknown Classroom'}
                            </p>
                          </div>
                        </div>

                        <div className="space-y-2">
                          {assignment.quiz?.description && (
                            <p className={`text-sm ${theme.colors.text.secondary} line-clamp-2`}>
                              {assignment.quiz.description}
                            </p>
                          )}

                          <div className="flex flex-wrap gap-4 text-sm">
                            {assignment.quiz?.questions && (
                              <div className="flex items-center space-x-1">
                                <BookOpen className="w-4 h-4 text-blue-500" />
                                <span className={theme.colors.text.secondary}>
                                  {assignment.quiz.questions.length} questions
                                </span>
                              </div>
                            )}

                            {assignment.settings?.timeLimit && (
                              <div className="flex items-center space-x-1">
                                <Calendar className="w-4 h-4 text-orange-500" />
                                <span className={theme.colors.text.secondary}>
                                  {assignment.settings.timeLimit} minutes
                                </span>
                              </div>
                            )}
                          </div>

                          {dueDate && (
                            <div className="flex items-center space-x-1 text-sm">
                              <Calendar className="w-4 h-4 text-red-500" />
                              <span className={theme.colors.text.secondary}>
                                Due: {dueDate.toLocaleDateString()} at {dueDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className={`px-3 py-1 rounded-full text-xs font-medium ${status.bg} ${status.color} border ${status.borderColor}`}>
                        {status.label}
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-700">
                      <div className="flex space-x-3">
                        {!hasSubmission ? (
                          <>
                            <Button
                              onClick={() => handleStartQuiz(assignment, 'regular')}
                              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium flex items-center space-x-2"
                            >
                              <Play className="w-4 h-4" />
                              <span>Start Quiz</span>
                            </Button>

                            {user?.isDisabled && (
                              <Button
                                onClick={() => handleStartQuiz(assignment, 'voice')}
                                className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg font-medium flex items-center space-x-2"
                              >
                                <Target className="w-4 h-4" />
                                <span>Voice Mode</span>
                              </Button>
                            )}
                          </>
                        ) : (
                          <div className="flex items-center space-x-2 text-green-600">
                            <Award className="w-5 h-5" />
                            <span className="font-medium">Completed</span>
                            {user?.isDisabled && (
                              <span className="text-sm text-gray-500">(Say "yes retake" to redo)</span>
                            )}
                          </div>
                        )}
                      </div>

                      {/* Voice Navigation Indicator */}
                      {user?.isDisabled && isCurrentFocus && (
                        <div className="flex items-center space-x-2 text-purple-600 bg-purple-100 dark:bg-purple-900/30 px-3 py-1 rounded-lg">
                          <Target className="w-4 h-4" />
                          <span className="text-sm font-medium">Assignment {index + 1}</span>
                        </div>
                      )}
                    </div>

                    {/* Voice Instructions for Current Focus */}
                    {user?.isDisabled && isCurrentFocus && (
                      <div className="mt-4 p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg border border-purple-200 dark:border-purple-700">
                        <p className="text-sm text-purple-800 dark:text-purple-200">
                          🎤 <strong>Voice Commands:</strong> Say "start quiz {index + 1}" to begin this assignment with full voice control,
                          "next assignment" or "previous assignment" to navigate, or "current assignment" for details.
                        </p>
                        {!hasSubmission && (
                          <p className="text-xs text-purple-600 dark:text-purple-300 mt-1">
                            During quiz: "next question", "previous question", "select option A/B/C/D", "submit quiz"
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        ) : (
          <div className="text-center py-12">
            <BookOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className={`text-lg font-medium ${theme.colors.text.primary} mb-2`}>
              No Assignments Yet
            </h3>
            <p className={`text-sm ${theme.colors.text.secondary}`}>
              Your assignments will appear here once your instructor creates them.
            </p>
          </div>
        )}

        {/* Voice Debug Panel for Disabled Users */}
        {user?.isDisabled && (debugInfo || finalTranscript || voiceError) && (
          <div className="mt-8 p-4 bg-gray-100 dark:bg-gray-800 rounded-lg">
            <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Voice Control Debug</h3>
            <div className="space-y-2 text-xs">
              {debugInfo && (
                <div className="text-blue-600 dark:text-blue-400">
                  <strong>Status:</strong> {debugInfo}
                </div>
              )}
              {finalTranscript && (
                <div className="text-green-600 dark:text-green-400">
                  <strong>Last Command:</strong> "{finalTranscript}"
                </div>
              )}
              {interimTranscript && (
                <div className="text-yellow-600 dark:text-yellow-400">
                  <strong>Listening:</strong> "{interimTranscript}"
                </div>
              )}
              {voiceError && (
                <div className="text-red-600 dark:text-red-400">
                  <strong>Error:</strong> {voiceError}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Voice Commands Reference for Disabled Users */}
        {user?.isDisabled && (
          <div className="mt-8 p-6 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-700">
            <h3 className="text-lg font-medium text-blue-800 dark:text-blue-200 mb-4">🎤 Voice Commands Reference</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <h4 className="font-medium text-blue-700 dark:text-blue-300 mb-2">Navigation Commands:</h4>
                <ul className="space-y-1 text-blue-600 dark:text-blue-400">
                  <li>• "next assignment" - Move to next assignment</li>
                  <li>• "previous assignment" - Move to previous assignment</li>
                  <li>• "current assignment" - Get current assignment details</li>
                  <li>• "read assignments" - List all assignments</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium text-blue-700 dark:text-blue-300 mb-2">Quiz Commands:</h4>
                <ul className="space-y-1 text-blue-600 dark:text-blue-400">
                  <li>• "start quiz [number]" - Start specific quiz</li>
                  <li>• "yes retake" - Retake completed quiz</li>
                  <li>• "help" - Get voice commands help</li>
                  <li>• "stop listening" - Turn off voice control</li>
                </ul>
              </div>
            </div>
            <div className="mt-4 p-3 bg-blue-100 dark:bg-blue-800/30 rounded">
              <p className="text-sm text-blue-700 dark:text-blue-300">
                <strong>During Quiz:</strong> You can use "next question", "previous question", "select option A/B/C/D", "submit quiz", and more commands for complete voice control.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default StudentAssignments