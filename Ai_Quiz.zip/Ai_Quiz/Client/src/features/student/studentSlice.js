import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'

// Async thunks for API calls
export const fetchStudentProgress = createAsyncThunk(
  'student/fetchProgress',
  async (studentId, { rejectWithValue }) => {
    try {
      const response = await fetch(`/api/student/${studentId}/progress`)
      const data = await response.json()
      return data
    } catch (error) {
      return rejectWithValue(error.message)
    }
  }
)

export const updateStreak = createAsyncThunk(
  'student/updateStreak',
  async ({ studentId, quizCompleted }, { rejectWithValue }) => {
    try {
      const response = await fetch(`/api/student/${studentId}/streak`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ quizCompleted })
      })
      const data = await response.json()
      return data
    } catch (error) {
      return rejectWithValue(error.message)
    }
  }
)

const initialState = {
  // Profile Info
  profile: {
    id: null,
    name: '',
    email: '',
    avatar: '',
    grade: '',
    school: '',
    joinDate: null,
  },
  
  // Progress Tracking
  progress: {
    totalQuizzes: 0,
    completedQuizzes: 0,
    averageScore: 0,
    totalTimeSpent: 0, // in minutes
    strongSubjects: [],
    weakSubjects: [],
    improvementAreas: [],
  },
  
  // Streaks & Motivation
  streaks: {
    currentStreak: 0,
    longestStreak: 0,
    lastQuizDate: null,
    dailyGoal: 3, // quizzes per day
    weeklyGoal: 15,
    monthlyGoal: 60,
  },
  
  // Rewards System
  rewards: {
    totalCoins: 0,
    badges: [],
    rank: 'Beginner',
    level: 1,
    xp: 0,
    nextLevelXP: 100,
  },
  
  // Learning History
  quizHistory: [],
  recentActivity: [],
  bookmarkedQuestions: [],
  
  // Goals & Achievements
  goals: {
    daily: { target: 3, completed: 0, streak: 0 },
    weekly: { target: 15, completed: 0 },
    monthly: { target: 60, completed: 0 },
    custom: [],
  },
  
  // AI Tutor Chat History
  chatHistory: [],
  
  // Loading states
  loading: false,
  error: null,
}

const studentSlice = createSlice({
  name: 'student',
  initialState,
  reducers: {
    setProfile: (state, action) => {
      state.profile = { ...state.profile, ...action.payload }
    },
    
    updateProgress: (state, action) => {
      const { score, timeSpent, subject, difficulty } = action.payload
      
      // Update basic stats
      state.progress.completedQuizzes += 1
      state.progress.totalTimeSpent += timeSpent
      
      // Calculate new average score
      const totalScore = state.progress.averageScore * (state.progress.completedQuizzes - 1) + score
      state.progress.averageScore = Math.round(totalScore / state.progress.completedQuizzes)
      
      // Update subject strengths/weaknesses
      if (score >= 80) {
        if (!state.progress.strongSubjects.includes(subject)) {
          state.progress.strongSubjects.push(subject)
        }
        // Remove from weak subjects if present
        state.progress.weakSubjects = state.progress.weakSubjects.filter(s => s !== subject)
      } else if (score < 60) {
        if (!state.progress.weakSubjects.includes(subject)) {
          state.progress.weakSubjects.push(subject)
        }
      }
    },
    
    addQuizToHistory: (state, action) => {
      const quiz = {
        ...action.payload,
        completedAt: new Date().toISOString(),
      }
      state.quizHistory.unshift(quiz)
      
      // Keep only last 50 quizzes
      if (state.quizHistory.length > 50) {
        state.quizHistory = state.quizHistory.slice(0, 50)
      }
    },
    
    updateStreaks: (state, action) => {
      const today = new Date().toDateString()
      const lastQuizDate = state.streaks.lastQuizDate
      
      if (lastQuizDate !== today) {
        const yesterday = new Date()
        yesterday.setDate(yesterday.getDate() - 1)
        
        if (lastQuizDate === yesterday.toDateString()) {
          // Continue streak
          state.streaks.currentStreak += 1
        } else {
          // Reset streak
          state.streaks.currentStreak = 1
        }
        
        state.streaks.lastQuizDate = today
        
        // Update longest streak
        if (state.streaks.currentStreak > state.streaks.longestStreak) {
          state.streaks.longestStreak = state.streaks.currentStreak
        }
      }
    },
    
    addReward: (state, action) => {
      const { type, amount, reason } = action.payload
      
      if (type === 'coins') {
        state.rewards.totalCoins += amount
      } else if (type === 'xp') {
        state.rewards.xp += amount
        
        // Check for level up
        while (state.rewards.xp >= state.rewards.nextLevelXP) {
          state.rewards.level += 1
          state.rewards.xp -= state.rewards.nextLevelXP
          state.rewards.nextLevelXP = Math.floor(state.rewards.nextLevelXP * 1.5)
          
          // Add level up reward
          state.rewards.totalCoins += state.rewards.level * 10
        }
      }
      
      // Add to recent activity
      state.recentActivity.unshift({
        type: 'reward',
        message: `Earned ${amount} ${type} for ${reason}`,
        timestamp: new Date().toISOString(),
      })
    },
    
    addBadge: (state, action) => {
      const badge = {
        ...action.payload,
        earnedAt: new Date().toISOString(),
      }
      state.rewards.badges.push(badge)
      
      state.recentActivity.unshift({
        type: 'badge',
        message: `Earned badge: ${badge.name}`,
        timestamp: new Date().toISOString(),
      })
    },
    
    updateGoals: (state, action) => {
      const { period, increment = 1 } = action.payload
      
      if (period === 'daily') {
        state.goals.daily.completed += increment
        if (state.goals.daily.completed >= state.goals.daily.target) {
          state.goals.daily.streak += 1
        }
      } else if (period === 'weekly') {
        state.goals.weekly.completed += increment
      } else if (period === 'monthly') {
        state.goals.monthly.completed += increment
      }
    },
    
    addChatMessage: (state, action) => {
      state.chatHistory.push({
        ...action.payload,
        timestamp: new Date().toISOString(),
      })
      
      // Keep only last 100 messages
      if (state.chatHistory.length > 100) {
        state.chatHistory = state.chatHistory.slice(-100)
      }
    },
    
    bookmarkQuestion: (state, action) => {
      const question = action.payload
      const exists = state.bookmarkedQuestions.find(q => q.id === question.id)
      
      if (!exists) {
        state.bookmarkedQuestions.push(question)
      }
    },
    
    removeBookmark: (state, action) => {
      const questionId = action.payload
      state.bookmarkedQuestions = state.bookmarkedQuestions.filter(q => q.id !== questionId)
    },
    
    resetDailyGoals: (state) => {
      state.goals.daily.completed = 0
    },
    
    resetWeeklyGoals: (state) => {
      state.goals.weekly.completed = 0
    },
    
    resetMonthlyGoals: (state) => {
      state.goals.monthly.completed = 0
    },
    
    clearError: (state) => {
      state.error = null
    },
  },
  
  extraReducers: (builder) => {
    builder
      .addCase(fetchStudentProgress.pending, (state) => {
        state.loading = true
        state.error = null
      })
      .addCase(fetchStudentProgress.fulfilled, (state, action) => {
        state.loading = false
        state.progress = action.payload.progress
        state.streaks = action.payload.streaks
        state.rewards = action.payload.rewards
        state.goals = action.payload.goals
      })
      .addCase(fetchStudentProgress.rejected, (state, action) => {
        state.loading = false
        state.error = action.payload
      })
      .addCase(updateStreak.fulfilled, (state, action) => {
        state.streaks = action.payload
      })
  },
})

export const {
  setProfile,
  updateProgress,
  addQuizToHistory,
  updateStreaks,
  addReward,
  addBadge,
  updateGoals,
  addChatMessage,
  bookmarkQuestion,
  removeBookmark,
  resetDailyGoals,
  resetWeeklyGoals,
  resetMonthlyGoals,
  clearError,
} = studentSlice.actions

export default studentSlice.reducer