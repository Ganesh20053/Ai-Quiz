import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { selectUser } from '../auth/authSlice';
import { logoutUser } from '../auth/authSlice';
import { useTheme } from '../../contexts/ThemeContext';
import Button from '../../components/common/Button';
import { User, Mail, Calendar, BookOpen, Settings, LogOut, ArrowLeft, Edit3, Save, X } from 'lucide-react';

const StudentProfile = () => {
  const user = useSelector(selectUser);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const theme = useTheme();

  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({
    name: user?.name || '',
    email: user?.email || '',
    grade: user?.grade || ''
  });

  const handleEditToggle = () => {
    if (isEditing) {
      // Reset form if canceling
      setEditForm({
        name: user?.name || '',
        email: user?.email || '',
        grade: user?.grade || ''
      });
    }
    setIsEditing(!isEditing);
  };

  const handleSave = async () => {
    // TODO: Implement profile update API call
    console.log('Saving profile:', editForm);
    setIsEditing(false);
    // Show success message
  };

  const handleLogout = async () => {
    try {
      await dispatch(logoutUser()).unwrap();
      navigate('/login');
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditForm(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <div className={`min-h-screen ${theme.colors.bg.secondary}`}>
      {/* Header */}
      <div className={`${theme.colors.bg.card} ${theme.shadows.sm} border-b ${theme.colors.border.primary}`}>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                onClick={() => navigate('/student/dashboard')}
                className={`${theme.colors.button.secondary} p-2 rounded-lg`}
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div>
                <h1 className={`text-2xl font-bold ${theme.colors.text.primary}`}>
                  Student Profile
                </h1>
                <p className={`${theme.colors.text.secondary}`}>
                  Manage your account settings and information
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              {!isEditing ? (
                <Button
                  onClick={handleEditToggle}
                  className={`${theme.colors.button.primary} flex items-center gap-2 px-4 py-2 rounded-lg`}
                >
                  <Edit3 className="w-4 h-4" />
                  Edit Profile
                </Button>
              ) : (
                <div className="flex space-x-2">
                  <Button
                    onClick={handleSave}
                    className="bg-green-600 hover:bg-green-700 text-white flex items-center gap-2 px-4 py-2 rounded-lg"
                  >
                    <Save className="w-4 h-4" />
                    Save
                  </Button>
                  <Button
                    onClick={handleEditToggle}
                    className={`${theme.colors.button.secondary} flex items-center gap-2 px-4 py-2 rounded-lg`}
                  >
                    <X className="w-4 h-4" />
                    Cancel
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Profile Card */}
          <div className="lg:col-span-2">
            <div className={`${theme.colors.bg.card} rounded-2xl ${theme.shadows.lg} p-8`}>
              <div className="flex items-center space-x-6 mb-8">
                <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white text-2xl font-bold">
                  {user?.name ? user.name.split(' ').map(n => n[0]).join('').toUpperCase() : 'S'}
                </div>
                <div>
                  <h2 className={`text-2xl font-bold ${theme.colors.text.primary}`}>
                    {user?.name || 'Student'}
                  </h2>
                  <p className={`${theme.colors.text.secondary}`}>
                    Student Account
                  </p>
                  <div className="flex items-center mt-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    <span className={`text-sm ${theme.colors.text.tertiary}`}>Active</span>
                  </div>
                </div>
              </div>

              {/* Profile Information */}
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className={`block text-sm font-medium ${theme.colors.text.secondary} mb-2`}>
                      Full Name
                    </label>
                    {isEditing ? (
                      <input
                        type="text"
                        name="name"
                        value={editForm.name}
                        onChange={handleInputChange}
                        className={`w-full px-4 py-3 border ${theme.colors.border.primary} rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${theme.colors.bg.tertiary} ${theme.colors.text.primary}`}
                      />
                    ) : (
                      <div className={`flex items-center p-3 ${theme.colors.bg.tertiary} rounded-lg`}>
                        <User className={`w-5 h-5 ${theme.colors.text.tertiary} mr-3`} />
                        <span className={theme.colors.text.primary}>{user?.name || 'Not provided'}</span>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className={`block text-sm font-medium ${theme.colors.text.secondary} mb-2`}>
                      Email Address
                    </label>
                    {isEditing ? (
                      <input
                        type="email"
                        name="email"
                        value={editForm.email}
                        onChange={handleInputChange}
                        className={`w-full px-4 py-3 border ${theme.colors.border.primary} rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${theme.colors.bg.tertiary} ${theme.colors.text.primary}`}
                      />
                    ) : (
                      <div className={`flex items-center p-3 ${theme.colors.bg.tertiary} rounded-lg`}>
                        <Mail className={`w-5 h-5 ${theme.colors.text.tertiary} mr-3`} />
                        <span className={theme.colors.text.primary}>{user?.email || 'Not provided'}</span>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className={`block text-sm font-medium ${theme.colors.text.secondary} mb-2`}>
                      Grade/Class
                    </label>
                    {isEditing ? (
                      <input
                        type="text"
                        name="grade"
                        value={editForm.grade}
                        onChange={handleInputChange}
                        className={`w-full px-4 py-3 border ${theme.colors.border.primary} rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${theme.colors.bg.tertiary} ${theme.colors.text.primary}`}
                      />
                    ) : (
                      <div className={`flex items-center p-3 ${theme.colors.bg.tertiary} rounded-lg`}>
                        <BookOpen className={`w-5 h-5 ${theme.colors.text.tertiary} mr-3`} />
                        <span className={theme.colors.text.primary}>{user?.grade || 'Not assigned'}</span>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className={`block text-sm font-medium ${theme.colors.text.secondary} mb-2`}>
                      Student ID
                    </label>
                    <div className={`flex items-center p-3 ${theme.colors.bg.tertiary} rounded-lg`}>
                      <Calendar className={`w-5 h-5 ${theme.colors.text.tertiary} mr-3`} />
                      <span className={theme.colors.text.primary}>{user?.studentId || 'Not assigned'}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <div className={`${theme.colors.bg.card} rounded-2xl ${theme.shadows.lg} p-6`}>
              <h3 className={`text-lg font-semibold ${theme.colors.text.primary} mb-4`}>
                Quick Actions
              </h3>
              <div className="space-y-3">
                <Button
                  onClick={() => navigate('/student/dashboard')}
                  className={`w-full ${theme.colors.button.secondary} flex items-center gap-3 p-3 rounded-lg text-left`}
                >
                  <BookOpen className="w-5 h-5" />
                  Go to Dashboard
                </Button>
                <Button
                  onClick={() => navigate('/student/assignments')}
                  className={`w-full ${theme.colors.button.secondary} flex items-center gap-3 p-3 rounded-lg text-left`}
                >
                  <Calendar className="w-5 h-5" />
                  View Assignments
                </Button>
                <Button
                  onClick={() => navigate('/student/rewards')}
                  className={`w-full ${theme.colors.button.secondary} flex items-center gap-3 p-3 rounded-lg text-left`}
                >
                  <Settings className="w-5 h-5" />
                  View Rewards
                </Button>
              </div>
            </div>

            {/* Account Actions */}
            <div className={`${theme.colors.bg.card} rounded-2xl ${theme.shadows.lg} p-6`}>
              <h3 className={`text-lg font-semibold ${theme.colors.text.primary} mb-4`}>
                Account
              </h3>
              <div className="space-y-3">
                <Button
                  onClick={handleLogout}
                  className="w-full bg-red-600 hover:bg-red-700 text-white flex items-center gap-3 p-3 rounded-lg text-left"
                >
                  <LogOut className="w-5 h-5" />
                  Sign Out
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentProfile;