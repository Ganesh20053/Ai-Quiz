import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { selectUser } from '../auth/authSlice';
import { useTheme } from '../../contexts/ThemeContext';
import Button from '../../components/common/Button';
import { Trophy, Star, Award, Gift, ArrowLeft, Crown, Target, Zap } from 'lucide-react';

const StudentRewards = () => {
  const user = useSelector(selectUser);
  const navigate = useNavigate();
  const theme = useTheme();

  // Mock data - in real app, this would come from API
  const [rewards, setRewards] = useState({
    totalPoints: 1250,
    level: 5,
    nextLevelPoints: 1500,
    badges: [
      { id: 1, name: 'First Quiz', description: 'Completed your first quiz', icon: '🎯', earned: true, date: '2024-01-15' },
      { id: 2, name: 'Perfect Score', description: 'Got 100% on a quiz', icon: '⭐', earned: true, date: '2024-01-20' },
      { id: 3, name: 'Speed Demon', description: 'Completed a quiz in under 5 minutes', icon: '⚡', earned: true, date: '2024-01-25' },
      { id: 4, name: 'Consistent Learner', description: 'Completed quizzes for 7 days straight', icon: '📚', earned: false },
      { id: 5, name: 'Quiz Master', description: 'Completed 50 quizzes', icon: '👑', earned: false },
      { id: 6, name: 'High Achiever', description: 'Maintain 90%+ average for a month', icon: '🏆', earned: false }
    ],
    achievements: [
      { id: 1, title: 'Mathematics Wizard', subject: 'Mathematics', points: 150, completed: true },
      { id: 2, title: 'Science Explorer', subject: 'Science', points: 120, completed: true },
      { id: 3, title: 'History Buff', subject: 'History', points: 100, completed: false },
      { id: 4, title: 'Language Master', subject: 'English', points: 200, completed: false }
    ]
  });

  const progressToNextLevel = ((rewards.totalPoints % 300) / 300) * 100;

  return (
    <div className={`min-h-screen ${theme.colors.bg.secondary}`}>
      {/* Header */}
      <div className={`${theme.colors.bg.card} ${theme.shadows.sm} border-b ${theme.colors.border.primary}`}>
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                onClick={() => navigate('/student/dashboard')}
                className={`${theme.colors.button.secondary} p-2 rounded-lg`}
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div>
                <h1 className={`text-2xl font-bold ${theme.colors.text.primary}`}>
                  Rewards & Achievements
                </h1>
                <p className={`${theme.colors.text.secondary}`}>
                  Track your progress and celebrate your accomplishments
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* Total Points */}
          <div className={`${theme.colors.bg.card} rounded-2xl ${theme.shadows.lg} p-6`}>
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-xl">
                <Star className="w-6 h-6 text-white" />
              </div>
              <span className={`text-2xl font-bold ${theme.colors.text.primary}`}>
                {rewards.totalPoints}
              </span>
            </div>
            <h3 className={`font-semibold ${theme.colors.text.primary} mb-1`}>Total Points</h3>
            <p className={`text-sm ${theme.colors.text.secondary}`}>Keep learning to earn more!</p>
          </div>

          {/* Current Level */}
          <div className={`${theme.colors.bg.card} rounded-2xl ${theme.shadows.lg} p-6`}>
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-xl">
                <Crown className="w-6 h-6 text-white" />
              </div>
              <span className={`text-2xl font-bold ${theme.colors.text.primary}`}>
                Level {rewards.level}
              </span>
            </div>
            <h3 className={`font-semibold ${theme.colors.text.primary} mb-1`}>Current Level</h3>
            <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
              <div
                className="bg-gradient-to-r from-purple-500 to-indigo-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${progressToNextLevel}%` }}
              ></div>
            </div>
            <p className={`text-xs ${theme.colors.text.secondary}`}>
              {250 - (rewards.totalPoints % 300)} points to Level {rewards.level + 1}
            </p>
          </div>

          {/* Badges Earned */}
          <div className={`${theme.colors.bg.card} rounded-2xl ${theme.shadows.lg} p-6`}>
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl">
                <Award className="w-6 h-6 text-white" />
              </div>
              <span className={`text-2xl font-bold ${theme.colors.text.primary}`}>
                {rewards.badges.filter(b => b.earned).length}
              </span>
            </div>
            <h3 className={`font-semibold ${theme.colors.text.primary} mb-1`}>Badges Earned</h3>
            <p className={`text-sm ${theme.colors.text.secondary}`}>
              {rewards.badges.filter(b => !b.earned).length} more to unlock
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Badges Section */}
          <div className={`${theme.colors.bg.card} rounded-2xl ${theme.shadows.lg} p-6`}>
            <div className="flex items-center justify-between mb-6">
              <h2 className={`text-xl font-bold ${theme.colors.text.primary}`}>Badges</h2>
              <div className="flex items-center space-x-2">
                <Trophy className={`w-5 h-5 ${theme.colors.text.secondary}`} />
                <span className={`text-sm ${theme.colors.text.secondary}`}>
                  {rewards.badges.filter(b => b.earned).length}/{rewards.badges.length}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {rewards.badges.map((badge) => (
                <div
                  key={badge.id}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    badge.earned
                      ? `${theme.colors.border.primary} ${theme.colors.bg.tertiary} hover:shadow-md`
                      : 'border-gray-200 bg-gray-50 opacity-60'
                  }`}
                >
                  <div className="text-center">
                    <div className={`text-3xl mb-2 ${badge.earned ? '' : 'grayscale'}`}>
                      {badge.icon}
                    </div>
                    <h3 className={`font-semibold text-sm ${theme.colors.text.primary} mb-1`}>
                      {badge.name}
                    </h3>
                    <p className={`text-xs ${theme.colors.text.secondary} mb-2`}>
                      {badge.description}
                    </p>
                    {badge.earned && badge.date && (
                      <span className="text-xs text-green-600 font-medium">
                        Earned {new Date(badge.date).toLocaleDateString()}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Achievements Section */}
          <div className={`${theme.colors.bg.card} rounded-2xl ${theme.shadows.lg} p-6`}>
            <div className="flex items-center justify-between mb-6">
              <h2 className={`text-xl font-bold ${theme.colors.text.primary}`}>Subject Achievements</h2>
              <Target className={`w-5 h-5 ${theme.colors.text.secondary}`} />
            </div>

            <div className="space-y-4">
              {rewards.achievements.map((achievement) => (
                <div
                  key={achievement.id}
                  className={`p-4 rounded-xl border transition-all ${
                    achievement.completed
                      ? `border-green-200 bg-green-50 ${theme.isDarkMode ? 'bg-green-900/20 border-green-800' : ''}`
                      : `${theme.colors.border.primary} ${theme.colors.bg.tertiary}`
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3">
                        <div className={`p-2 rounded-lg ${
                          achievement.completed ? 'bg-green-500' : 'bg-gray-400'
                        }`}>
                          {achievement.completed ? (
                            <Award className="w-4 h-4 text-white" />
                          ) : (
                            <Target className="w-4 h-4 text-white" />
                          )}
                        </div>
                        <div>
                          <h3 className={`font-semibold ${theme.colors.text.primary}`}>
                            {achievement.title}
                          </h3>
                          <p className={`text-sm ${theme.colors.text.secondary}`}>
                            {achievement.subject}
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className={`text-lg font-bold ${
                        achievement.completed ? 'text-green-600' : theme.colors.text.secondary
                      }`}>
                        +{achievement.points}
                      </div>
                      <div className="text-xs text-gray-500">points</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Motivational Section */}
        <div className={`mt-8 ${theme.colors.bg.card} rounded-2xl ${theme.shadows.lg} p-8`}>
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Zap className="w-8 h-8 text-white" />
            </div>
            <h2 className={`text-2xl font-bold ${theme.colors.text.primary} mb-4`}>
              Keep Up the Great Work!
            </h2>
            <p className={`${theme.colors.text.secondary} mb-6 max-w-2xl mx-auto`}>
              You're doing amazing! Every quiz you complete and every challenge you overcome
              brings you closer to mastering new skills. Keep learning and earning those rewards!
            </p>
            <Button
              onClick={() => navigate('/student/assignments')}
              className={`${theme.colors.button.primary} px-8 py-3 rounded-lg font-medium`}
            >
              Take a Quiz Now
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentRewards;