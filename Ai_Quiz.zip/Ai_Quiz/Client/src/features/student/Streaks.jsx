import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { selectUser } from '../auth/authSlice';
import { useTheme } from '../../contexts/ThemeContext';
import Button from '../../components/common/Button';
import { Flame, Calendar, Target, TrendingUp, ArrowLeft, Clock, Award } from 'lucide-react';

const StudentStreaks = () => {
  const user = useSelector(selectUser);
  const navigate = useNavigate();
  const theme = useTheme();

  // Mock data - in real app, this would come from API
  const [streakData, setStreakData] = useState({
    currentStreak: 7,
    longestStreak: 15,
    totalDays: 45,
    weeklyGoal: 5,
    completedThisWeek: 4,
    streakHistory: [
      { date: '2024-01-20', completed: true, quizzes: 2 },
      { date: '2024-01-21', completed: true, quizzes: 1 },
      { date: '2024-01-22', completed: true, quizzes: 3 },
      { date: '2024-01-23', completed: false, quizzes: 0 },
      { date: '2024-01-24', completed: true, quizzes: 1 },
      { date: '2024-01-25', completed: true, quizzes: 2 },
      { date: '2024-01-26', completed: true, quizzes: 1 },
      { date: '2024-01-27', completed: true, quizzes: 2 }
    ]
  });

  // Generate calendar for current month
  const generateCalendar = () => {
    const today = new Date();
    const currentMonth = today.getMonth();
    const currentYear = today.getFullYear();
    const firstDay = new Date(currentYear, currentMonth, 1);
    const lastDay = new Date(currentYear, currentMonth + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const calendar = [];

    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      calendar.push(null);
    }

    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(currentYear, currentMonth, day);
      const dateString = date.toISOString().split('T')[0];
      const dayData = streakData.streakHistory.find(d => d.date === dateString);

      calendar.push({
        day,
        date: dateString,
        isToday: day === today.getDate() && currentMonth === today.getMonth(),
        completed: dayData?.completed || false,
        quizzes: dayData?.quizzes || 0
      });
    }

    return calendar;
  };

  const calendar = generateCalendar();
  const weekProgress = (streakData.completedThisWeek / streakData.weeklyGoal) * 100;

  return (
    <div className={`min-h-screen ${theme.colors.bg.secondary}`}>
      {/* Header */}
      <div className={`${theme.colors.bg.card} ${theme.shadows.sm} border-b ${theme.colors.border.primary}`}>
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                onClick={() => navigate('/student/dashboard')}
                className={`${theme.colors.button.secondary} p-2 rounded-lg`}
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div>
                <h1 className={`text-2xl font-bold ${theme.colors.text.primary}`}>
                  Learning Streaks
                </h1>
                <p className={`${theme.colors.text.secondary}`}>
                  Track your daily learning consistency and build habits
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {/* Current Streak */}
          <div className={`${theme.colors.bg.card} rounded-2xl ${theme.shadows.lg} p-6`}>
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-gradient-to-br from-orange-400 to-red-500 rounded-xl">
                <Flame className="w-6 h-6 text-white" />
              </div>
              <span className={`text-2xl font-bold ${theme.colors.text.primary}`}>
                {streakData.currentStreak}
              </span>
            </div>
            <h3 className={`font-semibold ${theme.colors.text.primary} mb-1`}>Current Streak</h3>
            <p className={`text-sm ${theme.colors.text.secondary}`}>Days in a row</p>
          </div>

          {/* Longest Streak */}
          <div className={`${theme.colors.bg.card} rounded-2xl ${theme.shadows.lg} p-6`}>
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-xl">
                <Award className="w-6 h-6 text-white" />
              </div>
              <span className={`text-2xl font-bold ${theme.colors.text.primary}`}>
                {streakData.longestStreak}
              </span>
            </div>
            <h3 className={`font-semibold ${theme.colors.text.primary} mb-1`}>Best Streak</h3>
            <p className={`text-sm ${theme.colors.text.secondary}`}>Personal record</p>
          </div>

          {/* Total Days */}
          <div className={`${theme.colors.bg.card} rounded-2xl ${theme.shadows.lg} p-6`}>
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl">
                <Calendar className="w-6 h-6 text-white" />
              </div>
              <span className={`text-2xl font-bold ${theme.colors.text.primary}`}>
                {streakData.totalDays}
              </span>
            </div>
            <h3 className={`font-semibold ${theme.colors.text.primary} mb-1`}>Total Days</h3>
            <p className={`text-sm ${theme.colors.text.secondary}`}>Learning days</p>
          </div>

          {/* Weekly Progress */}
          <div className={`${theme.colors.bg.card} rounded-2xl ${theme.shadows.lg} p-6`}>
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-xl">
                <Target className="w-6 h-6 text-white" />
              </div>
              <span className={`text-2xl font-bold ${theme.colors.text.primary}`}>
                {streakData.completedThisWeek}/{streakData.weeklyGoal}
              </span>
            </div>
            <h3 className={`font-semibold ${theme.colors.text.primary} mb-1`}>This Week</h3>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-gradient-to-r from-blue-500 to-cyan-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${Math.min(weekProgress, 100)}%` }}
              ></div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Calendar View */}
          <div className={`${theme.colors.bg.card} rounded-2xl ${theme.shadows.lg} p-6`}>
            <div className="flex items-center justify-between mb-6">
              <h2 className={`text-xl font-bold ${theme.colors.text.primary}`}>
                {new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
              </h2>
              <Calendar className={`w-5 h-5 ${theme.colors.text.secondary}`} />
            </div>

            {/* Calendar Grid */}
            <div className="grid grid-cols-7 gap-2 mb-4">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                <div key={day} className={`text-center text-sm font-medium ${theme.colors.text.secondary} py-2`}>
                  {day}
                </div>
              ))}

              {calendar.map((day, index) => (
                <div key={index} className="aspect-square">
                  {day ? (
                    <div className={`
                      w-full h-full rounded-lg flex items-center justify-center text-sm font-medium
                      ${day.isToday
                        ? `ring-2 ring-blue-500 ${theme.colors.bg.tertiary}`
                        : ''
                      }
                      ${day.completed
                        ? 'bg-green-500 text-white'
                        : `${theme.colors.bg.tertiary} ${theme.colors.text.secondary}`
                      }
                      transition-all hover:scale-105
                    `}>
                      {day.day}
                      {day.completed && day.quizzes > 0 && (
                        <div className="absolute mt-6 text-xs">
                          {day.quizzes}
                        </div>
                      )}
                    </div>
                  ) : (
                    <div></div>
                  )}
                </div>
              ))}
            </div>

            {/* Legend */}
            <div className="flex items-center justify-center space-x-6 text-sm">
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-green-500 rounded"></div>
                <span className={theme.colors.text.secondary}>Completed</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className={`w-4 h-4 ${theme.colors.bg.tertiary} border rounded`}></div>
                <span className={theme.colors.text.secondary}>Missed</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 border-2 border-blue-500 rounded"></div>
                <span className={theme.colors.text.secondary}>Today</span>
              </div>
            </div>
          </div>

          {/* Streak Tips & Motivation */}
          <div className="space-y-6">
            {/* Current Status */}
            <div className={`${theme.colors.bg.card} rounded-2xl ${theme.shadows.lg} p-6`}>
              <h3 className={`text-lg font-semibold ${theme.colors.text.primary} mb-4`}>
                Streak Status
              </h3>

              {streakData.currentStreak > 0 ? (
                <div className="text-center">
                  <div className="text-4xl mb-2">🔥</div>
                  <p className={`text-lg font-semibold ${theme.colors.text.primary} mb-2`}>
                    You're on fire!
                  </p>
                  <p className={`${theme.colors.text.secondary} mb-4`}>
                    {streakData.currentStreak} days strong. Keep it going!
                  </p>
                  <Button
                    onClick={() => navigate('/student/assignments')}
                    className={`${theme.colors.button.primary} px-6 py-2 rounded-lg`}
                  >
                    Continue Streak
                  </Button>
                </div>
              ) : (
                <div className="text-center">
                  <div className="text-4xl mb-2">💪</div>
                  <p className={`text-lg font-semibold ${theme.colors.text.primary} mb-2`}>
                    Start Your Streak!
                  </p>
                  <p className={`${theme.colors.text.secondary} mb-4`}>
                    Take a quiz today to begin building your learning habit.
                  </p>
                  <Button
                    onClick={() => navigate('/student/assignments')}
                    className={`${theme.colors.button.primary} px-6 py-2 rounded-lg`}
                  >
                    Start Today
                  </Button>
                </div>
              )}
            </div>

            {/* Tips */}
            <div className={`${theme.colors.bg.card} rounded-2xl ${theme.shadows.lg} p-6`}>
              <h3 className={`text-lg font-semibold ${theme.colors.text.primary} mb-4`}>
                Streak Tips
              </h3>

              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mt-0.5">
                    <Clock className="w-3 h-3 text-blue-600" />
                  </div>
                  <div>
                    <p className={`text-sm font-medium ${theme.colors.text.primary}`}>
                      Set a daily time
                    </p>
                    <p className={`text-xs ${theme.colors.text.secondary}`}>
                      Pick a consistent time each day for learning
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center mt-0.5">
                    <Target className="w-3 h-3 text-green-600" />
                  </div>
                  <div>
                    <p className={`text-sm font-medium ${theme.colors.text.primary}`}>
                      Start small
                    </p>
                    <p className={`text-xs ${theme.colors.text.secondary}`}>
                      Even one quiz a day counts towards your streak
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center mt-0.5">
                    <TrendingUp className="w-3 h-3 text-purple-600" />
                  </div>
                  <div>
                    <p className={`text-sm font-medium ${theme.colors.text.primary}`}>
                      Track progress
                    </p>
                    <p className={`text-xs ${theme.colors.text.secondary}`}>
                      Celebrate milestones and learn from patterns
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentStreaks;