export const useVoiceCommands = (voiceControlState, assignments, navigate) => {
  const {
    currentFocus,
    setCurrentFocus,
    isSpeaking,
    isListening,
    stopSpeaking,
    stopListening,
    speak,
    setRecognitionHistory
  } = voiceControlState

  const getAssignmentStatus = (assignment) => {
    const now = new Date()
    const dueDate = assignment.settings?.dueDate ? new Date(assignment.settings.dueDate) : null
    const hasSubmissions = assignment.quiz?.submissions && assignment.quiz.submissions.length > 0

    if (hasSubmissions) {
      return {
        status: 'completed',
        label: 'Completed',
        color: 'text-green-700',
        bg: 'bg-green-100',
        icon: 'CheckCircle',
        borderColor: 'border-green-200'
      }
    }

    if (dueDate && now > dueDate) {
      return {
        status: 'overdue',
        label: 'Overdue',
        color: 'text-red-700',
        bg: 'bg-red-100',
        icon: 'AlertCircle',
        borderColor: 'border-red-200'
      }
    }

    if (assignment.status === 'active') {
      return {
        status: 'pending',
        label: 'Pending',
        color: 'text-blue-700',
        bg: 'bg-blue-100',
        icon: 'Clock',
        borderColor: 'border-blue-200'
      }
    }

    return {
      status: 'inactive',
      label: 'Inactive',
      color: 'text-gray-700',
      bg: 'bg-gray-100',
      icon: 'Clock',
      borderColor: 'border-gray-200'
    }
  }

  const getFilteredAssignments = (filter = 'all') => {
    if (filter === 'all') return assignments
    return assignments.filter(assignment => {
      const status = getAssignmentStatus(assignment)
      return status.status === filter
    })
  }

  const handleStartQuiz = (assignment, mode = 'regular') => {
    // Navigate to the dedicated quiz page with mode parameter
    const searchParams = new URLSearchParams();
    if (mode === 'voice') {
      searchParams.set('mode', 'voice');
    }

    const url = `/student/quiz/${assignment._id}${searchParams.toString() ? '?' + searchParams.toString() : ''}`;
    navigate(url);
  }

  const navigateNext = () => {
    const filteredAssignments = getFilteredAssignments()
    if (currentFocus < filteredAssignments.length - 1) {
      const newFocus = currentFocus + 1
      setCurrentFocus(newFocus)
      const assignment = filteredAssignments[newFocus]
      speak(`Assignment ${newFocus + 1}: ${assignment.quiz?.title || 'Untitled quiz'}`)
    } else {
      speak('This is the last assignment')
    }
  }

  const navigatePrevious = () => {
    if (currentFocus > 0) {
      const newFocus = currentFocus - 1
      setCurrentFocus(newFocus)
      const filteredAssignments = getFilteredAssignments()
      const assignment = filteredAssignments[newFocus]
      speak(`Assignment ${newFocus + 1}: ${assignment.quiz?.title || 'Untitled quiz'}`)
    } else {
      speak('This is the first assignment')
    }
  }

  const readAssignments = () => {
    const filteredAssignments = getFilteredAssignments()
    if (filteredAssignments.length === 0) {
      speak('No assignments available')
      return
    }

    let text = `You have ${filteredAssignments.length} assignments. `
    filteredAssignments.forEach((assignment, index) => {
      const status = getAssignmentStatus(assignment)
      text += `Assignment ${index + 1}: ${assignment.quiz?.title || 'Untitled quiz'}, Status: ${status.label}. `
    })
    text += 'Say "start quiz" followed by a number to begin.'

    speak(text)
  }

  const processVoiceCommand = (command) => {
    console.log('🎤 Voice command:', command)

    // Mark the latest command as processed in history
    setRecognitionHistory(prev =>
      prev.map((item, index) =>
        index === prev.length - 1 ? { ...item, processed: true } : item
      )
    )

    // Handle "stop" command differently based on current state
    if (command.includes('stop')) {
      if (isSpeaking) {
        // If system is speaking, stop the speech
        console.log('🛑 Stopping speech due to voice command')
        stopSpeaking()
        speak('Speech stopped')
        return
      } else if (command.includes('listening') || command.includes('voice')) {
        // Only stop voice recognition if specifically mentioned
        console.log('🛑 Stopping voice recognition due to command')
        stopListening()
        speak('Voice recognition stopped')
        return
      } else {
        // Generic "stop" - prioritize stopping speech if speaking, otherwise stop listening
        if (isListening) {
          console.log('🛑 Generic stop - stopping voice recognition')
          stopListening()
          speak('Voice recognition stopped')
          return
        }
      }
    }

    // Stop speech command (handle before other commands)
    if (command.includes('stop speech') || command.includes('stop talking') || command.includes('quiet') || command.includes('silence')) {
      console.log('🔇 Stop speech command received')
      stopSpeaking()
      return // Don't speak confirmation to avoid immediate restart
    }

    // Stop listening command (more specific)
    if (command.includes('stop listening') || command.includes('stop voice') || command.includes('turn off voice')) {
      console.log('🛑 Stop listening command received')
      stopListening()
      speak('Voice recognition stopped')
      return
    }

    // Help commands
    if (command.includes('help') || command.includes('commands')) {
      const helpText = `Available voice commands:
        Navigation: Say "next" or "previous" to move between assignments.
        Quiz Control: Say "start quiz" followed by a number to begin.
        Quiz Navigation: Say "next question", "previous question", or "save answer".
        Filtering: Say "filter pending" or "filter completed" to organize assignments.
        Page Navigation: Say "go to assignments" or "go to dashboard".
        System Control: Say "refresh" to reload, "stop speech" to interrupt talking, or "stop listening" to turn off voice control.
        Selection: Say "select option A" or "select option B" during quizzes.
        Submission: Say "submit answers" or "save and submit" to complete quizzes.`
      speak(helpText)
      return
    }

    // Page navigation commands
    if (command.includes('go to assignments') || command.includes('assignments page')) {
      speak('You are already on the assignments page')
      return
    }

    if (command.includes('go to dashboard') || command.includes('dashboard page')) {
      speak('Navigating to dashboard')
      navigate('/student/dashboard')
      return
    }

    if (command.includes('go to profile') || command.includes('profile page')) {
      speak('Navigating to profile')
      navigate('/student/profile')
      return
    }

    // Assignment navigation commands
    if (command.includes('next assignment') || (command.includes('next') && !command.includes('question'))) {
      navigateNext()
      return
    }

    if (command.includes('previous assignment') || command.includes('back assignment') ||
        (command.includes('previous') && !command.includes('question')) ||
        (command.includes('back') && !command.includes('question'))) {
      navigatePrevious()
      return
    }

    // Quiz-specific navigation (for when in quiz mode)
    if (command.includes('next question')) {
      speak('Next question command received. This will work when you are in a quiz.')
      return
    }

    if (command.includes('previous question') || command.includes('back question')) {
      speak('Previous question command received. This will work when you are in a quiz.')
      return
    }

    if (command.includes('save answer') || command.includes('save my answer')) {
      speak('Save answer command received. This will work when you are in a quiz.')
      return
    }

    // Filter commands
    if (command.includes('filter')) {
      if (command.includes('pending')) {
        speak('Showing pending assignments')
        // Note: setFilter would need to be passed in or handled differently
      } else if (command.includes('completed')) {
        speak('Showing completed assignments')
      } else if (command.includes('all')) {
        speak('Showing all assignments')
      }
      return
    }

    // Quiz start commands
    if (command.includes('start quiz')) {
      const numbers = command.match(/\d+/)
      if (numbers) {
        const quizIndex = parseInt(numbers[0]) - 1
        const filteredAssignments = getFilteredAssignments()
        if (quizIndex >= 0 && quizIndex < filteredAssignments.length) {
          const assignment = filteredAssignments[quizIndex]
          const quizTitle = assignment.quiz?.title || 'quiz'

          speak(`Starting ${quizTitle} with voice control. Loading quiz interface. Say "stop speech" to skip this announcement.`)

          // Navigate to voice quiz after a short delay
          setTimeout(() => {
            handleStartQuiz(assignment, 'voice')
          }, 2500) // Shorter delay, user can interrupt with "stop speech"

        } else {
          speak('Quiz number not found. Please try again.')
        }
      } else {
        speak('Please specify a quiz number. For example, say "start quiz 1"')
      }
      return
    }

    // Selection commands (for quiz options)
    if (command.includes('select option')) {
      const optionMatch = command.match(/select option ([a-d]|[1-4])/i)
      if (optionMatch) {
        const option = optionMatch[1].toLowerCase()
        speak(`Option ${option.toUpperCase()} selected. This will work when you are in a quiz.`)
      } else {
        speak('Please specify which option to select. For example, say "select option A" or "select option 1".')
      }
      return
    }

    if (command.includes('select answer')) {
      const answerMatch = command.match(/select answer ([a-d]|[1-4])/i)
      if (answerMatch) {
        const answer = answerMatch[1].toLowerCase()
        speak(`Answer ${answer.toUpperCase()} selected. This will work when you are in a quiz.`)
      } else {
        speak('Please specify which answer to select. For example, say "select answer A".')
      }
      return
    }

    // Submission commands
    if (command.includes('submit answers') || command.includes('submit quiz') || command.includes('submit my answers')) {
      speak('Submit command received. This will work when you are in a quiz to submit your answers.')
      return
    }

    if (command.includes('save and submit') || command.includes('finish quiz')) {
      speak('Save and submit command received. This will work when you are in a quiz to save and submit your answers.')
      return
    }

    // Refresh command
    if (command.includes('refresh') || command.includes('reload')) {
      speak('Refreshing assignments')
      // Note: dispatch would need to be passed in
      return
    }

    // Stop listening
    if (command.includes('stop listening') || command.includes('turn off')) {
      stopListening()
      speak('Voice control turned off. Click the microphone button to turn it back on.')
      return
    }

    // Read current assignments
    if (command.includes('read assignments') || command.includes('what assignments')) {
      readAssignments()
      return
    }

    // Unknown command
    speak('Command not recognized. Say "help" for available commands.')
  }

  return {
    processVoiceCommand,
    navigateNext,
    navigatePrevious,
    readAssignments,
    handleStartQuiz,
    getAssignmentStatus,
    getFilteredAssignments
  }
}
