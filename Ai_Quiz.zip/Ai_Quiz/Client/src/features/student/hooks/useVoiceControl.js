import { useState, useEffect, useRef } from 'react'

export const useVoiceControl = (user, assignments, navigate) => {
  // Voice Control State
  const [isListening, setIsListening] = useState(false)
  const [voiceCommand, setVoiceCommand] = useState('')
  const [interimTranscript, setInterimTranscript] = useState('')
  const [finalTranscript, setFinalTranscript] = useState('')
  const [speechSupported, setSpeechSupported] = useState(false)
  const [currentFocus, setCurrentFocus] = useState(0)
  const [voiceError, setVoiceError] = useState('')
  const [microphonePermission, setMicrophonePermission] = useState('unknown')
  const [recognitionHistory, setRecognitionHistory] = useState([])
  const [recognitionConfidence, setRecognitionConfidence] = useState(0)
  const [wordByWordDisplay, setWordByWordDisplay] = useState([])
  const [showDetailedRecognition, setShowDetailedRecognition] = useState(true)
  const [showCommandReference, setShowCommandReference] = useState(false)
  const [availableDevices, setAvailableDevices] = useState([])
  const [selectedDevice, setSelectedDevice] = useState(null)
  const [microphoneStream, setMicrophoneStream] = useState(null)
  const [debugInfo, setDebugInfo] = useState('')
  const [isSpeaking, setIsSpeaking] = useState(false)

  // Refs
  const recognitionRef = useRef(null)
  const synthRef = useRef(null)
  const manuallyStoppedRef = useRef(false)
  const mediaStreamRef = useRef(null)
  const restartTimeoutRef = useRef(null)
  const lastRestartTimeRef = useRef(0)
  const restartAttemptsRef = useRef(0)
  const currentUtteranceRef = useRef(null)
  const isInitializingRef = useRef(false)
  const isStartingRef = useRef(false)
  const speechQueueRef = useRef([])
  const speechProcessingRef = useRef(false)

  // Device enumeration and microphone access functions
  const enumerateAudioDevices = async () => {
    try {
      console.log('🔍 Enumerating audio devices...')
      const devices = await navigator.mediaDevices.enumerateDevices()
      const audioInputs = devices.filter(device => device.kind === 'audioinput')

      console.log('🎤 Available audio input devices:', audioInputs)
      setAvailableDevices(audioInputs)
      setDebugInfo(`Found ${audioInputs.length} audio devices`)

      // Log device details for debugging
      audioInputs.forEach((device, index) => {
        console.log(`Device ${index + 1}:`, {
          deviceId: device.deviceId,
          label: device.label || `Microphone ${index + 1}`,
          groupId: device.groupId
        })
      })

      return audioInputs
    } catch (error) {
      console.error('❌ Error enumerating devices:', error)
      setVoiceError('Could not enumerate audio devices: ' + error.message)
      return []
    }
  }

  const requestMicrophoneAccess = async () => {
    try {
      console.log('🎤 Requesting microphone access...')
      setDebugInfo('Requesting microphone access...')

      // Enhanced constraints for better device compatibility, especially AirPods
      const constraints = {
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
          sampleRate: 16000, // Lower sample rate for better Bluetooth compatibility
          channelCount: 1,
          latency: 0.1, // Low latency for better responsiveness
          // Allow any device initially
          deviceId: selectedDevice ? { exact: selectedDevice } : undefined
        }
      }

      console.log('🔧 Using constraints:', constraints)

      const stream = await navigator.mediaDevices.getUserMedia(constraints)
      console.log('✅ Microphone access granted')

      // Store the stream reference
      mediaStreamRef.current = stream
      setMicrophoneStream(stream)
      setMicrophonePermission('granted')
      setVoiceError('')
      setDebugInfo('Microphone access granted')

      // Log stream details
      const audioTracks = stream.getAudioTracks()
      if (audioTracks.length > 0) {
        const track = audioTracks[0]
        console.log('🎵 Audio track details:', {
          label: track.label,
          enabled: track.enabled,
          muted: track.muted,
          readyState: track.readyState,
          settings: track.getSettings()
        })
        setDebugInfo(`Using: ${track.label}`)
      }

      return stream
    } catch (error) {
      console.error('❌ Microphone access error:', error)
      setMicrophonePermission('denied')

      let errorMessage = 'Microphone access failed: '
      switch (error.name) {
        case 'NotAllowedError':
          errorMessage += 'Permission denied. Please allow microphone access.'
          break
        case 'NotFoundError':
          errorMessage += 'No microphone found. Please connect a microphone.'
          break
        case 'NotReadableError':
          errorMessage += 'Microphone is being used by another application.'
          break
        case 'OverconstrainedError':
          errorMessage += 'Microphone constraints not supported.'
          break
        default:
          errorMessage += error.message
      }

      setVoiceError(errorMessage)
      setDebugInfo(errorMessage)
      queueSpeech(errorMessage)
      return null
    }
  }

  // Queue-based speech system to prevent conflicts
  const queueSpeech = (text, options = {}) => {
    if (!synthRef.current || !user?.isDisabled) return

    speechQueueRef.current.push({ text, options })
    if (!speechProcessingRef.current) {
      processNextSpeech()
    }
  }

  const processNextSpeech = () => {
    if (speechQueueRef.current.length === 0) {
      speechProcessingRef.current = false
      // Resume recognition if it was paused for speech
      if (user?.isDisabled && speechSupported && !manuallyStoppedRef.current && !isListening && !isStartingRef.current) {
        console.log('🔄 Resuming recognition after speech queue completed')
        setTimeout(() => startListening(), 1000)
      }
      return
    }

    speechProcessingRef.current = true
    const { text, options } = speechQueueRef.current.shift()

    // Pause recognition during speech to prevent conflicts
    const wasListening = isListening
    if (wasListening && recognitionRef.current) {
      console.log('⏸️ Pausing recognition for speech')
      try {
        recognitionRef.current.stop()
      } catch (error) {
        console.log('⚠️ Error pausing recognition:', error)
      }
    }

    // Cancel any ongoing speech
    if (synthRef.current.speaking) {
      synthRef.current.cancel()
    }

    const utterance = new SpeechSynthesisUtterance(text)
    utterance.rate = options.rate || 0.8
    utterance.pitch = options.pitch || 1
    utterance.volume = options.volume || 1

    // Track speaking state
    utterance.onstart = () => {
      console.log('🗣️ Started speaking:', text.substring(0, 50) + '...')
      setIsSpeaking(true)
      setDebugInfo(`Speaking: ${text.substring(0, 30)}...`)
    }

    utterance.onend = () => {
      console.log('🔇 Finished speaking')
      setIsSpeaking(false)
      setDebugInfo('Speech completed')
      currentUtteranceRef.current = null
      
      // Process next item in queue after a short delay
      setTimeout(() => {
        processNextSpeech()
      }, 500)
    }

    utterance.onerror = (event) => {
      console.error('🔇 Speech error:', event.error)
      setIsSpeaking(false)
      setDebugInfo(`Speech error: ${event.error}`)
      currentUtteranceRef.current = null
      
      // Continue with next item even if there was an error
      setTimeout(() => {
        processNextSpeech()
      }, 500)
    }

    // Store reference for potential cancellation
    currentUtteranceRef.current = utterance
    synthRef.current.speak(utterance)
  }

  // Legacy speak function for backward compatibility
  const speak = (text, options = {}) => {
    queueSpeech(text, options)
  }

  const stopSpeaking = () => {
    if (synthRef.current && (isSpeaking || synthRef.current.speaking)) {
      console.log('🛑 Stopping speech...')
      synthRef.current.cancel()
      setIsSpeaking(false)
      setDebugInfo('Speech stopped')
      currentUtteranceRef.current = null
      
      // Clear speech queue
      speechQueueRef.current = []
      speechProcessingRef.current = false
    }
  }

  return {
    // State
    isListening,
    voiceCommand,
    interimTranscript,
    finalTranscript,
    speechSupported,
    currentFocus,
    voiceError,
    microphonePermission,
    recognitionHistory,
    recognitionConfidence,
    wordByWordDisplay,
    showDetailedRecognition,
    showCommandReference,
    availableDevices,
    selectedDevice,
    microphoneStream,
    debugInfo,
    isSpeaking,
    
    // Setters
    setCurrentFocus,
    setShowDetailedRecognition,
    setShowCommandReference,
    setSelectedDevice,
    
    // Functions
    speak,
    queueSpeech,
    stopSpeaking,
    enumerateAudioDevices,
    requestMicrophoneAccess,
    
    // Refs (for external access)
    recognitionRef,
    synthRef,
    manuallyStoppedRef,
    mediaStreamRef,
    restartTimeoutRef,
    lastRestartTimeRef,
    restartAttemptsRef,
    currentUtteranceRef,
    isInitializingRef,
    isStartingRef,
    speechQueueRef,
    speechProcessingRef,
    
    // State setters for internal use
    setSpeechSupported,
    setVoiceError,
    setDebugInfo,
    setMicrophonePermission,
    setIsListening,
    setIsSpeaking,
    setInterimTranscript,
    setFinalTranscript,
    setRecognitionHistory,
    setRecognitionConfidence,
    setWordByWordDisplay,
    setAvailableDevices,
    setMicrophoneStream
  }
}
