import { useEffect } from 'react'

export const useVoiceRecognition = (voiceControlState, assignments, navigate, processVoiceCommand) => {
  const {
    user,
    recognitionRef,
    synthRef,
    manuallyStoppedRef,
    mediaStreamRef,
    restartTimeoutRef,
    lastRestartTimeRef,
    restartAttemptsRef,
    isStartingRef,
    speechProcessingRef,
    speechSupported,
    isListening,
    isSpeaking,
    setSpeechSupported,
    setVoiceError,
    setDebugInfo,
    setMicrophonePermission,
    setIsListening,
    setInterimTranscript,
    setFinalTranscript,
    setRecognitionHistory,
    setRecognitionConfidence,
    setWordByWordDisplay,
    requestMicrophoneAccess,
    enumerateAudioDevices,
    queueSpeech
  } = voiceControlState

  // Voice Control Functions
  const initializeVoiceControl = async () => {
    console.log('🎤 Initializing voice control...')
    setDebugInfo('Initializing voice control...')

    try {
      // First, enumerate available audio devices
      await enumerateAudioDevices()

      // Request microphone access with specific constraints for better device support
      const stream = await requestMicrophoneAccess()
      if (!stream) {
        setVoiceError('Could not access microphone. Please check permissions and device connection.')
        return
      }

      // Check microphone permission
      if (navigator.permissions) {
        try {
          const permission = await navigator.permissions.query({ name: 'microphone' })
          setMicrophonePermission(permission.state)
          console.log('🎤 Microphone permission:', permission.state)
          setDebugInfo(`Permission: ${permission.state}`)
        } catch (error) {
          console.log('Could not check microphone permission:', error)
        }
      }

      // Check for speech recognition support
      if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
        console.log('✅ Speech recognition supported')
        setDebugInfo('Speech recognition supported')

        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
        recognitionRef.current = new SpeechRecognition()

        // Enhanced configuration for better recognition
        try {
          recognitionRef.current.continuous = true
          recognitionRef.current.interimResults = true
          recognitionRef.current.lang = 'en-US'

          // Only set maxAlternatives if supported
          if ('maxAlternatives' in recognitionRef.current) {
            recognitionRef.current.maxAlternatives = 1
          }

          // Set service URI if available (helps with some browsers)
          if ('serviceURI' in recognitionRef.current) {
            // Use default service
          }

          console.log('✅ Speech recognition configured successfully')
        } catch (configError) {
          console.warn('⚠️ Some speech recognition settings not supported:', configError)
          // Continue anyway with basic settings
        }

        console.log('🔧 Speech recognition configured:', {
          continuous: recognitionRef.current.continuous,
          interimResults: recognitionRef.current.interimResults,
          lang: recognitionRef.current.lang
        })

        // Set up event handlers
        setupSpeechRecognitionHandlers()

        setSpeechSupported(true)

        // Initialize speech synthesis
        if ('speechSynthesis' in window) {
          synthRef.current = window.speechSynthesis
        }

        // Auto-start voice control with a longer delay to ensure everything is ready
        setTimeout(() => {
          startListening()
        }, 2000)

      } else {
        console.warn('Speech recognition not supported')
        setVoiceError('Voice control not supported in this browser.')
        queueSpeech('Voice control not supported in this browser.')
      }

    } catch (error) {
      console.error('❌ Voice control initialization failed:', error)

      let errorMessage = 'Voice control initialization failed'
      let userMessage = 'Voice control initialization failed. Please try refreshing the page.'

      // Provide specific error messages for common issues
      if (error.message.includes('grammars')) {
        errorMessage = 'Speech recognition grammars not supported'
        userMessage = 'Speech recognition configuration issue. Trying basic setup.'
        // Try to initialize with minimal settings
        setTimeout(() => {
          console.log('🔄 Retrying with basic speech recognition setup...')
          initializeBasicVoiceControl()
        }, 2000)
      } else if (error.message.includes('SpeechRecognition')) {
        errorMessage = 'Speech recognition not available'
        userMessage = 'Speech recognition not supported in this browser.'
      } else if (error.message.includes('microphone') || error.message.includes('audio')) {
        errorMessage = 'Microphone access failed'
        userMessage = 'Could not access microphone. Please check permissions.'
      }

      setVoiceError(errorMessage)
      setDebugInfo(`Init failed: ${error.message}`)
      queueSpeech(userMessage)
    }
  }

  // Fallback initialization with minimal settings
  const initializeBasicVoiceControl = () => {
    try {
      console.log('🔄 Initializing basic voice control...')
      setDebugInfo('Initializing basic voice control...')

      if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
        recognitionRef.current = new SpeechRecognition()

        // Only set the most basic, widely supported properties
        recognitionRef.current.continuous = true
        recognitionRef.current.interimResults = true
        recognitionRef.current.lang = 'en-US'

        console.log('✅ Basic speech recognition configured')
        setDebugInfo('Basic speech recognition ready')

        // Set up the same event handlers
        setupSpeechRecognitionHandlers()

        setSpeechSupported(true)

        // Initialize speech synthesis
        if ('speechSynthesis' in window) {
          synthRef.current = window.speechSynthesis
        }

        queueSpeech('Basic voice control initialized. Say "help" for commands.')

      } else {
        throw new Error('Speech recognition not supported')
      }

    } catch (error) {
      console.error('❌ Basic voice control initialization also failed:', error)
      setVoiceError('Voice control not available in this browser')
      setDebugInfo('Voice control not supported')
      queueSpeech('Voice control is not available in this browser.')
    }
  }

  // Separate function to set up speech recognition event handlers
  const setupSpeechRecognitionHandlers = () => {
    if (!recognitionRef.current) return

    recognitionRef.current.onstart = () => {
      console.log('✅ Speech recognition started successfully')
      isStartingRef.current = false
      setIsListening(true)
      setVoiceError('') // Clear any previous errors
      setInterimTranscript('')
      setFinalTranscript('')
      setWordByWordDisplay([])
      setRecognitionConfidence(0)
      restartAttemptsRef.current = 0 // Reset restart attempts on successful start
      setDebugInfo('Voice recognition active')
      
      // Don't speak welcome message on restart to avoid conflicts
      // Only speak on initial start (when restart attempts is 0 and no speech in queue)
    }

    recognitionRef.current.onresult = (event) => {
      let interimTranscriptText = ''
      let finalTranscriptText = ''

      // Process all results
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i][0]
        const transcript = result.transcript
        const confidence = result.confidence || 0

        if (event.results[i].isFinal) {
          finalTranscriptText += transcript
          setRecognitionConfidence(confidence)
        } else {
          interimTranscriptText += transcript
          // Update word-by-word display for interim results
          const words = transcript.split(' ').filter(word => word.length > 0)
          setWordByWordDisplay(words.map((word, index) => ({
            word,
            index,
            confidence: confidence,
            timestamp: Date.now()
          })))
        }
      }

      // Update state with current recognition
      setInterimTranscript(interimTranscriptText)

      // If we have a final result, process it
      if (finalTranscriptText) {
        setFinalTranscript(finalTranscriptText)

        // Add to recognition history
        setRecognitionHistory(prev => [
          ...prev.slice(-4), // Keep last 5 entries
          {
            text: finalTranscriptText,
            timestamp: new Date().toLocaleTimeString(),
            processed: false
          }
        ])

        // Process the command
        processVoiceCommand(finalTranscriptText.toLowerCase().trim())

        // Clear interim after processing
        setTimeout(() => {
          setInterimTranscript('')
        }, 2000)
      }
    }

    // Set up error handler and other handlers...
    recognitionRef.current.onerror = (event) => {
      console.error('❌ Speech recognition error:', event.error, event)
      isStartingRef.current = false
      setDebugInfo(`Error: ${event.error}`)

      // Handle different types of errors with enhanced debugging
      switch (event.error) {
        case 'no-speech':
          console.log('⚠️ No speech detected')
          setVoiceError('')
          setDebugInfo('No speech detected, waiting...')
          // Don't restart immediately for no-speech, let the onend handler manage it
          break

        case 'audio-capture':
          const audioError = 'Microphone capture failed. Check device connection and permissions.'
          console.error('🎤 Audio capture error - possible causes: device disconnected, used by another app, or hardware issue')
          setVoiceError(audioError)
          setDebugInfo('Audio capture failed')
          queueSpeech(audioError)
          setIsListening(false)
          setMicrophonePermission('denied')
          // Try to re-enumerate devices
          setTimeout(() => enumerateAudioDevices(), 1000)
          break

        case 'not-allowed':
          const permError = 'Microphone permission denied. Please allow access in browser settings.'
          console.error('🚫 Permission denied - user needs to grant microphone access')
          setVoiceError(permError)
          setDebugInfo('Permission denied')
          queueSpeech(permError)
          setIsListening(false)
          setMicrophonePermission('denied')
          break

        case 'network':
          const netError = 'Network error. Speech recognition service unavailable.'
          console.error('🌐 Network error - speech recognition service may be down')
          setVoiceError(netError)
          setDebugInfo('Network error')
          queueSpeech(netError)
          setIsListening(false)
          break

        case 'service-not-allowed':
          const serviceError = 'Speech recognition service not allowed. Check browser settings.'
          console.error('🔒 Service not allowed - browser may be blocking speech recognition')
          setVoiceError(serviceError)
          setDebugInfo('Service blocked')
          queueSpeech(serviceError)
          setIsListening(false)
          break

        case 'bad-grammar':
          console.log('⚠️ Grammar error, continuing...')
          setDebugInfo('Grammar error')
          break

        case 'language-not-supported':
          const langError = 'Language not supported. Switching to default.'
          console.error('🌍 Language not supported')
          setVoiceError(langError)
          setDebugInfo('Language not supported')
          queueSpeech(langError)
          break

        case 'aborted':
          console.log('🛑 Speech recognition aborted')
          setVoiceError('')
          setDebugInfo('Recognition aborted')
          setIsListening(false)
          
          // Check if this is a rapid abort (within 2 seconds of starting)
          const now = Date.now()
          const timeSinceStart = now - lastRestartTimeRef.current
          
          if (timeSinceStart < 2000) {
            console.log('⚠️ Rapid abort detected, likely browser conflict')
            restartAttemptsRef.current += 1
            
            if (restartAttemptsRef.current > 3) {
              console.log('🛑 Too many rapid aborts, trying alternative approach')
              // Try reinitializing the recognition object
              setTimeout(() => {
                console.log('🔄 Reinitializing speech recognition due to repeated aborts...')
                initializeBasicVoiceControl()
              }, 5000)
              manuallyStoppedRef.current = true
              queueSpeech('Voice recognition encountered repeated errors. Trying to reinitialize. Please wait.')
            } else {
              // Don't set manual stop for rapid aborts - let the restart logic handle it
              console.log('🔄 Will attempt restart after delay')
            }
          } else {
            // Normal abort after running for a while - likely user action
            manuallyStoppedRef.current = true
          }
          break

        default:
          const defaultError = `Voice recognition error: ${event.error}. Please try again.`
          console.error('❓ Unknown error:', event.error)
          setVoiceError(defaultError)
          setDebugInfo(`Unknown error: ${event.error}`)
          queueSpeech(defaultError)
          setIsListening(false)
      }
    }

    recognitionRef.current.onend = () => {
      console.log('🔚 Speech recognition ended')
      isStartingRef.current = false
      setIsListening(false)

      // Clear any existing restart timeout
      if (restartTimeoutRef.current) {
        clearTimeout(restartTimeoutRef.current)
        restartTimeoutRef.current = null
      }

      // Auto-restart for disabled students if it wasn't manually stopped
      if (user?.isDisabled && speechSupported && !manuallyStoppedRef.current && !isSpeaking && !speechProcessingRef.current) {
        const now = Date.now()
        const timeSinceLastRestart = now - lastRestartTimeRef.current

        // Implement exponential backoff with maximum attempts
        if (timeSinceLastRestart < 10000) { // Less than 10 seconds since last restart
          restartAttemptsRef.current += 1
          console.log(`⚠️ Rapid restart attempt ${restartAttemptsRef.current}`)

          if (restartAttemptsRef.current > 5) {
            console.log('🛑 Too many rapid restarts, pausing auto-restart for 30 seconds')
            setDebugInfo('Auto-restart paused - too many attempts')
            queueSpeech('Voice recognition paused due to repeated errors. Please check your microphone.')

            // Longer pause before allowing restarts again
            setTimeout(() => {
              restartAttemptsRef.current = 0
              lastRestartTimeRef.current = 0
              console.log('🔄 Reset restart attempts, ready to try again')
            }, 30000)
            return
          }
        } else {
          restartAttemptsRef.current = 0 // Reset counter if enough time has passed
        }

        // Calculate delay based on restart attempts with exponential backoff
        let restartDelay = Math.min(3000 * Math.pow(2, restartAttemptsRef.current), 20000) // Max 20 seconds

        console.log(`⏰ Scheduling restart in ${restartDelay}ms (attempt ${restartAttemptsRef.current + 1})`)
        setDebugInfo(`Restarting in ${Math.round(restartDelay/1000)} seconds...`)

        restartTimeoutRef.current = setTimeout(() => {
          if (!isListening && !isStartingRef.current && recognitionRef.current && !manuallyStoppedRef.current && !isSpeaking && !speechProcessingRef.current) {
            console.log('🔄 Auto-restarting speech recognition...')
            lastRestartTimeRef.current = Date.now()
            startListening()
          } else {
            console.log('🚫 Skipping restart - conditions not met', {
              isListening,
              isStarting: isStartingRef.current,
              hasRecognition: !!recognitionRef.current,
              manuallyStopped: manuallyStoppedRef.current,
              isSpeaking,
              speechProcessing: speechProcessingRef.current
            })
          }
        }, restartDelay)
      }
    }
  }

  const startListening = async () => {
    console.log('🎤 Attempting to start listening...')

    // Prevent multiple simultaneous start attempts
    if (isStartingRef.current) {
      console.log('⚠️ Already starting, skipping...')
      return
    }

    if (isListening) {
      console.log('⚠️ Already listening')
      return
    }

    if (!recognitionRef.current) {
      console.error('❌ Speech recognition not initialized')
      setVoiceError('Speech recognition not initialized. Please refresh the page.')
      return
    }

    // Check for potential conflicts
    if (synthRef.current && synthRef.current.speaking) {
      console.log('⚠️ Speech synthesis is active, waiting...')
      setTimeout(() => startListening(), 1000)
      return
    }

    isStartingRef.current = true
    setDebugInfo('Starting voice recognition...')

    // Record the start attempt time for abort detection
    lastRestartTimeRef.current = Date.now()

    try {
      // Ensure we have microphone access
      if (!mediaStreamRef.current || !mediaStreamRef.current.active) {
        console.log('🔄 Requesting fresh microphone access...')
        const stream = await requestMicrophoneAccess()
        if (!stream) {
          setVoiceError('Could not access microphone. Please check device and permissions.')
          isStartingRef.current = false
          return
        }
      }

      // Check if microphone tracks are active
      const audioTracks = mediaStreamRef.current?.getAudioTracks() || []
      const activeTrack = audioTracks.find(track => track.readyState === 'live' && track.enabled)

      if (!activeTrack) {
        console.log('🔄 No active audio track, requesting new access...')
        const stream = await requestMicrophoneAccess()
        if (!stream) {
          setVoiceError('Microphone not available. Please check device connection.')
          isStartingRef.current = false
          return
        }
      }

      console.log('✅ Microphone ready, starting recognition...')
      manuallyStoppedRef.current = false // Reset manual stop flag
      setVoiceError('')
      setDebugInfo('Voice recognition starting...')

      // Clear any pending restart timeout
      if (restartTimeoutRef.current) {
        clearTimeout(restartTimeoutRef.current)
        restartTimeoutRef.current = null
      }

      // Wait for any ongoing speech to finish before starting recognition
      if (isSpeaking || speechProcessingRef.current) {
        console.log('⏳ Waiting for speech to finish before starting recognition...')
        const waitForSpeech = () => {
          if (!isSpeaking && !speechProcessingRef.current) {
            try {
              // Add a small delay even after speech finishes to prevent conflicts
              setTimeout(() => {
                if (recognitionRef.current && !manuallyStoppedRef.current) {
                  recognitionRef.current.start()
                }
              }, 1000)
            } catch (error) {
              console.error('❌ Error starting recognition after speech:', error)
              isStartingRef.current = false
            }
          } else {
            setTimeout(waitForSpeech, 500)
          }
        }
        waitForSpeech()
      } else {
        // Add a small delay before starting to give browser time to settle
        setTimeout(() => {
          if (recognitionRef.current && !manuallyStoppedRef.current && !isListening) {
            try {
              recognitionRef.current.start()
            } catch (error) {
              console.error('❌ Error starting recognition:', error)
              isStartingRef.current = false
              setVoiceError(`Failed to start: ${error.message}`)
            }
          }
        }, 500)
      }

    } catch (error) {
      console.error('❌ Error starting speech recognition:', error)
      isStartingRef.current = false
      setDebugInfo(`Start error: ${error.message}`)

      // Handle specific errors
      if (error.message && error.message.includes('already started')) {
        console.log('⚠️ Recognition already started, updating state')
        setIsListening(true)
        setDebugInfo('Recognition already active')
      } else if (error.name === 'InvalidStateError') {
        console.log('🔄 Invalid state, reinitializing...')
        setVoiceError('Reinitializing voice recognition...')
        setTimeout(() => {
          initializeVoiceControl()
        }, 1000)
      } else {
        setVoiceError(`Failed to start voice recognition: ${error.message}`)
        queueSpeech('Failed to start voice recognition. Please try again.')
      }
    }
  }

  const stopListening = () => {
    console.log('🛑 Stopping voice recognition...')
    manuallyStoppedRef.current = true // Set manual stop flag
    isStartingRef.current = false // Reset starting flag

    // Clear any pending restart timeout
    if (restartTimeoutRef.current) {
      clearTimeout(restartTimeoutRef.current)
      restartTimeoutRef.current = null
    }

    if (recognitionRef.current && (isListening || isStartingRef.current)) {
      try {
        recognitionRef.current.stop()
      } catch (error) {
        console.log('⚠️ Error stopping recognition:', error)
      }
      setDebugInfo('Voice recognition stopped')
      setIsListening(false)
    }
  }

  return {
    initializeVoiceControl,
    initializeBasicVoiceControl,
    setupSpeechRecognitionHandlers,
    startListening,
    stopListening
  }
}
