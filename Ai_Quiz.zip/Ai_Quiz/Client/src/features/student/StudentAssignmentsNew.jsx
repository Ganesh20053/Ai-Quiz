import { useState, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { fetchStudentAssignments } from '../classroom/classroomSlice'
import { selectUser } from '../auth/authSlice'
import { useTheme } from '../../contexts/ThemeContext'
import Button from '../../components/common/Button'
import Loader from '../../components/common/Loader'
import { ArrowLeft, Mic } from 'lucide-react'

// Import our new components and hooks
import { useVoiceControl } from './hooks/useVoiceControl'
import { useVoiceRecognition } from './hooks/useVoiceRecognition'
import { useVoiceCommands } from './hooks/useVoiceCommands'
import VoiceControlPanel from './components/VoiceControlPanel'
import AssignmentCard from './components/AssignmentCard'
import AssignmentFilters from './components/AssignmentFilters'

const StudentAssignments = () => {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const user = useSelector(selectUser)
  const theme = useTheme()
  const { assignments, assignmentsLoading, error } = useSelector(state => state.classroom)

  const [filter, setFilter] = useState('all') // 'all', 'pending', 'completed', 'overdue'
  const [showWelcomeMessage, setShowWelcomeMessage] = useState(user?.isDisabled)

  // Initialize voice control
  const voiceControlState = useVoiceControl(user, assignments, navigate)
  const voiceCommands = useVoiceCommands(voiceControlState, assignments, navigate)
  const voiceRecognition = useVoiceRecognition(voiceControlState, assignments, navigate, voiceCommands.processVoiceCommand)

  // Extract needed values
  const {
    speechSupported,
    isSpeaking,
    speechProcessingRef,
    queueSpeech,
    stopListening,
    stopSpeaking,
    restartAttemptsRef,
    lastRestartTimeRef,
    isStartingRef,
    speechQueueRef,
    speechProcessingRef: speechProcessingRefFromState,
    setVoiceError,
    setDebugInfo,
    requestMicrophoneAccess,
    enumerateAudioDevices
  } = voiceControlState

  const { initializeVoiceControl } = voiceRecognition
  const { getAssignmentStatus, getFilteredAssignments, processVoiceCommand } = voiceCommands

  useEffect(() => {
    console.log('🎯 StudentAssignments component mounted, fetching assignments...');
    console.log('👤 Current user:', {
      id: user?._id,
      name: user?.name,
      email: user?.email,
      role: user?.role,
      isDisabled: user?.isDisabled
    });
    dispatch(fetchStudentAssignments())

    // Initialize voice control for disabled students
    if (user?.isDisabled) {
      initializeVoiceControl()
    }
  }, [dispatch, user?.isDisabled, initializeVoiceControl])

  // Debug: Log the current state and announce for disabled students
  useEffect(() => {
    console.log('📊 StudentAssignments state:', {
      loading: assignmentsLoading,
      error,
      assignmentsCount: assignments.length,
      user: {
        id: user?._id,
        email: user?.email,
        isDisabled: user?.isDisabled
      },
      assignments: assignments.map(a => ({
        id: a._id,
        quizTitle: a.quiz?.title,
        classroomName: a.classroom?.name,
        assignedStudents: a.assignedStudents?.length || 0
      }))
    });

    // Log detailed error if any
    if (error) {
      console.error('❌ Assignment fetch error:', error);
    }

    // Log if no assignments found
    if (!assignmentsLoading && assignments.length === 0) {
      console.log('⚠️ No assignments found for user');
    }

    // Celebrate when assignments are found for disabled students
    if (!assignmentsLoading && assignments.length > 0 && user?.isDisabled) {
      console.log('🎉 Assignments loaded successfully for disabled student!')
    }

    // Auto-announce assignments for disabled students when they load
    if (user?.isDisabled && !assignmentsLoading && assignments.length > 0 && speechSupported) {
      setTimeout(() => {
        // Only announce if not currently speaking and recognition is ready
        if (!isSpeaking && !speechProcessingRef.current) {
          const filteredAssignments = getFilteredAssignments()
          const pendingCount = filteredAssignments.filter(a => getAssignmentStatus(a).status === 'pending').length
          const completedCount = filteredAssignments.filter(a => getAssignmentStatus(a).status === 'completed').length

          if (filteredAssignments.length > 0) {
            queueSpeech(`Welcome to your accessible quiz center. You have ${filteredAssignments.length} total assignments. ${pendingCount} pending and ${completedCount} completed. Say "read assignments" to hear details or "start quiz" followed by a number to begin.`)
          } else {
            queueSpeech(`Welcome to your accessible quiz center. No assignments are currently available. Please contact your instructor.`)
          }
        }
      }, 5000) // Longer delay to ensure voice control is fully ready
    }
  }, [assignmentsLoading, error, assignments, user?.isDisabled, speechSupported, isSpeaking, speechProcessingRef, getFilteredAssignments, getAssignmentStatus, queueSpeech]);

  // Cleanup voice control on unmount
  useEffect(() => {
    return () => {
      console.log('🧹 Cleaning up voice control...')

      // Stop all voice control activities
      voiceControlState.manuallyStoppedRef.current = true
      voiceControlState.isStartingRef.current = false

      if (voiceControlState.recognitionRef.current) {
        try {
          voiceControlState.recognitionRef.current.stop()
        } catch (error) {
          console.log('⚠️ Error stopping recognition during cleanup:', error)
        }
      }

      if (voiceControlState.synthRef.current) {
        voiceControlState.synthRef.current.cancel()
      }

      // Clear speech queue
      voiceControlState.speechQueueRef.current = []
      voiceControlState.speechProcessingRef.current = false

      if (voiceControlState.mediaStreamRef.current) {
        voiceControlState.mediaStreamRef.current.getTracks().forEach(track => {
          track.stop()
          console.log('🛑 Stopped audio track:', track.label)
        })
      }

      if (voiceControlState.restartTimeoutRef.current) {
        clearTimeout(voiceControlState.restartTimeoutRef.current)
        console.log('🛑 Cleared restart timeout')
      }
    }
  }, [voiceControlState])

  const testMicrophone = async () => {
    try {
      console.log('🧪 Testing microphone...')
      setDebugInfo('Testing microphone...')

      const stream = await requestMicrophoneAccess()
      if (!stream) {
        setVoiceError('Microphone test failed - no access')
        return
      }

      // Create audio context to test audio levels
      const AudioContextClass = window.AudioContext || window.webkitAudioContext
      const audioContext = new AudioContextClass()
      const source = audioContext.createMediaStreamSource(stream)
      const analyser = audioContext.createAnalyser()

      source.connect(analyser)
      analyser.fftSize = 256

      const bufferLength = analyser.frequencyBinCount
      const dataArray = new Uint8Array(bufferLength)

      let testDuration = 3000 // 3 seconds
      let maxVolume = 0

      const checkAudio = () => {
        analyser.getByteFrequencyData(dataArray)
        const volume = Math.max(...dataArray)
        maxVolume = Math.max(maxVolume, volume)

        setDebugInfo(`Testing... Volume: ${volume} (Max: ${maxVolume})`)

        if (testDuration > 0) {
          testDuration -= 100
          setTimeout(checkAudio, 100)
        } else {
          // Test complete
          audioContext.close()

          if (maxVolume > 10) {
            setDebugInfo(`✅ Microphone working! Max volume: ${maxVolume}`)
            queueSpeech('Microphone test successful. Audio is being detected.')
          } else {
            setDebugInfo(`⚠️ Low audio detected. Max volume: ${maxVolume}`)
            queueSpeech('Microphone test shows low audio. Please speak louder or check device.')
          }
        }
      }

      queueSpeech('Microphone test starting. Please say something.')
      checkAudio()

    } catch (error) {
      console.error('❌ Microphone test failed:', error)
      setVoiceError(`Microphone test failed: ${error.message}`)
      setDebugInfo(`Test failed: ${error.message}`)
    }
  }

  const handleResetVoiceControl = () => {
    console.log('🔄 Full voice control reset requested')
    stopListening()
    stopSpeaking()
    restartAttemptsRef.current = 0
    lastRestartTimeRef.current = 0
    voiceControlState.manuallyStoppedRef.current = false
    isStartingRef.current = false
    speechQueueRef.current = []
    speechProcessingRefFromState.current = false
    setVoiceError('')
    setDebugInfo('Resetting voice control...')
    
    // Reinitialize after a delay
    setTimeout(() => {
      initializeVoiceControl()
    }, 2000)
    
    queueSpeech('Resetting voice control system. Please wait.')
  }

  const getAssignmentStats = () => {
    const total = assignments.length
    const completed = assignments.filter(a => getAssignmentStatus(a).status === 'completed').length
    const pending = assignments.filter(a => getAssignmentStatus(a).status === 'pending').length
    const overdue = assignments.filter(a => getAssignmentStatus(a).status === 'overdue').length

    return { total, completed, pending, overdue }
  }

  if (assignmentsLoading) {
    return (
      <div className={`min-h-screen ${theme.colors.bg.secondary}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex justify-center items-center h-64">
            <div className="text-center">
              <Loader size="lg" />
              <p className={`mt-4 text-lg ${theme.colors.text.secondary}`}>Loading your assignments...</p>
            </div>
          </div>
        </div>
      </div>
    )
  }

  const stats = getAssignmentStats()
  const filteredAssignments = getFilteredAssignments(filter)

  return (
    <div className={`min-h-screen ${theme.colors.bg.secondary}`}>
      {/* Header */}
      <div className={`${theme.colors.bg.card} ${theme.shadows.sm} border-b ${theme.colors.border.primary}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              {/* Only show back button for normal students */}
              {!user?.isDisabled && (
                <Button
                  onClick={() => navigate('/student/dashboard')}
                  className={`${theme.colors.button.secondary} p-2 rounded-lg`}
                >
                  <ArrowLeft className="w-5 h-5" />
                </Button>
              )}
              <div>
                <h1 className={`text-3xl font-bold ${theme.colors.text.primary}`}>
                  {user?.isDisabled ? '♿ Accessible Quiz Center' : 'My Assignments'}
                </h1>
                <p className={`${theme.colors.text.secondary}`}>
                  {user?.isDisabled
                    ? '🎯 Your personalized quiz experience with full accessibility support'
                    : 'Complete your quiz assignments to track progress'
                  }
                </p>
                {user?.isDisabled && (
                  <div className="mt-2 flex items-center space-x-2 text-sm text-purple-600 dark:text-purple-400">
                    <Mic className="w-4 h-4" />
                    <span>Voice control ready • Audio feedback enabled • Extended time available</span>
                  </div>
                )}
              </div>
            </div>

            {/* Voice Control Panel for Disabled Students */}
            <VoiceControlPanel
              user={user}
              voiceControlState={voiceControlState}
              voiceRecognition={voiceRecognition}
              onTestMicrophone={testMicrophone}
              onResetVoiceControl={handleResetVoiceControl}
            />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Assignment Filters */}
        <AssignmentFilters
          filter={filter}
          setFilter={setFilter}
          stats={stats}
          user={user}
        />

        {/* Assignment Grid */}
        {filteredAssignments.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredAssignments.map((assignment, index) => {
              const status = getAssignmentStatus(assignment)
              const isCurrentFocus = user?.isDisabled && voiceControlState.currentFocus === index

              return (
                <AssignmentCard
                  key={assignment._id}
                  assignment={assignment}
                  index={index}
                  status={status}
                  isCurrentFocus={isCurrentFocus}
                  user={user}
                  onStartQuiz={voiceCommands.handleStartQuiz}
                />
              )
            })}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className={`text-lg ${theme.colors.text.secondary}`}>
              No assignments match the current filter.
            </p>
          </div>
        )}
      </div>
    </div>
  )
}

export default StudentAssignments
