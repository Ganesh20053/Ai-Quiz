import { Calendar, Users, Play, Target, Award, BookOpen } from 'lucide-react'
import Button from '../../../components/common/Button'
import { useTheme } from '../../../contexts/ThemeContext'

const AssignmentCard = ({ 
  assignment, 
  index, 
  status, 
  isCurrentFocus, 
  user, 
  onStartQuiz 
}) => {
  const theme = useTheme()
  const StatusIcon = status.icon === 'CheckCircle' ? Award : 
                     status.icon === 'AlertCircle' ? Target : 
                     status.icon === 'Clock' ? Calendar : BookOpen

  const hasSubmission = assignment.quiz?.submissions && assignment.quiz.submissions.length > 0
  const dueDate = assignment.settings?.dueDate ? new Date(assignment.settings.dueDate) : null

  return (
    <div 
      key={assignment._id} 
      className={`${theme.colors.bg.card} rounded-2xl ${theme.shadows.lg} border-l-4 ${status.borderColor} hover:shadow-xl transition-all duration-200 group relative ${
        isCurrentFocus ? 'ring-4 ring-purple-400 ring-opacity-50 bg-purple-50 dark:bg-purple-900/20' : ''
      }`}
    >
      {/* Assignment Header */}
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <div className="flex items-center space-x-3 mb-2">
              <div className={`p-2 rounded-lg ${status.bg}`}>
                <StatusIcon className={`w-5 h-5 ${status.color}`} />
              </div>
              <div>
                <h3 className={`text-xl font-bold ${theme.colors.text.primary} group-hover:text-blue-600 transition-colors`}>
                  {assignment.quiz?.title || 'Untitled Quiz'}
                </h3>
                <p className={`text-sm ${theme.colors.text.secondary}`}>
                  {assignment.classroom?.name || 'Unknown Classroom'}
                </p>
              </div>
            </div>

            {/* Assignment Details */}
            <div className="space-y-2">
              {assignment.quiz?.description && (
                <p className={`text-sm ${theme.colors.text.secondary} line-clamp-2`}>
                  {assignment.quiz.description}
                </p>
              )}

              <div className="flex flex-wrap gap-4 text-sm">
                {assignment.quiz?.questions && (
                  <div className="flex items-center space-x-1">
                    <BookOpen className="w-4 h-4 text-blue-500" />
                    <span className={theme.colors.text.secondary}>
                      {assignment.quiz.questions.length} questions
                    </span>
                  </div>
                )}

                {assignment.settings?.timeLimit && (
                  <div className="flex items-center space-x-1">
                    <Calendar className="w-4 h-4 text-orange-500" />
                    <span className={theme.colors.text.secondary}>
                      {assignment.settings.timeLimit} minutes
                    </span>
                  </div>
                )}

                {assignment.assignedStudents && (
                  <div className="flex items-center space-x-1">
                    <Users className="w-4 h-4 text-green-500" />
                    <span className={theme.colors.text.secondary}>
                      {assignment.assignedStudents.length} students
                    </span>
                  </div>
                )}
              </div>

              {dueDate && (
                <div className="flex items-center space-x-1 text-sm">
                  <Calendar className="w-4 h-4 text-red-500" />
                  <span className={theme.colors.text.secondary}>
                    Due: {dueDate.toLocaleDateString()} at {dueDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Status Badge */}
          <div className={`px-3 py-1 rounded-full text-xs font-medium ${status.bg} ${status.color} border ${status.borderColor}`}>
            {status.label}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-700">
          <div className="flex space-x-3">
            {!hasSubmission ? (
              <>
                <Button
                  onClick={() => onStartQuiz(assignment, 'regular')}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium flex items-center space-x-2"
                >
                  <Play className="w-4 h-4" />
                  <span>Start Quiz</span>
                </Button>

                {user?.isDisabled && (
                  <Button
                    onClick={() => onStartQuiz(assignment, 'voice')}
                    className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg font-medium flex items-center space-x-2"
                  >
                    <Target className="w-4 h-4" />
                    <span>Voice Mode</span>
                  </Button>
                )}
              </>
            ) : (
              <div className="flex items-center space-x-2 text-green-600">
                <Award className="w-5 h-5" />
                <span className="font-medium">Completed</span>
              </div>
            )}
          </div>

          {/* Voice Navigation Indicator */}
          {user?.isDisabled && isCurrentFocus && (
            <div className="flex items-center space-x-2 text-purple-600 bg-purple-100 dark:bg-purple-900/30 px-3 py-1 rounded-lg">
              <Target className="w-4 h-4" />
              <span className="text-sm font-medium">Assignment {index + 1}</span>
            </div>
          )}
        </div>

        {/* Accessibility Instructions for Voice Users */}
        {user?.isDisabled && isCurrentFocus && (
          <div className="mt-4 p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg border border-purple-200 dark:border-purple-700">
            <p className="text-sm text-purple-800 dark:text-purple-200">
              🎤 <strong>Voice Commands:</strong> Say "start quiz {index + 1}" to begin this assignment, 
              or "next" / "previous" to navigate between assignments.
            </p>
          </div>
        )}
      </div>
    </div>
  )
}

export default AssignmentCard
