import { CheckCircle, Clock, AlertCircle, BookOpen } from 'lucide-react'
import { useTheme } from '../../../contexts/ThemeContext'

const AssignmentFilters = ({ 
  filter, 
  setFilter, 
  stats, 
  user 
}) => {
  const theme = useTheme()

  const filterOptions = [
    {
      key: 'all',
      label: 'All Assignments',
      count: stats.total,
      icon: BookOpen,
      color: 'text-gray-600',
      bg: 'bg-gray-100',
      activeColor: 'text-white',
      activeBg: 'bg-gray-600'
    },
    {
      key: 'pending',
      label: 'Pending',
      count: stats.pending,
      icon: Clock,
      color: 'text-blue-600',
      bg: 'bg-blue-100',
      activeColor: 'text-white',
      activeBg: 'bg-blue-600'
    },
    {
      key: 'completed',
      label: 'Completed',
      count: stats.completed,
      icon: CheckCircle,
      color: 'text-green-600',
      bg: 'bg-green-100',
      activeColor: 'text-white',
      activeBg: 'bg-green-600'
    },
    {
      key: 'overdue',
      label: 'Overdue',
      count: stats.overdue,
      icon: AlertCircle,
      color: 'text-red-600',
      bg: 'bg-red-100',
      activeColor: 'text-white',
      activeBg: 'bg-red-600'
    }
  ]

  return (
    <div className={`${theme.colors.bg.card} rounded-2xl ${theme.shadows.sm} p-6 mb-8`}>
      <div className="flex items-center justify-between mb-6">
        <h2 className={`text-xl font-bold ${theme.colors.text.primary}`}>
          Assignment Overview
        </h2>
        {user?.isDisabled && (
          <div className="text-sm text-purple-600 dark:text-purple-400">
            🎤 Say "filter pending" or "filter completed" to organize assignments
          </div>
        )}
      </div>

      {/* Filter Buttons */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {filterOptions.map((option) => {
          const Icon = option.icon
          const isActive = filter === option.key
          
          return (
            <button
              key={option.key}
              onClick={() => setFilter(option.key)}
              className={`p-4 rounded-xl border-2 transition-all duration-200 hover:shadow-md ${
                isActive
                  ? `${option.activeBg} ${option.activeColor} border-transparent shadow-lg`
                  : `${theme.colors.bg.secondary} ${theme.colors.text.primary} border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600`
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <Icon className={`w-5 h-5 ${isActive ? option.activeColor : option.color}`} />
                <span className={`text-2xl font-bold ${isActive ? option.activeColor : option.color}`}>
                  {option.count}
                </span>
              </div>
              <div className={`text-sm font-medium ${isActive ? option.activeColor : theme.colors.text.secondary}`}>
                {option.label}
              </div>
            </button>
          )
        })}
      </div>

      {/* Progress Bar */}
      {stats.total > 0 && (
        <div className="mt-6">
          <div className="flex items-center justify-between mb-2">
            <span className={`text-sm font-medium ${theme.colors.text.secondary}`}>
              Overall Progress
            </span>
            <span className={`text-sm font-bold ${theme.colors.text.primary}`}>
              {Math.round((stats.completed / stats.total) * 100)}% Complete
            </span>
          </div>
          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3">
            <div 
              className="bg-gradient-to-r from-green-500 to-green-600 h-3 rounded-full transition-all duration-500"
              style={{ width: `${(stats.completed / stats.total) * 100}%` }}
            ></div>
          </div>
          <div className="flex justify-between mt-2 text-xs text-gray-500 dark:text-gray-400">
            <span>{stats.completed} completed</span>
            <span>{stats.pending} pending</span>
            {stats.overdue > 0 && <span className="text-red-500">{stats.overdue} overdue</span>}
          </div>
        </div>
      )}

      {/* No Assignments Message */}
      {stats.total === 0 && (
        <div className="text-center py-8">
          <BookOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className={`text-lg font-medium ${theme.colors.text.primary} mb-2`}>
            No Assignments Yet
          </h3>
          <p className={`text-sm ${theme.colors.text.secondary}`}>
            Your assignments will appear here once your instructor creates them.
          </p>
          {user?.isDisabled && (
            <p className="text-sm text-purple-600 dark:text-purple-400 mt-2">
              🎤 Voice control is ready for when assignments are available.
            </p>
          )}
        </div>
      )}
    </div>
  )
}

export default AssignmentFilters
