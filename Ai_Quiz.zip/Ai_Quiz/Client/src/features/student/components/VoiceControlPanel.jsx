import { Mic } from 'lucide-react'
import Button from '../../../components/common/Button'

const VoiceControlPanel = ({
  user,
  voiceControlState,
  voiceRecognition,
  onTestMicrophone,
  onResetVoiceControl
}) => {
  const {
    isListening,
    isSpeaking,
    interimTranscript,
    showDetailedRecognition,
    setShowDetailedRecognition,
    showCommandReference,
    setShowCommandReference,
    stopSpeaking,
    speak,
    enumerateAudioDevices,
    restartAttemptsRef,
    lastRestartTimeRef,
    restartTimeoutRef
  } = voiceControlState

  const { startListening, stopListening } = voiceRecognition

  if (!user?.isDisabled) return null

  return (
    <div className="flex items-center space-x-4">
      {/* Enhanced Voice Status Indicator */}
      <div className={`flex items-center space-x-2 px-4 py-2 rounded-xl border-2 transition-all ${
        isListening
          ? 'bg-green-50 border-green-300 text-green-800 dark:bg-green-900/20 dark:border-green-600 dark:text-green-300'
          : 'bg-gray-50 border-gray-300 text-gray-600 dark:bg-gray-800 dark:border-gray-600 dark:text-gray-400'
      }`}>
        <div className={`w-3 h-3 rounded-full ${isListening ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`}></div>
        <Mic className="w-4 h-4" />
        <div className="flex flex-col">
          <span className="text-sm font-medium">
            {isSpeaking ? '🗣️ Speaking...' :
             isListening ? '👂 Listening...' :
             restartTimeoutRef.current ? '🔄 Restarting...' : '🎤 Voice Ready'}
          </span>
          {isListening && interimTranscript && !isSpeaking && (
            <span className="text-xs opacity-70 max-w-32 truncate">
              "{interimTranscript}"
            </span>
          )}
          {isSpeaking && (
            <span className="text-xs opacity-70 text-blue-600">
              Say "stop speech" to interrupt
            </span>
          )}
          {!isListening && !isSpeaking && restartTimeoutRef.current && (
            <span className="text-xs opacity-70">
              Auto-restart pending...
            </span>
          )}
        </div>
      </div>

      {/* Voice Control Buttons */}
      {isSpeaking && (
        <Button
          onClick={stopSpeaking}
          className="bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-xl font-medium"
        >
          🔇 Stop Speech
        </Button>
      )}

      <Button
        onClick={isListening ? stopListening : startListening}
        className={`px-4 py-2 rounded-xl font-medium transition-all ${
          isListening
            ? 'bg-red-600 hover:bg-red-700 text-white'
            : 'bg-green-600 hover:bg-green-700 text-white'
        }`}
      >
        {isListening ? '🛑 Stop Listening' : '🎤 Start Voice'}
      </Button>

      <Button
        onClick={() => speak('Voice control help: Say "help" for commands, "start quiz" followed by a number to begin a quiz, "next" or "previous" to navigate, or "read assignments" to hear all assignments.')}
        className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl font-medium"
      >
        Help
      </Button>

      <Button
        onClick={() => setShowDetailedRecognition(!showDetailedRecognition)}
        className={`px-4 py-2 rounded-xl font-medium transition-all ${
          showDetailedRecognition
            ? 'bg-indigo-600 hover:bg-indigo-700 text-white'
            : 'bg-gray-600 hover:bg-gray-700 text-white'
        }`}
        title={showDetailedRecognition ? 'Hide detailed recognition display' : 'Show detailed recognition display'}
      >
        {showDetailedRecognition ? '👁️ Hide Details' : '👁️ Show Details'}
      </Button>

      <Button
        onClick={() => setShowCommandReference(!showCommandReference)}
        className={`px-4 py-2 rounded-xl font-medium transition-all ${
          showCommandReference
            ? 'bg-purple-600 hover:bg-purple-700 text-white'
            : 'bg-gray-600 hover:bg-gray-700 text-white'
        }`}
        title={showCommandReference ? 'Hide command reference' : 'Show command reference'}
      >
        {showCommandReference ? '📋 Hide Commands' : '📋 Show Commands'}
      </Button>

      <Button
        onClick={() => {
          enumerateAudioDevices()
          speak('Refreshing audio devices')
        }}
        className="bg-cyan-600 hover:bg-cyan-700 text-white px-4 py-2 rounded-xl font-medium"
        title="Refresh audio devices"
      >
        🔄 Refresh Devices
      </Button>

      <Button
        onClick={onTestMicrophone}
        className="bg-yellow-600 hover:bg-yellow-700 text-white px-4 py-2 rounded-xl font-medium"
        title="Test microphone audio levels"
      >
        🧪 Test Mic
      </Button>

      <Button
        onClick={onResetVoiceControl}
        className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-xl font-medium"
        title="Completely reset voice control system"
      >
        🔄 Reset Voice Control
      </Button>

      {!isListening && (
        <Button
          onClick={() => {
            console.log('🔄 Manual restart requested')
            restartAttemptsRef.current = 0
            lastRestartTimeRef.current = 0
            startListening()
            speak('Restarting voice recognition')
          }}
          className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-xl font-medium"
          title="Manually restart voice recognition"
        >
          🔄 Restart Voice
        </Button>
      )}
    </div>
  )
}

export default VoiceControlPanel
