import React, { useEffect, useState } from 'react';
import { getQuizzes } from '../../api/quiz';
import QuizCard from '../../components/quiz/QuizCard';
import QuizCreator from '../../components/quiz/QuizCreator';

const QuizPage = () => {
  const [quizzes, setQuizzes] = useState([]);
  const [showCreator, setShowCreator] = useState(false);

  const fetchQuizzes = async () => {
    const res = await getQuizzes();
    // If API returns { success, data: { quizzes: [...] } }, adjust accordingly
    if (res.success && res.data && res.data.quizzes) {
      setQuizzes(res.data.quizzes);
    } else if (Array.isArray(res)) {
      setQuizzes(res);
    } else {
      setQuizzes([]);
    }
  };

  useEffect(() => {
    fetchQuizzes();
  }, []);

  return (
    <div className="max-w-2xl mx-auto p-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold">All Quizzes</h2>
        <button
          className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700"
          onClick={() => setShowCreator(true)}
        >
          Create Quiz
        </button>
      </div>
      {showCreator && (
        <QuizCreator
          classroom={{}}
          onQuizCreated={() => {
            setShowCreator(false);
            fetchQuizzes();
          }}
          onClose={() => setShowCreator(false)}
        />
      )}
      <div>
        {quizzes.length === 0 ? (
          <p className="text-gray-500">No quizzes found.</p>
        ) : (
          quizzes.map((quiz) => <QuizCard key={quiz._id} quiz={quiz} />)
        )}
      </div>
    </div>
  );
};

export default QuizPage;
