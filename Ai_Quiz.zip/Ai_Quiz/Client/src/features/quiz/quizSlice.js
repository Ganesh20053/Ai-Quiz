import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import { generateQuizFromOpenAI } from '../../api/openai'

// Async thunks
export const generateQuiz = createAsyncThunk(
  'quiz/generateQuiz',
  async ({ topic, subtopic, difficulty, questionCount = 5 }, { rejectWithValue }) => {
    try {
      const quiz = await generateQuizFromOpenAI({
        topic,
        subtopic,
        difficulty,
        questionCount
      })
      return quiz
    } catch (error) {
      return rejectWithValue(error.message)
    }
  }
)

export const getHint = createAsyncThunk(
  'quiz/getHint',
  async ({ question, options }, { rejectWithValue }) => {
    try {
      const response = await fetch('/api/quiz/hint', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question, options })
      })
      const data = await response.json()
      return data.hint
    } catch (error) {
      return rejectWithValue(error.message)
    }
  }
)

export const getExplanation = createAsyncThunk(
  'quiz/getExplanation',
  async ({ question, correctAnswer, userAnswer }, { rejectWithValue }) => {
    try {
      const response = await fetch('/api/quiz/explanation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question, correctAnswer, userAnswer })
      })
      const data = await response.json()
      return data.explanation
    } catch (error) {
      return rejectWithValue(error.message)
    }
  }
)

const initialState = {
  // Quiz Configuration
  categories: [
    { id: 'science', name: 'Science', icon: '🔬', color: 'bg-blue-500' },
    { id: 'arts', name: 'Arts', icon: '🎨', color: 'bg-purple-500' },
    { id: 'medical', name: 'Medical', icon: '⚕️', color: 'bg-red-500' },
    { id: 'history', name: 'History', icon: '📚', color: 'bg-yellow-500' },
    { id: 'mathematics', name: 'Mathematics', icon: '🔢', color: 'bg-green-500' },
    { id: 'literature', name: 'Literature', icon: '📖', color: 'bg-indigo-500' },
    { id: 'geography', name: 'Geography', icon: '🌍', color: 'bg-teal-500' },
    { id: 'technology', name: 'Technology', icon: '💻', color: 'bg-gray-500' },
  ],
  
  // Current Quiz State
  currentQuiz: {
    id: null,
    title: '',
    topic: '',
    subtopic: '',
    difficulty: 'medium',
    questions: [],
    currentQuestionIndex: 0,
    answers: {},
    startTime: null,
    endTime: null,
    timeSpent: 0,
    score: 0,
    totalQuestions: 0,
  },
  
  // Quiz Session
  isActive: false,
  isPaused: false,
  timeRemaining: 0,
  autoSave: true,
  
  // AI Features
  hints: {},
  explanations: {},
  currentHint: null,
  
  // Voice Features
  isListening: false,
  voiceAnswer: '',
  pronunciationFeedback: null,
  
  // Results & Analytics
  results: {
    score: 0,
    percentage: 0,
    correctAnswers: 0,
    wrongAnswers: 0,
    skippedAnswers: 0,
    timePerQuestion: [],
    difficultyBreakdown: {},
    topicBreakdown: {},
  },
  
  // Mock Exam Features
  mockExams: [],
  currentMockExam: null,
  
  // Saved Quizzes
  savedQuizzes: [],
  resumableQuizzes: [],
  
  // Loading States
  loading: false,
  generating: false,
  error: null,
  hintLoading: false,
  explanationLoading: false,
}

const quizSlice = createSlice({
  name: 'quiz',
  initialState,
  reducers: {
    // Quiz Setup
    setQuizConfig: (state, action) => {
      const { topic, subtopic, difficulty, questionCount } = action.payload
      state.currentQuiz.topic = topic
      state.currentQuiz.subtopic = subtopic
      state.currentQuiz.difficulty = difficulty
      state.currentQuiz.totalQuestions = questionCount
    },
    
    startQuiz: (state, action) => {
      state.isActive = true
      state.isPaused = false
      state.currentQuiz.startTime = new Date().toISOString()
      state.currentQuiz.id = action.payload?.id || Date.now().toString()
      
      if (action.payload?.timeLimit) {
        state.timeRemaining = action.payload.timeLimit * 60 // Convert to seconds
      }
    },
    
    pauseQuiz: (state) => {
      state.isPaused = true
    },
    
    resumeQuiz: (state) => {
      state.isPaused = false
    },
    
    endQuiz: (state) => {
      state.isActive = false
      state.isPaused = false
      state.currentQuiz.endTime = new Date().toISOString()
      
      // Calculate results
      const answers = state.currentQuiz.answers
      const questions = state.currentQuiz.questions
      let correctCount = 0
      
      questions.forEach((question, index) => {
        if (answers[index] === question.correctAnswer) {
          correctCount++
        }
      })
      
      state.results.correctAnswers = correctCount
      state.results.wrongAnswers = questions.length - correctCount - state.results.skippedAnswers
      state.results.score = correctCount
      state.results.percentage = Math.round((correctCount / questions.length) * 100)
      
      // Calculate time spent
      const startTime = new Date(state.currentQuiz.startTime)
      const endTime = new Date(state.currentQuiz.endTime)
      state.currentQuiz.timeSpent = Math.round((endTime - startTime) / 1000 / 60) // in minutes
    },
    
    // Question Navigation
    nextQuestion: (state) => {
      if (state.currentQuiz.currentQuestionIndex < state.currentQuiz.questions.length - 1) {
        state.currentQuiz.currentQuestionIndex++
      }
    },
    
    previousQuestion: (state) => {
      if (state.currentQuiz.currentQuestionIndex > 0) {
        state.currentQuiz.currentQuestionIndex--
      }
    },
    
    goToQuestion: (state, action) => {
      const index = action.payload
      if (index >= 0 && index < state.currentQuiz.questions.length) {
        state.currentQuiz.currentQuestionIndex = index
      }
    },
    
    // Answer Management
    setAnswer: (state, action) => {
      const { questionIndex, answer } = action.payload
      state.currentQuiz.answers[questionIndex] = answer
      
      // Auto-save if enabled
      if (state.autoSave) {
        // This would trigger a save to localStorage or API
      }
    },
    
    clearAnswer: (state, action) => {
      const questionIndex = action.payload
      delete state.currentQuiz.answers[questionIndex]
    },
    
    // Timer Management
    updateTimer: (state, action) => {
      const timeRemaining = action.payload
      state.timeRemaining = Math.max(0, timeRemaining)
      
      if (state.timeRemaining === 0 && state.isActive) {
        // Auto-submit quiz when time runs out
        quizSlice.caseReducers.endQuiz(state)
      }
    },
    
    // Voice Features
    setListening: (state, action) => {
      state.isListening = action.payload
    },
    
    setVoiceAnswer: (state, action) => {
      state.voiceAnswer = action.payload
    },
    
    setPronunciationFeedback: (state, action) => {
      state.pronunciationFeedback = action.payload
    },
    
    // AI Features
    setCurrentHint: (state, action) => {
      state.currentHint = action.payload
    },
    
    clearCurrentHint: (state) => {
      state.currentHint = null
    },
    
    // Quiz Management
    saveQuiz: (state) => {
      const quizToSave = {
        ...state.currentQuiz,
        savedAt: new Date().toISOString(),
      }
      
      // Remove from resumable and add to saved
      state.resumableQuizzes = state.resumableQuizzes.filter(q => q.id !== quizToSave.id)
      state.savedQuizzes.push(quizToSave)
    },
    
    loadQuiz: (state, action) => {
      const quiz = action.payload
      state.currentQuiz = { ...quiz }
      state.isActive = false
      state.isPaused = false
    },
    
    deleteQuiz: (state, action) => {
      const quizId = action.payload
      state.savedQuizzes = state.savedQuizzes.filter(q => q.id !== quizId)
      state.resumableQuizzes = state.resumableQuizzes.filter(q => q.id !== quizId)
    },
    
    // Mock Exam Features
    startMockExam: (state, action) => {
      const mockExam = action.payload
      state.currentMockExam = mockExam
      state.currentQuiz = {
        ...initialState.currentQuiz,
        ...mockExam,
        id: `mock_${Date.now()}`,
      }
      quizSlice.caseReducers.startQuiz(state, { payload: { timeLimit: mockExam.timeLimit } })
    },
    
    // Utility
    resetQuiz: (state) => {
      state.currentQuiz = { ...initialState.currentQuiz }
      state.isActive = false
      state.isPaused = false
      state.timeRemaining = 0
      state.results = { ...initialState.results }
      state.currentHint = null
      state.hints = {}
      state.explanations = {}
    },
    
    clearError: (state) => {
      state.error = null
    },
  },
  
  extraReducers: (builder) => {
    builder
      // Generate Quiz
      .addCase(generateQuiz.pending, (state) => {
        state.generating = true
        state.error = null
      })
      .addCase(generateQuiz.fulfilled, (state, action) => {
        state.generating = false
        state.currentQuiz.questions = action.payload.questions
        state.currentQuiz.title = action.payload.title
        state.currentQuiz.totalQuestions = action.payload.questions.length
      })
      .addCase(generateQuiz.rejected, (state, action) => {
        state.generating = false
        state.error = action.payload
      })
      
      // Get Hint
      .addCase(getHint.pending, (state) => {
        state.hintLoading = true
      })
      .addCase(getHint.fulfilled, (state, action) => {
        state.hintLoading = false
        state.currentHint = action.payload
        
        // Store hint for current question
        const questionIndex = state.currentQuiz.currentQuestionIndex
        state.hints[questionIndex] = action.payload
      })
      .addCase(getHint.rejected, (state, action) => {
        state.hintLoading = false
        state.error = action.payload
      })
      
      // Get Explanation
      .addCase(getExplanation.pending, (state) => {
        state.explanationLoading = true
      })
      .addCase(getExplanation.fulfilled, (state, action) => {
        state.explanationLoading = false
        const questionIndex = state.currentQuiz.currentQuestionIndex
        state.explanations[questionIndex] = action.payload
      })
      .addCase(getExplanation.rejected, (state, action) => {
        state.explanationLoading = false
        state.error = action.payload
      })
  },
})

export const {
  setQuizConfig,
  startQuiz,
  pauseQuiz,
  resumeQuiz,
  endQuiz,
  nextQuestion,
  previousQuestion,
  goToQuestion,
  setAnswer,
  clearAnswer,
  updateTimer,
  setListening,
  setVoiceAnswer,
  setPronunciationFeedback,
  setCurrentHint,
  clearCurrentHint,
  saveQuiz,
  loadQuiz,
  deleteQuiz,
  startMockExam,
  resetQuiz,
  clearError,
} = quizSlice.actions

export default quizSlice.reducer