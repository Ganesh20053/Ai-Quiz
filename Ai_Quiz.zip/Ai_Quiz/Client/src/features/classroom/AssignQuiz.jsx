import React, { useState, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { assignQuiz } from './classroomSlice'
import { selectUser } from '../auth/authSlice'
import Button from '../../components/common/Button'
import Modal from '../../components/common/Modal'
import Loader from '../../components/common/Loader'

const AssignQuiz = ({
  isOpen,
  onClose,
  classroom,
  onSuccess,
  title = "Assign Quiz",
  targetStudents = [],
  assignmentType = "all"
}) => {
  const dispatch = useDispatch()
  const user = useSelector(selectUser)
  const { assigningQuiz, error } = useSelector(state => state.classroom)

  const [formData, setFormData] = useState({
    quizId: '',
    assignmentType: assignmentType,
    assignedStudents: targetStudents.map(student => student._id) || [],
    settings: {
      dueDate: '',
      timeLimit: 30,
      allowRetake: false,
      maxAttempts: 1,
      voiceEnabled: assignmentType === 'disabled',
      autoReadQuestions: assignmentType === 'disabled',
      provideAudioFeedback: assignmentType === 'disabled',
      allowVoiceControl: assignmentType === 'disabled'
    },
    instructions: '',
    scheduledFor: '',
    expiresAt: ''
  })

  const [availableQuizzes, setAvailableQuizzes] = useState([])
  const [selectedStudents, setSelectedStudents] = useState([])
  const [loadingQuizzes, setLoadingQuizzes] = useState(false)

  useEffect(() => {
    if (classroom) {
      // Set voice settings based on classroom type
      setFormData(prev => ({
        ...prev,
        settings: {
          ...prev.settings,
          voiceEnabled: classroom.classType === 'disabled' || classroom.classType === 'mixed',
          allowVoiceControl: classroom.classType === 'disabled' || classroom.classType === 'mixed'
        }
      }))
    }
  }, [classroom])

  useEffect(() => {
    // Fetch available quizzes for this teacher
    const fetchQuizzes = async () => {
      try {
        setLoadingQuizzes(true)
        console.log('🔄 Fetching teacher quizzes...')
        const response = await fetch('/api/quizzes/teacher', {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        })

        console.log('📡 Quiz fetch response status:', response.status)

        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`)
        }

        const data = await response.json()
        console.log('📚 Quiz data received:', data)

        // Ensure we always set an array - API returns data.quizzes
        const quizzes = Array.isArray(data.data?.quizzes) ? data.data.quizzes :
                       Array.isArray(data.quizzes) ? data.quizzes :
                       Array.isArray(data.data) ? data.data :
                       Array.isArray(data) ? data : []

        console.log('✅ Setting quizzes:', quizzes)
        setAvailableQuizzes(quizzes)
      } catch (error) {
        console.error('❌ Failed to fetch quizzes:', error)
        // Ensure we always have an array even on error
        setAvailableQuizzes([])
      } finally {
        setLoadingQuizzes(false)
      }
    }

    if (isOpen) {
      fetchQuizzes()
    }
  }, [isOpen])

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target
    
    if (name.startsWith('settings.')) {
      const settingKey = name.split('.')[1]
      setFormData(prev => ({
        ...prev,
        settings: {
          ...prev.settings,
          [settingKey]: type === 'checkbox' ? checked : value
        }
      }))
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: type === 'checkbox' ? checked : value
      }))
    }
  }

  const handleAssignmentTypeChange = (e) => {
    const assignmentType = e.target.value
    setFormData(prev => ({
      ...prev,
      assignmentType,
      assignedStudents: assignmentType === 'custom' ? selectedStudents : []
    }))
  }

  const handleStudentSelection = (studentId) => {
    if (selectedStudents.includes(studentId)) {
      setSelectedStudents(prev => prev.filter(id => id !== studentId))
    } else {
      setSelectedStudents(prev => [...prev, studentId])
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (!formData.quizId) {
      alert('Please select a quiz to assign')
      return
    }

    if (formData.assignmentType === 'custom' && selectedStudents.length === 0) {
      alert('Please select at least one student for custom assignment')
      return
    }

    try {
      const assignmentData = {
        ...formData,
        assignedStudents: formData.assignmentType === 'custom' ? selectedStudents : []
      }

      const result = await dispatch(assignQuiz({
        classroomId: classroom._id,
        quizData: assignmentData
      })).unwrap()

      onSuccess(result.data)
      onClose()
      
      // Reset form
      setFormData({
        quizId: '',
        assignmentType: 'all',
        assignedStudents: [],
        settings: {
          dueDate: '',
          timeLimit: 30,
          allowRetake: false,
          maxAttempts: 1,
          voiceEnabled: classroom?.classType === 'disabled' || classroom?.classType === 'mixed',
          autoReadQuestions: true,
          provideAudioFeedback: true,
          allowVoiceControl: classroom?.classType === 'disabled' || classroom?.classType === 'mixed'
        },
        instructions: '',
        scheduledFor: '',
        expiresAt: ''
      })
      setSelectedStudents([])
    } catch (error) {
      console.error('Failed to assign quiz:', error)
    }
  }

  const getStudentTypeLabel = (studentType) => {
    switch (studentType) {
      case 'regular': return 'Regular Student'
      case 'disabled': return 'Disabled Student'
      default: return 'Unknown'
    }
  }

  const getStudentTypeColor = (studentType) => {
    switch (studentType) {
      case 'regular': return 'bg-green-100 text-green-800'
      case 'disabled': return 'bg-blue-100 text-blue-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={title}
      size="xl"
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Target Students Info */}
        {targetStudents.length > 0 && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="text-sm font-medium text-blue-900 mb-2">
              Assignment Target
            </h4>
            <p className="text-sm text-blue-700">
              This quiz will be assigned to <strong>{targetStudents.length}</strong> student{targetStudents.length !== 1 ? 's' : ''}
              {assignmentType === 'normal' && ' (Normal Students)'}
              {assignmentType === 'disabled' && ' (Students with Disabilities)'}
            </p>
            {assignmentType === 'disabled' && (
              <p className="text-xs text-blue-600 mt-1">
                ✓ Accessibility features will be automatically enabled
              </p>
            )}
          </div>
        )}

        {/* Quiz Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Select Quiz *
          </label>
          <select
            name="quizId"
            value={formData.quizId}
            onChange={handleInputChange}
            required
            disabled={loadingQuizzes}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
          >
            <option value="">
              {loadingQuizzes ? 'Loading quizzes...' : 'Choose a quiz...'}
            </option>
            {Array.isArray(availableQuizzes) && availableQuizzes.map(quiz => (
              <option key={quiz._id} value={quiz._id}>
                {quiz.title} ({quiz.questionCount || quiz.questions?.length || 0} questions)
              </option>
            ))}
            {!loadingQuizzes && (!Array.isArray(availableQuizzes) || availableQuizzes.length === 0) && (
              <option value="" disabled>No quizzes available</option>
            )}
          </select>
        </div>

        {/* Assignment Type */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Assignment Type
          </label>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <label className="flex items-center p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                name="assignmentType"
                value="all"
                checked={formData.assignmentType === 'all'}
                onChange={handleAssignmentTypeChange}
                className="mr-2"
              />
              <div>
                <div className="font-medium text-gray-900">All Students</div>
                <div className="text-sm text-gray-500">Assign to everyone</div>
              </div>
            </label>

            <label className="flex items-center p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                name="assignmentType"
                value="regular"
                checked={formData.assignmentType === 'regular'}
                onChange={handleAssignmentTypeChange}
                className="mr-2"
              />
              <div>
                <div className="font-medium text-gray-900">Regular Students</div>
                <div className="text-sm text-gray-500">Regular students only</div>
              </div>
            </label>

            <label className="flex items-center p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                name="assignmentType"
                value="disabled"
                checked={formData.assignmentType === 'disabled'}
                onChange={handleAssignmentTypeChange}
                className="mr-2"
              />
              <div>
                <div className="font-medium text-gray-900">Disabled Students</div>
                <div className="text-sm text-gray-500">Voice-controlled only</div>
              </div>
            </label>

            <label className="flex items-center p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                name="assignmentType"
                value="custom"
                checked={formData.assignmentType === 'custom'}
                onChange={handleAssignmentTypeChange}
                className="mr-2"
              />
              <div>
                <div className="font-medium text-gray-900">Custom Selection</div>
                <div className="text-sm text-gray-500">Choose specific students</div>
              </div>
            </label>
          </div>
        </div>

        {/* Custom Student Selection */}
        {formData.assignmentType === 'custom' && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Select Students
            </label>
            <div className="max-h-60 overflow-y-auto border border-gray-300 rounded-md p-4">
              {classroom?.students?.map(student => (
                <label key={student.student._id} className="flex items-center p-2 hover:bg-gray-50 rounded">
                  <input
                    type="checkbox"
                    checked={selectedStudents.includes(student.student._id)}
                    onChange={() => handleStudentSelection(student.student._id)}
                    className="mr-3"
                  />
                  <div className="flex-1">
                    <div className="font-medium text-gray-900">{student.student.name}</div>
                    <div className="text-sm text-gray-500">{student.student.email}</div>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStudentTypeColor(student.studentType)}`}>
                    {getStudentTypeLabel(student.studentType)}
                  </span>
                </label>
              ))}
            </div>
          </div>
        )}

        {/* Assignment Settings */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Due Date
            </label>
            <input
              type="datetime-local"
              name="settings.dueDate"
              value={formData.settings.dueDate}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Time Limit (minutes)
            </label>
            <input
              type="number"
              name="settings.timeLimit"
              value={formData.settings.timeLimit}
              onChange={handleInputChange}
              min="1"
              max="180"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Max Attempts
            </label>
            <input
              type="number"
              name="settings.maxAttempts"
              value={formData.settings.maxAttempts}
              onChange={handleInputChange}
              min="1"
              max="10"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Scheduled For
            </label>
            <input
              type="datetime-local"
              name="scheduledFor"
              value={formData.scheduledFor}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Voice Settings for Disabled/Mixed Classes */}
        {(classroom?.classType === 'disabled' || classroom?.classType === 'mixed') && (
          <div className="bg-blue-50 p-4 rounded-lg">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Voice Accessibility Settings</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  name="settings.voiceEnabled"
                  checked={formData.settings.voiceEnabled}
                  onChange={handleInputChange}
                  className="mr-2"
                />
                <span className="text-sm font-medium text-gray-700">Enable Voice Features</span>
              </label>

              <label className="flex items-center">
                <input
                  type="checkbox"
                  name="settings.autoReadQuestions"
                  checked={formData.settings.autoReadQuestions}
                  onChange={handleInputChange}
                  className="mr-2"
                />
                <span className="text-sm font-medium text-gray-700">Auto-read Questions</span>
              </label>

              <label className="flex items-center">
                <input
                  type="checkbox"
                  name="settings.provideAudioFeedback"
                  checked={formData.settings.provideAudioFeedback}
                  onChange={handleInputChange}
                  className="mr-2"
                />
                <span className="text-sm font-medium text-gray-700">Provide Audio Feedback</span>
              </label>

              <label className="flex items-center">
                <input
                  type="checkbox"
                  name="settings.allowVoiceControl"
                  checked={formData.settings.allowVoiceControl}
                  onChange={handleInputChange}
                  className="mr-2"
                />
                <span className="text-sm font-medium text-gray-700">Allow Voice Control</span>
              </label>
            </div>
          </div>
        )}

        {/* General Settings */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <label className="flex items-center">
            <input
              type="checkbox"
              name="settings.allowRetake"
              checked={formData.settings.allowRetake}
              onChange={handleInputChange}
              className="mr-2"
            />
            <span className="text-sm font-medium text-gray-700">Allow Retakes</span>
          </label>
        </div>

        {/* Instructions */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Instructions
          </label>
          <textarea
            name="instructions"
            value={formData.instructions}
            onChange={handleInputChange}
            rows="3"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="Enter assignment instructions..."
          />
        </div>

        {/* Error Display */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <p className="text-red-800">{error}</p>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex justify-end space-x-4">
          <Button
            type="button"
            onClick={onClose}
            className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={assigningQuiz}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
          >
            {assigningQuiz ? <Loader size="sm" /> : 'Assign Quiz'}
          </Button>
        </div>
      </form>
    </Modal>
  )
}

export default AssignQuiz
