import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'

// Async thunks for API calls
export const fetchClassrooms = createAsyncThunk(
  'classroom/fetchClassrooms',
  async (teacherId, { rejectWithValue }) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/classroom', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      return data;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
)

export const createClassroom = createAsyncThunk(
  'classroom/createClassroom',
  async (classroomData, { rejectWithValue }) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/classroom', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(classroomData)
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      return data;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
)

export const addStudentToClassroom = createAsyncThunk(
  'classroom/addStudent',
  async ({ classroomId, studentIds, studentType = 'regular' }, { rejectWithValue }) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/classroom/${classroomId}/students`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ studentIds, studentType })
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      return data;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
)

export const assignQuiz = createAsyncThunk(
  'classroom/assignQuiz',
  async ({ classroomId, quizData }, { rejectWithValue }) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/classroom/${classroomId}/assign-quiz`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(quizData)
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      return data;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
)

export const fetchClassroomAnalytics = createAsyncThunk(
  'classroom/fetchAnalytics',
  async (classroomId, { rejectWithValue }) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/classroom/${classroomId}/analytics`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      return data;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
)

export const fetchClassroomAssignments = createAsyncThunk(
  'classroom/fetchAssignments',
  async (classroomId, { rejectWithValue }) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/classroom/${classroomId}/assignments`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      return data;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
)

export const fetchStudentAssignments = createAsyncThunk(
  'classroom/fetchStudentAssignments',
  async (_, { rejectWithValue }) => {
    try {
      console.log('🔄 Fetching student assignments...');
      const token = localStorage.getItem('token');
      console.log('🔑 Token:', token ? 'exists' : 'missing');

      const response = await fetch('/api/classroom/student/assignments', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      console.log('📡 Response status:', response.status);
      console.log('📡 Response ok:', response.ok);

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Response error:', errorText);
        throw new Error(`HTTP error! status: ${response.status} - ${errorText}`);
      }

      const data = await response.json();
      console.log('✅ Assignments data received:', data);
      return data;
    } catch (error) {
      console.error('❌ fetchStudentAssignments error:', error);
      return rejectWithValue(error.message);
    }
  }
)

const initialState = {
  // Classroom Management
  classrooms: {
    all: [],
    regular: [],
    disabled: [],
    mixed: []
  },
  currentClassroom: null,
  
  // Students Management
  students: [],
  regularStudents: [],
  disabledStudents: [],
  selectedStudents: [],
  
  // Quiz Assignment
  assignments: [],
  assignedQuizzes: [],
  quizTemplates: [],
  
  // Analytics & Performance
  analytics: {
    classroom: {},
    quizzes: {},
    assignments: {},
    studentPerformance: {}
  },
  
  // Staff Dashboard
  recentActivity: [],
  notifications: [],
  
  // Quiz Creation
  customQuizzes: [],
  aiGeneratedQuizzes: [],
  
  // Email & Communication
  emailHistory: [],
  pendingEmails: [],
  
  // Loading States
  loading: false,
  studentsLoading: false,
  analyticsLoading: false,
  assigningQuiz: false,
  assignmentsLoading: false,
  error: null,
}

const classroomSlice = createSlice({
  name: 'classroom',
  initialState,
  reducers: {
    // Classroom Management
    setCurrentClassroom: (state, action) => {
      state.currentClassroom = action.payload
    },
    
    updateClassroom: (state, action) => {
      const { id, updates } = action.payload
      const classroomIndex = state.classrooms.all.findIndex(c => c.id === id)
      if (classroomIndex !== -1) {
        state.classrooms.all[classroomIndex] = { ...state.classrooms.all[classroomIndex], ...updates }
      }
    },
    
    deleteClassroom: (state, action) => {
      const classroomId = action.payload
      state.classrooms.all = state.classrooms.all.filter(c => c.id !== classroomId)
      state.classrooms.regular = state.classrooms.regular.filter(c => c.id !== classroomId)
      state.classrooms.disabled = state.classrooms.disabled.filter(c => c.id !== classroomId)
      state.classrooms.mixed = state.classrooms.mixed.filter(c => c.id !== classroomId)
      if (state.currentClassroom?.id === classroomId) {
        state.currentClassroom = null
      }
    },
    
    // Student Management
    setStudents: (state, action) => {
      state.students = action.payload
      state.regularStudents = action.payload.filter(s => s.studentType === 'regular')
      state.disabledStudents = action.payload.filter(s => s.studentType === 'disabled')
    },
    
    addStudent: (state, action) => {
      const student = action.payload
      if (!state.students.find(s => s.id === student.id)) {
        state.students.push(student)
        if (student.studentType === 'regular') {
          state.regularStudents.push(student)
        } else if (student.studentType === 'disabled') {
          state.disabledStudents.push(student)
        }
      }
    },
    
    removeStudent: (state, action) => {
      const studentId = action.payload
      state.students = state.students.filter(s => s.id !== studentId)
      state.regularStudents = state.regularStudents.filter(s => s.id !== studentId)
      state.disabledStudents = state.disabledStudents.filter(s => s.id !== studentId)
      state.selectedStudents = state.selectedStudents.filter(id => id !== studentId)
    },
    
    selectStudent: (state, action) => {
      const studentId = action.payload
      if (!state.selectedStudents.includes(studentId)) {
        state.selectedStudents.push(studentId)
      }
    },
    
    deselectStudent: (state, action) => {
      const studentId = action.payload
      state.selectedStudents = state.selectedStudents.filter(id => id !== studentId)
    },
    
    selectAllStudents: (state) => {
      state.selectedStudents = state.students.map(s => s.id)
    },
    
    deselectAllStudents: (state) => {
      state.selectedStudents = []
    },
    
    // Assignment Management
    setAssignments: (state, action) => {
      state.assignments = action.payload
    },
    
    addAssignment: (state, action) => {
      state.assignments.unshift(action.payload)
    },
    
    updateAssignment: (state, action) => {
      const { id, updates } = action.payload
      const assignmentIndex = state.assignments.findIndex(a => a.id === id)
      if (assignmentIndex !== -1) {
        state.assignments[assignmentIndex] = { ...state.assignments[assignmentIndex], ...updates }
      }
    },
    
    removeAssignment: (state, action) => {
      const assignmentId = action.payload
      state.assignments = state.assignments.filter(a => a.id !== assignmentId)
    },
    
    // Quiz Management
    addCustomQuiz: (state, action) => {
      const quiz = {
        ...action.payload,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
        type: 'custom'
      }
      state.customQuizzes.push(quiz)
    },
    
    updateQuiz: (state, action) => {
      const { id, updates } = action.payload
      const customIndex = state.customQuizzes.findIndex(q => q.id === id)
      const aiIndex = state.aiGeneratedQuizzes.findIndex(q => q.id === id)
      
      if (customIndex !== -1) {
        state.customQuizzes[customIndex] = { ...state.customQuizzes[customIndex], ...updates }
      } else if (aiIndex !== -1) {
        state.aiGeneratedQuizzes[aiIndex] = { ...state.aiGeneratedQuizzes[aiIndex], ...updates }
      }
    },
    
    deleteQuiz: (state, action) => {
      const quizId = action.payload
      state.customQuizzes = state.customQuizzes.filter(q => q.id !== quizId)
      state.aiGeneratedQuizzes = state.aiGeneratedQuizzes.filter(q => q.id !== quizId)
    },
    
    addAIQuiz: (state, action) => {
      const quiz = {
        ...action.payload,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
        type: 'ai-generated'
      }
      state.aiGeneratedQuizzes.push(quiz)
    },
    
    // Analytics
    updateAnalytics: (state, action) => {
      state.analytics = { ...state.analytics, ...action.payload }
    },
    
    addPerformanceData: (state, action) => {
      const { studentId, quizId, score, timeSpent, subject } = action.payload
      
      // Update subject performance
      if (!state.analytics.subjectPerformance[subject]) {
        state.analytics.subjectPerformance[subject] = {
          totalAttempts: 0,
          averageScore: 0,
          totalScore: 0
        }
      }
      
      const subjectData = state.analytics.subjectPerformance[subject]
      subjectData.totalAttempts += 1
      subjectData.totalScore += score
      subjectData.averageScore = Math.round(subjectData.totalScore / subjectData.totalAttempts)
      
      // Update weekly progress
      const today = new Date().toISOString().split('T')[0]
      const todayProgress = state.analytics.weeklyProgress.find(p => p.date === today)
      
      if (todayProgress) {
        todayProgress.quizzes += 1
        todayProgress.averageScore = Math.round((todayProgress.averageScore + score) / 2)
      } else {
        state.analytics.weeklyProgress.push({
          date: today,
          quizzes: 1,
          averageScore: score,
          activeStudents: 1
        })
      }
      
      // Keep only last 7 days
      if (state.analytics.weeklyProgress.length > 7) {
        state.analytics.weeklyProgress = state.analytics.weeklyProgress.slice(-7)
      }
    },
    
    // Communication
    addEmailToHistory: (state, action) => {
      const email = {
        ...action.payload,
        id: Date.now().toString(),
        sentAt: new Date().toISOString(),
      }
      state.emailHistory.unshift(email)
      
      // Keep only last 100 emails
      if (state.emailHistory.length > 100) {
        state.emailHistory = state.emailHistory.slice(0, 100)
      }
    },
    
    addNotification: (state, action) => {
      const notification = {
        ...action.payload,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
        read: false,
      }
      state.notifications.unshift(notification)
      
      // Keep only last 50 notifications
      if (state.notifications.length > 50) {
        state.notifications = state.notifications.slice(0, 50)
      }
    },
    
    markNotificationAsRead: (state, action) => {
      const notificationId = action.payload
      const notification = state.notifications.find(n => n.id === notificationId)
      if (notification) {
        notification.read = true
      }
    },
    
    markAllNotificationsAsRead: (state) => {
      state.notifications.forEach(n => n.read = true)
    },
    
    // Activity Tracking
    addActivity: (state, action) => {
      const activity = {
        ...action.payload,
        id: Date.now().toString(),
        timestamp: new Date().toISOString(),
      }
      state.recentActivity.unshift(activity)
      
      // Keep only last 50 activities
      if (state.recentActivity.length > 50) {
        state.recentActivity = state.recentActivity.slice(0, 50)
      }
    },
    
    // Utility
    clearError: (state) => {
      state.error = null
    },
    
    resetClassroomState: (state) => {
      state.currentClassroom = null
      state.students = []
      state.regularStudents = []
      state.disabledStudents = []
      state.selectedStudents = []
      state.analytics = initialState.analytics
    },
  },
  
  extraReducers: (builder) => {
    builder
      // Fetch Classrooms
      .addCase(fetchClassrooms.pending, (state) => {
        state.loading = true
        state.error = null
      })
      .addCase(fetchClassrooms.fulfilled, (state, action) => {
        state.loading = false
        // Handle different possible response structures
        if (action.payload.success && action.payload.data) {
          if (action.payload.data.classrooms) {
            // If response has classrooms property
            state.classrooms = action.payload.data.classrooms
          } else if (Array.isArray(action.payload.data)) {
            // If response is directly an array
            state.classrooms = {
              all: action.payload.data,
              regular: action.payload.data.filter(c => c.classType === 'regular'),
              disabled: action.payload.data.filter(c => c.classType === 'disabled'),
              mixed: action.payload.data.filter(c => c.classType === 'mixed')
            }
          } else {
            // Fallback to empty structure
            state.classrooms = {
              all: [],
              regular: [],
              disabled: [],
              mixed: []
            }
          }
        } else {
          // If no success or data, set empty structure
          state.classrooms = {
            all: [],
            regular: [],
            disabled: [],
            mixed: []
          }
        }
      })
      .addCase(fetchClassrooms.rejected, (state, action) => {
        state.loading = false
        state.error = action.payload
        // Ensure classrooms structure is maintained even on error
        state.classrooms = {
          all: [],
          regular: [],
          disabled: [],
          mixed: []
        }
      })
      
      // Create Classroom
      .addCase(createClassroom.pending, (state) => {
        state.loading = true
        state.error = null
      })
      .addCase(createClassroom.fulfilled, (state, action) => {
        state.loading = false
        const newClassroom = action.payload.data
        state.classrooms.all.push(newClassroom)
        
        // Add to appropriate category
        if (newClassroom.classType === 'regular') {
          state.classrooms.regular.push(newClassroom)
        } else if (newClassroom.classType === 'disabled') {
          state.classrooms.disabled.push(newClassroom)
        } else if (newClassroom.classType === 'mixed') {
          state.classrooms.mixed.push(newClassroom)
        }
        
        state.currentClassroom = newClassroom
      })
      .addCase(createClassroom.rejected, (state, action) => {
        state.loading = false
        state.error = action.payload
      })
      
      // Add Student
      .addCase(addStudentToClassroom.pending, (state) => {
        state.studentsLoading = true
        state.error = null
      })
      .addCase(addStudentToClassroom.fulfilled, (state, action) => {
        state.studentsLoading = false
        const addedStudents = action.payload.data.addedStudents
        addedStudents.forEach(student => {
          state.students.push(student)
          if (student.studentType === 'regular') {
            state.regularStudents.push(student)
          } else if (student.studentType === 'disabled') {
            state.disabledStudents.push(student)
          }
        })
        
        // Add activity
        state.recentActivity.unshift({
          type: 'student_added',
          message: `${addedStudents.length} students added to classroom`,
          timestamp: new Date().toISOString(),
        })
      })
      .addCase(addStudentToClassroom.rejected, (state, action) => {
        state.studentsLoading = false
        state.error = action.payload
      })
      
      // Assign Quiz
      .addCase(assignQuiz.pending, (state) => {
        state.assigningQuiz = true
        state.error = null
      })
      .addCase(assignQuiz.fulfilled, (state, action) => {
        state.assigningQuiz = false
        state.assignments.unshift(action.payload.data)
        
        // Add email to history
        state.emailHistory.unshift({
          id: Date.now().toString(),
          type: 'quiz_assignment',
          recipients: action.payload.data.totalAssignedStudents,
          subject: `New Quiz Assigned: ${action.payload.data.quiz.title}`,
          sentAt: new Date().toISOString(),
        })
      })
      .addCase(assignQuiz.rejected, (state, action) => {
        state.assigningQuiz = false
        state.error = action.payload
      })
      
      // Fetch Analytics
      .addCase(fetchClassroomAnalytics.pending, (state) => {
        state.analyticsLoading = true
        state.error = null
      })
      .addCase(fetchClassroomAnalytics.fulfilled, (state, action) => {
        state.analyticsLoading = false
        state.analytics = action.payload.data
      })
      .addCase(fetchClassroomAnalytics.rejected, (state, action) => {
        state.analyticsLoading = false
        state.error = action.payload
      })
      
      // Fetch Assignments
      .addCase(fetchClassroomAssignments.pending, (state) => {
        state.assignmentsLoading = true
        state.error = null
      })
      .addCase(fetchClassroomAssignments.fulfilled, (state, action) => {
        state.assignmentsLoading = false
        state.assignments = action.payload.data
      })
      .addCase(fetchClassroomAssignments.rejected, (state, action) => {
        state.assignmentsLoading = false
        state.error = action.payload
      })
      
      // Fetch Student Assignments
      .addCase(fetchStudentAssignments.pending, (state) => {
        state.assignmentsLoading = true
        state.error = null
      })
      .addCase(fetchStudentAssignments.fulfilled, (state, action) => {
        state.assignmentsLoading = false
        state.assignments = action.payload.data
      })
      .addCase(fetchStudentAssignments.rejected, (state, action) => {
        state.assignmentsLoading = false
        state.error = action.payload
      })
  },
})

export const {
  setCurrentClassroom,
  updateClassroom,
  deleteClassroom,
  setStudents,
  addStudent,
  removeStudent,
  selectStudent,
  deselectStudent,
  selectAllStudents,
  deselectAllStudents,
  setAssignments,
  addAssignment,
  updateAssignment,
  removeAssignment,
  addCustomQuiz,
  updateQuiz,
  deleteQuiz,
  addAIQuiz,
  updateAnalytics,
  addPerformanceData,
  addEmailToHistory,
  addNotification,
  markNotificationAsRead,
  markAllNotificationsAsRead,
  addActivity,
  clearError,
  resetClassroomState,
} = classroomSlice.actions

export default classroomSlice.reducer