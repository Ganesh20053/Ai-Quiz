import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { createClassroom } from './classroomSlice'
import { selectUser } from '../auth/authSlice'
import Button from '../../components/common/Button'
import Modal from '../../components/common/Modal'
import Loader from '../../components/common/Loader'

const AddClassroom = ({ isOpen, onClose, onSuccess }) => {
  const dispatch = useDispatch()
  const user = useSelector(selectUser)
  const { loading, error } = useSelector(state => state.classroom)

  const [formData, setFormData] = useState({
    name: '',
    subject: '',
    description: '',
    grade: '',
    academicYear: '',
    semester: '1st',
    maxStudents: 50,
    classType: 'regular',
    voiceSettings: {
      enabled: false,
      autoReadQuestions: true,
      voiceCommands: true,
      speechRate: 0.9,
      voiceLanguage: 'en-US'
    }
  })

  const handleInputChange = (e) => {
    const { name, value } = e.target
    if (name.startsWith('voiceSettings.')) {
      const settingKey = name.split('.')[1]
      setFormData(prev => ({
        ...prev,
        voiceSettings: {
          ...prev.voiceSettings,
          [settingKey]: value === 'true' ? true : value === 'false' ? false : value
        }
      }))
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: value
      }))
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    try {
      const result = await dispatch(createClassroom(formData)).unwrap()
      onSuccess(result.data)
      onClose()
      setFormData({
        name: '',
        subject: '',
        description: '',
        grade: '',
        academicYear: '',
        semester: '1st',
        maxStudents: 50,
        classType: 'regular',
        voiceSettings: {
          enabled: false,
          autoReadQuestions: true,
          voiceCommands: true,
          speechRate: 0.9,
          voiceLanguage: 'en-US'
        }
      })
    } catch (error) {
      console.error('Failed to create classroom:', error)
    }
  }

  const handleClassTypeChange = (e) => {
    const classType = e.target.value
    setFormData(prev => ({
      ...prev,
      classType,
      voiceSettings: {
        ...prev.voiceSettings,
        enabled: classType === 'disabled' || classType === 'mixed'
      }
    }))
  }

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Create New Classroom"
      size="lg"
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Basic Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Classroom Name *
            </label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter classroom name"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Subject *
            </label>
            <input
              type="text"
              name="subject"
              value={formData.subject}
              onChange={handleInputChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="e.g., Mathematics, Science"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Grade *
            </label>
            <input
              type="text"
              name="grade"
              value={formData.grade}
              onChange={handleInputChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="e.g., Grade 10, Class 12"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Academic Year *
            </label>
            <input
              type="text"
              name="academicYear"
              value={formData.academicYear}
              onChange={handleInputChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="e.g., 2024-2025"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Semester
            </label>
            <select
              name="semester"
              value={formData.semester}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="1st">1st Semester</option>
              <option value="2nd">2nd Semester</option>
              <option value="3rd">3rd Semester</option>
              <option value="4th">4th Semester</option>
              <option value="5th">5th Semester</option>
              <option value="6th">6th Semester</option>
              <option value="7th">7th Semester</option>
              <option value="8th">8th Semester</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Max Students
            </label>
            <input
              type="number"
              name="maxStudents"
              value={formData.maxStudents}
              onChange={handleInputChange}
              min="1"
              max="200"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Description */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Description
          </label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleInputChange}
            rows="3"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="Enter classroom description..."
          />
        </div>

        {/* Class Type Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Class Type *
          </label>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <label className="flex items-center p-4 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                name="classType"
                value="regular"
                checked={formData.classType === 'regular'}
                onChange={handleClassTypeChange}
                className="mr-3"
              />
              <div>
                <div className="font-medium text-gray-900">Regular Class</div>
                <div className="text-sm text-gray-500">Standard classroom for regular students</div>
              </div>
            </label>

            <label className="flex items-center p-4 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                name="classType"
                value="disabled"
                checked={formData.classType === 'disabled'}
                onChange={handleClassTypeChange}
                className="mr-3"
              />
              <div>
                <div className="font-medium text-gray-900">Disabled Students</div>
                <div className="text-sm text-gray-500">Voice-controlled quizzes for disabled students</div>
              </div>
            </label>

            <label className="flex items-center p-4 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                name="classType"
                value="mixed"
                checked={formData.classType === 'mixed'}
                onChange={handleClassTypeChange}
                className="mr-3"
              />
              <div>
                <div className="font-medium text-gray-900">Mixed Class</div>
                <div className="text-sm text-gray-500">Both regular and disabled students</div>
              </div>
            </label>
          </div>
        </div>

        {/* Voice Settings for Disabled/Mixed Classes */}
        {(formData.classType === 'disabled' || formData.classType === 'mixed') && (
          <div className="bg-blue-50 p-4 rounded-lg">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Voice Accessibility Settings</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    name="voiceSettings.enabled"
                    checked={formData.voiceSettings.enabled}
                    onChange={handleInputChange}
                    className="mr-2"
                  />
                  <span className="text-sm font-medium text-gray-700">Enable Voice Features</span>
                </label>
              </div>

              <div>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    name="voiceSettings.autoReadQuestions"
                    checked={formData.voiceSettings.autoReadQuestions}
                    onChange={handleInputChange}
                    className="mr-2"
                  />
                  <span className="text-sm font-medium text-gray-700">Auto-read Questions</span>
                </label>
              </div>

              <div>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    name="voiceSettings.voiceCommands"
                    checked={formData.voiceSettings.voiceCommands}
                    onChange={handleInputChange}
                    className="mr-2"
                  />
                  <span className="text-sm font-medium text-gray-700">Enable Voice Commands</span>
                </label>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Speech Rate
                </label>
                <select
                  name="voiceSettings.speechRate"
                  value={formData.voiceSettings.speechRate}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value={0.5}>Slow (0.5x)</option>
                  <option value={0.7}>Slow-Normal (0.7x)</option>
                  <option value={0.9}>Normal (0.9x)</option>
                  <option value={1.0}>Standard (1.0x)</option>
                  <option value={1.2}>Fast (1.2x)</option>
                  <option value={1.5}>Very Fast (1.5x)</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Voice Language
                </label>
                <select
                  name="voiceSettings.voiceLanguage"
                  value={formData.voiceSettings.voiceLanguage}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="en-US">English (US)</option>
                  <option value="en-GB">English (UK)</option>
                  <option value="es-ES">Spanish</option>
                  <option value="fr-FR">French</option>
                  <option value="de-DE">German</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* Error Display */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <p className="text-red-800">{error}</p>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex justify-end space-x-4">
          <Button
            type="button"
            onClick={onClose}
            className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={loading}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
          >
            {loading ? <Loader size="sm" /> : 'Create Classroom'}
          </Button>
        </div>
      </form>
    </Modal>
  )
}

export default AddClassroom
