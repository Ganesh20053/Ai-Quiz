import axios from 'axios';

export const getQuiz = async (category, difficulty) => {
  try {
    const res = await axios.get(`/api/quiz?category=${category}&difficulty=${difficulty}`);
    return res.data.questions;
  } catch (error) {
    console.error('Quiz Error:', error);
    return [];
  }
};

export const getQuizzes = async () => {
  try {
    const token = localStorage.getItem('token');
    const res = await axios.get('/api/quizzes/teacher', {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return res.data;
  } catch (error) {
    console.error('Get Quizzes Error:', error);
    return { success: false, data: { quizzes: [] } };
  }
};

export const getQuizById = async (quizId) => {
  try {
    const token = localStorage.getItem('token');
    const res = await axios.get(`/api/quizzes/${quizId}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return res.data;
  } catch (error) {
    console.error('Get Quiz By ID Error:', error);
    throw error;
  }
};

export const createQuiz = async (quizData) => {
  try {
    const token = localStorage.getItem('token');
    const res = await axios.post('/api/quizzes', quizData, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return res.data;
  } catch (error) {
    console.error('Create Quiz Error:', error);
    throw error;
  }
};

export const updateQuiz = async (quizId, quizData) => {
  try {
    const token = localStorage.getItem('token');
    const res = await axios.put(`/api/quizzes/${quizId}`, quizData, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return res.data;
  } catch (error) {
    console.error('Update Quiz Error:', error);
    throw error;
  }
};

export const deleteQuiz = async (quizId) => {
  try {
    const token = localStorage.getItem('token');
    const res = await axios.delete(`/api/quizzes/${quizId}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return res.data;
  } catch (error) {
    console.error('Delete Quiz Error:', error);
    throw error;
  }
};
