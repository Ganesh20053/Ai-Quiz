// src/api/openai.js

import axios from 'axios';

/**
 * Generates quiz questions from OpenAI backend
 * @param {string} category
 * @param {string} difficulty
 * @returns {Promise<Array>}
 */
export const generateQuizFromOpenAI = async (category, difficulty) => {
  try {
    const res = await axios.post('/api/openai', { category, difficulty });
    return res.data.questions || [];
  } catch (err) {
    console.error('Failed to generate quiz:', err);
    return [];
  }
};
