import React, { createContext, useContext, useState, useEffect } from 'react';

const ThemeContext = createContext();

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

export const ThemeProvider = ({ children }) => {
  const [isDarkMode, setIsDarkMode] = useState(() => {
    // Check localStorage first, then system preference
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
      return savedTheme === 'dark';
    }
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  useEffect(() => {
    // Update localStorage when theme changes
    localStorage.setItem('theme', isDarkMode ? 'dark' : 'light');
    
    // Update document class for Tailwind dark mode
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const toggleTheme = () => {
    setIsDarkMode(prev => !prev);
  };

  const theme = {
    isDarkMode,
    toggleTheme,
    colors: {
      // Background colors
      bg: {
        primary: isDarkMode ? 'bg-gray-900' : 'bg-white',
        secondary: isDarkMode ? 'bg-gray-800' : 'bg-gray-50',
        tertiary: isDarkMode ? 'bg-gray-700' : 'bg-gray-100',
        card: isDarkMode ? 'bg-gray-800' : 'bg-white',
        overlay: isDarkMode ? 'bg-gray-900/90' : 'bg-white/90',
      },
      // Text colors
      text: {
        primary: isDarkMode ? 'text-white' : 'text-gray-900',
        secondary: isDarkMode ? 'text-gray-300' : 'text-gray-600',
        tertiary: isDarkMode ? 'text-gray-400' : 'text-gray-500',
        muted: isDarkMode ? 'text-gray-500' : 'text-gray-400',
      },
      // Border colors
      border: {
        primary: isDarkMode ? 'border-gray-700' : 'border-gray-200',
        secondary: isDarkMode ? 'border-gray-600' : 'border-gray-300',
        light: isDarkMode ? 'border-gray-800' : 'border-gray-100',
      },
      // Button colors
      button: {
        primary: 'bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white',
        secondary: isDarkMode 
          ? 'bg-gray-700 hover:bg-gray-600 text-gray-200 border border-gray-600' 
          : 'bg-gray-100 hover:bg-gray-200 text-gray-700 border border-gray-300',
        success: 'bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white',
        danger: 'bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700 text-white',
        warning: 'bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-700 hover:to-orange-700 text-white',
      },
      // Status colors
      status: {
        success: isDarkMode ? 'bg-green-900/30 text-green-300 border-green-800' : 'bg-green-100 text-green-700 border-green-200',
        error: isDarkMode ? 'bg-red-900/30 text-red-300 border-red-800' : 'bg-red-100 text-red-700 border-red-200',
        warning: isDarkMode ? 'bg-yellow-900/30 text-yellow-300 border-yellow-800' : 'bg-yellow-100 text-yellow-700 border-yellow-200',
        info: isDarkMode ? 'bg-blue-900/30 text-blue-300 border-blue-800' : 'bg-blue-100 text-blue-700 border-blue-200',
      },
      // Hover effects
      hover: {
        card: isDarkMode ? 'hover:bg-gray-700' : 'hover:bg-gray-50',
        button: isDarkMode ? 'hover:bg-gray-600' : 'hover:bg-gray-200',
      }
    },
    // Gradient backgrounds
    gradients: {
      primary: 'bg-gradient-to-br from-indigo-600 via-purple-600 to-blue-700',
      secondary: 'bg-gradient-to-br from-emerald-600 via-teal-600 to-cyan-700',
      warm: 'bg-gradient-to-br from-orange-600 via-red-600 to-pink-700',
      cool: 'bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-700',
      dark: isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900'
        : 'bg-gradient-to-br from-gray-100 via-white to-gray-50',
    },
    // Shadow styles
    shadows: {
      sm: isDarkMode ? 'shadow-lg shadow-black/20' : 'shadow-sm',
      md: isDarkMode ? 'shadow-xl shadow-black/25' : 'shadow-md',
      lg: isDarkMode ? 'shadow-2xl shadow-black/30' : 'shadow-lg',
      xl: isDarkMode ? 'shadow-2xl shadow-black/40' : 'shadow-xl',
    }
  };

  return (
    <ThemeContext.Provider value={theme}>
      {children}
    </ThemeContext.Provider>
  );
};

export default ThemeProvider;
