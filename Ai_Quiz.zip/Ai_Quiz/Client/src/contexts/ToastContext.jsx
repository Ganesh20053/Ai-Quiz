import React, { createContext, useContext, useState } from 'react';
import Toast from '../components/common/Toast';

const ToastContext = createContext();

export const useToast = () => {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error('useToast must be used within a ToastProvider');
  }
  return context;
};

export const ToastProvider = ({ children }) => {
  const [toasts, setToasts] = useState([]);

  const addToast = ({ type = 'info', title, message, password, email, duration = 8000 }) => {
    const id = Date.now() + Math.random();
    const newToast = {
      id,
      type,
      title,
      message,
      password,
      email,
      duration
    };

    setToasts(prev => [...prev, newToast]);

    // Auto remove after duration
    setTimeout(() => {
      removeToast(id);
    }, duration);

    return id;
  };

  const removeToast = (id) => {
    setToasts(prev => prev.filter(toast => toast.id !== id));
  };

  const showSuccess = (title, message, options = {}) => {
    return addToast({ type: 'success', title, message, ...options });
  };

  const showError = (title, message, options = {}) => {
    return addToast({ type: 'error', title, message, ...options });
  };

  const showWarning = (title, message, options = {}) => {
    return addToast({ type: 'warning', title, message, ...options });
  };

  const showInfo = (title, message, options = {}) => {
    return addToast({ type: 'info', title, message, ...options });
  };

  const showStudentCreated = (studentData) => {
    return addToast({
      type: 'success',
      title: 'Student Created Successfully! 🎉',
      message: `${studentData.name} has been added to the classroom and login credentials have been sent via email.`,
      email: studentData.email,
      password: studentData.password,
      duration: 12000 // Longer duration for important info
    });
  };

  const value = {
    toasts,
    addToast,
    removeToast,
    showSuccess,
    showError,
    showWarning,
    showInfo,
    showStudentCreated
  };

  return (
    <ToastContext.Provider value={value}>
      {children}
      
      {/* Toast Container */}
      <div className="fixed top-4 right-4 z-50 space-y-2">
        {toasts.map((toast, index) => (
          <div
            key={toast.id}
            style={{
              transform: `translateY(${index * 10}px)`,
              zIndex: 1000 - index
            }}
          >
            <Toast
              type={toast.type}
              title={toast.title}
              message={toast.message}
              password={toast.password}
              email={toast.email}
              duration={toast.duration}
              onClose={() => removeToast(toast.id)}
            />
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
};

export default ToastProvider;
