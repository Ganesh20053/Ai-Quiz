import React from 'react'
import { Provider } from 'react-redux'
import { Toaster } from 'react-hot-toast'
import { store } from './store/store'
import AppRouter from './routes/AppRouter'
import AccessibilityProvider from './components/accessibility/AccessibilityProvider'
import ThemeProvider, { useTheme } from './contexts/ThemeContext'
import ToastProvider from './contexts/ToastContext'
import './styles/animations.css'

const AppContent = () => {
  const { isDarkMode } = useTheme();

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
      <AppRouter />
      <Toaster
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: {
            background: isDarkMode ? '#1f2937' : '#363636',
            color: '#fff',
            border: isDarkMode ? '1px solid #374151' : 'none',
          },
          success: {
            style: {
              background: isDarkMode ? '#065f46' : '#10b981',
            },
          },
          error: {
            style: {
              background: isDarkMode ? '#7f1d1d' : '#ef4444',
            },
          },
        }}
      />
    </div>
  );
};

const App = () => {
  return (
    <Provider store={store}>
      <ThemeProvider>
        <ToastProvider>
          <AccessibilityProvider>
            <AppContent />
          </AccessibilityProvider>
        </ToastProvider>
      </ThemeProvider>
    </Provider>
  )
}

export default App