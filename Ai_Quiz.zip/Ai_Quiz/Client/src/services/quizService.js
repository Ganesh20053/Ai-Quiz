import axios from 'axios'

const API_BASE_URL = '/api'

class QuizService {
  constructor() {
    this.baseURL = `${API_BASE_URL}/quizzes`
  }

  // Create a new quiz
  async createQuiz(quizData) {
    try {
      const response = await axios.post(this.baseURL, quizData, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        }
      })
      return response.data
    } catch (error) {
      console.error('Error creating quiz:', error)
      throw error
    }
  }

  // Get all quizzes for a classroom
  async getClassroomQuizzes(classroomId) {
    try {
      const response = await axios.get(`${this.baseURL}/classroom/${classroomId}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      return response.data
    } catch (error) {
      console.error('Error fetching classroom quizzes:', error)
      throw error
    }
  }

  // Get all quizzes for a teacher
  async getTeacherQuizzes(params = {}) {
    try {
      const response = await axios.get(`${this.baseURL}/teacher`, {
        params,
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      return response.data
    } catch (error) {
      console.error('Error fetching teacher quizzes:', error)
      throw error
    }
  }

  // Get quiz by ID
  async getQuizById(quizId) {
    try {
      const response = await axios.get(`${this.baseURL}/${quizId}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      return response.data
    } catch (error) {
      console.error('Error fetching quiz:', error)
      throw error
    }
  }

  // Update quiz
  async updateQuiz(quizId, updateData) {
    try {
      const response = await axios.put(`${this.baseURL}/${quizId}`, updateData, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        }
      })
      return response.data
    } catch (error) {
      console.error('Error updating quiz:', error)
      throw error
    }
  }

  // Delete quiz
  async deleteQuiz(quizId) {
    try {
      const response = await axios.delete(`${this.baseURL}/${quizId}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      return response.data
    } catch (error) {
      console.error('Error deleting quiz:', error)
      throw error
    }
  }

  // Publish quiz
  async publishQuiz(quizId) {
    try {
      const response = await axios.patch(`${this.baseURL}/${quizId}/publish`, {}, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      return response.data
    } catch (error) {
      console.error('Error publishing quiz:', error)
      throw error
    }
  }

  // Archive quiz
  async archiveQuiz(quizId) {
    try {
      const response = await axios.patch(`${this.baseURL}/${quizId}/archive`, {}, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      return response.data
    } catch (error) {
      console.error('Error archiving quiz:', error)
      throw error
    }
  }

  // Get quiz statistics
  async getQuizStatistics(quizId) {
    try {
      const response = await axios.get(`${this.baseURL}/${quizId}/statistics`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      return response.data
    } catch (error) {
      console.error('Error fetching quiz statistics:', error)
      throw error
    }
  }

  // Assign quiz to students
  async assignQuiz(quizId, assignmentData) {
    try {
      const response = await axios.post(`${this.baseURL}/${quizId}/assign`, assignmentData, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        }
      })
      return response.data
    } catch (error) {
      console.error('Error assigning quiz:', error)
      throw error
    }
  }

  // Get quiz assignments
  async getQuizAssignments(quizId) {
    try {
      const response = await axios.get(`${this.baseURL}/${quizId}/assignments`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      return response.data
    } catch (error) {
      console.error('Error fetching quiz assignments:', error)
      throw error
    }
  }

  // Get quiz results/analytics
  async getQuizAnalytics(quizId) {
    try {
      const response = await axios.get(`${this.baseURL}/${quizId}/analytics`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      return response.data
    } catch (error) {
      console.error('Error fetching quiz analytics:', error)
      throw error
    }
  }

  // Duplicate quiz
  async duplicateQuiz(quizId, newTitle) {
    try {
      const response = await axios.post(`${this.baseURL}/${quizId}/duplicate`, 
        { title: newTitle },
        {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`,
            'Content-Type': 'application/json'
          }
        }
      )
      return response.data
    } catch (error) {
      console.error('Error duplicating quiz:', error)
      throw error
    }
  }

  // Export quiz
  async exportQuiz(quizId, format = 'json') {
    try {
      const response = await axios.get(`${this.baseURL}/${quizId}/export`, {
        params: { format },
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        responseType: format === 'pdf' ? 'blob' : 'json'
      })
      return response.data
    } catch (error) {
      console.error('Error exporting quiz:', error)
      throw error
    }
  }

  // Import quiz
  async importQuiz(classroomId, quizData) {
    try {
      const response = await axios.post(`${this.baseURL}/import`, {
        classroomId,
        quizData
      }, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        }
      })
      return response.data
    } catch (error) {
      console.error('Error importing quiz:', error)
      throw error
    }
  }

  // Search quizzes
  async searchQuizzes(classroomId, searchTerm, filters = {}) {
    try {
      const response = await axios.get(`${this.baseURL}/search`, {
        params: {
          classroomId,
          q: searchTerm,
          ...filters
        },
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      return response.data
    } catch (error) {
      console.error('Error searching quizzes:', error)
      throw error
    }
  }

  // Get quiz templates
  async getQuizTemplates() {
    try {
      const response = await axios.get(`${this.baseURL}/templates`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      return response.data
    } catch (error) {
      console.error('Error fetching quiz templates:', error)
      throw error
    }
  }

  // Validate quiz data
  validateQuizData(quizData) {
    const errors = []
    
    if (!quizData.title || quizData.title.trim().length === 0) {
      errors.push('Quiz title is required')
    }
    
    if (!quizData.questions || quizData.questions.length === 0) {
      errors.push('At least one question is required')
    }
    
    if (quizData.questions) {
      quizData.questions.forEach((question, index) => {
        if (!question.question || question.question.trim().length === 0) {
          errors.push(`Question ${index + 1}: Question text is required`)
        }
        
        if (question.type === 'multiple-choice') {
          if (!question.options || question.options.length < 2) {
          errors.push(`Question ${index + 1}: At least 2 options are required`)
        }
        
          const hasCorrectAnswer = question.options.some(opt => opt.isCorrect)
          if (!hasCorrectAnswer) {
            errors.push(`Question ${index + 1}: Must have one correct answer`)
        }
        } else if (question.type === 'true-false' || question.type === 'short-answer') {
          if (!question.correctAnswer || question.correctAnswer.trim().length === 0) {
            errors.push(`Question ${index + 1}: Correct answer is required`)
          }
        }
      })
    }
    
    if (quizData.settings?.timeLimit && (quizData.settings.timeLimit < 1 || quizData.settings.timeLimit > 300)) {
      errors.push('Time limit must be between 1 and 300 minutes')
    }
    
    return {
      isValid: errors.length === 0,
      errors
    }
  }

  // Format quiz data for API
  formatQuizForAPI(quizData, classroomId) {
    return {
      title: quizData.quizTitle || quizData.title,
      description: quizData.description || `Quiz on ${quizData.topic}`,
      classroomId,
      subject: quizData.subject,
      grade: quizData.grade,
      questions: quizData.questions.map((q, index) => ({
        question: q.question,
        type: q.type || 'multiple-choice',
        options: q.options || [],
        correctAnswer: q.correctAnswer,
        explanation: q.explanation || '',
        points: q.points || 1,
        difficulty: q.difficulty || quizData.difficulty || 'medium'
      })),
      settings: {
        timeLimit: quizData.settings?.timeLimit || 30,
        passingScore: quizData.settings?.passingScore || 60,
        allowRetake: quizData.settings?.allowRetake || false,
        maxAttempts: quizData.settings?.maxAttempts || 1,
        shuffleQuestions: quizData.settings?.shuffleQuestions !== false,
        showResults: quizData.settings?.showResults !== false,
        showCorrectAnswers: quizData.settings?.showCorrectAnswers || false,
        requirePassword: quizData.settings?.requirePassword || false,
        password: quizData.settings?.password || null
      },
      aiGenerated: quizData.aiGenerated || false,
      aiPrompt: quizData.aiPrompt || null
    }
  }
}

export default new QuizService()