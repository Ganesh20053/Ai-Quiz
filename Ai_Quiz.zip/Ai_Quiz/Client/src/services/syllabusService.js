import axios from 'axios'

const API_BASE_URL = '/api'

class SyllabusService {
  constructor() {
    this.baseURL = `${API_BASE_URL}/syllabus`
  }

  // Upload and process syllabus file
  async uploadSyllabus(file, classroomId) {
    try {
      const formData = new FormData()
      formData.append('syllabus', file)
      formData.append('classroomId', classroomId)

      const response = await axios.post(`${this.baseURL}/upload`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        onUploadProgress: (progressEvent) => {
          const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total)
          // You can emit this to update UI progress
          console.log(`Upload Progress: ${percentCompleted}%`)
        }
      })

      return response.data
    } catch (error) {
      console.error('Error uploading syllabus:', error)
      
      // Fallback: Process syllabus locally using Gemini
      if (error.response?.status === 404 || error.code === 'ERR_NETWORK') {
        console.warn('Backend not available, processing syllabus locally')
        return this.processSyllabusLocally(file, classroomId)
      }
      
      throw error
    }
  }

  // Fallback method to process syllabus locally
  async processSyllabusLocally(file, classroomId) {
    try {
      // Extract text from file
      const text = await this.extractTextFromFile(file)
      
      // Import geminiService here to avoid circular dependency
      const { default: geminiService } = await import('./geminiService')
      
      // Process with Gemini AI
      const syllabusData = await geminiService.summarizeSyllabus(text)
      
      // Store locally with expiration
      const syllabusRecord = {
        classroomId,
        syllabusData,
        fileName: file.name,
        uploadedAt: new Date().toISOString(),
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString() // 7 days
      }
      
      localStorage.setItem(`syllabus_${classroomId}`, JSON.stringify(syllabusRecord))
      
      return {
        success: true,
        syllabusData,
        message: 'Syllabus processed successfully (stored locally)'
      }
    } catch (error) {
      console.error('Error processing syllabus locally:', error)
      throw new Error('Failed to process syllabus: ' + error.message)
    }
  }

  // Extract text from file for local processing
  async extractTextFromFile(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      
      reader.onload = (e) => {
        const text = e.target.result
        resolve(text)
      }
      
      reader.onerror = () => {
        reject(new Error('Failed to read file'))
      }
      
      if (file.type === 'text/plain' || file.type === 'text/markdown') {
        reader.readAsText(file)
      } else {
        // For other file types, we'll need a more sophisticated approach
        // For now, just reject with a helpful message
        reject(new Error('File type not supported for local processing. Please use TXT or MD files.'))
      }
    })
  }

  // Get syllabus summary for a classroom
  async getSyllabusSummary(classroomId) {
    try {
      const response = await axios.get(`${this.baseURL}/${classroomId}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      return response.data
    } catch (error) {
      console.error('Error fetching syllabus:', error)
      
      // Fallback: Get from localStorage
      if (error.response?.status === 404 || error.code === 'ERR_NETWORK') {
        console.warn('Backend not available, getting syllabus from localStorage')
        return this.getLocalSyllabus(classroomId)
      }
      
      throw error
    }
  }

  // Get syllabus from localStorage
  getLocalSyllabus(classroomId) {
    const syllabusRecord = localStorage.getItem(`syllabus_${classroomId}`)
    if (!syllabusRecord) {
      throw new Error('No syllabus found for this classroom')
    }
    
    const parsed = JSON.parse(syllabusRecord)
    
    // Check if expired
    if (new Date() > new Date(parsed.expiresAt)) {
      localStorage.removeItem(`syllabus_${classroomId}`)
      throw new Error('Syllabus has expired')
    }
    
    return parsed.syllabusData
  }

  // Get available topics from syllabus
  async getAvailableTopics(classroomId) {
    try {
      const response = await axios.get(`${this.baseURL}/${classroomId}/topics`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      return response.data
    } catch (error) {
      console.error('Error fetching topics:', error)
      throw error
    }
  }

  // Delete syllabus (admin only)
  async deleteSyllabus(classroomId) {
    try {
      const response = await axios.delete(`${this.baseURL}/${classroomId}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      return response.data
    } catch (error) {
      console.error('Error deleting syllabus:', error)
      throw error
    }
  }

  // Update syllabus summary manually
  async updateSyllabusSummary(classroomId, summaryData) {
    try {
      const response = await axios.put(`${this.baseURL}/${classroomId}/summary`, summaryData, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        }
      })
      return response.data
    } catch (error) {
      console.error('Error updating syllabus summary:', error)
      throw error
    }
  }

  // Check if syllabus exists for classroom
  async checkSyllabusExists(classroomId) {
    try {
      const response = await axios.get(`${this.baseURL}/${classroomId}/exists`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      return response.data.exists
    } catch (error) {
      console.error('Error checking syllabus existence:', error)
      
      // Fallback: Check localStorage
      if (error.response?.status === 404 || error.code === 'ERR_NETWORK') {
        const syllabusRecord = localStorage.getItem(`syllabus_${classroomId}`)
        if (syllabusRecord) {
          const parsed = JSON.parse(syllabusRecord)
          // Check if expired
          if (new Date() <= new Date(parsed.expiresAt)) {
            return true
          } else {
            localStorage.removeItem(`syllabus_${classroomId}`)
          }
        }
      }
      
      return false
    }
  }

  // Get syllabus processing status
  async getProcessingStatus(classroomId) {
    try {
      const response = await axios.get(`${this.baseURL}/${classroomId}/status`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      return response.data
    } catch (error) {
      console.error('Error fetching processing status:', error)
      throw error
    }
  }

  // Search topics in syllabus
  async searchTopics(classroomId, searchTerm) {
    try {
      const response = await axios.get(`${this.baseURL}/${classroomId}/search`, {
        params: { q: searchTerm },
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      return response.data
    } catch (error) {
      console.error('Error searching topics:', error)
      throw error
    }
  }

  // Get topic details with subtopics
  async getTopicDetails(classroomId, topicName) {
    try {
      const response = await axios.get(`${this.baseURL}/${classroomId}/topics/${encodeURIComponent(topicName)}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      return response.data
    } catch (error) {
      console.error('Error fetching topic details:', error)
      throw error
    }
  }

  // Validate file before upload
  validateFile(file) {
    const allowedTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'text/plain',
      'text/markdown'
    ]
    
    const maxSize = 10 * 1024 * 1024 // 10MB
    
    const errors = []
    
    if (!allowedTypes.includes(file.type)) {
      errors.push('File type not supported. Please upload PDF, DOC, DOCX, TXT, or MD files.')
    }
    
    if (file.size > maxSize) {
      errors.push('File size too large. Maximum size is 10MB.')
    }
    
    if (file.size === 0) {
      errors.push('File is empty.')
    }
    
    return {
      isValid: errors.length === 0,
      errors
    }
  }

  // Extract text from different file types (client-side preview)
  async extractTextPreview(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      
      reader.onload = (e) => {
        const text = e.target.result
        // Basic text extraction - for preview only
        // Actual processing happens on server
        resolve(text.substring(0, 1000) + (text.length > 1000 ? '...' : ''))
      }
      
      reader.onerror = () => {
        reject(new Error('Failed to read file'))
      }
      
      if (file.type === 'text/plain' || file.type === 'text/markdown') {
        reader.readAsText(file)
      } else {
        // For other file types, we'll show file info instead of content
        resolve(`File: ${file.name}\nSize: ${(file.size / 1024).toFixed(2)} KB\nType: ${file.type}`)
      }
    })
  }
}

export default new SyllabusService()