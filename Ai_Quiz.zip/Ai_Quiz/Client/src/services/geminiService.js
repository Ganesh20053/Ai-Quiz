import axios from 'axios'

const GEMINI_API_KEY = import.meta.env.VITE_GEMINI_API_KEY || 'AIzaSyDxrQqQqQqQqQqQqQqQqQqQqQqQqQqQqQ'
const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent'

class GeminiService {
  constructor() {
    this.apiKey = GEMINI_API_KEY
    this.baseURL = GEMINI_API_URL
  }

  async generateContent(prompt) {
    try {
      // In development, always use fallback to avoid API issues
      if (import.meta.env.DEV) {
        console.log('Using development fallback for Gemini API')
        return this.getFallbackResponse(prompt)
      }
      
      const response = await axios.post(
        `${this.baseURL}?key=${this.apiKey}`,
        {
          contents: [{
            parts: [{
              text: prompt
            }]
          }]
        },
        {
          headers: {
            'Content-Type': 'application/json',
          }
        }
      )

      return response.data.candidates[0].content.parts[0].text
    } catch (error) {
      console.error('Gemini API Error:', error)
      
      // Fallback: Return a basic response for development
      console.warn('Using fallback response due to Gemini API error')
      return this.getFallbackResponse(prompt)
    }
  }

  getFallbackResponse(prompt) {
    // Simple fallback responses for development
    if (prompt.includes('summarize') || prompt.includes('syllabus')) {
      return JSON.stringify({
        title: "Sample Course",
        description: "A comprehensive course covering fundamental concepts",
        topics: [
          {
            name: "Introduction",
            subtopics: ["Basics", "Overview"],
            difficulty: "easy",
            learningObjectives: ["Understand basic concepts", "Learn fundamentals"]
          }
        ],
        totalTopics: 1,
        estimatedDuration: "4 weeks",
        prerequisites: ["None"],
        keyTerms: ["Concept", "Fundamental"]
      })
    }
    
    if (prompt.includes('quiz') || prompt.includes('question')) {
      return JSON.stringify({
        quizTitle: "Sample Quiz",
        topic: "General Knowledge",
        difficulty: "medium",
        questions: [
          {
            question: "What is the capital of France?",
            options: { A: "London", B: "Paris", C: "Berlin", D: "Madrid" },
            correctAnswer: "B",
            explanation: "Paris is the capital of France"
          },
          {
            question: "Which planet is closest to the Sun?",
            options: { A: "Venus", B: "Mars", C: "Mercury", D: "Earth" },
            correctAnswer: "C",
            explanation: "Mercury is the closest planet to the Sun"
          },
          {
            question: "What is 2 + 2?",
            options: { A: "3", B: "4", C: "5", D: "6" },
            correctAnswer: "B",
            explanation: "2 + 2 = 4"
          }
        ]
      })
    }
    
    return "Fallback response: Unable to generate content at this time."
  }

  async summarizeSyllabus(syllabusText) {
    const prompt = `
      Please analyze and summarize the following syllabus content. Extract key topics, learning objectives, and create a structured summary that can be used for quiz generation.

      Syllabus Content:
      ${syllabusText}

      Please provide the summary in the following JSON format:
      {
        "title": "Course/Subject Title",
        "description": "Brief description of the course",
        "topics": [
          {
            "name": "Topic Name",
            "subtopics": ["Subtopic 1", "Subtopic 2"],
            "difficulty": "easy|medium|hard",
            "learningObjectives": ["Objective 1", "Objective 2"]
          }
        ],
        "totalTopics": number,
        "estimatedDuration": "X weeks/months",
        "prerequisites": ["Prerequisite 1", "Prerequisite 2"],
        "keyTerms": ["Term 1", "Term 2"]
      }
    `

    try {
      const response = await this.generateContent(prompt)
      // Clean the response to extract JSON
      const jsonMatch = response.match(/\{[\s\S]*\}/)
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0])
      }
      throw new Error('Invalid response format')
    } catch (error) {
      console.error('Error summarizing syllabus:', error)
      throw error
    }
  }

  async generateQuizFromSyllabus(syllabusData, topic, difficulty = 'medium', questionCount = 10) {
    const relevantTopic = syllabusData.topics.find(t => 
      t.name.toLowerCase().includes(topic.toLowerCase()) ||
      t.subtopics.some(st => st.toLowerCase().includes(topic.toLowerCase()))
    )

    if (!relevantTopic) {
      throw new Error(`Topic "${topic}" not found in the syllabus`)
    }

    const prompt = `
      Based on the following syllabus topic, generate a quiz with ${questionCount} multiple-choice questions at ${difficulty} difficulty level.

      Topic: ${relevantTopic.name}
      Subtopics: ${relevantTopic.subtopics.join(', ')}
      Learning Objectives: ${relevantTopic.learningObjectives.join(', ')}
      Difficulty: ${difficulty}

      Generate questions that test understanding of the key concepts. Each question should have 4 options (A, B, C, D) with only one correct answer.

      Please provide the response in the following JSON format:
      {
        "quizTitle": "Quiz title based on topic",
        "topic": "${topic}",
        "difficulty": "${difficulty}",
        "totalQuestions": ${questionCount},
        "timeLimit": 30,
        "questions": [
          {
            "id": 1,
            "question": "Question text here?",
            "options": {
              "A": "Option A text",
              "B": "Option B text", 
              "C": "Option C text",
              "D": "Option D text"
            },
            "correctAnswer": "A",
            "explanation": "Detailed explanation of why this is correct",
            "difficulty": "${difficulty}",
            "topic": "${topic}",
            "subtopic": "Specific subtopic if applicable"
          }
        ]
      }
    `

    try {
      const response = await this.generateContent(prompt)
      const jsonMatch = response.match(/\{[\s\S]*\}/)
      if (jsonMatch) {
        const quizData = JSON.parse(jsonMatch[0])
        // Add metadata
        quizData.createdAt = new Date().toISOString()
        quizData.source = 'syllabus'
        quizData.syllabusReference = {
          topicName: relevantTopic.name,
          subtopics: relevantTopic.subtopics
        }
        return quizData
      }
      throw new Error('Invalid quiz response format')
    } catch (error) {
      console.error('Error generating quiz from syllabus:', error)
      throw error
    }
  }

  async generateCustomQuiz(topic, difficulty = 'medium', questionCount = 10, additionalContext = '') {
    const prompt = `
      Generate a comprehensive quiz on the topic: "${topic}" with ${questionCount} multiple-choice questions at ${difficulty} difficulty level.

      ${additionalContext ? `Additional Context: ${additionalContext}` : ''}

      Requirements:
      - Questions should be educational and test real understanding
      - Cover different aspects of the topic
      - Include practical applications where relevant
      - Ensure questions are clear and unambiguous
      - Provide detailed explanations for correct answers

      Please provide the response in the following JSON format:
      {
        "quizTitle": "Comprehensive Quiz on ${topic}",
        "topic": "${topic}",
        "difficulty": "${difficulty}",
        "totalQuestions": ${questionCount},
        "timeLimit": ${Math.max(questionCount * 2, 15)},
        "questions": [
          {
            "id": 1,
            "question": "Question text here?",
            "options": {
              "A": "Option A text",
              "B": "Option B text",
              "C": "Option C text", 
              "D": "Option D text"
            },
            "correctAnswer": "A",
            "explanation": "Detailed explanation of why this is correct",
            "difficulty": "${difficulty}",
            "topic": "${topic}",
            "subtopic": "Specific subtopic if applicable"
          }
        ]
      }
    `

    try {
      const response = await this.generateContent(prompt)
      const jsonMatch = response.match(/\{[\s\S]*\}/)
      if (jsonMatch) {
        const quizData = JSON.parse(jsonMatch[0])
        quizData.createdAt = new Date().toISOString()
        quizData.source = 'custom'
        return quizData
      }
      throw new Error('Invalid quiz response format')
    } catch (error) {
      console.error('Error generating custom quiz:', error)
      throw error
    }
  }

  async enhanceQuestion(question, context = '') {
    const prompt = `
      Improve the following quiz question to make it more educational and engaging:

      Original Question: ${question}
      ${context ? `Context: ${context}` : ''}

      Please provide an enhanced version with:
      1. Clearer wording
      2. Better options that test understanding
      3. Detailed explanation
      4. Difficulty assessment

      Format as JSON:
      {
        "enhancedQuestion": "Improved question text",
        "options": {
          "A": "Option A",
          "B": "Option B", 
          "C": "Option C",
          "D": "Option D"
        },
        "correctAnswer": "A",
        "explanation": "Detailed explanation",
        "improvementNotes": "What was improved and why"
      }
    `

    try {
      const response = await this.generateContent(prompt)
      const jsonMatch = response.match(/\{[\s\S]*\}/)
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0])
      }
      throw new Error('Invalid enhancement response format')
    } catch (error) {
      console.error('Error enhancing question:', error)
      throw error
    }
  }

  async validateQuizContent(quizData) {
    const prompt = `
      Please review and validate the following quiz content for educational quality, accuracy, and clarity:

      ${JSON.stringify(quizData, null, 2)}

      Provide feedback on:
      1. Question clarity and accuracy
      2. Option quality (are distractors reasonable?)
      3. Difficulty appropriateness
      4. Educational value
      5. Any potential issues or improvements

      Format response as JSON:
      {
        "overallScore": 85,
        "feedback": {
          "strengths": ["Strength 1", "Strength 2"],
          "improvements": ["Improvement 1", "Improvement 2"],
          "issues": ["Issue 1", "Issue 2"]
        },
        "questionFeedback": [
          {
            "questionId": 1,
            "score": 90,
            "comments": "Specific feedback for this question"
          }
        ],
        "recommendations": ["Recommendation 1", "Recommendation 2"]
      }
    `

    try {
      const response = await this.generateContent(prompt)
      const jsonMatch = response.match(/\{[\s\S]*\}/)
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0])
      }
      throw new Error('Invalid validation response format')
    } catch (error) {
      console.error('Error validating quiz:', error)
      throw error
    }
  }
}

export default new GeminiService()