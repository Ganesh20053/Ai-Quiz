// Cleanup service for managing temporary data
class CleanupService {
  constructor() {
    this.init()
  }

  init() {
    // Run cleanup on initialization
    this.cleanupExpiredData()
    
    // Set up periodic cleanup (every hour)
    setInterval(() => {
      this.cleanupExpiredData()
    }, 60 * 60 * 1000) // 1 hour
  }

  cleanupExpiredData() {
    try {
      // Clean up expired syllabus data
      this.cleanupExpiredSyllabus()
      
      // Clean up old local quizzes (optional - keep for 30 days)
      this.cleanupOldQuizzes()
      
      console.log('Cleanup completed successfully')
    } catch (error) {
      console.error('Error during cleanup:', error)
    }
  }

  cleanupExpiredSyllabus() {
    const keys = Object.keys(localStorage)
    const syllabusKeys = keys.filter(key => key.startsWith('syllabus_'))
    
    let cleanedCount = 0
    
    syllabusKeys.forEach(key => {
      try {
        const data = JSON.parse(localStorage.getItem(key))
        if (data.expiresAt && new Date() > new Date(data.expiresAt)) {
          localStorage.removeItem(key)
          cleanedCount++
          console.log(`Removed expired syllabus: ${key}`)
        }
      } catch (error) {
        // If we can't parse the data, remove it
        localStorage.removeItem(key)
        cleanedCount++
        console.log(`Removed corrupted syllabus data: ${key}`)
      }
    })
    
    if (cleanedCount > 0) {
      console.log(`Cleaned up ${cleanedCount} expired syllabus records`)
    }
  }

  cleanupOldQuizzes() {
    try {
      const quizzes = JSON.parse(localStorage.getItem('localQuizzes') || '[]')
      const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
      
      const validQuizzes = quizzes.filter(quiz => {
        if (!quiz.createdAt) return true // Keep quizzes without creation date
        return new Date(quiz.createdAt) > thirtyDaysAgo
      })
      
      if (validQuizzes.length !== quizzes.length) {
        localStorage.setItem('localQuizzes', JSON.stringify(validQuizzes))
        console.log(`Cleaned up ${quizzes.length - validQuizzes.length} old local quizzes`)
      }
    } catch (error) {
      console.error('Error cleaning up old quizzes:', error)
    }
  }

  // Manual cleanup methods
  cleanupAllSyllabusData() {
    const keys = Object.keys(localStorage)
    const syllabusKeys = keys.filter(key => key.startsWith('syllabus_'))
    
    syllabusKeys.forEach(key => {
      localStorage.removeItem(key)
    })
    
    console.log(`Manually removed ${syllabusKeys.length} syllabus records`)
    return syllabusKeys.length
  }

  cleanupAllLocalQuizzes() {
    localStorage.removeItem('localQuizzes')
    console.log('Manually removed all local quizzes')
  }

  // Get storage usage info
  getStorageInfo() {
    const keys = Object.keys(localStorage)
    const syllabusKeys = keys.filter(key => key.startsWith('syllabus_'))
    const localQuizzes = JSON.parse(localStorage.getItem('localQuizzes') || '[]')
    
    let totalSyllabusSize = 0
    let expiredSyllabusCount = 0
    
    syllabusKeys.forEach(key => {
      const data = localStorage.getItem(key)
      totalSyllabusSize += data.length
      
      try {
        const parsed = JSON.parse(data)
        if (parsed.expiresAt && new Date() > new Date(parsed.expiresAt)) {
          expiredSyllabusCount++
        }
      } catch (error) {
        expiredSyllabusCount++
      }
    })
    
    const quizSize = JSON.stringify(localQuizzes).length
    
    return {
      syllabusRecords: syllabusKeys.length,
      expiredSyllabusRecords: expiredSyllabusCount,
      syllabusStorageSize: totalSyllabusSize,
      localQuizzes: localQuizzes.length,
      quizStorageSize: quizSize,
      totalStorageSize: totalSyllabusSize + quizSize
    }
  }

  // Format storage size for display
  formatStorageSize(bytes) {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }
}

// Create singleton instance
const cleanupService = new CleanupService()

export default cleanupService