import { useState, useEffect, useRef, useCallback } from 'react'
import { useSelector } from 'react-redux'

const useVoiceRecognition = () => {
  const [isListening, setIsListening] = useState(false)
  const [transcript, setTranscript] = useState('')
  const [confidence, setConfidence] = useState(0)
  const [error, setError] = useState(null)
  const [isSupported, setIsSupported] = useState(false)
  
  const recognitionRef = useRef(null)
  const settings = useSelector((state) => state.settings)
  
  // Voice commands mapping
  const voiceCommands = {
    // Navigation commands
    'next': () => ({ action: 'next', data: null }),
    'next question': () => ({ action: 'next', data: null }),
    'previous': () => ({ action: 'previous', data: null }),
    'previous question': () => ({ action: 'previous', data: null }),
    'go back': () => ({ action: 'previous', data: null }),
    'submit': () => ({ action: 'submit', data: null }),
    'submit quiz': () => ({ action: 'submit', data: null }),
    'finish': () => ({ action: 'submit', data: null }),
    
    // Answer selection commands
    'option a': () => ({ action: 'select_option', data: 'A' }),
    'option b': () => ({ action: 'select_option', data: 'B' }),
    'option c': () => ({ action: 'select_option', data: 'C' }),
    'option d': () => ({ action: 'select_option', data: 'D' }),
    'first option': () => ({ action: 'select_option', data: 'A' }),
    'second option': () => ({ action: 'select_option', data: 'B' }),
    'third option': () => ({ action: 'select_option', data: 'C' }),
    'fourth option': () => ({ action: 'select_option', data: 'D' }),
    
    // Help commands
    'help': () => ({ action: 'help', data: null }),
    'hint': () => ({ action: 'hint', data: null }),
    'give me a hint': () => ({ action: 'hint', data: null }),
    'repeat': () => ({ action: 'repeat', data: null }),
    'repeat question': () => ({ action: 'repeat', data: null }),
    'read question': () => ({ action: 'repeat', data: null }),
    
    // Quiz control commands
    'pause': () => ({ action: 'pause', data: null }),
    'pause quiz': () => ({ action: 'pause', data: null }),
    'resume': () => ({ action: 'resume', data: null }),
    'resume quiz': () => ({ action: 'resume', data: null }),
    'save': () => ({ action: 'save', data: null }),
    'save quiz': () => ({ action: 'save', data: null }),
    
    // Accessibility commands
    'increase font size': () => ({ action: 'accessibility', data: { type: 'fontSize', value: 'increase' } }),
    'decrease font size': () => ({ action: 'accessibility', data: { type: 'fontSize', value: 'decrease' } }),
    'dark mode': () => ({ action: 'accessibility', data: { type: 'darkMode', value: 'toggle' } }),
    'high contrast': () => ({ action: 'accessibility', data: { type: 'highContrast', value: 'toggle' } }),
    
    // Topic selection commands
    'science': () => ({ action: 'select_topic', data: 'science' }),
    'mathematics': () => ({ action: 'select_topic', data: 'mathematics' }),
    'history': () => ({ action: 'select_topic', data: 'history' }),
    'arts': () => ({ action: 'select_topic', data: 'arts' }),
    'medical': () => ({ action: 'select_topic', data: 'medical' }),
    'literature': () => ({ action: 'select_topic', data: 'literature' }),
    'geography': () => ({ action: 'select_topic', data: 'geography' }),
    'technology': () => ({ action: 'select_topic', data: 'technology' }),
    
    // Difficulty commands
    'easy': () => ({ action: 'select_difficulty', data: 'easy' }),
    'medium': () => ({ action: 'select_difficulty', data: 'medium' }),
    'hard': () => ({ action: 'select_difficulty', data: 'hard' }),
    'difficult': () => ({ action: 'select_difficulty', data: 'hard' }),
  }

  useEffect(() => {
    // Check if speech recognition is supported
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    
    if (SpeechRecognition) {
      setIsSupported(true)
      
      const recognition = new SpeechRecognition()
      recognition.continuous = true
      recognition.interimResults = true
      recognition.lang = settings.currentLanguage || 'en-US'
      
      // Configure recognition based on language
      const languageMap = {
        'en': 'en-US',
        'hi': 'hi-IN',
        'ta': 'ta-IN',
        'es': 'es-ES',
        'fr': 'fr-FR',
      }
      
      recognition.lang = languageMap[settings.currentLanguage] || 'en-US'
      
      recognition.onstart = () => {
        setIsListening(true)
        setError(null)
      }
      
      recognition.onresult = (event) => {
        let finalTranscript = ''
        let interimTranscript = ''
        
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const result = event.results[i]
          if (result.isFinal) {
            finalTranscript += result[0].transcript
            setConfidence(result[0].confidence)
          } else {
            interimTranscript += result[0].transcript
          }
        }
        
        setTranscript(finalTranscript || interimTranscript)
        
        // Process final transcript for commands
        if (finalTranscript) {
          processVoiceCommand(finalTranscript.toLowerCase().trim())
        }
      }
      
      recognition.onerror = (event) => {
        setError(event.error)
        setIsListening(false)
        
        // Handle specific errors
        switch (event.error) {
          case 'no-speech':
            setError('No speech detected. Please try again.')
            break
          case 'audio-capture':
            setError('Microphone not accessible. Please check permissions.')
            break
          case 'not-allowed':
            setError('Microphone permission denied.')
            break
          case 'network':
            setError('Network error occurred.')
            break
          default:
            setError(`Speech recognition error: ${event.error}`)
        }
      }
      
      recognition.onend = () => {
        setIsListening(false)
      }
      
      recognitionRef.current = recognition
    } else {
      setIsSupported(false)
      setError('Speech recognition not supported in this browser.')
    }
    
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop()
      }
    }
  }, [settings.currentLanguage])

  const processVoiceCommand = useCallback((command) => {
    // Check for exact matches first
    if (voiceCommands[command]) {
      const result = voiceCommands[command]()
      onCommandRecognized?.(result)
      return
    }
    
    // Check for partial matches
    for (const [key, handler] of Object.entries(voiceCommands)) {
      if (command.includes(key)) {
        const result = handler()
        onCommandRecognized?.(result)
        return
      }
    }
    
    // If no command matched, treat as answer text
    onCommandRecognized?.({
      action: 'text_input',
      data: command
    })
  }, [])

  const startListening = useCallback(() => {
    if (!isSupported) {
      setError('Speech recognition not supported')
      return
    }
    
    if (!settings.voiceEnabled) {
      setError('Voice recognition is disabled in settings')
      return
    }
    
    if (recognitionRef.current && !isListening) {
      setTranscript('')
      setError(null)
      recognitionRef.current.start()
    }
  }, [isSupported, isListening, settings.voiceEnabled])

  const stopListening = useCallback(() => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop()
    }
  }, [isListening])

  const toggleListening = useCallback(() => {
    if (isListening) {
      stopListening()
    } else {
      startListening()
    }
  }, [isListening, startListening, stopListening])

  // Pronunciation checking function
  const checkPronunciation = useCallback(async (expectedText, spokenText) => {
    // Simple pronunciation checking logic
    // In a real app, you might use a more sophisticated API
    const similarity = calculateSimilarity(expectedText.toLowerCase(), spokenText.toLowerCase())
    
    return {
      score: similarity,
      feedback: similarity > 0.8 ? 'Excellent pronunciation!' : 
                similarity > 0.6 ? 'Good pronunciation, try to be clearer.' :
                'Please try again, focus on pronunciation.',
      suggestions: similarity < 0.6 ? generatePronunciationTips(expectedText) : []
    }
  }, [])

  // Simple string similarity calculation
  const calculateSimilarity = (str1, str2) => {
    const longer = str1.length > str2.length ? str1 : str2
    const shorter = str1.length > str2.length ? str2 : str1
    
    if (longer.length === 0) return 1.0
    
    const editDistance = levenshteinDistance(longer, shorter)
    return (longer.length - editDistance) / longer.length
  }

  // Levenshtein distance calculation
  const levenshteinDistance = (str1, str2) => {
    const matrix = []
    
    for (let i = 0; i <= str2.length; i++) {
      matrix[i] = [i]
    }
    
    for (let j = 0; j <= str1.length; j++) {
      matrix[0][j] = j
    }
    
    for (let i = 1; i <= str2.length; i++) {
      for (let j = 1; j <= str1.length; j++) {
        if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
          matrix[i][j] = matrix[i - 1][j - 1]
        } else {
          matrix[i][j] = Math.min(
            matrix[i - 1][j - 1] + 1,
            matrix[i][j - 1] + 1,
            matrix[i - 1][j] + 1
          )
        }
      }
    }
    
    return matrix[str2.length][str1.length]
  }

  const generatePronunciationTips = (text) => {
    // Generate simple pronunciation tips
    return [
      'Speak slowly and clearly',
      'Make sure you\'re in a quiet environment',
      'Hold the microphone close to your mouth',
      'Try breaking the word into syllables'
    ]
  }

  // Command recognition callback (to be set by components using this hook)
  let onCommandRecognized = null

  const setCommandCallback = useCallback((callback) => {
    onCommandRecognized = callback
  }, [])

  return {
    isListening,
    transcript,
    confidence,
    error,
    isSupported,
    startListening,
    stopListening,
    toggleListening,
    checkPronunciation,
    setCommandCallback,
    voiceCommands: Object.keys(voiceCommands),
  }
}

export default useVoiceRecognition