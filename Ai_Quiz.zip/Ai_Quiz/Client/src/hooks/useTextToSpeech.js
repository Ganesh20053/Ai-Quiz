import { useState, useEffect, useRef, useCallback } from 'react'
import { useSelector } from 'react-redux'

const useTextToSpeech = () => {
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [isPaused, setIsPaused] = useState(false)
  const [isSupported, setIsSupported] = useState(false)
  const [voices, setVoices] = useState([])
  const [currentUtterance, setCurrentUtterance] = useState(null)
  
  const settings = useSelector((state) => state.settings)
  const utteranceRef = useRef(null)
  const queueRef = useRef([])

  useEffect(() => {
    // Check if speech synthesis is supported
    if ('speechSynthesis' in window) {
      setIsSupported(true)
      
      // Load available voices
      const loadVoices = () => {
        const availableVoices = speechSynthesis.getVoices()
        setVoices(availableVoices)
      }
      
      loadVoices()
      
      // Some browsers load voices asynchronously
      if (speechSynthesis.onvoiceschanged !== undefined) {
        speechSynthesis.onvoiceschanged = loadVoices
      }
    } else {
      setIsSupported(false)
    }
  }, [])

  // Get the best voice for current language
  const getPreferredVoice = useCallback(() => {
    if (!voices.length) return null
    
    // If user has selected a preferred voice
    if (settings.preferredVoice) {
      const selectedVoice = voices.find(voice => voice.name === settings.preferredVoice)
      if (selectedVoice) return selectedVoice
    }
    
    // Find voice matching current language
    const languageVoices = voices.filter(voice => 
      voice.lang.startsWith(settings.currentLanguage)
    )
    
    if (languageVoices.length > 0) {
      // Prefer female voices for better clarity
      const femaleVoice = languageVoices.find(voice => 
        voice.name.toLowerCase().includes('female') || 
        voice.name.toLowerCase().includes('woman')
      )
      return femaleVoice || languageVoices[0]
    }
    
    // Fallback to default voice
    return voices[0] || null
  }, [voices, settings.preferredVoice, settings.currentLanguage])

  const speak = useCallback((text, options = {}) => {
    if (!isSupported || !settings.voiceEnabled) {
      console.warn('Text-to-speech not supported or disabled')
      return Promise.resolve()
    }

    return new Promise((resolve, reject) => {
      // Cancel any ongoing speech
      speechSynthesis.cancel()
      
      const utterance = new SpeechSynthesisUtterance(text)
      const preferredVoice = getPreferredVoice()
      
      if (preferredVoice) {
        utterance.voice = preferredVoice
      }
      
      // Apply settings
      utterance.rate = options.rate || settings.voiceSpeed || 1.0
      utterance.volume = options.volume || settings.voiceVolume || 1.0
      utterance.pitch = options.pitch || 1.0
      
      // Set language
      utterance.lang = getLanguageCode(settings.currentLanguage)
      
      utterance.onstart = () => {
        setIsSpeaking(true)
        setIsPaused(false)
        setCurrentUtterance(utterance)
      }
      
      utterance.onend = () => {
        setIsSpeaking(false)
        setIsPaused(false)
        setCurrentUtterance(null)
        resolve()
      }
      
      utterance.onerror = (event) => {
        setIsSpeaking(false)
        setIsPaused(false)
        setCurrentUtterance(null)
        reject(new Error(`Speech synthesis error: ${event.error}`))
      }
      
      utterance.onpause = () => {
        setIsPaused(true)
      }
      
      utterance.onresume = () => {
        setIsPaused(false)
      }
      
      utteranceRef.current = utterance
      speechSynthesis.speak(utterance)
    })
  }, [isSupported, settings, getPreferredVoice])

  const speakQuestion = useCallback(async (question, options = {}) => {
    const questionText = `Question: ${question.text || question}`
    await speak(questionText, { ...options, rate: 0.9 })
  }, [speak])

  const speakOptions = useCallback(async (options, selectedOption = null) => {
    if (!Array.isArray(options)) return
    
    for (let i = 0; i < options.length; i++) {
      const optionLetter = String.fromCharCode(65 + i) // A, B, C, D
      const isSelected = selectedOption === optionLetter
      const prefix = isSelected ? 'Selected option' : 'Option'
      const text = `${prefix} ${optionLetter}: ${options[i]}`
      
      await speak(text, { 
        rate: 0.8,
        pitch: isSelected ? 1.2 : 1.0 
      })
      
      // Small pause between options
      await new Promise(resolve => setTimeout(resolve, 500))
    }
  }, [speak])

  const speakResult = useCallback(async (isCorrect, explanation = '') => {
    const resultText = isCorrect ? 
      'Correct! Well done.' : 
      'Incorrect. Let me explain.'
    
    await speak(resultText, { 
      pitch: isCorrect ? 1.3 : 0.8,
      rate: 0.9 
    })
    
    if (explanation) {
      await speak(explanation, { rate: 0.8 })
    }
  }, [speak])

  const speakHint = useCallback(async (hint) => {
    await speak(`Here's a hint: ${hint}`, { rate: 0.8, pitch: 1.1 })
  }, [speak])

  const speakWelcome = useCallback(async (userName = '') => {
    const welcomeText = userName ? 
      `Welcome back, ${userName}! What topic would you like to learn today?` :
      'Welcome! What topic would you like to learn today?'
    
    await speak(welcomeText, { rate: 0.9, pitch: 1.1 })
  }, [speak])

  const speakInstructions = useCallback(async (instructions) => {
    const instructionText = `Instructions: ${instructions}`
    await speak(instructionText, { rate: 0.8 })
  }, [speak])

  const speakScore = useCallback(async (score, total) => {
    const percentage = Math.round((score / total) * 100)
    let message = `You scored ${score} out of ${total}, that's ${percentage} percent.`
    
    if (percentage >= 90) {
      message += ' Excellent work!'
    } else if (percentage >= 70) {
      message += ' Good job!'
    } else if (percentage >= 50) {
      message += ' Keep practicing!'
    } else {
      message += ' Don\'t worry, you\'ll do better next time!'
    }
    
    await speak(message, { rate: 0.9 })
  }, [speak])

  const speakTimer = useCallback(async (timeRemaining) => {
    if (timeRemaining <= 60) {
      await speak(`${timeRemaining} seconds remaining`, { rate: 1.2 })
    } else {
      const minutes = Math.floor(timeRemaining / 60)
      await speak(`${minutes} minutes remaining`, { rate: 1.1 })
    }
  }, [speak])

  const pause = useCallback(() => {
    if (isSpeaking && !isPaused) {
      speechSynthesis.pause()
    }
  }, [isSpeaking, isPaused])

  const resume = useCallback(() => {
    if (isSpeaking && isPaused) {
      speechSynthesis.resume()
    }
  }, [isSpeaking, isPaused])

  const stop = useCallback(() => {
    speechSynthesis.cancel()
    setIsSpeaking(false)
    setIsPaused(false)
    setCurrentUtterance(null)
  }, [])

  const toggle = useCallback(() => {
    if (isSpeaking) {
      if (isPaused) {
        resume()
      } else {
        pause()
      }
    }
  }, [isSpeaking, isPaused, pause, resume])

  // Queue system for multiple speech items
  const addToQueue = useCallback((text, options = {}) => {
    queueRef.current.push({ text, options })
  }, [])

  const processQueue = useCallback(async () => {
    while (queueRef.current.length > 0) {
      const { text, options } = queueRef.current.shift()
      await speak(text, options)
    }
  }, [speak])

  const clearQueue = useCallback(() => {
    queueRef.current = []
    stop()
  }, [stop])

  // Language code mapping
  const getLanguageCode = (language) => {
    const languageMap = {
      'en': 'en-US',
      'hi': 'hi-IN',
      'ta': 'ta-IN',
      'es': 'es-ES',
      'fr': 'fr-FR',
    }
    return languageMap[language] || 'en-US'
  }

  // Accessibility announcements
  const announcePageChange = useCallback(async (pageName) => {
    await speak(`Navigated to ${pageName}`, { rate: 1.1 })
  }, [speak])

  const announceError = useCallback(async (error) => {
    await speak(`Error: ${error}`, { rate: 0.9, pitch: 0.8 })
  }, [speak])

  const announceSuccess = useCallback(async (message) => {
    await speak(`Success: ${message}`, { rate: 1.0, pitch: 1.2 })
  }, [speak])

  // Reading mode for long content
  const readContent = useCallback(async (content, options = {}) => {
    const sentences = content.split(/[.!?]+/).filter(s => s.trim().length > 0)
    
    for (const sentence of sentences) {
      await speak(sentence.trim(), { 
        ...options, 
        rate: options.rate || 0.8 
      })
      
      // Pause between sentences
      await new Promise(resolve => setTimeout(resolve, 300))
    }
  }, [speak])

  return {
    // Basic controls
    speak,
    pause,
    resume,
    stop,
    toggle,
    
    // Specialized speaking functions
    speakQuestion,
    speakOptions,
    speakResult,
    speakHint,
    speakWelcome,
    speakInstructions,
    speakScore,
    speakTimer,
    
    // Queue management
    addToQueue,
    processQueue,
    clearQueue,
    
    // Accessibility
    announcePageChange,
    announceError,
    announceSuccess,
    readContent,
    
    // State
    isSpeaking,
    isPaused,
    isSupported,
    voices,
    currentUtterance,
    
    // Voice selection
    getPreferredVoice,
  }
}

export default useTextToSpeech