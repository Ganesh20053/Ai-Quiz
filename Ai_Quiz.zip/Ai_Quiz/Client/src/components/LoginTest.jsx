import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { loginUser } from '../features/auth/authSlice';

const LoginTest = () => {
  const dispatch = useDispatch();
  const [status, setStatus] = useState('');

  const testLogin = async (role) => {
    setStatus('Testing login...');
    
    const credentials = {
      admin: { email: 'admin@quizapp.com', password: 'admin123' },
      staff: { email: 'staff@quizapp.com', password: 'staff123' },
      student: { email: 'student@quizapp.com', password: 'student123' },
      disabledStudent: { email: 'disabled.student@quizapp.com', password: 'disabled123' }
    };

    try {
      console.log('Attempting login with:', credentials[role]);
      const result = await dispatch(loginUser(credentials[role])).unwrap();
      console.log('Login successful:', result);
      setStatus(`✅ ${role} login successful!`);
    } catch (error) {
      console.error('Login failed:', error);
      setStatus(`❌ ${role} login failed: ${error}`);
    }
  };

  return (
    <div className="p-4 bg-white rounded-lg shadow">
      <h3 className="text-lg font-semibold mb-4">Login Test</h3>
      <div className="space-y-2">
        <button 
          onClick={() => testLogin('staff')}
          className="w-full px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
        >
          Test Staff Login
        </button>
        <button
          onClick={() => testLogin('student')}
          className="w-full px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600"
        >
          Test Student Login
        </button>
        <button
          onClick={() => testLogin('disabledStudent')}
          className="w-full px-4 py-2 bg-orange-500 text-white rounded hover:bg-orange-600 flex items-center justify-center gap-2"
        >
          <span>♿</span>
          Test Disabled Student Login
        </button>
        <button
          onClick={() => testLogin('admin')}
          className="w-full px-4 py-2 bg-purple-500 text-white rounded hover:bg-purple-600"
        >
          Test Admin Login
        </button>
      </div>
      {status && (
        <div className="mt-4 p-2 bg-gray-100 rounded">
          <p className="text-sm">{status}</p>
        </div>
      )}
    </div>
  );
};

export default LoginTest; 