import React, { useState } from 'react';
import Button from '../common/Button';
import Modal from '../common/Modal';
import Loader from '../common/Loader';
import geminiService from '../../services/geminiService';
import quizService from '../../services/quizService';

const AIQuizGenerator = ({ isOpen, onClose, onQuizGenerated, classroom }) => {
  const [formData, setFormData] = useState({
    topic: '',
    subject: '',
    grade: '',
    numberOfQuestions: 5,
    difficulty: 'medium',
    questionType: 'multiple_choice',
    includeExplanation: true,
    voiceEnabled: false
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      // Build context for AI generation
      const context = [
        formData.subject && `Subject: ${formData.subject}`,
        formData.grade && `Grade Level: ${formData.grade}`,
        classroom?.classType && `Class Type: ${classroom.classType}`,
        formData.voiceEnabled && 'Include voice accessibility features',
        formData.includeExplanation && 'Include detailed explanations'
      ].filter(Boolean).join(', ');

      // Generate quiz using Gemini AI
      const quizData = await geminiService.generateCustomQuiz(
        formData.topic,
        formData.difficulty,
        formData.numberOfQuestions,
        context
      );

      // Format quiz data for the application
      const formattedQuiz = {
        ...quizData,
        classroomId: classroom?._id,
        subject: formData.subject,
        grade: formData.grade,
        questionType: formData.questionType,
        voiceEnabled: formData.voiceEnabled,
        includeExplanation: formData.includeExplanation,
        classType: classroom?.classType
      };

      // Call the parent component's callback
      onQuizGenerated(formattedQuiz);
      onClose();
      
      // Reset form
      setFormData({
        topic: '',
        subject: '',
        grade: '',
        numberOfQuestions: 5,
        difficulty: 'medium',
        questionType: 'multiple_choice',
        includeExplanation: true,
        voiceEnabled: false
      });
      
    } catch (err) {
      console.error('Error generating quiz:', err);
      setError(err.message || 'Failed to generate quiz. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="AI Quiz Generator"
      size="lg"
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Topic */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Quiz Topic *
          </label>
          <input
            type="text"
            name="topic"
            value={formData.topic}
            onChange={handleInputChange}
            placeholder="e.g., Introduction to JavaScript, Basic Algebra, World History"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            required
          />
        </div>

        {/* Subject and Grade */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Subject
            </label>
            <input
              type="text"
              name="subject"
              value={formData.subject}
              onChange={handleInputChange}
              placeholder="e.g., Computer Science, Mathematics"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Grade Level
            </label>
            <input
              type="text"
              name="grade"
              value={formData.grade}
              onChange={handleInputChange}
              placeholder="e.g., 9th Grade, High School"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            />
          </div>
        </div>

        {/* Number of Questions and Difficulty */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Number of Questions
            </label>
            <select
              name="numberOfQuestions"
              value={formData.numberOfQuestions}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            >
              <option value={3}>3 Questions</option>
              <option value={5}>5 Questions</option>
              <option value={10}>10 Questions</option>
              <option value={15}>15 Questions</option>
              <option value={20}>20 Questions</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Difficulty Level
            </label>
            <select
              name="difficulty"
              value={formData.difficulty}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            >
              <option value="easy">Easy</option>
              <option value="medium">Medium</option>
              <option value="hard">Hard</option>
            </select>
          </div>
        </div>

        {/* Question Type */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Question Type
          </label>
          <select
            name="questionType"
            value={formData.questionType}
            onChange={handleInputChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
          >
            <option value="multiple_choice">Multiple Choice</option>
            <option value="true_false">True/False</option>
            <option value="fill_in_blank">Fill in the Blank</option>
            <option value="short_answer">Short Answer</option>
          </select>
        </div>

        {/* Options */}
        <div className="space-y-3">
          <div className="flex items-center">
            <input
              type="checkbox"
              name="includeExplanation"
              checked={formData.includeExplanation}
              onChange={handleInputChange}
              className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
            />
            <label className="ml-2 block text-sm text-gray-700">
              Include explanations for correct answers
            </label>
          </div>
          
          {classroom?.classType === 'disabled' || classroom?.classType === 'mixed' ? (
            <div className="flex items-center">
              <input
                type="checkbox"
                name="voiceEnabled"
                checked={formData.voiceEnabled}
                onChange={handleInputChange}
                className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
              />
              <label className="ml-2 block text-sm text-gray-700">
                Enable voice accessibility features
              </label>
            </div>
          ) : null}
        </div>

        {/* Error Message */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3">
            <p className="text-sm text-red-600">{error}</p>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex justify-end space-x-3 pt-4">
          <Button
            type="button"
            onClick={onClose}
            className="bg-gray-100 text-gray-700 hover:bg-gray-200"
            disabled={loading}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            className="bg-indigo-600 text-white hover:bg-indigo-700"
            disabled={loading}
          >
            {loading ? (
              <div className="flex items-center">
                <Loader size="sm" className="mr-2" />
                Generating Quiz...
              </div>
            ) : (
              'Generate Quiz'
            )}
          </Button>
        </div>
      </form>
    </Modal>
  );
};

export default AIQuizGenerator; 