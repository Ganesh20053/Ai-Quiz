import React, { useState, useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { TextPlugin } from 'gsap/TextPlugin';
import { motion, AnimatePresence } from 'framer-motion';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Text3D, Center, Float } from '@react-three/drei';
import { 
  Clock, 
  CheckCircle, 
  XCircle, 
  Star, 
  Trophy, 
  Zap,
  Brain,
  Target,
  Award
} from 'lucide-react';

// Register GSAP plugins
gsap.registerPlugin(TextPlugin);

// Enhanced Confetti Component with spectacular effects
const Confetti = ({ show, isCorrect }) => {
  const confettiRef = useRef();

  useEffect(() => {
    if (show && isCorrect && confettiRef.current) {
      // Create multiple types of confetti particles
      const colors = ['#FFD700', '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#FF7675', '#74B9FF'];
      const shapes = ['circle', 'square', 'star'];
      const particles = [];

      for (let i = 0; i < 80; i++) {
        const particle = document.createElement('div');
        const color = colors[Math.floor(Math.random() * colors.length)];
        const shape = shapes[Math.floor(Math.random() * shapes.length)];
        const size = Math.random() * 8 + 4;

        if (shape === 'star') {
          particle.innerHTML = '★';
          particle.style.cssText = `
            position: absolute;
            font-size: ${size}px;
            color: ${color};
            left: 50%;
            top: 50%;
            pointer-events: none;
          `;
        } else {
          particle.className = `absolute ${shape === 'circle' ? 'rounded-full' : 'rounded-sm'}`;
          particle.style.cssText = `
            width: ${size}px;
            height: ${size}px;
            background: ${color};
            left: 50%;
            top: 50%;
            pointer-events: none;
          `;
        }

        confettiRef.current.appendChild(particle);
        particles.push(particle);
      }

      // Enhanced animation with realistic physics
      particles.forEach((particle, index) => {
        gsap.to(particle, {
          x: (Math.random() - 0.5) * 800,
          y: Math.random() * 600 + 200,
          rotation: Math.random() * 720,
          scale: Math.random() * 0.5 + 0.5,
          opacity: 0,
          duration: Math.random() * 2 + 2,
          delay: index * 0.02,
          ease: "power2.out",
          onComplete: () => {
            particle.remove();
          }
        });
      });

      // Add screen flash effect
      const flash = document.createElement('div');
      flash.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background: radial-gradient(circle, rgba(16, 185, 129, 0.2) 0%, transparent 70%);
        pointer-events: none;
        z-index: 999;
      `;
      document.body.appendChild(flash);

      gsap.fromTo(flash,
        { opacity: 0 },
        {
          opacity: 1,
          duration: 0.1,
          yoyo: true,
          repeat: 1,
          onComplete: () => flash.remove()
        }
      );
    }
  }, [show, isCorrect]);

  return <div ref={confettiRef} className="absolute inset-0 pointer-events-none z-10" />;
};

// 3D Floating Elements Component
const FloatingElements = () => {
  return (
    <>
      <Float speed={1.5} rotationIntensity={1} floatIntensity={2}>
        <mesh position={[-3, 2, 0]}>
          <sphereGeometry args={[0.3, 32, 32]} />
          <meshStandardMaterial color="#3B82F6" />
        </mesh>
      </Float>
      
      <Float speed={2} rotationIntensity={1.5} floatIntensity={1.5}>
        <mesh position={[3, -1, 0]}>
          <boxGeometry args={[0.5, 0.5, 0.5]} />
          <meshStandardMaterial color="#10B981" />
        </mesh>
      </Float>
      
      <Float speed={1.8} rotationIntensity={0.8} floatIntensity={2.5}>
        <mesh position={[0, 3, -2]}>
          <octahedronGeometry args={[0.4]} />
          <meshStandardMaterial color="#F59E0B" />
        </mesh>
      </Float>
      
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} />
    </>
  );
};

// Animated Progress Bar
const AnimatedProgressBar = ({ progress, total }) => {
  const progressRef = useRef();
  
  useEffect(() => {
    gsap.to(progressRef.current, {
      width: `${(progress / total) * 100}%`,
      duration: 0.8,
      ease: "power2.out"
    });
  }, [progress, total]);
  
  return (
    <div className="w-full bg-gray-200 rounded-full h-3 mb-6 overflow-hidden">
      <div 
        ref={progressRef}
        className="h-full bg-gradient-to-r from-blue-500 to-purple-600 rounded-full transition-all duration-300"
        style={{ width: '0%' }}
      />
    </div>
  );
};

// Animated Question Card
const AnimatedQuestionCard = ({ question, onAnswer, questionNumber, totalQuestions, disabled = false }) => {
  const cardRef = useRef();
  const questionRef = useRef();
  const optionsRef = useRef();
  const [showFeedback, setShowFeedback] = useState(false);
  const [selectedOption, setSelectedOption] = useState(null);
  const [selectedIndex, setSelectedIndex] = useState(null);
  const [isCorrect, setIsCorrect] = useState(false);

  useEffect(() => {
    const tl = gsap.timeline();

    // Enhanced card entrance with more dramatic effects
    tl.fromTo(cardRef.current,
      {
        scale: 0.7,
        opacity: 0,
        rotationY: -25,
        z: -100,
        filter: "blur(10px)"
      },
      {
        scale: 1,
        opacity: 1,
        rotationY: 0,
        z: 0,
        filter: "blur(0px)",
        duration: 0.8,
        ease: "back.out(1.7)"
      }
    )
    // Question text with typewriter effect
    .fromTo(questionRef.current,
      { y: 50, opacity: 0, scale: 0.9 },
      { y: 0, opacity: 1, scale: 1, duration: 0.6, ease: "back.out(1.7)" },
      "-=0.4"
    )
    // Options with staggered bounce effect
    .fromTo(optionsRef.current.children,
      {
        x: -80,
        opacity: 0,
        scale: 0.8,
        rotationX: -15
      },
      {
        x: 0,
        opacity: 1,
        scale: 1,
        rotationX: 0,
        duration: 0.5,
        stagger: 0.15,
        ease: "back.out(1.7)"
      },
      "-=0.3"
    );
  }, [question]);

  const handleOptionClick = (option, index) => {
    if (showFeedback || disabled) return; // Prevent multiple clicks during feedback or when disabled

    // Check if this option is correct based on the question structure
    let correct = false;
    if (question.options && question.options[index]) {
      // For multiple choice questions with options array
      correct = question.options[index].isCorrect === true;
    } else {
      // Fallback to text comparison for other question types
      correct = option === question.correctAnswer;
    }

    setSelectedOption(option);
    setSelectedIndex(index);
    setIsCorrect(correct);
    setShowFeedback(true);

    // Enhanced selection animation with more attractive effects
    const selectedElement = optionsRef.current.children[index];

    // Create a more dramatic selection effect
    const tl = gsap.timeline();

    // Initial pulse effect
    tl.to(selectedElement, {
      scale: 1.05,
      duration: 0.1,
      ease: "power2.out"
    })
    // Glow effect
    .to(selectedElement, {
      boxShadow: correct
        ? "0 0 30px rgba(16, 185, 129, 0.6), 0 0 60px rgba(16, 185, 129, 0.3)"
        : "0 0 30px rgba(239, 68, 68, 0.6), 0 0 60px rgba(239, 68, 68, 0.3)",
      duration: 0.2,
      ease: "power2.out"
    }, 0)
    // Settle animation
    .to(selectedElement, {
      scale: 1.02,
      duration: 0.15,
      ease: "back.out(1.7)",
      onComplete: () => {
        // Show feedback animation
        showAnswerFeedback(correct, index);
      }
    });
  };

  const showAnswerFeedback = (correct, selectedIdx) => {
    const tl = gsap.timeline();

    // Animate all options to show correct/incorrect states
    Array.from(optionsRef.current.children).forEach((option, index) => {
      const isSelected = index === selectedIdx;

      // Check if this option is the correct one
      let isCorrectOption = false;
      if (question.options && question.options[index]) {
        isCorrectOption = question.options[index].isCorrect === true;
      } else {
        // Fallback to text comparison
        const currentOption = question.options[index];
        const optionValue = typeof currentOption === 'string' ? currentOption : currentOption.text || currentOption.option || currentOption.value || String(currentOption);
        const normalizedOptionValue = String(optionValue).trim();
        let correctAnswer = question.correctAnswer;
        if (typeof correctAnswer === 'object' && correctAnswer !== null) {
          correctAnswer = correctAnswer.text || correctAnswer.option || correctAnswer.value || String(correctAnswer);
        }
        const normalizedCorrectAnswer = String(correctAnswer).trim();
        isCorrectOption = normalizedOptionValue === normalizedCorrectAnswer;
      }

      if (isSelected) {
        // Enhanced selected option animation with more dramatic effects
        tl.to(option, {
          backgroundColor: correct ? '#10B981' : '#EF4444',
          color: '#FFFFFF',
          scale: 1.03,
          rotationX: correct ? 5 : -5,
          boxShadow: correct
            ? "0 10px 40px rgba(16, 185, 129, 0.4), 0 0 0 3px rgba(16, 185, 129, 0.2)"
            : "0 10px 40px rgba(239, 68, 68, 0.4), 0 0 0 3px rgba(239, 68, 68, 0.2)",
          duration: 0.3,
          ease: "back.out(1.7)"
        }, 0)
        // Add a subtle bounce effect
        .to(option, {
          rotationX: 0,
          scale: 1.02,
          duration: 0.2,
          ease: "power2.out"
        }, 0.3);
      } else if (isCorrectOption && !correct) {
        // Enhanced correct answer reveal with glow effect
        tl.to(option, {
          backgroundColor: '#10B981',
          color: '#FFFFFF',
          scale: 1.02,
          boxShadow: "0 8px 32px rgba(16, 185, 129, 0.3), 0 0 0 2px rgba(16, 185, 129, 0.2)",
          duration: 0.25,
          ease: "back.out(1.7)"
        }, 0.1);
      } else {
        // More elegant fade out with slight scale down
        tl.to(option, {
          opacity: 0.4,
          scale: 0.98,
          filter: "blur(1px)",
          duration: 0.2,
          ease: "power2.out"
        }, 0);
      }
    });

    // Reduced wait time - proceed faster
    tl.call(() => {
      setTimeout(() => {
        // Pass complete answer information including correctness
        onAnswer({
          selectedOption,
          selectedIndex,
          isCorrect
        });
      }, 800); // Reduced from 2000ms to 800ms
    });
  };
  
  return (
    <motion.div
      ref={cardRef}
      className="bg-white rounded-3xl shadow-2xl p-8 max-w-4xl mx-auto relative overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
    >
      {/* 3D Background */}
      <div className="absolute inset-0 opacity-10">
        <Canvas>
          <FloatingElements />
          <OrbitControls enableZoom={false} enablePan={false} />
        </Canvas>
      </div>

      {/* Confetti Effect */}
      <Confetti show={showFeedback} isCorrect={isCorrect} />
      
      {/* Question Header */}
      <div className="relative z-10">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-800">Question {questionNumber}</h3>
              <p className="text-sm text-gray-500">of {totalQuestions}</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Target className="w-5 h-5 text-blue-500" />
            <span className="text-sm font-medium text-gray-600">Choose the best answer</span>
          </div>
        </div>
        
        {/* Progress Bar */}
        <AnimatedProgressBar progress={questionNumber} total={totalQuestions} />
        
        {/* Question Text */}
        <div ref={questionRef} className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 leading-relaxed">
            {question.question || question.text || 'Question text not available'}
          </h2>
        </div>
        
        {/* Options */}
        <div ref={optionsRef} className="space-y-4">
          {question.options && Array.isArray(question.options) ? question.options.map((option, index) => {
            // Handle both string options and object options
            const optionText = typeof option === 'string' ? option : option.text || option.option || option.value || String(option);
            const optionValue = typeof option === 'string' ? option : option.text || option.option || option.value || String(option);

            // Check if this option is correct
            let isOptionCorrect = false;
            if (typeof option === 'object' && option !== null && option.hasOwnProperty('isCorrect')) {
              isOptionCorrect = option.isCorrect === true;
            } else {
              // Fallback to text comparison
              let correctAnswer = question.correctAnswer;
              if (typeof correctAnswer === 'object' && correctAnswer !== null) {
                correctAnswer = correctAnswer.text || correctAnswer.option || correctAnswer.value || String(correctAnswer);
              }
              const normalizedOptionValue = String(optionValue).trim();
              const normalizedCorrectAnswer = String(correctAnswer).trim();
              isOptionCorrect = normalizedOptionValue === normalizedCorrectAnswer;
            }

            console.log(`Option ${index}:`, {
              raw: option,
              text: optionText,
              value: optionValue,
              isCorrect: isOptionCorrect
            });

            return (
              <motion.button
                key={index}
                onClick={() => {
                  console.log(`🖱️ Clicked option ${index}:`, optionValue);
                  handleOptionClick(optionValue, index);
                }}
                disabled={showFeedback || disabled}
                className={`w-full p-6 text-left rounded-2xl border-2 transition-all duration-300 group relative overflow-hidden ${
                  showFeedback || disabled
                    ? 'cursor-not-allowed'
                    : 'bg-gradient-to-r from-gray-50 to-gray-100 hover:from-blue-50 hover:to-purple-50 border-gray-200 hover:border-blue-300 hover:shadow-lg transform hover:-translate-y-1'
                }`}
                style={{
                  background: showFeedback
                    ? (index === selectedIndex
                        ? (isCorrect ? 'linear-gradient(135deg, #10B981, #059669)' : 'linear-gradient(135deg, #EF4444, #DC2626)')
                        : (isOptionCorrect ? 'linear-gradient(135deg, #10B981, #059669)' : 'rgba(156, 163, 175, 0.3)')
                      )
                    : undefined
                }}
                whileHover={!showFeedback && !disabled ? { scale: 1.02 } : {}}
                whileTap={!showFeedback && !disabled ? { scale: 0.98 } : {}}
              >
                <div className="flex items-center space-x-4">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 transition-colors ${
                    showFeedback
                      ? (index === selectedIndex
                          ? (isCorrect ? 'bg-green-500 border-green-500' : 'bg-red-500 border-red-500')
                          : (isOptionCorrect ? 'bg-green-500 border-green-500' : 'bg-gray-300 border-gray-300')
                        )
                      : 'bg-white border-gray-300 group-hover:border-blue-500'
                  }`}>
                    {showFeedback && (index === selectedIndex || isOptionCorrect) ? (
                      index === selectedIndex && isCorrect ? (
                        <CheckCircle className="w-5 h-5 text-white" />
                      ) : index === selectedIndex && !isCorrect ? (
                        <XCircle className="w-5 h-5 text-white" />
                      ) : isOptionCorrect ? (
                        <CheckCircle className="w-5 h-5 text-white" />
                      ) : null
                    ) : (
                      <span className={`font-semibold ${
                        showFeedback ? 'text-white' : 'text-gray-600 group-hover:text-blue-600'
                      }`}>
                        {String.fromCharCode(65 + index)}
                      </span>
                    )}
                  </div>
                  <span className={`text-lg ${
                    showFeedback
                      ? (index === selectedIndex || isOptionCorrect ? 'text-white font-semibold' : 'text-gray-600')
                      : 'text-gray-800 group-hover:text-gray-900'
                  }`}>
                    {optionText}
                  </span>
                </div>
              </motion.button>
            );
          }) : (
            <div className="text-center text-gray-500 py-8">
              No options available for this question.
            </div>
          )}
        </div>

        {/* Feedback Display */}
        <AnimatePresence>
          {showFeedback && (
            <motion.div
              initial={{ opacity: 0, y: 20, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.9 }}
              className={`mt-6 p-6 rounded-2xl border-2 ${
                isCorrect
                  ? 'bg-green-50 border-green-200'
                  : 'bg-red-50 border-red-200'
              }`}
            >
              <div className="flex items-center space-x-3">
                <div className={`p-2 rounded-full ${
                  isCorrect ? 'bg-green-100' : 'bg-red-100'
                }`}>
                  {isCorrect ? (
                    <CheckCircle className="w-6 h-6 text-green-600" />
                  ) : (
                    <XCircle className="w-6 h-6 text-red-600" />
                  )}
                </div>
                <div className="flex-1">
                  <h4 className={`text-lg font-bold ${
                    isCorrect ? 'text-green-800' : 'text-red-800'
                  }`}>
                    {isCorrect ? '🎉 Correct!' : '❌ Incorrect!'}
                  </h4>
                  <p className={`text-sm ${
                    isCorrect ? 'text-green-700' : 'text-red-700'
                  }`}>
                    {isCorrect
                      ? 'Great job! You got it right.'
                      : `The correct answer is: ${(() => {
                          // Find the correct option
                          if (question.options && Array.isArray(question.options)) {
                            const correctOption = question.options.find(opt =>
                              typeof opt === 'object' && opt.isCorrect === true
                            );
                            if (correctOption) {
                              return correctOption.text || correctOption.option || correctOption.value || String(correctOption);
                            }
                          }
                          // Fallback to question.correctAnswer
                          let correctAnswer = question.correctAnswer;
                          if (typeof correctAnswer === 'object' && correctAnswer !== null) {
                            correctAnswer = correctAnswer.text || correctAnswer.option || correctAnswer.value || String(correctAnswer);
                          }
                          return correctAnswer || 'Not available';
                        })()}`
                    }
                  </p>
                </div>
                <div className={`text-2xl font-bold ${
                  isCorrect ? 'text-green-600' : 'text-red-600'
                }`}>
                  {isCorrect ? '+1' : '+0'}
                </div>
              </div>

              {/* Progress indicator */}
              <div className="mt-4 flex items-center justify-center">
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <Clock className="w-4 h-4" />
                  <span>Next question in 1 second...</span>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
};

// Main Animated Quiz Component
const AnimatedQuiz = ({ quiz, onComplete, onClose }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState([]);
  const [timeLeft, setTimeLeft] = useState(quiz.timeLimit * 60 || 1800); // 30 minutes default
  const [showResults, setShowResults] = useState(false);
  const [currentScore, setCurrentScore] = useState(0);
  const [showingFeedback, setShowingFeedback] = useState(false);

  const containerRef = useRef();
  const timerRef = useRef();
  const scoreRef = useRef();

  // Debug: Log quiz structure
  useEffect(() => {
    console.log('🎯 Quiz data structure:', quiz);
    if (quiz.questions && quiz.questions.length > 0) {
      console.log('📝 First question structure:', quiz.questions[0]);
      console.log('🔤 Options structure:', quiz.questions[0].options);
      console.log('✅ Correct answer:', quiz.questions[0].correctAnswer);
    }
  }, [quiz]);
  
  useEffect(() => {
    // Animate container entrance
    gsap.fromTo(containerRef.current,
      { opacity: 0, y: 50 },
      { opacity: 1, y: 0, duration: 1, ease: "power2.out" }
    );
    
    // Start timer animation
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          handleQuizComplete();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    return () => clearInterval(timer);
  }, []);
  
  useEffect(() => {
    // Animate timer color based on time left
    const percentage = (timeLeft / (quiz.timeLimit * 60 || 1800)) * 100;
    let color = '#10B981'; // green
    
    if (percentage < 50) color = '#F59E0B'; // yellow
    if (percentage < 25) color = '#EF4444'; // red
    
    gsap.to(timerRef.current, {
      color: color,
      duration: 0.3
    });
  }, [timeLeft]);
  
  const handleAnswer = (answerData) => {
    const currentQ = quiz.questions[currentQuestion];

    // Handle both old format (string) and new format (object)
    let selectedOption, selectedIndex, isCorrect;

    if (typeof answerData === 'string') {
      // Old format - just the option text
      selectedOption = answerData;
      selectedIndex = -1;
      isCorrect = false;

      // Need to calculate correctness
      if (currentQ.options && Array.isArray(currentQ.options)) {
        selectedIndex = currentQ.options.findIndex(option => {
          const optionText = typeof option === 'string' ? option : (option.text || option.option || option.value || String(option));
          return optionText === selectedOption;
        });

        if (selectedIndex !== -1 && currentQ.options[selectedIndex]) {
          const selectedOptionObj = currentQ.options[selectedIndex];
          if (typeof selectedOptionObj === 'object' && selectedOptionObj.hasOwnProperty('isCorrect')) {
            isCorrect = selectedOptionObj.isCorrect === true;
          }
        }
      }
    } else {
      // New format - object with all data
      selectedOption = answerData.selectedOption;
      selectedIndex = answerData.selectedIndex;
      isCorrect = answerData.isCorrect;
    }

    // Enhanced debug logging
    console.log('🎯 Answer data received:', answerData);
    console.log('🎯 Processed data:', { selectedOption, selectedIndex, isCorrect });
    console.log('✅ Correct answer (raw):', currentQ.correctAnswer);
    console.log('📝 Question options:', currentQ.options);

    // Validation is now handled in the question card component
    // Just log the final result
    console.log('🔍 Final answer validation:', {
      selectedOption,
      selectedIndex,
      isCorrect,
      questionIndex: currentQuestion
    });

    const newAnswers = [...answers, {
      questionIndex: currentQuestion,
      selectedOption,
      selectedAnswer: selectedIndex, // Add selected index for server validation
      isCorrect
    }];

    setAnswers(newAnswers);
    setShowingFeedback(true);

    // Update score immediately if correct with enhanced animation
    if (isCorrect) {
      const newScore = currentScore + 1;
      setCurrentScore(newScore);

      // Enhanced score animation with glow and bounce
      const scoreTl = gsap.timeline();
      scoreTl.to(scoreRef.current, {
        scale: 1.3,
        rotation: 5,
        color: "#10B981",
        textShadow: "0 0 20px rgba(16, 185, 129, 0.8)",
        duration: 0.2,
        ease: "back.out(1.7)"
      })
      .to(scoreRef.current, {
        scale: 1.1,
        rotation: 0,
        duration: 0.3,
        ease: "elastic.out(1, 0.3)"
      })
      .to(scoreRef.current, {
        scale: 1,
        color: "#374151",
        textShadow: "none",
        duration: 0.2,
        ease: "power2.out"
      });

      // Add floating "+1" animation
      const plusOne = document.createElement('div');
      plusOne.textContent = '+1';
      plusOne.style.cssText = `
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        color: #10B981;
        font-weight: bold;
        font-size: 1.5rem;
        pointer-events: none;
        z-index: 1000;
      `;
      scoreRef.current.parentElement.appendChild(plusOne);

      gsap.fromTo(plusOne,
        { y: 0, opacity: 1, scale: 0.5 },
        {
          y: -50,
          opacity: 0,
          scale: 1.2,
          duration: 1,
          ease: "power2.out",
          onComplete: () => plusOne.remove()
        }
      );
    }

    // Reduced feedback time - show for only 1 second
    setTimeout(() => {
      setShowingFeedback(false);

      if (currentQuestion < quiz.questions.length - 1) {
        // Quick transition to next question
        setCurrentQuestion(prev => prev + 1);
      } else {
        handleQuizComplete(newAnswers);
      }
    }, 1000); // Reduced from 2500ms to 1000ms
  };
  
  const handleQuizComplete = (finalAnswers = answers) => {
    console.log('🏁 Quiz completion triggered');
    console.log('📊 Final answers:', finalAnswers);
    console.log('📝 Quiz questions length:', quiz.questions.length);

    setShowResults(true);

    // Debug each answer and recalculate if needed
    let correctCount = 0;
    finalAnswers.forEach((answer, index) => {
      console.log(`Answer ${index}:`, {
        questionIndex: answer.questionIndex,
        selectedOption: answer.selectedOption,
        selectedAnswer: answer.selectedAnswer,
        isCorrect: answer.isCorrect
      });

      if (answer.isCorrect === true) {
        correctCount++;
      }
    });

    const score = correctCount;
    const percentage = quiz.questions.length > 0 ? Math.round((score / quiz.questions.length) * 100) : 0;
    const timeSpentSeconds = (quiz.timeLimit * 60 || 1800) - timeLeft;

    const results = {
      answers: finalAnswers,
      score,
      percentage,
      timeSpent: timeSpentSeconds,
      totalQuestions: quiz.questions.length
    };

    console.log('🎯 Quiz results calculated:', {
      score,
      totalQuestions: quiz.questions.length,
      percentage,
      correctAnswers: finalAnswers.filter(answer => answer.isCorrect),
      results
    });

    // Add completion animation
    gsap.to(containerRef.current, {
      scale: 0.95,
      opacity: 0.8,
      duration: 0.5,
      ease: "power2.out",
      onComplete: () => {
        onComplete(results);
      }
    });
  };
  
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  if (showResults) {
    return null; // Results will be handled by parent component
  }
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 p-4">
      <div ref={containerRef} className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <motion.button
              onClick={onClose}
              className="p-3 bg-white rounded-full shadow-lg hover:shadow-xl transition-shadow"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <XCircle className="w-6 h-6 text-gray-600" />
            </motion.button>
            
            <div>
              <h1 className="text-3xl font-bold text-gray-900">{quiz.title}</h1>
              <p className="text-gray-600">{quiz.description}</p>
            </div>
          </div>
          
          {/* Score and Timer */}
          <div className="flex items-center space-x-4">
            {/* Score Counter */}
            <div className="flex items-center space-x-3 bg-white rounded-2xl px-6 py-3 shadow-lg">
              <Star className="w-6 h-6 text-yellow-500" />
              <div className="text-center">
                <div ref={scoreRef} className="text-2xl font-bold text-gray-900">
                  {currentScore}
                </div>
                <div className="text-xs text-gray-500">
                  / {quiz.questions.length}
                </div>
              </div>
            </div>

            {/* Timer */}
            <div className="flex items-center space-x-3 bg-white rounded-2xl px-6 py-3 shadow-lg">
              <Clock className="w-6 h-6 text-blue-500" />
              <span ref={timerRef} className="text-2xl font-bold">
                {formatTime(timeLeft)}
              </span>
            </div>
          </div>
        </div>
        
        {/* Question */}
        <AnimatePresence mode="wait">
          <AnimatedQuestionCard
            key={currentQuestion}
            question={quiz.questions[currentQuestion]}
            onAnswer={handleAnswer}
            questionNumber={currentQuestion + 1}
            totalQuestions={quiz.questions.length}
            disabled={showingFeedback}
          />
        </AnimatePresence>
      </div>
    </div>
  );
};

export default AnimatedQuiz;
