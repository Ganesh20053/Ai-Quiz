import React, { useState, useEffect, useRef } from 'react'
import { useSelector } from 'react-redux'
import { selectUser } from '../../features/auth/authSlice'
import Button from '../common/Button'
import Loader from '../common/Loader'
import Modal from '../common/Modal'
import VoiceButton from '../common/VoiceButton'
import AnimatedQuiz from './AnimatedQuiz'
import AnimatedQuizResults from './AnimatedQuizResults'
import QuizErrorBoundary from '../common/QuizErrorBoundary'

const RegularQuiz = ({ quiz, classroom, assignment, onComplete, onClose, isFullPage = false }) => {
  const user = useSelector(selectUser)
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [answers, setAnswers] = useState([])
  const [timeSpent, setTimeSpent] = useState(0)
  const [startedAt, setStartedAt] = useState(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState(null)
  const [showVoiceButton, setShowVoiceButton] = useState(false)
  const [useAnimatedMode, setUseAnimatedMode] = useState(true) // Enable animated mode by default
  const [quizResults, setQuizResults] = useState(null)
  const [showResults, setShowResults] = useState(false)
  const [animatedModeError, setAnimatedModeError] = useState(false)

  const timerRef = useRef(null)

  useEffect(() => {
    setStartedAt(new Date())
    
    // Start timer
    timerRef.current = setInterval(() => {
      setTimeSpent(prev => prev + 1)
    }, 1000)

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
    }
  }, [])

  const handleAnswerSelect = (answerIndex) => {
    const newAnswers = [...answers]
    newAnswers[currentQuestionIndex] = {
      questionIndex: currentQuestionIndex,
      selectedAnswer: answerIndex,
      isCorrect: quiz.questions[currentQuestionIndex].options[answerIndex]?.isCorrect || false
    }
    setAnswers(newAnswers)
  }

  const handleNext = () => {
    if (currentQuestionIndex < quiz.questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1)
    }
  }

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1)
    }
  }

  const handleSubmit = async () => {
    setIsSubmitting(true)
    
    if (timerRef.current) {
      clearInterval(timerRef.current)
    }

    const completedAnswers = answers.filter(answer => answer !== undefined)
    const score = completedAnswers.filter(answer => answer.isCorrect).length
    const percentage = Math.round((score / quiz.questions.length) * 100)

    const submissionData = {
      answers: completedAnswers,
      startedAt: startedAt,
      completedAt: new Date(),
      timeSpent: Math.floor(timeSpent / 60), // Convert to minutes
      score,
      percentage,
      isVoiceControlled: false
    }

    try {
      const token = localStorage.getItem('token')
      const response = await fetch(`/api/classroom/assignments/${assignment._id}/submit`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(submissionData)
      })

      if (!response.ok) {
        throw new Error('Failed to submit quiz')
      }

      const result = await response.json()
      
      setTimeout(() => {
        onComplete(result.data)
      }, 2000)

    } catch (error) {
      console.error('Error submitting quiz:', error)
      setError('Failed to submit quiz. Please try again.')
    }
  }

  // Handlers for animated quiz
  const handleAnimatedQuizComplete = async (results) => {
    console.log('🎯 Quiz completed with results:', results);
    setQuizResults(results)
    setShowResults(true)

    // Submit to backend
    try {
      const submissionData = {
        answers: results.answers.map(answer => {
          // Ensure selectedAnswer is properly set
          let selectedAnswer = answer.selectedAnswer;
          if (typeof selectedAnswer !== 'number' || selectedAnswer < 0) {
            // Find the index by matching the selected option text
            const question = quiz.questions[answer.questionIndex];
            if (question && question.options) {
              selectedAnswer = question.options.findIndex(opt => {
                const optText = typeof opt === 'string' ? opt : (opt.text || opt.option || opt.value || String(opt));
                return optText === answer.selectedOption;
              });
              if (selectedAnswer === -1) selectedAnswer = 0; // Fallback to first option
            } else {
              selectedAnswer = 0;
            }
          }

          return {
            questionIndex: answer.questionIndex,
            selectedAnswer: selectedAnswer,
            selectedOption: answer.selectedOption,
            isCorrect: answer.isCorrect
          };
        }),
        timeSpent: Math.floor(results.timeSpent / 60), // Convert to minutes
        score: results.score,
        percentage: results.percentage,
        isVoiceControlled: false
      };

      console.log('📤 Submitting quiz data:', submissionData);

      const token = localStorage.getItem('token');
      const response = await fetch(`/api/classroom/assignments/${assignment._id}/submit`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(submissionData)
      });

      if (!response.ok) {
        throw new Error('Failed to submit quiz');
      }

      const result = await response.json();
      console.log('✅ Quiz submitted successfully:', result);

    } catch (error) {
      console.error('❌ Error submitting quiz:', error);
      // Still show results even if submission fails
    }
  }

  const handleRetakeQuiz = () => {
    setShowResults(false)
    setQuizResults(null)
    setCurrentQuestionIndex(0)
    setAnswers([])
    setTimeSpent(0)
    setStartedAt(Date.now())
  }

  const handleCloseResults = () => {
    setShowResults(false)
    onClose()
  }

  const currentQuestion = quiz.questions[currentQuestionIndex]
  const progress = ((currentQuestionIndex + 1) / quiz.questions.length) * 100
  const answeredQuestions = answers.filter(answer => answer !== undefined).length

  // Show animated results if available
  if (showResults && quizResults) {
    return (
      <AnimatedQuizResults
        results={quizResults}
        quiz={quiz}
        onClose={handleCloseResults}
        onRetake={handleRetakeQuiz}
      />
    )
  }

  // Show animated quiz if enabled and no error occurred
  if (useAnimatedMode && !showResults && !animatedModeError) {
    return (
      <QuizErrorBoundary
        onClose={onClose}
        onError={() => setAnimatedModeError(true)}
      >
        <AnimatedQuiz
          quiz={quiz}
          onComplete={handleAnimatedQuizComplete}
          onClose={onClose}
        />
      </QuizErrorBoundary>
    )
  }

  // Quiz content component
  const QuizContent = () => {
    return (
      <div className="space-y-6">
        {/* Progress and Timer */}
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-gray-700">
              Question {currentQuestionIndex + 1} of {quiz.questions.length}
            </span>
            <span className="text-sm text-gray-500">
              Time: {Math.floor(timeSpent / 60)}:{(timeSpent % 60).toString().padStart(2, '0')}
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="mt-2 text-sm text-gray-600">
            {answeredQuestions} of {quiz.questions.length} questions answered
          </div>
        </div>

        {/* Current Question */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Question {currentQuestionIndex + 1}
          </h3>
          
          <p className="text-gray-700 mb-6 text-lg">
            {currentQuestion?.question}
          </p>

          {currentQuestion?.type === 'multiple-choice' && currentQuestion?.options && (
            <div className="space-y-3">
              {currentQuestion.options.map((option, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-lg border-2 transition-all cursor-pointer ${
                    answers[currentQuestionIndex]?.selectedAnswer === index
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => handleAnswerSelect(index)}
                >
                  <div className="flex items-center">
                    <span className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center text-sm font-medium mr-3">
                      {String.fromCharCode(65 + index)}
                    </span>
                    <span className="text-gray-700">{option.text}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Voice Button for Regular Students */}
        <div className="flex justify-center">
          <VoiceButton
            onToggle={() => setShowVoiceButton(!showVoiceButton)}
            isActive={showVoiceButton}
            className="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
          >
            {showVoiceButton ? 'Disable Voice' : 'Enable Voice'}
          </VoiceButton>
        </div>

        {/* Voice Instructions */}
        {showVoiceButton && (
          <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
            <h4 className="font-medium text-purple-900 mb-2">Voice Commands Available:</h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
              <div className="bg-white p-2 rounded border">
                <span className="font-medium">"Answer A/B/C/D"</span> - Select answer
              </div>
              <div className="bg-white p-2 rounded border">
                <span className="font-medium">"Next"</span> - Next question
              </div>
              <div className="bg-white p-2 rounded border">
                <span className="font-medium">"Previous"</span> - Previous question
              </div>
              <div className="bg-white p-2 rounded border">
                <span className="font-medium">"Submit"</span> - Submit quiz
              </div>
            </div>
          </div>
        )}

        {/* Navigation Controls */}
        <div className="flex justify-between items-center">
          <div className="flex space-x-4">
            <Button
              onClick={handlePrevious}
              disabled={currentQuestionIndex === 0}
              className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 disabled:opacity-50"
            >
              Previous
            </Button>
            
            <Button
              onClick={handleNext}
              disabled={currentQuestionIndex === quiz.questions.length - 1}
              className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 disabled:opacity-50"
            >
              Next
            </Button>
          </div>

          <div className="flex space-x-4">
            <Button
              onClick={onClose}
              className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
            >
              Cancel
            </Button>
            
            <Button
              onClick={handleSubmit}
              disabled={isSubmitting || answeredQuestions < quiz.questions.length}
              className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50"
            >
              {isSubmitting ? <Loader size="sm" /> : 'Submit Quiz'}
            </Button>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <p className="text-red-800">{error}</p>
          </div>
        )}

        {/* Quiz Summary */}
        <div className="bg-gray-50 rounded-lg p-4">
          <h4 className="font-medium text-gray-900 mb-2">Quiz Summary</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div>
              <span className="text-gray-500">Total Questions:</span>
              <div className="font-medium">{quiz.questions.length}</div>
            </div>
            <div>
              <span className="text-gray-500">Answered:</span>
              <div className="font-medium">{answeredQuestions}</div>
            </div>
            <div>
              <span className="text-gray-500">Remaining:</span>
              <div className="font-medium">{quiz.questions.length - answeredQuestions}</div>
            </div>
            <div>
              <span className="text-gray-500">Time Spent:</span>
              <div className="font-medium">{Math.floor(timeSpent / 60)}:{(timeSpent % 60).toString().padStart(2, '0')}</div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Conditional rendering based on isFullPage prop
  if (isFullPage) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header for full page */}
        <div className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-10">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center justify-between">
              <h1 className="text-xl font-semibold text-gray-900">
                Quiz: {quiz.title}
              </h1>
              <Button
                onClick={onClose}
                className="text-gray-500 hover:text-gray-700 p-2 rounded-lg hover:bg-gray-100"
              >
                ✕
              </Button>
            </div>
          </div>
        </div>

        {/* Quiz content */}
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <QuizContent />
        </div>
      </div>
    );
  }

  // Modal rendering for embedded mode
  return (
    <Modal
      isOpen={true}
      onClose={onClose}
      title={`Quiz: ${quiz.title}`}
      size="xl"
    >
      <QuizContent />
    </Modal>
  )
}

export default RegularQuiz 