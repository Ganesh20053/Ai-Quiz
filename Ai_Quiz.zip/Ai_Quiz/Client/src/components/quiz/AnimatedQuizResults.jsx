import React, { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { TextPlugin } from 'gsap/TextPlugin';
import { motion, AnimatePresence } from 'framer-motion';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Text3D, Center, Float, Sparkles } from '@react-three/drei';
import { 
  Trophy, 
  Star, 
  Award, 
  Target, 
  CheckCircle, 
  XCircle, 
  Clock, 
  Brain,
  Zap,
  Medal,
  Crown,
  Gem
} from 'lucide-react';

// Register GSAP plugins
gsap.registerPlugin(TextPlugin);

// 3D Trophy Component
const Trophy3D = ({ performance }) => {
  const trophyRef = useRef();
  
  useEffect(() => {
    if (trophyRef.current) {
      gsap.to(trophyRef.current.rotation, {
        y: Math.PI * 2,
        duration: 4,
        repeat: -1,
        ease: "none"
      });
    }
  }, []);
  
  const getTrophyColor = () => {
    if (performance >= 90) return "#FFD700"; // Gold
    if (performance >= 80) return "#C0C0C0"; // Silver
    if (performance >= 70) return "#CD7F32"; // Bronze
    return "#6B7280"; // Gray
  };
  
  return (
    <Float speed={1.5} rotationIntensity={0.5} floatIntensity={2}>
      <mesh ref={trophyRef}>
        <cylinderGeometry args={[0.8, 1.2, 2, 8]} />
        <meshStandardMaterial color={getTrophyColor()} metalness={0.8} roughness={0.2} />
      </mesh>
      
      {/* Trophy handles */}
      <mesh position={[-1.2, 0.5, 0]}>
        <torusGeometry args={[0.3, 0.1, 8, 16]} />
        <meshStandardMaterial color={getTrophyColor()} metalness={0.8} roughness={0.2} />
      </mesh>
      
      <mesh position={[1.2, 0.5, 0]}>
        <torusGeometry args={[0.3, 0.1, 8, 16]} />
        <meshStandardMaterial color={getTrophyColor()} metalness={0.8} roughness={0.2} />
      </mesh>
      
      {/* Base */}
      <mesh position={[0, -1.5, 0]}>
        <cylinderGeometry args={[1.5, 1.5, 0.5, 8]} />
        <meshStandardMaterial color="#4B5563" metalness={0.6} roughness={0.3} />
      </mesh>
    </Float>
  );
};

// Floating Particles
const FloatingParticles = () => {
  return (
    <>
      <Sparkles count={100} scale={[10, 10, 10]} size={2} speed={0.5} />
      
      {Array.from({ length: 20 }).map((_, i) => (
        <Float key={i} speed={1 + Math.random()} rotationIntensity={1} floatIntensity={2}>
          <mesh position={[
            (Math.random() - 0.5) * 20,
            (Math.random() - 0.5) * 10,
            (Math.random() - 0.5) * 10
          ]}>
            <sphereGeometry args={[0.1, 8, 8]} />
            <meshStandardMaterial 
              color={`hsl(${Math.random() * 360}, 70%, 60%)`}
              emissive={`hsl(${Math.random() * 360}, 70%, 30%)`}
            />
          </mesh>
        </Float>
      ))}
      
      <ambientLight intensity={0.6} />
      <pointLight position={[10, 10, 10]} intensity={1} />
      <pointLight position={[-10, -10, -10]} intensity={0.5} color="#3B82F6" />
    </>
  );
};

// Enhanced Animated Score Counter with more dramatic effects
const AnimatedScore = ({ score, total, duration = 3 }) => {
  const scoreRef = useRef();
  const [displayScore, setDisplayScore] = useState(0);
  const [displayTotal, setDisplayTotal] = useState(0);

  // Debug logging
  console.log('🎯 AnimatedScore received:', { score, total, duration });

  useEffect(() => {
    // Reset display values
    setDisplayScore(0);
    setDisplayTotal(0);

    // Ensure we have valid numbers
    const validScore = Number(score) || 0;
    const validTotal = Number(total) || 0;

    console.log('🎯 AnimatedScore animating:', { validScore, validTotal });

    // Animate score counting
    gsap.to({ value: 0 }, {
      value: validScore,
      duration: duration * 0.7,
      ease: "power2.out",
      onUpdate: function() {
        setDisplayScore(Math.round(this.targets()[0].value));
      }
    });

    // Animate total counting (slightly delayed)
    gsap.to({ value: 0 }, {
      value: validTotal,
      duration: duration * 0.5,
      delay: 0.3,
      ease: "power2.out",
      onUpdate: function() {
        setDisplayTotal(Math.round(this.targets()[0].value));
      }
    });

    // Add pulsing animation to the score element
    if (scoreRef.current) {
      gsap.fromTo(scoreRef.current,
        { scale: 0.5, opacity: 0 },
        {
          scale: 1,
          opacity: 1,
          duration: 0.8,
          ease: "back.out(1.7)",
          delay: 0.5
        }
      );
    }
  }, [score, total, duration]);

  return (
    <span
      ref={scoreRef}
      className="text-7xl font-bold bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 bg-clip-text text-transparent drop-shadow-lg"
      style={{
        textShadow: '0 0 30px rgba(255, 215, 0, 0.5)'
      }}
    >
      {displayScore}/{displayTotal}
    </span>
  );
};

// Animated Credits Counter
const AnimatedCredits = ({ credits, duration = 2 }) => {
  const creditsRef = useRef();
  const [displayCredits, setDisplayCredits] = useState(0);

  useEffect(() => {
    gsap.to({ value: 0 }, {
      value: credits,
      duration,
      ease: "power2.out",
      delay: 1.4,
      onUpdate: function() {
        setDisplayCredits(Math.round(this.targets()[0].value));
      }
    });
  }, [credits, duration]);

  return (
    <span ref={creditsRef} className="text-5xl font-bold text-purple-400 drop-shadow-lg">
      {displayCredits}
    </span>
  );
};

// Performance Badge
const PerformanceBadge = ({ percentage }) => {
  const badgeRef = useRef();
  
  useEffect(() => {
    gsap.fromTo(badgeRef.current,
      { scale: 0, rotation: -180 },
      { scale: 1, rotation: 0, duration: 1, ease: "back.out(1.7)", delay: 1 }
    );
  }, []);
  
  const getBadgeInfo = () => {
    if (percentage >= 90) return { icon: Crown, color: "from-yellow-400 to-yellow-600", text: "Excellent!", bg: "bg-yellow-100" };
    if (percentage >= 80) return { icon: Medal, color: "from-gray-400 to-gray-600", text: "Great Job!", bg: "bg-gray-100" };
    if (percentage >= 70) return { icon: Award, color: "from-orange-400 to-orange-600", text: "Good Work!", bg: "bg-orange-100" };
    if (percentage >= 60) return { icon: Target, color: "from-blue-400 to-blue-600", text: "Well Done!", bg: "bg-blue-100" };
    return { icon: Brain, color: "from-purple-400 to-purple-600", text: "Keep Learning!", bg: "bg-purple-100" };
  };
  
  const badge = getBadgeInfo();
  const Icon = badge.icon;
  
  return (
    <motion.div
      ref={badgeRef}
      className={`${badge.bg} rounded-full p-6 shadow-2xl`}
      whileHover={{ scale: 1.1 }}
    >
      <div className={`w-20 h-20 bg-gradient-to-r ${badge.color} rounded-full flex items-center justify-center`}>
        <Icon className="w-10 h-10 text-white" />
      </div>
      <p className="text-center mt-3 font-bold text-gray-800">{badge.text}</p>
    </motion.div>
  );
};

// Question Review Card
const QuestionReviewCard = ({ question, answer, index }) => {
  const cardRef = useRef();
  
  useEffect(() => {
    gsap.fromTo(cardRef.current,
      { x: -100, opacity: 0 },
      { x: 0, opacity: 1, duration: 0.6, delay: index * 0.1, ease: "power2.out" }
    );
  }, [index]);
  
  return (
    <motion.div
      ref={cardRef}
      className={`p-6 rounded-2xl border-l-4 ${
        answer.isCorrect 
          ? 'bg-green-50 border-green-500' 
          : 'bg-red-50 border-red-500'
      } shadow-lg hover:shadow-xl transition-shadow`}
      whileHover={{ scale: 1.02 }}
    >
      <div className="flex items-start space-x-4">
        <div className={`p-2 rounded-full ${
          answer.isCorrect ? 'bg-green-100' : 'bg-red-100'
        }`}>
          {answer.isCorrect ? (
            <CheckCircle className="w-6 h-6 text-green-600" />
          ) : (
            <XCircle className="w-6 h-6 text-red-600" />
          )}
        </div>
        
        <div className="flex-1">
          <h4 className="font-semibold text-gray-900 mb-2">
            Question {index + 1}
          </h4>
          <p className="text-gray-700 mb-3">{question.question}</p>
          
          <div className="space-y-2">
            <div className={`p-3 rounded-lg ${
              answer.isCorrect ? 'bg-green-100' : 'bg-red-100'
            }`}>
              <span className="text-sm font-medium text-gray-600">Your Answer: </span>
              <span className={answer.isCorrect ? 'text-green-800' : 'text-red-800'}>
                {answer.selectedOption}
              </span>
            </div>
            
            {!answer.isCorrect && (
              <div className="p-3 rounded-lg bg-green-100">
                <span className="text-sm font-medium text-gray-600">Correct Answer: </span>
                <span className="text-green-800">{question.correctAnswer}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
};

// Main Results Component
const AnimatedQuizResults = ({ results, quiz, onClose, onRetake, isFullPage = false }) => {
  const [showDetails, setShowDetails] = useState(false);
  const containerRef = useRef();
  const titleRef = useRef();
  const statsRef = useRef();

  // Debug logging
  console.log('🎯 AnimatedQuizResults received:', { results, quiz });
  console.log('🔍 Results breakdown:', {
    'results.score': results?.score,
    'results.totalQuestions': results?.totalQuestions,
    'results.answers': results?.answers,
    'quiz.questions.length': quiz?.questions?.length
  });

  // Ensure we have valid results with proper score calculation
  let score = results?.score || 0;
  let totalQuestions = results?.totalQuestions || quiz?.questions?.length || 0;
  const timeSpentRaw = results?.timeSpent || 0;
  const answers = results?.answers || [];

  // Debug each answer
  console.log('📝 Analyzing answers:');
  answers.forEach((answer, index) => {
    console.log(`Answer ${index}:`, {
      questionIndex: answer.questionIndex,
      selectedOption: answer.selectedOption,
      selectedAnswer: answer.selectedAnswer,
      isCorrect: answer.isCorrect,
      type: typeof answer.isCorrect
    });
  });

  // Recalculate score from answers if needed
  if (answers.length > 0) {
    const calculatedScore = answers.filter(answer => answer.isCorrect === true).length;
    console.log('🧮 Score calculation:', {
      originalScore: score,
      calculatedScore,
      answersWithCorrectTrue: answers.filter(answer => answer.isCorrect === true),
      totalAnswers: answers.length
    });

    if (score === 0 || calculatedScore > score) {
      score = calculatedScore;
      console.log('🔧 Updated score to:', score);
    }
  }

  // Ensure we have valid numbers
  if (totalQuestions === 0 && quiz?.questions?.length > 0) {
    totalQuestions = quiz.questions.length;
  }

  // Calculate percentage properly
  const percentage = totalQuestions > 0 ? Math.round((score / totalQuestions) * 100) : 0;

  // Fix time calculation - timeSpentRaw is in seconds
  const timeSpentMinutes = Math.floor(timeSpentRaw / 60);
  const timeSpentSeconds = timeSpentRaw % 60;
  const timeSpentFormatted = `${timeSpentMinutes}:${timeSpentSeconds.toString().padStart(2, '0')}`;

  // Better credits calculation - more generous rewards
  const baseCredits = Math.floor(percentage * 2); // 2 credits per percentage point
  const bonusCredits = percentage >= 80 ? 20 : percentage >= 60 ? 10 : 0; // Bonus for good performance
  const credits = baseCredits + bonusCredits;

  const safeResults = {
    score,
    totalQuestions,
    timeSpent: timeSpentRaw,
    answers,
    percentage
  };

  console.log('📊 Calculated values:', {
    score,
    totalQuestions,
    percentage,
    timeSpentRaw,
    timeSpentMinutes,
    timeSpentFormatted,
    baseCredits,
    bonusCredits,
    credits,
    safeResults,
    originalResults: results
  });
  
  useEffect(() => {
    const tl = gsap.timeline();
    
    // Animate container entrance
    tl.fromTo(containerRef.current,
      { opacity: 0, scale: 0.8 },
      { opacity: 1, scale: 1, duration: 1, ease: "back.out(1.7)" }
    )
    .fromTo(titleRef.current,
      { y: -50, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.8, ease: "power2.out" },
      "-=0.5"
    )
    .fromTo(statsRef.current.children,
      { y: 30, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.6, stagger: 0.2, ease: "power2.out" },
      "-=0.3"
    );
  }, []);
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 relative overflow-hidden">
      {/* 3D Background */}
      <div className="absolute inset-0 opacity-30">
        <Canvas>
          <FloatingParticles />
          <Trophy3D performance={percentage} />
          <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.5} />
        </Canvas>
      </div>
      
      <div ref={containerRef} className="relative z-10 p-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div ref={titleRef} className="text-center mb-12">
            <motion.h1 
              className="text-6xl font-bold text-white mb-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 0.5 }}
            >
              Quiz Complete!
            </motion.h1>
            <p className="text-2xl text-blue-200">{quiz.title}</p>
          </div>
          
          {/* Main Stats */}
          <div ref={statsRef} className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {/* Enhanced Score Display */}
            <motion.div
              className="bg-gradient-to-br from-yellow-400/20 to-orange-500/20 backdrop-blur-lg rounded-3xl p-8 text-center border-2 border-yellow-400/30 relative overflow-hidden"
              whileHover={{ scale: 1.05, rotateY: 5 }}
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              {/* Animated background glow */}
              <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/10 to-orange-500/10 animate-pulse"></div>

              <div className="relative z-10">
                <motion.div
                  initial={{ scale: 0, rotate: -180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ duration: 1, delay: 0.5, type: "spring", stiffness: 200 }}
                >
                  <Trophy className="w-20 h-20 text-yellow-400 mx-auto mb-4 drop-shadow-lg" />
                </motion.div>

                <h3 className="text-3xl font-bold text-white mb-4 drop-shadow-lg">Final Score</h3>

                <div className="mb-4">
                  <AnimatedScore score={score} total={totalQuestions} />
                </div>

                {/* Large static score display as backup */}
                <div className="text-white text-6xl font-bold mb-4 bg-black/20 p-4 rounded-lg">
                  <span className="text-yellow-400">{score}</span>
                  <span className="text-white/70">/</span>
                  <span className="text-blue-400">{totalQuestions}</span>
                </div>

                {/* Debug info for troubleshooting */}
                {process.env.NODE_ENV === 'development' && (
                  <div className="text-white text-xs mb-4 opacity-30 bg-black/20 p-2 rounded">
                    <p>Debug Info:</p>
                    <p>Score: {score}, Total: {totalQuestions}, Percentage: {percentage}</p>
                    <p>Results: {JSON.stringify(results, null, 2)}</p>
                  </div>
                )}

                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 0.6, delay: 1.5, type: "spring", stiffness: 300 }}
                >
                  <p className="text-5xl font-bold text-yellow-400 mt-4 drop-shadow-lg">
                    {percentage}%
                  </p>
                </motion.div>

                <motion.p
                  className={`text-lg font-semibold mt-2 ${
                    percentage >= 80 ? 'text-green-300' :
                    percentage >= 60 ? 'text-yellow-300' : 'text-red-300'
                  }`}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 2 }}
                >
                  {percentage >= 80 ? '🎉 Excellent!' :
                   percentage >= 60 ? '👍 Good Job!' : '💪 Keep Practicing!'}
                </motion.p>
              </div>
            </motion.div>
            
            {/* Enhanced Time Display */}
            <motion.div
              className="bg-gradient-to-br from-blue-400/20 to-cyan-500/20 backdrop-blur-lg rounded-3xl p-8 text-center border-2 border-blue-400/30 relative overflow-hidden"
              whileHover={{ scale: 1.05, rotateY: 5 }}
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-blue-400/10 to-cyan-500/10 animate-pulse"></div>
              <div className="relative z-10">
                <motion.div
                  initial={{ scale: 0, rotate: -180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ duration: 1, delay: 0.7, type: "spring", stiffness: 200 }}
                >
                  <Clock className="w-20 h-20 text-blue-400 mx-auto mb-4 drop-shadow-lg" />
                </motion.div>
                <h3 className="text-3xl font-bold text-white mb-4 drop-shadow-lg">Time Spent</h3>
                <motion.p
                  className="text-5xl font-bold text-blue-400 mb-2 drop-shadow-lg"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 0.6, delay: 1.2, type: "spring", stiffness: 300 }}
                >
                  {timeSpentFormatted}
                </motion.p>
                <p className="text-white/70 text-lg">out of {quiz.timeLimit || 30} minutes</p>
              </div>
            </motion.div>
            
            {/* Enhanced Credits Display */}
            <motion.div
              className="bg-gradient-to-br from-purple-400/20 to-pink-500/20 backdrop-blur-lg rounded-3xl p-8 text-center border-2 border-purple-400/30 relative overflow-hidden"
              whileHover={{ scale: 1.05, rotateY: -5 }}
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-purple-400/10 to-pink-500/10 animate-pulse"></div>
              <div className="relative z-10">
                <motion.div
                  initial={{ scale: 0, rotate: 180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ duration: 1, delay: 0.9, type: "spring", stiffness: 200 }}
                >
                  <Gem className="w-20 h-20 text-purple-400 mx-auto mb-4 drop-shadow-lg" />
                </motion.div>
                <h3 className="text-3xl font-bold text-white mb-4 drop-shadow-lg">Credits Earned</h3>
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 0.6, delay: 1.4, type: "spring", stiffness: 300 }}
                  className="mb-2"
                >
                  <AnimatedCredits credits={credits} />
                </motion.div>
                <p className="text-white/70 text-lg">Knowledge Points</p>
                {bonusCredits > 0 && (
                  <motion.p
                    className="text-yellow-400 text-sm mt-2 font-semibold"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 1.8 }}
                  >
                    🎉 +{bonusCredits} Bonus!
                  </motion.p>
                )}
              </div>
            </motion.div>
          </div>
          
          {/* Performance Badge */}
          <div className="flex justify-center mb-12">
            <PerformanceBadge percentage={percentage} />
          </div>
          
          {/* Action Buttons */}
          <div className="flex justify-center space-x-6 mb-12">
            <motion.button
              onClick={() => setShowDetails(!showDetails)}
              className="px-8 py-4 bg-white/20 backdrop-blur-lg text-white rounded-2xl border border-white/30 hover:bg-white/30 transition-all"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {showDetails ? 'Hide Details' : 'View Details'}
            </motion.button>
            
            <motion.button
              onClick={onRetake}
              className="px-8 py-4 bg-blue-600 text-white rounded-2xl hover:bg-blue-700 transition-all"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Retake Quiz
            </motion.button>
            
            <motion.button
              onClick={onClose}
              className="px-8 py-4 bg-gray-600 text-white rounded-2xl hover:bg-gray-700 transition-all"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Close
            </motion.button>
          </div>
          
          {/* Detailed Results */}
          <AnimatePresence>
            {showDetails && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="bg-white/10 backdrop-blur-lg rounded-3xl p-8 border border-white/20"
              >
                <h3 className="text-3xl font-bold text-white mb-8 text-center">Question Review</h3>
                <div className="space-y-6 max-h-96 overflow-y-auto">
                  {safeResults.answers.map((answer, index) => (
                    <QuestionReviewCard
                      key={index}
                      question={quiz?.questions?.[answer.questionIndex] || {}}
                      answer={answer}
                      index={index}
                    />
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

export default AnimatedQuizResults;
