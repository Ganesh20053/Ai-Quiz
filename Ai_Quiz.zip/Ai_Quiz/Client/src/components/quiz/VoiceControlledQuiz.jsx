import React, { useState, useEffect, useRef } from 'react'
import { useSelector } from 'react-redux'
import { selectUser } from '../../features/auth/authSlice'
import { useTheme } from '../../contexts/ThemeContext'
import Button from '../common/Button'
import Loader from '../common/Loader'
import Modal from '../common/Modal'
import { Mic, Volume2, SkipForward, SkipBack, Square, Play, Pause, HelpCircle, CheckCircle } from 'lucide-react'

const VoiceControlledQuiz = ({ quiz, assignment, onComplete, onClose, isFullPage = false, user }) => {
  const theme = useTheme()
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [answers, setAnswers] = useState([])
  const [isListening, setIsListening] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [isReading, setIsReading] = useState(false)
  const [feedback, setFeedback] = useState('')
  const [timeSpent, setTimeSpent] = useState(0)
  const [startedAt, setStartedAt] = useState(null)
  const [voiceCommands, setVoiceCommands] = useState([])
  const [accessibilityLog, setAccessibilityLog] = useState([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState(null)
  const [interimTranscript, setInterimTranscript] = useState('')
  const [finalTranscript, setFinalTranscript] = useState('')
  const [debugInfo, setDebugInfo] = useState('')
  const [speechQueue, setSpeechQueue] = useState([])
  const [speechProcessing, setSpeechProcessing] = useState(false)

  const recognitionRef = useRef(null)
  const speechRef = useRef(null)
  const timerRef = useRef(null)
  const manuallyStoppedRef = useRef(false)

  // Enhanced voice commands mapping
  const voiceCommandsMap = {
    // Navigation commands
    'next question': () => handleNext(),
    'next': () => handleNext(),
    'previous question': () => handlePrevious(),
    'previous': () => handlePrevious(),
    'back': () => handlePrevious(),
    'skip question': () => handleSkip(),
    'skip': () => handleSkip(),

    // Reading commands
    'repeat question': () => readCurrentQuestion(),
    'repeat': () => readCurrentQuestion(),
    'read question': () => readCurrentQuestion(),
    'read options': () => readOptions(),
    'read all': () => readQuestionAndOptions(),

    // Answer selection commands
    'select option a': () => selectAnswer(0),
    'select option b': () => selectAnswer(1),
    'select option c': () => selectAnswer(2),
    'select option d': () => selectAnswer(3),
    'option a': () => selectAnswer(0),
    'option b': () => selectAnswer(1),
    'option c': () => selectAnswer(2),
    'option d': () => selectAnswer(3),
    'answer a': () => selectAnswer(0),
    'answer b': () => selectAnswer(1),
    'answer c': () => selectAnswer(2),
    'answer d': () => selectAnswer(3),
    'choose a': () => selectAnswer(0),
    'choose b': () => selectAnswer(1),
    'choose c': () => selectAnswer(2),
    'choose d': () => selectAnswer(3),

    // Quiz control commands
    'submit quiz': () => handleFinish(),
    'finish quiz': () => handleFinish(),
    'submit': () => handleFinish(),
    'finish': () => handleFinish(),
    'complete quiz': () => handleFinish(),

    // Voice control commands
    'stop listening': () => stopListening(),
    'stop voice': () => stopListening(),
    'pause voice': () => stopListening(),
    'stop speaking': () => stopSpeaking(),
    'quiet': () => stopSpeaking(),
    'silence': () => stopSpeaking(),
    'help': () => provideHelp(),
    'commands': () => provideHelp(),
    'what can i say': () => provideHelp(),

    // Status commands
    'current question': () => announceCurrentStatus(),
    'question number': () => announceQuestionNumber(),
    'time remaining': () => announceTimeRemaining(),
    'my progress': () => announceProgress(),
    'how many questions': () => announceQuestionCount()
  }

  useEffect(() => {
    initializeVoiceRecognition()
    initializeSpeechSynthesis()
    setStartedAt(new Date())

    // Welcome announcement with quiz details
    setTimeout(() => {
      const quizTitle = quiz?.title || 'Untitled Quiz'
      const questionCount = quiz?.questions?.length || 0
      const timeLimit = assignment?.settings?.timeLimit || null

      let welcomeMessage = `Welcome to the voice-controlled quiz: ${quizTitle}. `
      if (questionCount > 0) {
        welcomeMessage += `This quiz has ${questionCount} questions. `
      }
      if (timeLimit) {
        welcomeMessage += `Time limit: ${timeLimit} minutes. `
      }
      welcomeMessage += `Voice control is active. I will now read the first question.`

      speak(welcomeMessage, true)

      // Read first question after welcome message
      setTimeout(() => {
        readCurrentQuestion()
      }, 2000)
    }, 1000)

    // Start timer
    timerRef.current = setInterval(() => {
      setTimeSpent(prev => prev + 1)
    }, 1000)

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
      if (recognitionRef.current) {
        recognitionRef.current.stop()
      }
      if (speechRef.current) {
        window.speechSynthesis.cancel()
      }
    }
  }, [])

  const initializeVoiceRecognition = () => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
      recognitionRef.current = new SpeechRecognition()

      recognitionRef.current.continuous = true
      recognitionRef.current.interimResults = true
      recognitionRef.current.lang = 'en-US'

      recognitionRef.current.onstart = () => {
        setIsListening(true)
        setDebugInfo('Voice recognition active')
        logAccessibility('Voice recognition started')
      }

      recognitionRef.current.onresult = (event) => {
        let interimText = ''
        let finalText = ''

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript
          if (event.results[i].isFinal) {
            finalText += transcript
          } else {
            interimText += transcript
          }
        }

        setInterimTranscript(interimText)
        if (finalText) {
          setFinalTranscript(finalText)
          const command = finalText.toLowerCase().trim()
          setDebugInfo(`Command: ${command}`)
          handleVoiceCommand(command)
        }
      }

      recognitionRef.current.onerror = (event) => {
        console.error('Speech recognition error:', event.error)

        let errorMessage = ''
        switch (event.error) {
          case 'not-allowed':
            errorMessage = 'Microphone access denied. Please allow microphone access and refresh the page.'
            break
          case 'no-speech':
            errorMessage = 'No speech detected. Please try speaking again.'
            break
          case 'audio-capture':
            errorMessage = 'No microphone found. Please check your microphone connection.'
            break
          case 'network':
            errorMessage = 'Network error. Please check your internet connection.'
            break
          default:
            errorMessage = `Voice error: ${event.error}`
        }

        setDebugInfo(errorMessage)
        setError(errorMessage)

        if (event.error === 'not-allowed') {
          speak('Microphone access is required for voice control. Please allow microphone access in your browser and refresh the page.', true)
        }
        setIsListening(false)
        setError(`Voice recognition error: ${event.error}`)
        logAccessibility(`Voice recognition error: ${event.error}`)
      }

      recognitionRef.current.onend = () => {
        setIsListening(false)
        logAccessibility('Voice recognition ended')
        // Restart listening if not manually stopped
        if (!manuallyStoppedRef.current && !isSubmitting) {
          setTimeout(() => {
            if (recognitionRef.current && !isListening) {
              try {
                recognitionRef.current.start()
              } catch (error) {
                console.error('Error restarting voice recognition:', error)
              }
            }
          }, 1000)
        }
      }

      // Start listening automatically after a short delay
      setTimeout(() => {
        if (recognitionRef.current && user?.isDisabled) {
          try {
            recognitionRef.current.start()
            setIsListening(true)
          } catch (error) {
            console.error('Error starting voice recognition:', error)
            setError('Failed to start voice recognition automatically')
          }
        }
      }, 1000)
    } else {
      setError('Speech recognition not supported in this browser')
    }
  }

  const initializeSpeechSynthesis = () => {
    if ('speechSynthesis' in window) {
      speechRef.current = window.speechSynthesis
    } else {
      setError('Speech synthesis not supported in this browser')
    }
  }

  const handleVoiceCommand = (transcript) => {
    logAccessibility(`Voice command received: ${transcript}`)
    setVoiceCommands(prev => [...prev, { command: transcript, timestamp: new Date() }])

    // Check for exact matches first
    if (voiceCommandsMap[transcript]) {
      voiceCommandsMap[transcript]()
      return
    }

    // Check for partial matches
    for (const [command, action] of Object.entries(voiceCommandsMap)) {
      if (transcript.includes(command)) {
        action()
        return
      }
    }

    // Check for answer selection with numbers
    const answerMatch = transcript.match(/answer (\d+)/)
    if (answerMatch) {
      const answerIndex = parseInt(answerMatch[1]) - 1
      if (answerIndex >= 0 && answerIndex < 4) {
        selectAnswer(answerIndex)
        return
      }
    }

    // Provide feedback for unrecognized command
    speak(`Command not recognized. Please try again.`)
    logAccessibility(`Unrecognized command: ${transcript}`)
  }

  // Enhanced speech system with queue
  const speak = (text, priority = false) => {
    if (!speechRef.current || !user?.isDisabled) return

    if (priority) {
      // Stop current speech and clear queue for high priority messages
      speechRef.current.cancel()
      setSpeechQueue([])
      setSpeechProcessing(false)
    }

    setSpeechQueue(prev => [...prev, { text, priority }])
    if (!speechProcessing) {
      processNextSpeech()
    }
  }

  const processNextSpeech = () => {
    setSpeechQueue(prev => {
      if (prev.length === 0) {
        setSpeechProcessing(false)
        setIsSpeaking(false)
        setIsReading(false)
        return prev
      }

      setSpeechProcessing(true)
      const { text } = prev[0]

      if (speechRef.current.speaking) {
        speechRef.current.cancel()
      }

      const utterance = new SpeechSynthesisUtterance(text)
      utterance.rate = 0.8
      utterance.pitch = 1
      utterance.volume = 1

      utterance.onstart = () => {
        setIsSpeaking(true)
        setIsReading(true)
        setDebugInfo(`Speaking: ${text.substring(0, 30)}...`)
        logAccessibility(`Speaking: ${text.substring(0, 50)}...`)
      }

      utterance.onend = () => {
        setTimeout(() => {
          setSpeechQueue(prev => {
            const newQueue = prev.slice(1)
            if (newQueue.length > 0) {
              processNextSpeech()
            } else {
              setSpeechProcessing(false)
              setIsSpeaking(false)
              setIsReading(false)
            }
            return newQueue
          })
        }, 500)
      }

      utterance.onerror = () => {
        setTimeout(() => {
          setSpeechQueue(prev => {
            const newQueue = prev.slice(1)
            if (newQueue.length > 0) {
              processNextSpeech()
            } else {
              setSpeechProcessing(false)
              setIsSpeaking(false)
              setIsReading(false)
            }
            return newQueue
          })
        }, 500)
      }

      speechRef.current.speak(utterance)
      return prev
    })
  }

  const stopSpeaking = () => {
    if (speechRef.current) {
      speechRef.current.cancel()
      setSpeechQueue([])
      setSpeechProcessing(false)
      setIsSpeaking(false)
      setIsReading(false)
      setDebugInfo('Speech stopped')
    }
  }

  const readCurrentQuestion = () => {
    const question = quiz.questions[currentQuestionIndex]
    if (!question) return

    let text = `Question ${currentQuestionIndex + 1} of ${quiz.questions.length}: ${question.question}. `
    speak(text, true)
    logAccessibility(`Question ${currentQuestionIndex + 1} read aloud`)
  }

  const readOptions = () => {
    const question = quiz.questions[currentQuestionIndex]
    if (!question || !question.options) return

    let text = 'The options are: '
    question.options.forEach((option, index) => {
      text += `Option ${String.fromCharCode(65 + index)}: ${option.text}. `
    })
    text += 'Say "select option A", "select option B", "select option C", or "select option D" to choose your answer.'

    speak(text, true)
    logAccessibility('Options read aloud')
  }

  const readQuestionAndOptions = () => {
    const question = quiz.questions[currentQuestionIndex]
    if (!question) return

    let text = `Question ${currentQuestionIndex + 1} of ${quiz.questions.length}: ${question.question}. `

    if (question.type === 'multiple-choice' && question.options) {
      text += 'The options are: '
      question.options.forEach((option, index) => {
        text += `Option ${String.fromCharCode(65 + index)}: ${option.text}. `
      })
    }

    text += 'Say "select option A", "select option B", "select option C", or "select option D" to choose your answer. '
    text += 'Say "next question" to continue, "previous question" to go back, or "repeat question" to hear this again.'

    speak(text, true)
    logAccessibility(`Question ${currentQuestionIndex + 1} and options read aloud`)
  }

  const provideHelp = () => {
    let helpText = 'Voice commands available: '
    helpText += 'Say "next question" or "previous question" to navigate. '
    helpText += 'Say "select option A", "select option B", "select option C", or "select option D" to choose answers. '
    helpText += 'Say "repeat question" to hear the question again, "read options" for just the options. '
    helpText += 'Say "submit quiz" when finished, "current question" for status, or "stop listening" to pause voice control.'

    speak(helpText, true)
    logAccessibility('Help provided')
  }

  const announceCurrentStatus = () => {
    const answeredCount = answers.filter(a => a !== undefined).length
    const text = `You are on question ${currentQuestionIndex + 1} of ${quiz.questions.length}. You have answered ${answeredCount} questions so far. Time spent: ${Math.floor(timeSpent / 60)} minutes and ${timeSpent % 60} seconds.`
    speak(text, true)
  }

  const announceQuestionNumber = () => {
    speak(`You are currently on question ${currentQuestionIndex + 1} of ${quiz.questions.length}.`, true)
  }

  const announceTimeRemaining = () => {
    const minutes = Math.floor(timeSpent / 60)
    const seconds = timeSpent % 60
    speak(`You have been working for ${minutes} minutes and ${seconds} seconds.`, true)
  }

  const announceProgress = () => {
    const answeredCount = answers.filter(a => a !== undefined).length
    const percentage = Math.round((answeredCount / quiz.questions.length) * 100)
    speak(`You have completed ${answeredCount} out of ${quiz.questions.length} questions. That's ${percentage} percent complete.`, true)
  }

  const announceQuestionCount = () => {
    speak(`This quiz has ${quiz.questions.length} questions in total.`, true)
  }

  const selectAnswer = (answerIndex) => {
    const question = quiz.questions[currentQuestionIndex]
    if (!question) return

    const newAnswers = [...answers]
    newAnswers[currentQuestionIndex] = {
      questionIndex: currentQuestionIndex,
      selectedAnswer: answerIndex,
      isCorrect: question.type === 'multiple-choice' ? 
        question.options[answerIndex]?.isCorrect : 
        answerIndex.toString().toLowerCase() === question.correctAnswer?.toLowerCase()
    }

    setAnswers(newAnswers)

    // Provide immediate feedback
    const isCorrect = newAnswers[currentQuestionIndex].isCorrect
    const feedbackText = isCorrect ? 
      'Correct! Well done.' : 
      'Incorrect. The correct answer is ' + 
      (question.type === 'multiple-choice' ? 
        `option ${String.fromCharCode(65 + question.options.findIndex(opt => opt.isCorrect))}` :
        question.correctAnswer)

    speak(feedbackText)
    setFeedback(feedbackText)
    logAccessibility(`Answer selected: ${String.fromCharCode(65 + answerIndex)}, ${isCorrect ? 'correct' : 'incorrect'}`)

    // Auto-advance after 3 seconds for correct answers
    if (isCorrect) {
      setTimeout(() => {
        if (currentQuestionIndex < quiz.questions.length - 1) {
          handleNext()
        }
      }, 3000)
    }
  }

  const handleNext = () => {
    if (currentQuestionIndex < quiz.questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1)
      setFeedback('')
      setTimeout(() => readCurrentQuestion(), 500)
      logAccessibility('Moved to next question')
    } else {
      speak('This is the last question. Say "finish" to submit your quiz.')
    }
  }

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1)
      setFeedback('')
      setTimeout(() => readCurrentQuestion(), 500)
      logAccessibility('Moved to previous question')
    } else {
      speak('This is the first question.')
    }
  }

  const handleSkip = () => {
    if (currentQuestionIndex < quiz.questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1)
      setFeedback('Question skipped.')
      setTimeout(() => readCurrentQuestion(), 500)
      logAccessibility('Question skipped')
    } else {
      speak('Cannot skip the last question.')
    }
  }

  const startListening = () => {
    if (recognitionRef.current && !isListening) {
      manuallyStoppedRef.current = false
      try {
        recognitionRef.current.start()
        speak('Voice recognition started. You can now use voice commands.')
        logAccessibility('Voice recognition manually started')
      } catch (error) {
        console.error('Error starting voice recognition:', error)
        setError('Failed to start voice recognition. Please try again.')
      }
    }
  }

  const stopListening = () => {
    manuallyStoppedRef.current = true
    if (recognitionRef.current) {
      recognitionRef.current.stop()
    }
    speak('Voice recognition stopped.')
    logAccessibility('Voice recognition manually stopped')
  }

  const handleFinish = async () => {
    setIsSubmitting(true)
    
    if (recognitionRef.current) {
      recognitionRef.current.stop()
    }

    const completedAnswers = answers.filter(answer => answer !== undefined)
    const score = completedAnswers.filter(answer => answer.isCorrect).length
    const percentage = Math.round((score / quiz.questions.length) * 100)

    const submissionData = {
      answers: completedAnswers,
      startedAt: startedAt,
      completedAt: new Date(),
      timeSpent: Math.floor(timeSpent / 60), // Convert to minutes
      score,
      percentage,
      isVoiceControlled: true,
      voiceCommands,
      accessibilityLog
    }

    try {
      const token = localStorage.getItem('token')
      const response = await fetch(`/api/classroom/assignments/${assignment._id}/submit`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(submissionData)
      })

      if (!response.ok) {
        throw new Error('Failed to submit quiz')
      }

      const result = await response.json()
      
      const completionMessage = `Quiz completed! You scored ${score} out of ${quiz.questions.length} questions. That's ${percentage} percent. ${percentage >= 60 ? 'Congratulations! You passed!' : 'Keep practicing!'}`
      speak(completionMessage)

      setTimeout(() => {
        onComplete(result.data)
      }, 5000)

    } catch (error) {
      console.error('Error submitting quiz:', error)
      setError('Failed to submit quiz. Please try again.')
      speak('There was an error submitting your quiz. Please contact your teacher.')
    }
  }

  const logAccessibility = (action) => {
    setAccessibilityLog(prev => [...prev, {
      action,
      timestamp: new Date(),
      questionIndex: currentQuestionIndex
    }])
  }

  const currentQuestion = quiz.questions[currentQuestionIndex]
  const progress = ((currentQuestionIndex + 1) / quiz.questions.length) * 100

  // Render function for quiz content
  const QuizContent = () => (
    <div className="space-y-6">
      {/* Voice Control Status Panel */}
      <div className={`${theme.colors.bg.secondary} rounded-xl p-4 border-2 ${
        isListening ? 'border-green-300 bg-green-50 dark:bg-green-900/20' : 'border-gray-300'
      }`}>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-3">
            <div className={`w-4 h-4 rounded-full ${isListening ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`}></div>
            <Mic className={`w-5 h-5 ${isListening ? 'text-green-600' : 'text-gray-400'}`} />
            <span className={`font-medium ${theme.colors.text.primary}`}>
              {isSpeaking ? '🗣️ Speaking...' : isListening ? '👂 Listening for commands...' : '🎤 Voice Ready'}
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              onClick={isListening ? stopListening : startListening}
              className={`px-3 py-1 rounded-lg text-sm ${
                isListening
                  ? 'bg-red-600 hover:bg-red-700 text-white'
                  : 'bg-green-600 hover:bg-green-700 text-white'
              }`}
            >
              {isListening ? 'Stop Voice' : 'Start Voice'}
            </Button>
            <Button
              onClick={provideHelp}
              className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm"
            >
              Help
            </Button>
          </div>
        </div>

        {/* Live transcript display */}
        {(interimTranscript || finalTranscript) && (
          <div className="mt-2 p-2 bg-white dark:bg-gray-800 rounded border">
            <div className="text-sm">
              {finalTranscript && (
                <span className="text-green-600 font-medium">Last: "{finalTranscript}"</span>
              )}
              {interimTranscript && (
                <span className="text-blue-600 ml-2">Hearing: "{interimTranscript}"</span>
              )}
            </div>
          </div>
        )}

        {debugInfo && (
          <div className="mt-2 text-xs text-gray-500">
            Status: {debugInfo}
          </div>
        )}
      </div>

      {/* Progress and Status */}
      <div className={`${theme.colors.bg.secondary} rounded-xl p-4`}>
        <div className="flex justify-between items-center mb-3">
          <span className={`text-lg font-medium ${theme.colors.text.primary}`}>
            Question {currentQuestionIndex + 1} of {quiz.questions.length}
          </span>
          <span className={`text-sm ${theme.colors.text.secondary}`}>
            Time: {Math.floor(timeSpent / 60)}:{(timeSpent % 60).toString().padStart(2, '0')}
          </span>
        </div>
        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3">
          <div
            className="bg-gradient-to-r from-purple-500 to-indigo-600 h-3 rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="flex justify-between mt-2 text-xs text-gray-500">
          <span>Answered: {answers.filter(a => a !== undefined).length}</span>
          <span>{Math.round(progress)}% Complete</span>
        </div>
      </div>

        {/* Voice Status */}
        <div className="flex items-center justify-center space-x-4">
          <div className={`flex items-center space-x-2 px-4 py-2 rounded-full ${
            isListening ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-600'
          }`}>
            <div className={`w-3 h-3 rounded-full ${isListening ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`} />
            <span className="text-sm font-medium">
              {isListening ? 'Listening...' : 'Voice recognition inactive'}
            </span>
          </div>
          
          {isReading && (
            <div className="flex items-center space-x-2 px-4 py-2 rounded-full bg-blue-100 text-blue-800">
              <div className="w-3 h-3 rounded-full bg-blue-500 animate-pulse" />
              <span className="text-sm font-medium">Reading...</span>
            </div>
          )}
        </div>

      {/* Question Display */}
      <div className={`${theme.colors.bg.card} rounded-xl p-6 border-l-4 border-purple-500`}>
        <div className="mb-4">
          <h3 className={`text-xl font-bold ${theme.colors.text.primary} mb-3`}>
            Question {currentQuestionIndex + 1}
          </h3>
          <p className={`text-lg ${theme.colors.text.primary} leading-relaxed`}>
            {currentQuestion?.question}
          </p>
        </div>

        {/* Answer Options */}
        {currentQuestion?.type === 'multiple-choice' && currentQuestion?.options && (
          <div className="space-y-3">
            {currentQuestion.options.map((option, index) => {
              const isSelected = answers[currentQuestionIndex]?.selectedAnswer === index
              const isCorrect = answers[currentQuestionIndex]?.isCorrect

              return (
                <div
                  key={index}
                  className={`p-4 rounded-xl border-2 transition-all cursor-pointer ${
                    isSelected
                      ? isCorrect
                        ? 'border-green-500 bg-green-50 dark:bg-green-900/20'
                        : 'border-red-500 bg-red-50 dark:bg-red-900/20'
                      : 'border-gray-200 dark:border-gray-600 hover:border-purple-300 hover:bg-purple-50 dark:hover:bg-purple-900/20'
                  }`}
                  onClick={() => selectAnswer(index)}
                >
                  <div className="flex items-center">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center text-lg font-bold mr-4 ${
                      isSelected
                        ? isCorrect
                          ? 'bg-green-500 text-white'
                          : 'bg-red-500 text-white'
                        : 'bg-purple-100 text-purple-700 dark:bg-purple-800 dark:text-purple-200'
                    }`}>
                      {String.fromCharCode(65 + index)}
                    </div>
                    <span className={`text-lg ${theme.colors.text.primary}`}>
                      {option.text}
                    </span>
                    {isSelected && (
                      <CheckCircle className={`w-6 h-6 ml-auto ${
                        isCorrect ? 'text-green-500' : 'text-red-500'
                      }`} />
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        )}

        {/* Voice Instructions for Current Question */}
        <div className="mt-6 p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg border border-purple-200 dark:border-purple-700">
          <p className="text-sm text-purple-800 dark:text-purple-200">
            🎤 <strong>Say:</strong> "select option A", "select option B", "select option C", or "select option D" to choose your answer.
            <br />
            📢 <strong>Navigation:</strong> "next question", "previous question", "repeat question", or "read options".
          </p>
        </div>

        {/* Feedback */}
        {feedback && (
          <div className={`mt-4 p-4 rounded-lg ${
            answers[currentQuestionIndex]?.isCorrect
              ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-200'
              : 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-200'
          }`}>
            <p className="font-medium">{feedback}</p>
          </div>
        )}
      </div>

      {/* Voice Commands Reference */}
      <div className={`${theme.colors.bg.secondary} rounded-xl p-4`}>
        <h4 className={`font-medium ${theme.colors.text.primary} mb-3 flex items-center`}>
          <HelpCircle className="w-5 h-5 mr-2" />
          Voice Commands Reference
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-sm">
          <div className={`${theme.colors.bg.card} p-3 rounded-lg border`}>
            <span className="font-medium text-purple-600">"select option A/B/C/D"</span>
            <br />Choose answer
          </div>
          <div className={`${theme.colors.bg.card} p-3 rounded-lg border`}>
            <span className="font-medium text-blue-600">"next question"</span>
            <br />Move forward
          </div>
          <div className={`${theme.colors.bg.card} p-3 rounded-lg border`}>
            <span className="font-medium text-blue-600">"previous question"</span>
            <br />Go back
          </div>
          <div className={`${theme.colors.bg.card} p-3 rounded-lg border`}>
            <span className="font-medium text-green-600">"repeat question"</span>
            <br />Hear again
          </div>
          <div className={`${theme.colors.bg.card} p-3 rounded-lg border`}>
            <span className="font-medium text-green-600">"read options"</span>
            <br />Hear choices
          </div>
          <div className={`${theme.colors.bg.card} p-3 rounded-lg border`}>
            <span className="font-medium text-red-600">"submit quiz"</span>
            <br />Finish quiz
          </div>
        </div>
      </div>

      {/* Manual Controls */}
      <div className="flex justify-center space-x-4">
        <Button
          onClick={handlePrevious}
          disabled={currentQuestionIndex === 0}
          className="px-6 py-3 bg-gray-600 hover:bg-gray-700 text-white rounded-xl font-medium disabled:opacity-50 flex items-center space-x-2"
        >
          <SkipBack className="w-4 h-4" />
          <span>Previous</span>
        </Button>

        <Button
          onClick={readQuestionAndOptions}
          className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium flex items-center space-x-2"
        >
          <Volume2 className="w-4 h-4" />
          <span>Read Question</span>
        </Button>

        <Button
          onClick={handleNext}
          disabled={currentQuestionIndex === quiz.questions.length - 1}
          className="px-6 py-3 bg-gray-600 hover:bg-gray-700 text-white rounded-xl font-medium disabled:opacity-50 flex items-center space-x-2"
        >
          <span>Next</span>
          <SkipForward className="w-4 h-4" />
        </Button>

        <Button
          onClick={handleFinish}
          className="px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white rounded-xl font-medium flex items-center space-x-2"
        >
          <Square className="w-4 h-4" />
          <span>Submit Quiz</span>
        </Button>
      </div>
    </div>
  )

  // Conditional rendering based on isFullPage prop
  if (isFullPage) {
    return (
      <div className={`min-h-screen ${theme.colors.bg.secondary}`}>
        {/* Header for full page */}
        <div className={`${theme.colors.bg.card} shadow-sm border-b ${theme.colors.border.primary} sticky top-0 z-10`}>
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Mic className="w-6 h-6 text-purple-600" />
                <h1 className={`text-xl font-semibold ${theme.colors.text.primary}`}>
                  Voice-Controlled Quiz: {quiz.title}
                </h1>
              </div>
              <Button
                onClick={onClose}
                className={`${theme.colors.text.secondary} hover:${theme.colors.text.primary} p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800`}
              >
                ✕
              </Button>
            </div>
          </div>
        </div>

        {/* Quiz content */}
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <QuizContent />
        </div>
      </div>
    );
  }

  // Modal rendering for embedded mode
  return (
    <Modal
      isOpen={true}
      onClose={onClose}
      title={`Voice-Controlled Quiz: ${quiz.title}`}
      size="xl"
    >
      <QuizContent />
    </Modal>
  )
}

export default VoiceControlledQuiz