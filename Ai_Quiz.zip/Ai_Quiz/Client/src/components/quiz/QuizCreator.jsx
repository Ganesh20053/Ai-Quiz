import React, { useState, useEffect } from 'react'
import Button from '../common/Button'
import Loader from '../common/Loader'
import Modal from '../common/Modal'

const QuizCreator = ({ classroom, onQuizCreated, onClose }) => {
  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  
  // Quiz basic info
  const [quizInfo, setQuizInfo] = useState({
    title: '',
    description: '',
    subject: classroom?.subject || '',
    topic: '',
    difficulty: 'medium',
    questionCount: 10,
    questionTypes: ['multiple-choice']
  })
  
  // AI generation
  const [aiLoading, setAiLoading] = useState(false)
  const [generatedQuestions, setGeneratedQuestions] = useState([])
  const [aiSuggestions, setAiSuggestions] = useState([])
  
  // Quiz settings
  const [quizSettings, setQuizSettings] = useState({
    timeLimit: 30,
    passingScore: 60,
    allowRetake: false,
    maxAttempts: 1,
    shuffleQuestions: true,
    showResults: true,
    showCorrectAnswers: false,
    requirePassword: false,
    password: ''
  })

  useEffect(() => {
    if (classroom) {
      setQuizInfo(prev => ({
        ...prev,
        subject: classroom.subject
      }))
      fetchAISuggestions()
    }
  }, [classroom])

  const fetchAISuggestions = async () => {
    try {
      const token = localStorage.getItem('token')
      const response = await fetch(`/api/ai/suggestions?subject=${classroom.subject}&topic=${quizInfo.topic}&grade=${classroom.grade}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      })

      if (response.ok) {
        const data = await response.json()
        setAiSuggestions(data.data.suggestions)
      }
    } catch (err) {
      console.error('Error fetching AI suggestions:', err)
    }
  }

  const generateQuestions = async () => {
    try {
      setAiLoading(true)
      setError(null)
      
      const token = localStorage.getItem('token')
      const response = await fetch('/api/ai/generate-questions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          ...quizInfo,
          classroomId: classroom._id,
          grade: classroom.grade
        })
      })

      if (!response.ok) {
        throw new Error('Failed to generate questions')
      }

      const data = await response.json()
      setGeneratedQuestions(data.data.questions)
      setStep(3)
    } catch (err) {
      setError(err.message)
      console.error('Error generating questions:', err)
    } finally {
      setAiLoading(false)
    }
  }

  const createQuiz = async () => {
    try {
      setLoading(true)
      setError(null)
      
      const token = localStorage.getItem('token')
      const response = await fetch('/api/ai/create-quiz', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          title: quizInfo.title,
          description: quizInfo.description,
          classroomId: classroom._id,
          subject: quizInfo.subject,
          topic: quizInfo.topic,
          difficulty: quizInfo.difficulty,
          questionCount: quizInfo.questionCount,
          questionTypes: quizInfo.questionTypes,
          settings: quizSettings
        })
      })

      if (!response.ok) {
        throw new Error('Failed to create quiz')
      }

      const data = await response.json()
      onQuizCreated(data.data.quiz)
    } catch (err) {
      setError(err.message)
      console.error('Error creating quiz:', err)
    } finally {
      setLoading(false)
    }
  }

  const handleQuizInfoChange = (field, value) => {
    setQuizInfo(prev => ({
      ...prev,
      [field]: value
    }))
  }

  const handleSettingsChange = (field, value) => {
    setQuizSettings(prev => ({
      ...prev,
      [field]: value
    }))
  }

  const handleSuggestionClick = (suggestion) => {
    setQuizInfo(prev => ({
      ...prev,
      topic: suggestion.topic,
      difficulty: suggestion.difficulty,
      questionCount: suggestion.questionCount
    }))
  }

  const renderStep1 = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Quiz Information</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Quiz Title <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={quizInfo.title}
              onChange={(e) => handleQuizInfoChange('title', e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="e.g., Algebra Fundamentals Quiz"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Subject
            </label>
            <input
              type="text"
              value={quizInfo.subject}
              onChange={(e) => handleQuizInfoChange('subject', e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="e.g., Mathematics"
            />
          </div>
        </div>

        <div className="mt-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Description
          </label>
          <textarea
            value={quizInfo.description}
            onChange={(e) => handleQuizInfoChange('description', e.target.value)}
            rows="3"
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            placeholder="Brief description of the quiz content"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Topic <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={quizInfo.topic}
              onChange={(e) => handleQuizInfoChange('topic', e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="e.g., Linear Equations"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Difficulty
            </label>
            <select
              value={quizInfo.difficulty}
              onChange={(e) => handleQuizInfoChange('difficulty', e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            >
              <option value="easy">Easy</option>
              <option value="medium">Medium</option>
              <option value="hard">Hard</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Question Count
            </label>
            <input
              type="number"
              min="1"
              max="50"
              value={quizInfo.questionCount}
              onChange={(e) => handleQuizInfoChange('questionCount', parseInt(e.target.value))}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            />
          </div>
        </div>

        <div className="mt-4">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Question Types
          </label>
          <div className="space-y-2">
            {['multiple-choice', 'true-false', 'short-answer', 'essay'].map(type => (
              <label key={type} className="flex items-center">
                <input
                  type="checkbox"
                  checked={quizInfo.questionTypes.includes(type)}
                  onChange={(e) => {
                    if (e.target.checked) {
                      handleQuizInfoChange('questionTypes', [...quizInfo.questionTypes, type])
                    } else {
                      handleQuizInfoChange('questionTypes', quizInfo.questionTypes.filter(t => t !== type))
                    }
                  }}
                  className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                />
                <span className="ml-2 text-sm text-gray-700 capitalize">
                  {type.replace('-', ' ')}
                </span>
              </label>
            ))}
          </div>
        </div>
      </div>

      {/* AI Suggestions */}
      {aiSuggestions.length > 0 && (
        <div className="bg-blue-50 rounded-lg p-4">
          <h4 className="font-semibold text-gray-900 mb-3">AI Suggestions</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {aiSuggestions.map((suggestion, index) => (
              <div
                key={index}
                className="bg-white rounded-lg p-3 border border-blue-200 cursor-pointer hover:border-blue-300 transition-colors"
                onClick={() => handleSuggestionClick(suggestion)}
              >
                <h5 className="font-medium text-gray-900">{suggestion.topic}</h5>
                <p className="text-sm text-gray-600 mt-1">
                  {suggestion.concepts.join(', ')}
                </p>
                <div className="flex items-center justify-between mt-2">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    suggestion.difficulty === 'easy' ? 'bg-green-100 text-green-800' :
                    suggestion.difficulty === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {suggestion.difficulty}
                  </span>
                  <span className="text-xs text-gray-500">
                    {suggestion.questionCount} questions
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="flex justify-end space-x-3">
        <Button
          onClick={onClose}
          className="px-6 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors"
        >
          Cancel
        </Button>
        <Button
          onClick={() => setStep(2)}
          disabled={!quizInfo.title || !quizInfo.topic}
          className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50"
        >
          Next: Generate Questions
        </Button>
      </div>
    </div>
  )

  const renderStep2 = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Generate Questions with AI</h3>
        
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-6">
          <div className="text-center">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
              </svg>
            </div>
            <h4 className="text-lg font-medium text-gray-900 mb-2">AI-Powered Question Generation</h4>
            <p className="text-gray-600 mb-6">
              Our AI will generate {quizInfo.questionCount} {quizInfo.difficulty} questions about "{quizInfo.topic}" 
              in {quizInfo.subject} for {classroom.grade} grade students.
            </p>
            
            <div className="bg-white rounded-lg p-4 mb-6">
              <h5 className="font-medium text-gray-900 mb-3">Quiz Summary</h5>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-500">Title:</span>
                  <p className="font-medium">{quizInfo.title}</p>
                </div>
                <div>
                  <span className="text-gray-500">Topic:</span>
                  <p className="font-medium">{quizInfo.topic}</p>
                </div>
                <div>
                  <span className="text-gray-500">Difficulty:</span>
                  <p className="font-medium capitalize">{quizInfo.difficulty}</p>
                </div>
                <div>
                  <span className="text-gray-500">Questions:</span>
                  <p className="font-medium">{quizInfo.questionCount}</p>
                </div>
              </div>
            </div>

            <Button
              onClick={generateQuestions}
              disabled={aiLoading}
              className="px-8 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg hover:shadow-md transition-all disabled:opacity-50 flex items-center mx-auto"
            >
              {aiLoading ? (
                <>
                  <Loader size="sm" className="mr-2" />
                  Generating Questions...
                </>
              ) : (
                <>
                  <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                  Generate Questions with AI
                </>
              )}
            </Button>
          </div>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-red-400" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-red-800">Error generating questions</h3>
              <p className="text-sm text-red-700 mt-1">{error}</p>
            </div>
          </div>
        </div>
      )}

      <div className="flex justify-between">
        <Button
          onClick={() => setStep(1)}
          className="px-6 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors"
        >
          Back
        </Button>
      </div>
    </div>
  )

  const renderStep3 = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Quiz Settings</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Time Limit (minutes)
              </label>
              <input
                type="number"
                min="1"
                max="180"
                value={quizSettings.timeLimit}
                onChange={(e) => handleSettingsChange('timeLimit', parseInt(e.target.value))}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Passing Score (%)
              </label>
              <input
                type="number"
                min="0"
                max="100"
                value={quizSettings.passingScore}
                onChange={(e) => handleSettingsChange('passingScore', parseInt(e.target.value))}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Max Attempts
              </label>
              <input
                type="number"
                min="1"
                max="10"
                value={quizSettings.maxAttempts}
                onChange={(e) => handleSettingsChange('maxAttempts', parseInt(e.target.value))}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="space-y-3">
              <label className="block text-sm font-medium text-gray-700">Quiz Options</label>
              
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={quizSettings.allowRetake}
                  onChange={(e) => handleSettingsChange('allowRetake', e.target.checked)}
                  className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                />
                <span className="ml-2 text-sm text-gray-700">Allow retakes</span>
              </label>
              
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={quizSettings.shuffleQuestions}
                  onChange={(e) => handleSettingsChange('shuffleQuestions', e.target.checked)}
                  className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                />
                <span className="ml-2 text-sm text-gray-700">Shuffle questions</span>
              </label>
              
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={quizSettings.showResults}
                  onChange={(e) => handleSettingsChange('showResults', e.target.checked)}
                  className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                />
                <span className="ml-2 text-sm text-gray-700">Show results immediately</span>
              </label>
              
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={quizSettings.showCorrectAnswers}
                  onChange={(e) => handleSettingsChange('showCorrectAnswers', e.target.checked)}
                  className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                />
                <span className="ml-2 text-sm text-gray-700">Show correct answers</span>
              </label>
              
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={quizSettings.requirePassword}
                  onChange={(e) => handleSettingsChange('requirePassword', e.target.checked)}
                  className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                />
                <span className="ml-2 text-sm text-gray-700">Require password</span>
              </label>
            </div>
            
            {quizSettings.requirePassword && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Quiz Password
                </label>
                <input
                  type="text"
                  value={quizSettings.password}
                  onChange={(e) => handleSettingsChange('password', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="Enter quiz password"
                />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Generated Questions Preview */}
      <div>
        <h4 className="font-semibold text-gray-900 mb-3">
          Generated Questions ({generatedQuestions.length})
        </h4>
        <div className="bg-gray-50 rounded-lg p-4 max-h-64 overflow-y-auto">
          {generatedQuestions.map((question, index) => (
            <div key={index} className="mb-4 p-3 bg-white rounded border">
              <p className="font-medium text-sm text-gray-900 mb-2">
                Q{index + 1}. {question.question}
              </p>
              {question.type === 'multiple-choice' && question.options && (
                <div className="space-y-1">
                  {question.options.map((option, optIndex) => (
                    <div key={optIndex} className="text-sm text-gray-600">
                      {String.fromCharCode(65 + optIndex)}) {option.text}
                      {option.isCorrect && <span className="text-green-600 ml-2">✓</span>}
                    </div>
                  ))}
                </div>
              )}
              {question.explanation && (
                <p className="text-xs text-gray-500 mt-2">
                  <strong>Explanation:</strong> {question.explanation}
                </p>
              )}
            </div>
          ))}
        </div>
      </div>

      <div className="flex justify-between">
        <Button
          onClick={() => setStep(2)}
          className="px-6 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors"
        >
          Back
        </Button>
        <Button
          onClick={createQuiz}
          disabled={loading}
          className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 flex items-center"
        >
          {loading ? (
            <>
              <Loader size="sm" className="mr-2" />
              Creating Quiz...
            </>
          ) : (
            <>
              <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              Create Quiz
            </>
          )}
        </Button>
      </div>
    </div>
  )

  return (
    <Modal
      isOpen={true}
      onClose={onClose}
      title={`Create Quiz - ${classroom?.name}`}
      size="lg"
    >
      <div className="space-y-6">
        {/* Progress Steps */}
        <div className="flex items-center justify-center space-x-4">
          {[1, 2, 3].map((stepNumber) => (
            <div key={stepNumber} className="flex items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                step >= stepNumber 
                  ? 'bg-indigo-600 text-white' 
                  : 'bg-gray-200 text-gray-600'
              }`}>
                {stepNumber}
              </div>
              {stepNumber < 3 && (
                <div className={`w-12 h-1 mx-2 ${
                  step > stepNumber ? 'bg-indigo-600' : 'bg-gray-200'
                }`} />
              )}
            </div>
          ))}
        </div>

        {/* Step Content */}
        {step === 1 && renderStep1()}
        {step === 2 && renderStep2()}
        {step === 3 && renderStep3()}
      </div>
    </Modal>
  )
}

export default QuizCreator 