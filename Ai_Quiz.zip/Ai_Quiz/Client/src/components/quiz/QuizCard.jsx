import React from 'react';

const QuizCard = ({ quiz }) => {
  if (!quiz) return null;
  return (
    <div className="border rounded-lg p-4 mb-4 bg-white shadow">
      <h3 className="text-lg font-semibold mb-1">{quiz.title}</h3>
      {quiz.description && <p className="text-gray-600 mb-2">{quiz.description}</p>}
      <div className="text-sm text-gray-500">
        <span>Status: {quiz.status || 'N/A'}</span> |{' '}
        <span>Questions: {quiz.questionCount || (quiz.questions ? quiz.questions.length : 0)}</span> |{' '}
        <span>Created: {quiz.createdAt ? new Date(quiz.createdAt).toLocaleString() : 'N/A'}</span>
      </div>
    </div>
  );
};

export default QuizCard;
