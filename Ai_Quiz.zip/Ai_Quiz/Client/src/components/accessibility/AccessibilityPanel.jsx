import React from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { motion, AnimatePresence } from 'framer-motion'
import { X, Moon, Sun, Eye, Type, Volume2, VolumeX, Mic, MicOff } from 'lucide-react'
import {
  toggleDarkMode,
  toggleHighContrast,
  toggleDyslexiaFont,
  toggleAudioOnlyMode,
  setFontSize,
  toggleVoice,
  setVoiceSettings,
  updateSettings
} from '../../features/settings/settingsSlice'

const AccessibilityPanel = ({ isOpen, onClose }) => {
  const dispatch = useDispatch()
  const settings = useSelector((state) => state.settings)

  const fontSizes = [
    { value: 'small', label: 'Small', class: 'text-sm' },
    { value: 'medium', label: 'Medium', class: 'text-base' },
    { value: 'large', label: 'Large', class: 'text-lg' },
    { value: 'xl', label: 'Extra Large', class: 'text-xl' }
  ]

  const handleVoiceSpeedChange = (speed) => {
    dispatch(setVoiceSettings({ speed }))
  }

  const handleVoiceVolumeChange = (volume) => {
    dispatch(setVoiceSettings({ volume }))
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 z-40"
            onClick={onClose}
          />
          
          {/* Panel */}
          <motion.div
            initial={{ opacity: 0, x: 300 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 300 }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed right-0 top-0 h-full w-96 bg-white dark:bg-gray-800 shadow-2xl z-50 overflow-y-auto"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                Accessibility Settings
              </h2>
              <button
                onClick={onClose}
                className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                aria-label="Close accessibility panel"
              >
                <X className="w-5 h-5 text-gray-600 dark:text-gray-300" />
              </button>
            </div>

            {/* Content */}
            <div className="p-6 space-y-8">
              {/* Visual Settings */}
              <section>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                  Visual Settings
                </h3>
                
                <div className="space-y-4">
                  {/* Dark Mode */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      {settings.isDarkMode ? (
                        <Moon className="w-5 h-5 text-gray-600 dark:text-gray-300" />
                      ) : (
                        <Sun className="w-5 h-5 text-gray-600 dark:text-gray-300" />
                      )}
                      <div>
                        <p className="font-medium text-gray-900 dark:text-white">Dark Mode</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Reduce eye strain in low light</p>
                      </div>
                    </div>
                    <button
                      onClick={() => dispatch(toggleDarkMode())}
                      className={`
                        relative inline-flex h-6 w-11 items-center rounded-full transition-colors
                        ${settings.isDarkMode ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-700'}
                      `}
                      aria-label="Toggle dark mode"
                    >
                      <span
                        className={`
                          inline-block h-4 w-4 transform rounded-full bg-white transition-transform
                          ${settings.isDarkMode ? 'translate-x-6' : 'translate-x-1'}
                        `}
                      />
                    </button>
                  </div>

                  {/* High Contrast */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Eye className="w-5 h-5 text-gray-600 dark:text-gray-300" />
                      <div>
                        <p className="font-medium text-gray-900 dark:text-white">High Contrast</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Increase color contrast</p>
                      </div>
                    </div>
                    <button
                      onClick={() => dispatch(toggleHighContrast())}
                      className={`
                        relative inline-flex h-6 w-11 items-center rounded-full transition-colors
                        ${settings.isHighContrast ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-700'}
                      `}
                      aria-label="Toggle high contrast"
                    >
                      <span
                        className={`
                          inline-block h-4 w-4 transform rounded-full bg-white transition-transform
                          ${settings.isHighContrast ? 'translate-x-6' : 'translate-x-1'}
                        `}
                      />
                    </button>
                  </div>

                  {/* Dyslexia Font */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Type className="w-5 h-5 text-gray-600 dark:text-gray-300" />
                      <div>
                        <p className="font-medium text-gray-900 dark:text-white">Dyslexia Font</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Use dyslexia-friendly font</p>
                      </div>
                    </div>
                    <button
                      onClick={() => dispatch(toggleDyslexiaFont())}
                      className={`
                        relative inline-flex h-6 w-11 items-center rounded-full transition-colors
                        ${settings.isDyslexiaFont ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-700'}
                      `}
                      aria-label="Toggle dyslexia font"
                    >
                      <span
                        className={`
                          inline-block h-4 w-4 transform rounded-full bg-white transition-transform
                          ${settings.isDyslexiaFont ? 'translate-x-6' : 'translate-x-1'}
                        `}
                      />
                    </button>
                  </div>

                  {/* Font Size */}
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white mb-3">Font Size</p>
                    <div className="grid grid-cols-2 gap-2">
                      {fontSizes.map((size) => (
                        <button
                          key={size.value}
                          onClick={() => dispatch(setFontSize(size.value))}
                          className={`
                            p-3 rounded-lg border-2 transition-colors ${size.class}
                            ${settings.fontSize === size.value
                              ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                              : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                            }
                          `}
                        >
                          {size.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </section>

              {/* Audio Settings */}
              <section>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                  Audio Settings
                </h3>
                
                <div className="space-y-4">
                  {/* Voice Enabled */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      {settings.voiceEnabled ? (
                        <Volume2 className="w-5 h-5 text-gray-600 dark:text-gray-300" />
                      ) : (
                        <VolumeX className="w-5 h-5 text-gray-600 dark:text-gray-300" />
                      )}
                      <div>
                        <p className="font-medium text-gray-900 dark:text-white">Text-to-Speech</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Enable voice narration</p>
                      </div>
                    </div>
                    <button
                      onClick={() => dispatch(toggleVoice())}
                      className={`
                        relative inline-flex h-6 w-11 items-center rounded-full transition-colors
                        ${settings.voiceEnabled ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-700'}
                      `}
                      aria-label="Toggle text-to-speech"
                    >
                      <span
                        className={`
                          inline-block h-4 w-4 transform rounded-full bg-white transition-transform
                          ${settings.voiceEnabled ? 'translate-x-6' : 'translate-x-1'}
                        `}
                      />
                    </button>
                  </div>

                  {/* Voice Speed */}
                  {settings.voiceEnabled && (
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <p className="font-medium text-gray-900 dark:text-white">Speech Speed</p>
                        <span className="text-sm text-gray-600 dark:text-gray-400">
                          {settings.voiceSpeed}x
                        </span>
                      </div>
                      <input
                        type="range"
                        min="0.5"
                        max="2"
                        step="0.1"
                        value={settings.voiceSpeed}
                        onChange={(e) => handleVoiceSpeedChange(parseFloat(e.target.value))}
                        className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer"
                      />
                      <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mt-1">
                        <span>Slow</span>
                        <span>Normal</span>
                        <span>Fast</span>
                      </div>
                    </div>
                  )}

                  {/* Voice Volume */}
                  {settings.voiceEnabled && (
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <p className="font-medium text-gray-900 dark:text-white">Volume</p>
                        <span className="text-sm text-gray-600 dark:text-gray-400">
                          {Math.round(settings.voiceVolume * 100)}%
                        </span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.1"
                        value={settings.voiceVolume}
                        onChange={(e) => handleVoiceVolumeChange(parseFloat(e.target.value))}
                        className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer"
                      />
                    </div>
                  )}

                  {/* Audio Only Mode */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Mic className="w-5 h-5 text-gray-600 dark:text-gray-300" />
                      <div>
                        <p className="font-medium text-gray-900 dark:text-white">Audio Only Mode</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Hide visual elements</p>
                      </div>
                    </div>
                    <button
                      onClick={() => dispatch(toggleAudioOnlyMode())}
                      className={`
                        relative inline-flex h-6 w-11 items-center rounded-full transition-colors
                        ${settings.isAudioOnlyMode ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-700'}
                      `}
                      aria-label="Toggle audio only mode"
                    >
                      <span
                        className={`
                          inline-block h-4 w-4 transform rounded-full bg-white transition-transform
                          ${settings.isAudioOnlyMode ? 'translate-x-6' : 'translate-x-1'}
                        `}
                      />
                    </button>
                  </div>
                </div>
              </section>

              {/* Quiz Settings */}
              <section>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                  Quiz Settings
                </h3>
                
                <div className="space-y-4">
                  {/* Auto Timer */}
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">Auto Timer</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Automatic question timing</p>
                    </div>
                    <button
                      onClick={() => dispatch(updateSettings({ autoTimer: !settings.autoTimer }))}
                      className={`
                        relative inline-flex h-6 w-11 items-center rounded-full transition-colors
                        ${settings.autoTimer ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-700'}
                      `}
                      aria-label="Toggle auto timer"
                    >
                      <span
                        className={`
                          inline-block h-4 w-4 transform rounded-full bg-white transition-transform
                          ${settings.autoTimer ? 'translate-x-6' : 'translate-x-1'}
                        `}
                      />
                    </button>
                  </div>

                  {/* Show Hints */}
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">Show Hints</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Enable hint button</p>
                    </div>
                    <button
                      onClick={() => dispatch(updateSettings({ showHints: !settings.showHints }))}
                      className={`
                        relative inline-flex h-6 w-11 items-center rounded-full transition-colors
                        ${settings.showHints ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-700'}
                      `}
                      aria-label="Toggle hints"
                    >
                      <span
                        className={`
                          inline-block h-4 w-4 transform rounded-full bg-white transition-transform
                          ${settings.showHints ? 'translate-x-6' : 'translate-x-1'}
                        `}
                      />
                    </button>
                  </div>

                  {/* Pronunciation Check */}
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">Pronunciation Check</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Voice answer validation</p>
                    </div>
                    <button
                      onClick={() => dispatch(updateSettings({ pronunciationCheck: !settings.pronunciationCheck }))}
                      className={`
                        relative inline-flex h-6 w-11 items-center rounded-full transition-colors
                        ${settings.pronunciationCheck ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-700'}
                      `}
                      aria-label="Toggle pronunciation check"
                    >
                      <span
                        className={`
                          inline-block h-4 w-4 transform rounded-full bg-white transition-transform
                          ${settings.pronunciationCheck ? 'translate-x-6' : 'translate-x-1'}
                        `}
                      />
                    </button>
                  </div>
                </div>
              </section>

              {/* Reset Button */}
              <section>
                <button
                  onClick={() => {
                    if (confirm('Reset all accessibility settings to default?')) {
                      dispatch(updateSettings({
                        isDarkMode: false,
                        isHighContrast: false,
                        isDyslexiaFont: false,
                        isAudioOnlyMode: false,
                        fontSize: 'medium',
                        voiceEnabled: true,
                        voiceSpeed: 1.0,
                        voiceVolume: 1.0,
                        autoTimer: true,
                        showHints: true,
                        pronunciationCheck: true,
                      }))
                    }
                  }}
                  className="w-full py-3 px-4 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 rounded-lg transition-colors"
                >
                  Reset to Defaults
                </button>
              </section>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}

export default AccessibilityPanel