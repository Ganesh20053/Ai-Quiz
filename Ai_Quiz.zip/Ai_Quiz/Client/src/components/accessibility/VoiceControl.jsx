import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, Volume2, HelpCircle } from 'lucide-react';
import Button from '../common/Button';

const VoiceControl = ({ 
  isEnabled = false, 
  onCommand, 
  commands = [], 
  autoStart = true,
  welcomeMessage = "Voice control activated"
}) => {
  const [isListening, setIsListening] = useState(false);
  const [currentCommand, setCurrentCommand] = useState('');
  const [speechSupported, setSpeechSupported] = useState(false);
  const [volume, setVolume] = useState(1);
  
  const recognitionRef = useRef(null);
  const synthRef = useRef(null);

  useEffect(() => {
    if (isEnabled) {
      initializeVoiceControl();
    }
    
    return () => {
      cleanup();
    };
  }, [isEnabled]);

  const initializeVoiceControl = () => {
    // Check for speech recognition support
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = 'en-US';
      
      recognitionRef.current.onstart = () => {
        setIsListening(true);
        speak(welcomeMessage);
      };
      
      recognitionRef.current.onresult = (event) => {
        const transcript = Array.from(event.results)
          .map(result => result[0])
          .map(result => result.transcript)
          .join('');
        
        setCurrentCommand(transcript);
        
        if (event.results[event.results.length - 1].isFinal) {
          processCommand(transcript.toLowerCase().trim());
        }
      };
      
      recognitionRef.current.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        speak('Voice recognition error. Please try again.');
        setIsListening(false);
      };
      
      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
      
      setSpeechSupported(true);
      
      // Initialize speech synthesis
      if ('speechSynthesis' in window) {
        synthRef.current = window.speechSynthesis;
      }
      
      // Auto-start if enabled
      if (autoStart) {
        setTimeout(() => {
          startListening();
        }, 1000);
      }
    } else {
      console.warn('Speech recognition not supported');
      speak('Voice control not supported in this browser.');
    }
  };

  const speak = (text) => {
    if (synthRef.current && isEnabled) {
      // Cancel any ongoing speech
      synthRef.current.cancel();
      
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.8;
      utterance.pitch = 1;
      utterance.volume = volume;
      
      synthRef.current.speak(utterance);
    }
  };

  const startListening = () => {
    if (recognitionRef.current && !isListening && speechSupported) {
      try {
        recognitionRef.current.start();
      } catch (error) {
        console.error('Error starting speech recognition:', error);
      }
    }
  };

  const stopListening = () => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
    }
  };

  const processCommand = (command) => {
    console.log('🎤 Voice command:', command);
    setCurrentCommand('');
    
    // Handle built-in commands
    if (command.includes('help') || command.includes('commands')) {
      const helpText = `Available commands: ${commands.join(', ')}. Say "stop listening" to turn off voice control.`;
      speak(helpText);
      return;
    }
    
    if (command.includes('stop listening') || command.includes('turn off')) {
      stopListening();
      speak('Voice control turned off.');
      return;
    }
    
    if (command.includes('volume up')) {
      setVolume(Math.min(1, volume + 0.2));
      speak('Volume increased');
      return;
    }
    
    if (command.includes('volume down')) {
      setVolume(Math.max(0.2, volume - 0.2));
      speak('Volume decreased');
      return;
    }
    
    // Pass command to parent component
    if (onCommand) {
      onCommand(command, speak);
    }
  };

  const cleanup = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    if (synthRef.current) {
      synthRef.current.cancel();
    }
  };

  if (!isEnabled) {
    return null;
  }

  return (
    <div className="voice-control-panel">
      {/* Voice Status Indicator */}
      <div className={`flex items-center space-x-2 px-4 py-2 rounded-xl border-2 transition-all ${
        isListening 
          ? 'bg-green-50 border-green-300 text-green-800 dark:bg-green-900/20 dark:border-green-600 dark:text-green-300' 
          : 'bg-gray-50 border-gray-300 text-gray-600 dark:bg-gray-800 dark:border-gray-600 dark:text-gray-400'
      }`}>
        <div className={`w-3 h-3 rounded-full ${isListening ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`}></div>
        {isListening ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
        <span className="text-sm font-medium">
          {isListening ? 'Listening...' : 'Voice Ready'}
        </span>
      </div>

      {/* Voice Command Display */}
      {currentCommand && (
        <div className="mt-2 bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3 border border-blue-200 dark:border-blue-700">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
            <span className="text-sm text-blue-700 dark:text-blue-300">You said:</span>
            <span className="font-medium text-blue-900 dark:text-blue-100">"{currentCommand}"</span>
          </div>
        </div>
      )}

      {/* Control Buttons */}
      <div className="flex items-center space-x-2 mt-3">
        <Button
          onClick={isListening ? stopListening : startListening}
          className={`px-3 py-2 rounded-lg font-medium transition-all text-sm ${
            isListening
              ? 'bg-red-600 hover:bg-red-700 text-white'
              : 'bg-green-600 hover:bg-green-700 text-white'
          }`}
        >
          {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
        </Button>

        <Button
          onClick={() => speak(`Available commands: ${commands.join(', ')}`)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded-lg font-medium text-sm"
        >
          <HelpCircle className="w-4 h-4" />
        </Button>

        <Button
          onClick={() => speak('Voice control test. If you can hear this, audio is working properly.')}
          className="bg-purple-600 hover:bg-purple-700 text-white px-3 py-2 rounded-lg font-medium text-sm"
        >
          <Volume2 className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
};

export default VoiceControl;
