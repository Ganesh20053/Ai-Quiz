import React, { useEffect } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { updateSettings } from '../../features/settings/settingsSlice'

const AccessibilityProvider = ({ children }) => {
  const dispatch = useDispatch()
  const settings = useSelector((state) => state.settings)

  useEffect(() => {
    // Load settings from localStorage on mount
    const savedSettings = localStorage.getItem('accessibility-settings')
    if (savedSettings) {
      try {
        const parsedSettings = JSON.parse(savedSettings)
        dispatch(updateSettings(parsedSettings))
      } catch (error) {
        console.error('Error loading accessibility settings:', error)
      }
    }
  }, [dispatch])

  useEffect(() => {
    // Save settings to localStorage whenever they change
    localStorage.setItem('accessibility-settings', JSON.stringify(settings))
    
    // Apply accessibility settings to document
    applyAccessibilitySettings(settings)
  }, [settings])

  const applyAccessibilitySettings = (settings) => {
    const root = document.documentElement
    const body = document.body

    // Dark Mode
    if (settings.isDarkMode) {
      root.classList.add('dark')
    } else {
      root.classList.remove('dark')
    }

    // High Contrast
    if (settings.isHighContrast) {
      root.classList.add('high-contrast')
    } else {
      root.classList.remove('high-contrast')
    }

    // Dyslexia Font
    if (settings.isDyslexiaFont) {
      root.classList.add('dyslexia-font')
    } else {
      root.classList.remove('dyslexia-font')
    }

    // Font Size
    root.classList.remove('text-sm', 'text-base', 'text-lg', 'text-xl')
    switch (settings.fontSize) {
      case 'small':
        root.classList.add('text-sm')
        break
      case 'medium':
        root.classList.add('text-base')
        break
      case 'large':
        root.classList.add('text-lg')
        break
      case 'xl':
        root.classList.add('text-xl')
        break
      default:
        root.classList.add('text-base')
    }

    // Audio Only Mode
    if (settings.isAudioOnlyMode) {
      root.classList.add('audio-only')
      // Hide visual elements and enhance audio cues
      body.style.visibility = 'hidden'
      // Keep essential elements visible
      const essentialElements = document.querySelectorAll('[data-audio-essential]')
      essentialElements.forEach(el => {
        el.style.visibility = 'visible'
      })
    } else {
      root.classList.remove('audio-only')
      body.style.visibility = 'visible'
    }

    // Language Direction (for RTL languages)
    const rtlLanguages = ['ar', 'he', 'fa', 'ur']
    if (rtlLanguages.includes(settings.currentLanguage)) {
      root.setAttribute('dir', 'rtl')
    } else {
      root.setAttribute('dir', 'ltr')
    }

    // Language attribute
    root.setAttribute('lang', settings.currentLanguage)
  }

  // Keyboard navigation enhancement
  useEffect(() => {
    const handleKeyDown = (event) => {
      // Skip to main content (Alt + M)
      if (event.altKey && event.key === 'm') {
        event.preventDefault()
        const mainContent = document.querySelector('main, [role="main"]')
        if (mainContent) {
          mainContent.focus()
        }
      }

      // Skip to navigation (Alt + N)
      if (event.altKey && event.key === 'n') {
        event.preventDefault()
        const navigation = document.querySelector('nav, [role="navigation"]')
        if (navigation) {
          navigation.focus()
        }
      }

      // Toggle voice commands (Alt + V)
      if (event.altKey && event.key === 'v') {
        event.preventDefault()
        // This would trigger voice command mode
        console.log('Voice command mode toggled')
      }
    }

    document.addEventListener('keydown', handleKeyDown)
    return () => document.removeEventListener('keydown', handleKeyDown)
  }, [])

  // Screen reader announcements
  const announceToScreenReader = (message) => {
    const announcement = document.createElement('div')
    announcement.setAttribute('aria-live', 'polite')
    announcement.setAttribute('aria-atomic', 'true')
    announcement.className = 'sr-only'
    announcement.textContent = message
    
    document.body.appendChild(announcement)
    
    setTimeout(() => {
      document.body.removeChild(announcement)
    }, 1000)
  }

  // Provide announcement function to child components
  const contextValue = {
    settings,
    announceToScreenReader,
  }

  return (
    <AccessibilityContext.Provider value={contextValue}>
      {children}
    </AccessibilityContext.Provider>
  )
}

// Create context for accessibility features
export const AccessibilityContext = React.createContext()

// Custom hook to use accessibility context
export const useAccessibility = () => {
  const context = React.useContext(AccessibilityContext)
  if (!context) {
    throw new Error('useAccessibility must be used within AccessibilityProvider')
  }
  return context
}

export default AccessibilityProvider