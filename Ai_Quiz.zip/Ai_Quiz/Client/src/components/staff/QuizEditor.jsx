import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  X, 
  Save, 
  Plus, 
  Trash2, 
  Edit3, 
  Eye, 
  EyeOff,
  ChevronUp,
  ChevronDown,
  Copy,
  Sparkles,
  AlertCircle,
  CheckCircle,
  Clock,
  Settings,
  Shuffle,
  RotateCcw
} from 'lucide-react'
import { toast } from 'react-hot-toast'
import geminiService from '../../services/geminiService'
import quizService from '../../services/quizService'

const QuizEditor = ({ isOpen, onClose, quiz, onSave, classroomId }) => {
  const [quizData, setQuizData] = useState({
    title: '',
    description: '',
    topic: '',
    difficulty: 'medium',
    timeLimit: 30,
    questions: [{
      id: 1,
      question: '',
      options: { A: '', B: '', C: '', D: '' },
      correctAnswer: 'A',
      explanation: '',
      difficulty: 'medium',
      topic: '',
      subtopic: '',
      points: 1
    }],
    settings: {
      shuffleQuestions: false,
      shuffleOptions: false,
      showResults: true,
      allowRetake: false,
      showCorrectAnswers: true
    }
  })
  
  const [activeTab, setActiveTab] = useState('questions') // 'questions', 'settings', 'preview'
  const [expandedQuestion, setExpandedQuestion] = useState(0)
  const [validationErrors, setValidationErrors] = useState({})
  const [saving, setSaving] = useState(false)
  const [enhancing, setEnhancing] = useState(null)

  // Initialize quiz data
  useEffect(() => {
    if (isOpen) {
      if (quiz) {
        setQuizData({
          ...quiz,
          questions: quiz.questions || [{
            id: 1,
            question: '',
            options: { A: '', B: '', C: '', D: '' },
            correctAnswer: 'A',
            explanation: '',
            difficulty: 'medium',
            topic: '',
            subtopic: '',
            points: 1
          }],
          settings: quiz.settings || {
            shuffleQuestions: false,
            shuffleOptions: false,
            showResults: true,
            allowRetake: false,
            showCorrectAnswers: true
          }
        })
      } else {
        // New quiz
        setQuizData({
          title: '',
          description: '',
          topic: '',
          difficulty: 'medium',
          timeLimit: 30,
          questions: [{
            id: 1,
            question: '',
            options: { A: '', B: '', C: '', D: '' },
            correctAnswer: 'A',
            explanation: '',
            difficulty: 'medium',
            topic: '',
            subtopic: '',
            points: 1
          }],
          settings: {
            shuffleQuestions: false,
            shuffleOptions: false,
            showResults: true,
            allowRetake: false,
            showCorrectAnswers: true
          }
        })
      }
      setActiveTab('questions')
      setExpandedQuestion(0)
      setValidationErrors({})
    }
  }, [isOpen, quiz])

  const validateQuiz = () => {
    const errors = {}
    
    if (!quizData.title.trim()) {
      errors.title = 'Quiz title is required'
    }
    
    if (!quizData.topic.trim()) {
      errors.topic = 'Topic is required'
    }
    
    if (quizData.timeLimit < 1 || quizData.timeLimit > 300) {
      errors.timeLimit = 'Time limit must be between 1 and 300 minutes'
    }
    
    if (!quizData.questions || quizData.questions.length === 0) {
      errors.questions = 'At least one question is required'
    }
    
    quizData.questions && quizData.questions.forEach((question, index) => {
      if (!question.question.trim()) {
        errors[`question_${index}_text`] = `Question ${index + 1}: Question text is required`
      }
      
      const optionCount = Object.values(question.options).filter(opt => opt.trim()).length
      if (optionCount < 2) {
        errors[`question_${index}_options`] = `Question ${index + 1}: At least 2 options are required`
      }
      
      if (!question.options[question.correctAnswer]?.trim()) {
        errors[`question_${index}_answer`] = `Question ${index + 1}: Correct answer option cannot be empty`
      }
    })
    
    setValidationErrors(errors)
    return Object.keys(errors).length === 0
  }

  const handleSave = async () => {
    if (!validateQuiz()) {
      toast.error('Please fix validation errors before saving')
      return
    }
    
    try {
      setSaving(true)
      
      const formattedQuiz = {
        ...quizData,
        classroomId,
        totalQuestions: quizData.questions ? quizData.questions.length : 0,
        isActive: true,
        updatedAt: new Date().toISOString()
      }
      
      if (quiz) {
        // Update existing quiz - include the _id
        const quizToUpdate = {
          ...formattedQuiz,
          _id: quiz._id
        }
        await onSave(quizToUpdate)
      } else {
        // Create new quiz - format the data for API
        const quizData = quizService.formatQuizForAPI(formattedQuiz, classroomId)
        await onSave(quizData)
      }
      
    } catch (error) {
      console.error('Error saving quiz:', error)
      toast.error('Failed to save quiz')
    } finally {
      setSaving(false)
    }
  }

  const addQuestion = () => {
    const newQuestion = {
      id: (quizData.questions ? quizData.questions.length : 0) + 1,
      question: '',
      options: { A: '', B: '', C: '', D: '' },
      correctAnswer: 'A',
      explanation: '',
      difficulty: quizData.difficulty,
      topic: quizData.topic,
      subtopic: '',
      points: 1
    }
    
    setQuizData(prev => ({
      ...prev,
      questions: [...prev.questions, newQuestion]
    }))
    
    setExpandedQuestion(quizData.questions ? quizData.questions.length : 0)
  }

  const removeQuestion = (index) => {
    if (!quizData.questions || quizData.questions.length === 1) {
      toast.error('Quiz must have at least one question')
      return
    }
    
    setQuizData(prev => ({
      ...prev,
      questions: prev.questions.filter((_, i) => i !== index)
    }))
    
    if (expandedQuestion >= index && expandedQuestion > 0) {
      setExpandedQuestion(expandedQuestion - 1)
    }
  }

  const duplicateQuestion = (index) => {
    const questionToDuplicate = { ...quizData.questions[index] }
    questionToDuplicate.id = (quizData.questions ? quizData.questions.length : 0) + 1
    questionToDuplicate.question = `${questionToDuplicate.question} (Copy)`
    
    setQuizData(prev => ({
      ...prev,
      questions: [...prev.questions, questionToDuplicate]
    }))
  }

  const updateQuestion = (index, field, value) => {
    setQuizData(prev => ({
      ...prev,
      questions: prev.questions.map((q, i) => 
        i === index ? { ...q, [field]: value } : q
      )
    }))
  }

  const updateQuestionOption = (questionIndex, optionKey, value) => {
    setQuizData(prev => ({
      ...prev,
      questions: prev.questions.map((q, i) => 
        i === questionIndex 
          ? { ...q, options: { ...q.options, [optionKey]: value } }
          : q
      )
    }))
  }

  const enhanceQuestion = async (index) => {
    try {
      setEnhancing(index)
      const question = quizData.questions[index]
      
      const enhanced = await geminiService.enhanceQuestion(
        question.question,
        `Topic: ${quizData.topic}, Difficulty: ${question.difficulty}`
      )
      
      updateQuestion(index, 'question', enhanced.enhancedQuestion)
      updateQuestion(index, 'options', enhanced.options)
      updateQuestion(index, 'correctAnswer', enhanced.correctAnswer)
      updateQuestion(index, 'explanation', enhanced.explanation)
      
      toast.success('Question enhanced successfully!')
      
    } catch (error) {
      console.error('Error enhancing question:', error)
      toast.error('Failed to enhance question')
    } finally {
      setEnhancing(null)
    }
  }

  const moveQuestion = (index, direction) => {
    const newIndex = direction === 'up' ? index - 1 : index + 1
    if (!quizData.questions || newIndex < 0 || newIndex >= quizData.questions.length) return
    
    const newQuestions = [...quizData.questions]
    const temp = newQuestions[index]
    newQuestions[index] = newQuestions[newIndex]
    newQuestions[newIndex] = temp
    
    setQuizData(prev => ({ ...prev, questions: newQuestions }))
    setExpandedQuestion(newIndex)
  }

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'easy': return 'text-green-600 bg-green-100 dark:bg-green-900/20'
      case 'medium': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20'
      case 'hard': return 'text-red-600 bg-red-100 dark:bg-red-900/20'
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900/20'
    }
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 z-40"
            onClick={onClose}
          />
          
          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
          >
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-6xl max-h-[95vh] overflow-hidden">
              {/* Header */}
              <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
                <div>
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                    {quiz ? 'Edit Quiz' : 'Create New Quiz'}
                  </h2>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                    {quiz ? 'Modify your quiz content and settings' : 'Build your quiz from scratch'}
                  </p>
                </div>
                
                <div className="flex items-center space-x-3">
                  {/* Validation Status */}
                  {Object.keys(validationErrors).length > 0 ? (
                    <div className="flex items-center space-x-2 text-red-600 dark:text-red-400">
                      <AlertCircle className="w-4 h-4" />
                      <span className="text-sm">{Object.keys(validationErrors).length} errors</span>
                    </div>
                  ) : quizData.title && quizData.questions && quizData.questions.length > 0 && (
                    <div className="flex items-center space-x-2 text-green-600 dark:text-green-400">
                      <CheckCircle className="w-4 h-4" />
                      <span className="text-sm">Ready to save</span>
                    </div>
                  )}
                  
                  <button
                    onClick={onClose}
                    className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                    disabled={saving}
                  >
                    <X className="w-5 h-5 text-gray-600 dark:text-gray-300" />
                  </button>
                </div>
              </div>

              {/* Tabs */}
              <div className="flex border-b border-gray-200 dark:border-gray-700">
                {[
                  { id: 'questions', label: 'Questions', icon: Edit3 },
                  { id: 'settings', label: 'Settings', icon: Settings },
                  { id: 'preview', label: 'Preview', icon: Eye }
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`
                      flex items-center space-x-2 px-6 py-3 border-b-2 transition-colors
                      ${activeTab === tab.id
                        ? 'border-blue-500 text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/20'
                        : 'border-transparent text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200'
                      }
                    `}
                  >
                    <tab.icon className="w-4 h-4" />
                    <span className="font-medium">{tab.label}</span>
                  </button>
                ))}
              </div>

              {/* Content */}
              <div className="flex-1 overflow-y-auto max-h-[calc(95vh-200px)]">
                {activeTab === 'questions' && (
                  <div className="p-6">
                    {/* Quiz Basic Info */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Quiz Title *
                        </label>
                        <input
                          type="text"
                          value={quizData.title}
                          onChange={(e) => setQuizData(prev => ({ ...prev, title: e.target.value }))}
                          placeholder="Enter quiz title..."
                          className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                        />
                        {validationErrors.title && (
                          <p className="mt-1 text-sm text-red-600 dark:text-red-400">
                            {validationErrors.title}
                          </p>
                        )}
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Topic *
                        </label>
                        <input
                          type="text"
                          value={quizData.topic}
                          onChange={(e) => setQuizData(prev => ({ ...prev, topic: e.target.value }))}
                          placeholder="Enter topic..."
                          className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                        />
                        {validationErrors.topic && (
                          <p className="mt-1 text-sm text-red-600 dark:text-red-400">
                            {validationErrors.topic}
                          </p>
                        )}
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Difficulty
                        </label>
                        <select
                          value={quizData.difficulty}
                          onChange={(e) => setQuizData(prev => ({ ...prev, difficulty: e.target.value }))}
                          className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                        >
                          <option value="easy">Easy</option>
                          <option value="medium">Medium</option>
                          <option value="hard">Hard</option>
                        </select>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Time Limit (minutes)
                        </label>
                        <input
                          type="number"
                          min="1"
                          max="300"
                          value={quizData.timeLimit}
                          onChange={(e) => setQuizData(prev => ({ ...prev, timeLimit: parseInt(e.target.value) || 30 }))}
                          className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                        />
                        {validationErrors.timeLimit && (
                          <p className="mt-1 text-sm text-red-600 dark:text-red-400">
                            {validationErrors.timeLimit}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Description */}
                    <div className="mb-8">
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Description (Optional)
                      </label>
                      <textarea
                        value={quizData.description}
                        onChange={(e) => setQuizData(prev => ({ ...prev, description: e.target.value }))}
                        placeholder="Enter quiz description..."
                        rows={3}
                        className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white resize-none"
                      />
                    </div>

                    {/* Questions */}
                    <div className="space-y-6">
                      <div className="flex items-center justify-between">
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                          Questions ({quizData.questions ? quizData.questions.length : 0})
                        </h3>
                        <button
                          onClick={addQuestion}
                          className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                        >
                          <Plus className="w-4 h-4" />
                          <span>Add Question</span>
                        </button>
                      </div>

                      {quizData.questions && quizData.questions.map((question, index) => (
                        <div
                          key={index}
                          className="border border-gray-200 dark:border-gray-600 rounded-lg overflow-hidden"
                        >
                          {/* Question Header */}
                          <div
                            className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 cursor-pointer"
                            onClick={() => setExpandedQuestion(expandedQuestion === index ? -1 : index)}
                          >
                            <div className="flex items-center space-x-3">
                              <span className="flex items-center justify-center w-8 h-8 bg-blue-100 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-full text-sm font-medium">
                                {index + 1}
                              </span>
                              <div>
                                <p className="font-medium text-gray-900 dark:text-white">
                                  {question.question || `Question ${index + 1}`}
                                </p>
                                <div className="flex items-center space-x-2 mt-1">
                                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(question.difficulty)}`}>
                                    {question.difficulty}
                                  </span>
                                  <span className="text-xs text-gray-500 dark:text-gray-400">
                                    {question.points} point{question.points !== 1 ? 's' : ''}
                                  </span>
                                </div>
                              </div>
                            </div>
                            
                            <div className="flex items-center space-x-2">
                              {/* Question Actions */}
                              <button
                                onClick={(e) => {
                                  e.stopPropagation()
                                  enhanceQuestion(index)
                                }}
                                disabled={enhancing === index}
                                className="p-2 text-purple-600 hover:bg-purple-100 dark:hover:bg-purple-900/20 rounded-lg transition-colors"
                                title="Enhance with AI"
                              >
                                {enhancing === index ? (
                                  <div className="w-4 h-4 border-2 border-purple-600 border-t-transparent rounded-full animate-spin" />
                                ) : (
                                  <Sparkles className="w-4 h-4" />
                                )}
                              </button>
                              
                              <button
                                onClick={(e) => {
                                  e.stopPropagation()
                                  duplicateQuestion(index)
                                }}
                                className="p-2 text-gray-600 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-colors"
                                title="Duplicate question"
                              >
                                <Copy className="w-4 h-4" />
                              </button>
                              
                              <button
                                onClick={(e) => {
                                  e.stopPropagation()
                                  moveQuestion(index, 'up')
                                }}
                                disabled={index === 0}
                                className="p-2 text-gray-600 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                title="Move up"
                              >
                                <ChevronUp className="w-4 h-4" />
                              </button>
                              
                              <button
                                onClick={(e) => {
                                  e.stopPropagation()
                                  moveQuestion(index, 'down')
                                }}
                                disabled={!quizData.questions || index === quizData.questions.length - 1}
                                className="p-2 text-gray-600 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                title="Move down"
                              >
                                <ChevronDown className="w-4 h-4" />
                              </button>
                              
                              <button
                                onClick={(e) => {
                                  e.stopPropagation()
                                  removeQuestion(index)
                                }}
                                className="p-2 text-red-600 hover:bg-red-100 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                                title="Delete question"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                              
                              {expandedQuestion === index ? (
                                <ChevronUp className="w-5 h-5 text-gray-400" />
                              ) : (
                                <ChevronDown className="w-5 h-5 text-gray-400" />
                              )}
                            </div>
                          </div>

                          {/* Question Content */}
                          {expandedQuestion === index && (
                            <div className="p-6 space-y-6">
                              {/* Question Text */}
                              <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                  Question Text *
                                </label>
                                <textarea
                                  value={question.question}
                                  onChange={(e) => updateQuestion(index, 'question', e.target.value)}
                                  placeholder="Enter your question..."
                                  rows={3}
                                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white resize-none"
                                />
                                {validationErrors[`question_${index}_text`] && (
                                  <p className="mt-1 text-sm text-red-600 dark:text-red-400">
                                    {validationErrors[`question_${index}_text`]}
                                  </p>
                                )}
                              </div>

                              {/* Options */}
                              <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                                  Answer Options *
                                </label>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  {Object.entries(question.options).map(([key, value]) => (
                                    <div key={key} className="relative">
                                      <div className="flex items-center space-x-3">
                                        <input
                                          type="radio"
                                          name={`correct_${index}`}
                                          checked={question.correctAnswer === key}
                                          onChange={() => updateQuestion(index, 'correctAnswer', key)}
                                          className="w-4 h-4 text-blue-600 focus:ring-blue-500"
                                        />
                                        <div className="flex-1">
                                          <label className="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">
                                            Option {key}
                                          </label>
                                          <input
                                            type="text"
                                            value={value}
                                            onChange={(e) => updateQuestionOption(index, key, e.target.value)}
                                            placeholder={`Enter option ${key}...`}
                                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                                          />
                                        </div>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                                {validationErrors[`question_${index}_options`] && (
                                  <p className="mt-2 text-sm text-red-600 dark:text-red-400">
                                    {validationErrors[`question_${index}_options`]}
                                  </p>
                                )}
                                {validationErrors[`question_${index}_answer`] && (
                                  <p className="mt-2 text-sm text-red-600 dark:text-red-400">
                                    {validationErrors[`question_${index}_answer`]}
                                  </p>
                                )}
                              </div>

                              {/* Additional Settings */}
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div>
                                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                    Difficulty
                                  </label>
                                  <select
                                    value={question.difficulty}
                                    onChange={(e) => updateQuestion(index, 'difficulty', e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                                  >
                                    <option value="easy">Easy</option>
                                    <option value="medium">Medium</option>
                                    <option value="hard">Hard</option>
                                  </select>
                                </div>
                                
                                <div>
                                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                    Points
                                  </label>
                                  <input
                                    type="number"
                                    min="1"
                                    max="10"
                                    value={question.points}
                                    onChange={(e) => updateQuestion(index, 'points', parseInt(e.target.value) || 1)}
                                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                                  />
                                </div>
                                
                                <div>
                                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                    Subtopic
                                  </label>
                                  <input
                                    type="text"
                                    value={question.subtopic}
                                    onChange={(e) => updateQuestion(index, 'subtopic', e.target.value)}
                                    placeholder="Optional subtopic..."
                                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                                  />
                                </div>
                              </div>

                              {/* Explanation */}
                              <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                  Explanation (Optional)
                                </label>
                                <textarea
                                  value={question.explanation}
                                  onChange={(e) => updateQuestion(index, 'explanation', e.target.value)}
                                  placeholder="Explain why this answer is correct..."
                                  rows={2}
                                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white resize-none"
                                />
                              </div>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeTab === 'settings' && (
                  <div className="p-6">
                    <div className="max-w-2xl space-y-8">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                          Quiz Settings
                        </h3>
                        
                        <div className="space-y-6">
                          {/* Question Settings */}
                          <div className="space-y-4">
                            <h4 className="font-medium text-gray-900 dark:text-white">Question Behavior</h4>
                            
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="font-medium text-gray-900 dark:text-white">Shuffle Questions</p>
                                <p className="text-sm text-gray-600 dark:text-gray-400">Randomize question order for each student</p>
                              </div>
                              <button
                                onClick={() => setQuizData(prev => ({
                                  ...prev,
                                  settings: { ...prev.settings, shuffleQuestions: !prev.settings.shuffleQuestions }
                                }))}
                                className={`
                                  relative inline-flex h-6 w-11 items-center rounded-full transition-colors
                                  ${quizData.settings.shuffleQuestions ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-700'}
                                `}
                              >
                                <span
                                  className={`
                                    inline-block h-4 w-4 transform rounded-full bg-white transition-transform
                                    ${quizData.settings.shuffleQuestions ? 'translate-x-6' : 'translate-x-1'}
                                  `}
                                />
                              </button>
                            </div>
                            
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="font-medium text-gray-900 dark:text-white">Shuffle Options</p>
                                <p className="text-sm text-gray-600 dark:text-gray-400">Randomize answer options within questions</p>
                              </div>
                              <button
                                onClick={() => setQuizData(prev => ({
                                  ...prev,
                                  settings: { ...prev.settings, shuffleOptions: !prev.settings.shuffleOptions }
                                }))}
                                className={`
                                  relative inline-flex h-6 w-11 items-center rounded-full transition-colors
                                  ${quizData.settings.shuffleOptions ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-700'}
                                `}
                              >
                                <span
                                  className={`
                                    inline-block h-4 w-4 transform rounded-full bg-white transition-transform
                                    ${quizData.settings.shuffleOptions ? 'translate-x-6' : 'translate-x-1'}
                                  `}
                                />
                              </button>
                            </div>
                          </div>

                          {/* Result Settings */}
                          <div className="space-y-4">
                            <h4 className="font-medium text-gray-900 dark:text-white">Results & Feedback</h4>
                            
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="font-medium text-gray-900 dark:text-white">Show Results</p>
                                <p className="text-sm text-gray-600 dark:text-gray-400">Display score and results after completion</p>
                              </div>
                              <button
                                onClick={() => setQuizData(prev => ({
                                  ...prev,
                                  settings: { ...prev.settings, showResults: !prev.settings.showResults }
                                }))}
                                className={`
                                  relative inline-flex h-6 w-11 items-center rounded-full transition-colors
                                  ${quizData.settings.showResults ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-700'}
                                `}
                              >
                                <span
                                  className={`
                                    inline-block h-4 w-4 transform rounded-full bg-white transition-transform
                                    ${quizData.settings.showResults ? 'translate-x-6' : 'translate-x-1'}
                                  `}
                                />
                              </button>
                            </div>
                            
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="font-medium text-gray-900 dark:text-white">Show Correct Answers</p>
                                <p className="text-sm text-gray-600 dark:text-gray-400">Reveal correct answers in results</p>
                              </div>
                              <button
                                onClick={() => setQuizData(prev => ({
                                  ...prev,
                                  settings: { ...prev.settings, showCorrectAnswers: !prev.settings.showCorrectAnswers }
                                }))}
                                className={`
                                  relative inline-flex h-6 w-11 items-center rounded-full transition-colors
                                  ${quizData.settings.showCorrectAnswers ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-700'}
                                `}
                              >
                                <span
                                  className={`
                                    inline-block h-4 w-4 transform rounded-full bg-white transition-transform
                                    ${quizData.settings.showCorrectAnswers ? 'translate-x-6' : 'translate-x-1'}
                                  `}
                                />
                              </button>
                            </div>
                            
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="font-medium text-gray-900 dark:text-white">Allow Retakes</p>
                                <p className="text-sm text-gray-600 dark:text-gray-400">Students can retake the quiz multiple times</p>
                              </div>
                              <button
                                onClick={() => setQuizData(prev => ({
                                  ...prev,
                                  settings: { ...prev.settings, allowRetake: !prev.settings.allowRetake }
                                }))}
                                className={`
                                  relative inline-flex h-6 w-11 items-center rounded-full transition-colors
                                  ${quizData.settings.allowRetake ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-700'}
                                `}
                              >
                                <span
                                  className={`
                                    inline-block h-4 w-4 transform rounded-full bg-white transition-transform
                                    ${quizData.settings.allowRetake ? 'translate-x-6' : 'translate-x-1'}
                                  `}
                                />
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'preview' && (
                  <div className="p-6">
                    <div className="max-w-4xl mx-auto">
                      <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6">
                        <div className="text-center mb-8">
                          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                            {quizData.title || 'Untitled Quiz'}
                          </h2>
                          {quizData.description && (
                            <p className="text-gray-600 dark:text-gray-400 mb-4">
                              {quizData.description}
                            </p>
                          )}
                          <div className="flex items-center justify-center space-x-6 text-sm text-gray-600 dark:text-gray-400">
                            <div className="flex items-center space-x-2">
                              <BookOpen className="w-4 h-4" />
                              <span>{quizData.questions ? quizData.questions.length : 0} Questions</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Clock className="w-4 h-4" />
                              <span>{quizData.timeLimit} Minutes</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Target className="w-4 h-4" />
                              <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(quizData.difficulty)}`}>
                                {quizData.difficulty}
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="space-y-6">
                          {quizData.questions && quizData.questions.map((question, index) => (
                            <div key={index} className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-600">
                              <div className="flex items-start space-x-4">
                                <span className="flex items-center justify-center w-8 h-8 bg-blue-100 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-full text-sm font-medium flex-shrink-0">
                                  {index + 1}
                                </span>
                                <div className="flex-1">
                                  <h4 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
                                    {question.question || `Question ${index + 1}`}
                                  </h4>
                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                    {Object.entries(question.options).map(([key, value]) => (
                                      <div
                                        key={key}
                                        className={`
                                          p-3 rounded-lg border-2 transition-colors
                                          ${question.correctAnswer === key
                                            ? 'border-green-500 bg-green-50 dark:bg-green-900/20'
                                            : 'border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-700'
                                          }
                                        `}
                                      >
                                        <div className="flex items-center space-x-3">
                                          <span className="flex items-center justify-center w-6 h-6 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-full text-sm font-medium">
                                            {key}
                                          </span>
                                          <span className="text-gray-900 dark:text-white">
                                            {value || `Option ${key}`}
                                          </span>
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                  {question.explanation && (
                                    <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                                      <p className="text-sm text-blue-800 dark:text-blue-200">
                                        <strong>Explanation:</strong> {question.explanation}
                                      </p>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between p-6 border-t border-gray-200 dark:border-gray-700">
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  {saving && 'Saving quiz...'}
                </div>
                
                <div className="flex items-center space-x-3">
                  <button
                    onClick={onClose}
                    className="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                    disabled={saving}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSave}
                    disabled={saving || Object.keys(validationErrors).length > 0}
                    className="flex items-center space-x-2 px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
                  >
                    {saving ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        <span>Saving...</span>
                      </>
                    ) : (
                      <>
                        <Save className="w-4 h-4" />
                        <span>{quiz ? 'Update Quiz' : 'Create Quiz'}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}

export default QuizEditor