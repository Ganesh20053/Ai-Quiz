import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  X, 
  BookOpen, 
  Clock, 
  Target, 
  ChevronDown, 
  ChevronRight,
  Search,
  Download,
  Edit3,
  Trash2,
  RefreshCw,
  Calendar,
  Tag,
  Users,
  BarChart3
} from 'lucide-react'
import { toast } from 'react-hot-toast'

const SyllabusViewer = ({ isOpen, onClose, syllabusData, classroomId }) => {
  const [expandedTopics, setExpandedTopics] = useState(new Set())
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedTopic, setSelectedTopic] = useState(null)

  const toggleTopicExpansion = (topicName) => {
    const newExpanded = new Set(expandedTopics)
    if (newExpanded.has(topicName)) {
      newExpanded.delete(topicName)
    } else {
      newExpanded.add(topicName)
    }
    setExpandedTopics(newExpanded)
  }

  const handleTopicSelect = (topic) => {
    setSelectedTopic(topic)
  }

  const handleDeleteSyllabus = async () => {
    if (!confirm('Are you sure you want to delete this syllabus? This action cannot be undone.')) {
      return
    }

    try {
      // Remove from localStorage
      localStorage.removeItem(`syllabus_${classroomId}`)
      toast.success('Syllabus deleted successfully')
      onClose()
    } catch (error) {
      console.error('Error deleting syllabus:', error)
      toast.error('Failed to delete syllabus')
    }
  }

  const handleExportSyllabus = () => {
    try {
      const dataStr = JSON.stringify(syllabusData, null, 2)
      const dataBlob = new Blob([dataStr], { type: 'application/json' })
      const url = URL.createObjectURL(dataBlob)
      const link = document.createElement('a')
      link.href = url
      link.download = `syllabus-${syllabusData.title || 'export'}-${new Date().toISOString().split('T')[0]}.json`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      URL.revokeObjectURL(url)
      toast.success('Syllabus exported successfully')
    } catch (error) {
      console.error('Error exporting syllabus:', error)
      toast.error('Failed to export syllabus')
    }
  }

  const filteredTopics = syllabusData?.topics?.filter(topic =>
    topic.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    topic.subtopics.some(subtopic => 
      subtopic.toLowerCase().includes(searchTerm.toLowerCase())
    ) ||
    topic.learningObjectives.some(objective =>
      objective.toLowerCase().includes(searchTerm.toLowerCase())
    )
  ) || []

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'easy': return 'text-green-600 bg-green-100 dark:bg-green-900/20'
      case 'medium': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20'
      case 'hard': return 'text-red-600 bg-red-100 dark:bg-red-900/20'
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900/20'
    }
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })
  }

  if (!syllabusData) {
    return null
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 z-40"
            onClick={onClose}
          />
          
          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
          >
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-6xl max-h-[95vh] overflow-hidden">
              {/* Header */}
              <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-blue-100 dark:bg-blue-900/20 rounded-lg">
                    <BookOpen className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                      {syllabusData.title || 'Course Syllabus'}
                    </h2>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {syllabusData.totalTopics} topics • {syllabusData.estimatedDuration}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <button
                    onClick={handleExportSyllabus}
                    className="p-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                    title="Export syllabus"
                  >
                    <Download className="w-5 h-5" />
                  </button>
                  <button
                    onClick={handleDeleteSyllabus}
                    className="p-2 text-red-600 hover:bg-red-100 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                    title="Delete syllabus"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                  <button
                    onClick={onClose}
                    className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                  >
                    <X className="w-5 h-5 text-gray-600 dark:text-gray-300" />
                  </button>
                </div>
              </div>

              {/* Content */}
              <div className="flex-1 overflow-y-auto max-h-[calc(95vh-140px)]">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 p-6">
                  {/* Left Column - Overview */}
                  <div className="lg:col-span-1 space-y-6">
                    {/* Course Info */}
                    <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                      <h3 className="font-semibold text-gray-900 dark:text-white mb-3">
                        Course Overview
                      </h3>
                      <div className="space-y-3 text-sm">
                        <div>
                          <p className="text-gray-600 dark:text-gray-400">Description</p>
                          <p className="text-gray-900 dark:text-white">
                            {syllabusData.description || 'No description available'}
                          </p>
                        </div>
                        <div>
                          <p className="text-gray-600 dark:text-gray-400">Duration</p>
                          <p className="text-gray-900 dark:text-white flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            {syllabusData.estimatedDuration}
                          </p>
                        </div>
                        <div>
                          <p className="text-gray-600 dark:text-gray-400">Total Topics</p>
                          <p className="text-gray-900 dark:text-white flex items-center">
                            <Target className="w-4 h-4 mr-1" />
                            {syllabusData.totalTopics}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Prerequisites */}
                    {syllabusData.prerequisites && syllabusData.prerequisites.length > 0 && (
                      <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
                        <h4 className="font-medium text-yellow-800 dark:text-yellow-200 mb-2">
                          Prerequisites
                        </h4>
                        <ul className="text-sm text-yellow-700 dark:text-yellow-300 space-y-1">
                          {syllabusData.prerequisites.map((prereq, index) => (
                            <li key={index}>• {prereq}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Key Terms */}
                    {syllabusData.keyTerms && syllabusData.keyTerms.length > 0 && (
                      <div>
                        <h4 className="font-medium text-gray-900 dark:text-white mb-3">
                          Key Terms
                        </h4>
                        <div className="flex flex-wrap gap-2">
                          {syllabusData.keyTerms.map((term, index) => (
                            <span
                              key={index}
                              className="px-2 py-1 bg-blue-100 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 rounded-full text-xs font-medium"
                            >
                              {term}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Statistics */}
                    <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                      <h4 className="font-medium text-blue-800 dark:text-blue-200 mb-3 flex items-center">
                        <BarChart3 className="w-4 h-4 mr-2" />
                        Statistics
                      </h4>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-blue-600 dark:text-blue-400">Easy Topics</p>
                          <p className="font-semibold text-blue-800 dark:text-blue-200">
                            {syllabusData.topics?.filter(t => t.difficulty === 'easy').length || 0}
                          </p>
                        </div>
                        <div>
                          <p className="text-blue-600 dark:text-blue-400">Medium Topics</p>
                          <p className="font-semibold text-blue-800 dark:text-blue-200">
                            {syllabusData.topics?.filter(t => t.difficulty === 'medium').length || 0}
                          </p>
                        </div>
                        <div>
                          <p className="text-blue-600 dark:text-blue-400">Hard Topics</p>
                          <p className="font-semibold text-blue-800 dark:text-blue-200">
                            {syllabusData.topics?.filter(t => t.difficulty === 'hard').length || 0}
                          </p>
                        </div>
                        <div>
                          <p className="text-blue-600 dark:text-blue-400">Total Subtopics</p>
                          <p className="font-semibold text-blue-800 dark:text-blue-200">
                            {syllabusData.topics?.reduce((acc, topic) => acc + topic.subtopics.length, 0) || 0}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Right Column - Topics */}
                  <div className="lg:col-span-2">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                        Course Topics
                      </h3>
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                        <input
                          type="text"
                          placeholder="Search topics..."
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                        />
                      </div>
                    </div>

                    <div className="space-y-4">
                      {filteredTopics.map((topic, index) => (
                        <div
                          key={index}
                          className="border border-gray-200 dark:border-gray-600 rounded-lg overflow-hidden"
                        >
                          {/* Topic Header */}
                          <div
                            className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
                            onClick={() => toggleTopicExpansion(topic.name)}
                          >
                            <div className="flex items-center space-x-3">
                              {expandedTopics.has(topic.name) ? (
                                <ChevronDown className="w-5 h-5 text-gray-400" />
                              ) : (
                                <ChevronRight className="w-5 h-5 text-gray-400" />
                              )}
                              <div>
                                <h4 className="font-medium text-gray-900 dark:text-white">
                                  {topic.name}
                                </h4>
                                <p className="text-sm text-gray-600 dark:text-gray-400">
                                  {topic.subtopics.length} subtopics • {topic.learningObjectives.length} objectives
                                </p>
                              </div>
                            </div>
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(topic.difficulty)}`}>
                              {topic.difficulty}
                            </span>
                          </div>

                          {/* Topic Content */}
                          {expandedTopics.has(topic.name) && (
                            <div className="p-4 space-y-4">
                              {/* Subtopics */}
                              <div>
                                <h5 className="font-medium text-gray-900 dark:text-white mb-2">
                                  Subtopics
                                </h5>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                                  {topic.subtopics.map((subtopic, subIndex) => (
                                    <div
                                      key={subIndex}
                                      className="p-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded text-sm"
                                    >
                                      {subtopic}
                                    </div>
                                  ))}
                                </div>
                              </div>

                              {/* Learning Objectives */}
                              <div>
                                <h5 className="font-medium text-gray-900 dark:text-white mb-2">
                                  Learning Objectives
                                </h5>
                                <ul className="space-y-1 text-sm text-gray-700 dark:text-gray-300">
                                  {topic.learningObjectives.map((objective, objIndex) => (
                                    <li key={objIndex} className="flex items-start">
                                      <span className="text-blue-500 mr-2">•</span>
                                      {objective}
                                    </li>
                                  ))}
                                </ul>
                              </div>

                              {/* Action Button */}
                              <div className="pt-2 border-t border-gray-200 dark:border-gray-600">
                                <button
                                  onClick={() => handleTopicSelect(topic)}
                                  className="text-sm text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 font-medium"
                                >
                                  Generate Quiz for this Topic →
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      ))}

                      {filteredTopics.length === 0 && (
                        <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                          <BookOpen className="w-12 h-12 mx-auto mb-3 opacity-50" />
                          <p>No topics found matching your search</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between p-6 border-t border-gray-200 dark:border-gray-700">
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  Last updated: {formatDate(new Date())}
                </div>
                <button
                  onClick={onClose}
                  className="px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}

export default SyllabusViewer