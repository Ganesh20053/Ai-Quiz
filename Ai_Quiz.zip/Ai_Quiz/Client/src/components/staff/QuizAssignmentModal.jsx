import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  X, 
  Send, 
  Calendar, 
  Clock, 
  Users, 
  Search,
  CheckCircle,
  AlertCircle,
  Loader,
  Mail,
  Settings
} from 'lucide-react'
import { toast } from 'react-hot-toast'

const QuizAssignmentModal = ({ isOpen, onClose, quiz, classroomId }) => {
  const [students, setStudents] = useState([])
  const [selectedStudents, setSelectedStudents] = useState([])
  const [searchTerm, setSearchTerm] = useState('')
  const [assignmentSettings, setAssignmentSettings] = useState({
    dueDate: '',
    dueTime: '',
    allowLateSubmission: true,
    maxAttempts: 1,
    showResultsImmediately: true,
    sendEmailNotification: true,
    instructions: ''
  })
  const [loading, setLoading] = useState(false)
  const [assigning, setAssigning] = useState(false)

  // Load students when modal opens
  useEffect(() => {
    if (isOpen && classroomId) {
      loadStudents()
    }
  }, [isOpen, classroomId])

  const loadStudents = async () => {
    try {
      setLoading(true)
      // This would normally fetch from API
      // For now, using mock data or localStorage
      const mockStudents = [
        { _id: '1', name: 'John Doe', email: 'john@example.com', studentId: 'ST001' },
        { _id: '2', name: 'Jane Smith', email: 'jane@example.com', studentId: 'ST002' },
        { _id: '3', name: 'Mike Johnson', email: 'mike@example.com', studentId: 'ST003' },
        { _id: '4', name: 'Sarah Wilson', email: 'sarah@example.com', studentId: 'ST004' },
        { _id: '5', name: 'David Brown', email: 'david@example.com', studentId: 'ST005' }
      ]
      setStudents(mockStudents)
    } catch (error) {
      console.error('Error loading students:', error)
      toast.error('Failed to load students')
    } finally {
      setLoading(false)
    }
  }

  const handleStudentToggle = (studentId) => {
    setSelectedStudents(prev => 
      prev.includes(studentId)
        ? prev.filter(id => id !== studentId)
        : [...prev, studentId]
    )
  }

  const handleSelectAll = () => {
    const filteredStudentIds = filteredStudents.map(s => s._id)
    if (selectedStudents.length === filteredStudentIds.length) {
      setSelectedStudents([])
    } else {
      setSelectedStudents(filteredStudentIds)
    }
  }

  const handleAssignQuiz = async () => {
    if (selectedStudents.length === 0) {
      toast.error('Please select at least one student')
      return
    }

    if (!assignmentSettings.dueDate) {
      toast.error('Please set a due date')
      return
    }

    try {
      setAssigning(true)
      
      const assignmentData = {
        quizId: quiz._id,
        classroomId,
        studentIds: selectedStudents,
        settings: {
          ...assignmentSettings,
          dueDateTime: new Date(`${assignmentSettings.dueDate}T${assignmentSettings.dueTime || '23:59'}`).toISOString()
        }
      }

      // This would normally call the API
      console.log('Assignment data:', assignmentData)
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      toast.success(`Quiz assigned to ${selectedStudents.length} student${selectedStudents.length !== 1 ? 's' : ''}`)
      onClose()
      
    } catch (error) {
      console.error('Error assigning quiz:', error)
      toast.error('Failed to assign quiz')
    } finally {
      setAssigning(false)
    }
  }

  const filteredStudents = students.filter(student =>
    student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    student.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    student.studentId.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const formatDateTime = (date, time) => {
    if (!date) return 'Not set'
    const dateTime = new Date(`${date}T${time || '23:59'}`)
    return dateTime.toLocaleString()
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 z-40"
            onClick={onClose}
          />
          
          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
          >
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
              {/* Header */}
              <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
                <div>
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                    Assign Quiz
                  </h2>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                    {quiz?.title}
                  </p>
                </div>
                <button
                  onClick={onClose}
                  className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                  disabled={assigning}
                >
                  <X className="w-5 h-5 text-gray-600 dark:text-gray-300" />
                </button>
              </div>

              {/* Content */}
              <div className="flex-1 overflow-y-auto max-h-[calc(90vh-140px)]">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 p-6">
                  {/* Left Column - Student Selection */}
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                        Select Students
                      </h3>
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        {selectedStudents.length} of {filteredStudents.length} selected
                      </span>
                    </div>

                    {/* Search */}
                    <div className="relative mb-4">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <input
                        type="text"
                        placeholder="Search students..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                      />
                    </div>

                    {/* Select All */}
                    <div className="flex items-center justify-between mb-4">
                      <button
                        onClick={handleSelectAll}
                        className="text-sm text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
                      >
                        {selectedStudents.length === filteredStudents.length ? 'Deselect All' : 'Select All'}
                      </button>
                    </div>

                    {/* Students List */}
                    {loading ? (
                      <div className="flex items-center justify-center py-8">
                        <Loader className="w-6 h-6 animate-spin text-blue-600" />
                        <span className="ml-2 text-gray-600 dark:text-gray-400">Loading students...</span>
                      </div>
                    ) : (
                      <div className="max-h-80 overflow-y-auto border border-gray-200 dark:border-gray-600 rounded-lg">
                        {filteredStudents.map((student) => (
                          <div
                            key={student._id}
                            className="flex items-center space-x-3 p-3 hover:bg-gray-50 dark:hover:bg-gray-700 border-b border-gray-200 dark:border-gray-600 last:border-b-0"
                          >
                            <input
                              type="checkbox"
                              checked={selectedStudents.includes(student._id)}
                              onChange={() => handleStudentToggle(student._id)}
                              className="w-4 h-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                            />
                            <div className="flex-1">
                              <p className="font-medium text-gray-900 dark:text-white">
                                {student.name}
                              </p>
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                {student.email} • {student.studentId}
                              </p>
                            </div>
                          </div>
                        ))}
                        
                        {filteredStudents.length === 0 && (
                          <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                            No students found
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Right Column - Assignment Settings */}
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                      Assignment Settings
                    </h3>

                    <div className="space-y-6">
                      {/* Due Date & Time */}
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Due Date *
                          </label>
                          <input
                            type="date"
                            value={assignmentSettings.dueDate}
                            onChange={(e) => setAssignmentSettings(prev => ({ ...prev, dueDate: e.target.value }))}
                            min={new Date().toISOString().split('T')[0]}
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Due Time
                          </label>
                          <input
                            type="time"
                            value={assignmentSettings.dueTime}
                            onChange={(e) => setAssignmentSettings(prev => ({ ...prev, dueTime: e.target.value }))}
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                          />
                        </div>
                      </div>

                      {/* Max Attempts */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Maximum Attempts
                        </label>
                        <select
                          value={assignmentSettings.maxAttempts}
                          onChange={(e) => setAssignmentSettings(prev => ({ ...prev, maxAttempts: parseInt(e.target.value) }))}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                        >
                          <option value={1}>1 Attempt</option>
                          <option value={2}>2 Attempts</option>
                          <option value={3}>3 Attempts</option>
                          <option value={-1}>Unlimited</option>
                        </select>
                      </div>

                      {/* Settings Toggles */}
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium text-gray-900 dark:text-white">Allow Late Submission</p>
                            <p className="text-sm text-gray-600 dark:text-gray-400">Students can submit after due date</p>
                          </div>
                          <button
                            onClick={() => setAssignmentSettings(prev => ({ ...prev, allowLateSubmission: !prev.allowLateSubmission }))}
                            className={`
                              relative inline-flex h-6 w-11 items-center rounded-full transition-colors
                              ${assignmentSettings.allowLateSubmission ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-700'}
                            `}
                          >
                            <span
                              className={`
                                inline-block h-4 w-4 transform rounded-full bg-white transition-transform
                                ${assignmentSettings.allowLateSubmission ? 'translate-x-6' : 'translate-x-1'}
                              `}
                            />
                          </button>
                        </div>

                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium text-gray-900 dark:text-white">Show Results Immediately</p>
                            <p className="text-sm text-gray-600 dark:text-gray-400">Display results after submission</p>
                          </div>
                          <button
                            onClick={() => setAssignmentSettings(prev => ({ ...prev, showResultsImmediately: !prev.showResultsImmediately }))}
                            className={`
                              relative inline-flex h-6 w-11 items-center rounded-full transition-colors
                              ${assignmentSettings.showResultsImmediately ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-700'}
                            `}
                          >
                            <span
                              className={`
                                inline-block h-4 w-4 transform rounded-full bg-white transition-transform
                                ${assignmentSettings.showResultsImmediately ? 'translate-x-6' : 'translate-x-1'}
                              `}
                            />
                          </button>
                        </div>

                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium text-gray-900 dark:text-white">Send Email Notification</p>
                            <p className="text-sm text-gray-600 dark:text-gray-400">Notify students via email</p>
                          </div>
                          <button
                            onClick={() => setAssignmentSettings(prev => ({ ...prev, sendEmailNotification: !prev.sendEmailNotification }))}
                            className={`
                              relative inline-flex h-6 w-11 items-center rounded-full transition-colors
                              ${assignmentSettings.sendEmailNotification ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-700'}
                            `}
                          >
                            <span
                              className={`
                                inline-block h-4 w-4 transform rounded-full bg-white transition-transform
                                ${assignmentSettings.sendEmailNotification ? 'translate-x-6' : 'translate-x-1'}
                              `}
                            />
                          </button>
                        </div>
                      </div>

                      {/* Instructions */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Instructions (Optional)
                        </label>
                        <textarea
                          value={assignmentSettings.instructions}
                          onChange={(e) => setAssignmentSettings(prev => ({ ...prev, instructions: e.target.value }))}
                          placeholder="Add any special instructions for students..."
                          rows={3}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white resize-none"
                        />
                      </div>

                      {/* Assignment Summary */}
                      <div className="p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                        <h4 className="font-medium text-blue-800 dark:text-blue-200 mb-2">Assignment Summary</h4>
                        <div className="text-sm text-blue-700 dark:text-blue-300 space-y-1">
                          <p>• {selectedStudents.length} student{selectedStudents.length !== 1 ? 's' : ''} selected</p>
                          <p>• Due: {formatDateTime(assignmentSettings.dueDate, assignmentSettings.dueTime)}</p>
                          <p>• Max attempts: {assignmentSettings.maxAttempts === -1 ? 'Unlimited' : assignmentSettings.maxAttempts}</p>
                          <p>• Late submission: {assignmentSettings.allowLateSubmission ? 'Allowed' : 'Not allowed'}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between p-6 border-t border-gray-200 dark:border-gray-700">
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  {assigning && (
                    <div className="flex items-center space-x-2">
                      <Loader className="w-4 h-4 animate-spin" />
                      <span>Assigning quiz...</span>
                    </div>
                  )}
                </div>
                
                <div className="flex items-center space-x-3">
                  <button
                    onClick={onClose}
                    className="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                    disabled={assigning}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleAssignQuiz}
                    disabled={assigning || selectedStudents.length === 0 || !assignmentSettings.dueDate}
                    className="flex items-center space-x-2 px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
                  >
                    {assigning ? (
                      <>
                        <Loader className="w-4 h-4 animate-spin" />
                        <span>Assigning...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>Assign Quiz</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}

export default QuizAssignmentModal