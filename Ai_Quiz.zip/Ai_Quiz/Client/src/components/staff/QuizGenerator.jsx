import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  X, 
  Sparkles, 
  BookOpen, 
  Brain, 
  Search,
  ChevronDown,
  ChevronRight,
  Loader,
  AlertCircle,
  Lightbulb,
  Target,
  Clock
} from 'lucide-react'

const QuizGenerator = ({ isOpen, onClose, onGenerate, syllabusData, generating }) => {
  const [generationMode, setGenerationMode] = useState('custom') // 'syllabus' or 'custom'
  const [selectedTopic, setSelectedTopic] = useState('')
  const [customTopic, setCustomTopic] = useState('')
  const [difficulty, setDifficulty] = useState('medium')
  const [questionCount, setQuestionCount] = useState(10)
  const [additionalContext, setAdditionalContext] = useState('')
  const [expandedTopics, setExpandedTopics] = useState(new Set())
  const [searchTerm, setSearchTerm] = useState('')
  const [errors, setErrors] = useState({})

  // Reset form when modal opens
  useEffect(() => {
    if (isOpen) {
      setGenerationMode(syllabusData ? 'syllabus' : 'custom')
      setSelectedTopic('')
      setCustomTopic('')
      setDifficulty('medium')
      setQuestionCount(10)
      setAdditionalContext('')
      setErrors({})
      setSearchTerm('')
    }
  }, [isOpen, syllabusData])

  const validateForm = () => {
    const newErrors = {}

    if (generationMode === 'syllabus' && !selectedTopic) {
      newErrors.topic = 'Please select a topic from the syllabus'
    }

    if (generationMode === 'custom' && !customTopic.trim()) {
      newErrors.customTopic = 'Please enter a topic'
    }

    if (questionCount < 1 || questionCount > 50) {
      newErrors.questionCount = 'Question count must be between 1 and 50'
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleGenerate = () => {
    if (!validateForm()) return

    const generationData = {
      source: generationMode,
      topic: generationMode === 'syllabus' ? selectedTopic : customTopic,
      difficulty,
      questionCount,
      context: additionalContext
    }

    onGenerate(generationData)
  }

  const toggleTopicExpansion = (topicName) => {
    const newExpanded = new Set(expandedTopics)
    if (newExpanded.has(topicName)) {
      newExpanded.delete(topicName)
    } else {
      newExpanded.add(topicName)
    }
    setExpandedTopics(newExpanded)
  }

  const filteredTopics = syllabusData?.topics?.filter(topic =>
    topic.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    topic.subtopics.some(subtopic => 
      subtopic.toLowerCase().includes(searchTerm.toLowerCase())
    )
  ) || []

  const getDifficultyColor = (level) => {
    switch (level) {
      case 'easy': return 'text-green-600 bg-green-100 dark:bg-green-900/20'
      case 'medium': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20'
      case 'hard': return 'text-red-600 bg-red-100 dark:bg-red-900/20'
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900/20'
    }
  }

  const getEstimatedTime = (count, difficulty) => {
    const baseTime = {
      easy: 1.5,
      medium: 2,
      hard: 3
    }
    return Math.round(count * baseTime[difficulty])
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 z-40"
            onClick={onClose}
          />
          
          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
          >
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
              {/* Header */}
              <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-purple-100 dark:bg-purple-900/20 rounded-lg">
                    <Sparkles className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                      AI Quiz Generator
                    </h2>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Generate intelligent quizzes using AI
                    </p>
                  </div>
                </div>
                <button
                  onClick={onClose}
                  className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                  disabled={generating}
                >
                  <X className="w-5 h-5 text-gray-600 dark:text-gray-300" />
                </button>
              </div>

              {/* Content */}
              <div className="p-6 overflow-y-auto max-h-[calc(90vh-140px)]">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Left Column - Generation Options */}
                  <div className="space-y-6">
                    {/* Generation Mode */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                        Generation Source
                      </label>
                      <div className="grid grid-cols-2 gap-3">
                        <button
                          onClick={() => setGenerationMode('syllabus')}
                          disabled={!syllabusData}
                          className={`
                            p-4 rounded-lg border-2 transition-all text-left
                            ${generationMode === 'syllabus'
                              ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20'
                              : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                            }
                            ${!syllabusData ? 'opacity-50 cursor-not-allowed' : ''}
                          `}
                        >
                          <div className="flex items-center space-x-3">
                            <BookOpen className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                            <div>
                              <p className="font-medium text-gray-900 dark:text-white">
                                From Syllabus
                              </p>
                              <p className="text-xs text-gray-600 dark:text-gray-400">
                                {syllabusData ? 'Use uploaded syllabus' : 'No syllabus uploaded'}
                              </p>
                            </div>
                          </div>
                        </button>
                        
                        <button
                          onClick={() => setGenerationMode('custom')}
                          className={`
                            p-4 rounded-lg border-2 transition-all text-left
                            ${generationMode === 'custom'
                              ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20'
                              : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                            }
                          `}
                        >
                          <div className="flex items-center space-x-3">
                            <Brain className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                            <div>
                              <p className="font-medium text-gray-900 dark:text-white">
                                Custom Topic
                              </p>
                              <p className="text-xs text-gray-600 dark:text-gray-400">
                                Enter any topic
                              </p>
                            </div>
                          </div>
                        </button>
                      </div>
                    </div>

                    {/* Topic Selection */}
                    {generationMode === 'syllabus' && syllabusData ? (
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                          Select Topic from Syllabus
                        </label>
                        
                        {/* Search */}
                        <div className="relative mb-4">
                          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                          <input
                            type="text"
                            placeholder="Search topics..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                          />
                        </div>

                        {/* Topics List */}
                        <div className="max-h-64 overflow-y-auto border border-gray-200 dark:border-gray-600 rounded-lg">
                          {filteredTopics.map((topic, index) => (
                            <div key={index} className="border-b border-gray-200 dark:border-gray-600 last:border-b-0">
                              <div
                                className="flex items-center justify-between p-3 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer"
                                onClick={() => toggleTopicExpansion(topic.name)}
                              >
                                <div className="flex items-center space-x-3">
                                  {expandedTopics.has(topic.name) ? (
                                    <ChevronDown className="w-4 h-4 text-gray-400" />
                                  ) : (
                                    <ChevronRight className="w-4 h-4 text-gray-400" />
                                  )}
                                  <div>
                                    <p className="font-medium text-gray-900 dark:text-white">
                                      {topic.name}
                                    </p>
                                    <p className="text-xs text-gray-600 dark:text-gray-400">
                                      {topic.subtopics.length} subtopics
                                    </p>
                                  </div>
                                </div>
                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(topic.difficulty)}`}>
                                  {topic.difficulty}
                                </span>
                              </div>
                              
                              {expandedTopics.has(topic.name) && (
                                <div className="px-6 pb-3">
                                  <div className="space-y-2">
                                    <button
                                      onClick={() => setSelectedTopic(topic.name)}
                                      className={`
                                        w-full text-left p-2 rounded border transition-colors
                                        ${selectedTopic === topic.name
                                          ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20 text-purple-700 dark:text-purple-300'
                                          : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                                        }
                                      `}
                                    >
                                      <span className="font-medium">Entire Topic: {topic.name}</span>
                                    </button>
                                    
                                    {topic.subtopics.map((subtopic, subIndex) => (
                                      <button
                                        key={subIndex}
                                        onClick={() => setSelectedTopic(subtopic)}
                                        className={`
                                          w-full text-left p-2 rounded border transition-colors
                                          ${selectedTopic === subtopic
                                            ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20 text-purple-700 dark:text-purple-300'
                                            : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                                          }
                                        `}
                                      >
                                        <span className="text-sm">• {subtopic}</span>
                                      </button>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                        
                        {errors.topic && (
                          <p className="mt-2 text-sm text-red-600 dark:text-red-400">
                            {errors.topic}
                          </p>
                        )}
                      </div>
                    ) : (
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Custom Topic
                        </label>
                        <input
                          type="text"
                          placeholder="e.g., Photosynthesis, World War II, Calculus..."
                          value={customTopic}
                          onChange={(e) => setCustomTopic(e.target.value)}
                          className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                        />
                        {errors.customTopic && (
                          <p className="mt-2 text-sm text-red-600 dark:text-red-400">
                            {errors.customTopic}
                          </p>
                        )}
                      </div>
                    )}

                    {/* Additional Context */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Additional Context (Optional)
                      </label>
                      <textarea
                        placeholder="Provide any specific requirements, focus areas, or context for the quiz..."
                        value={additionalContext}
                        onChange={(e) => setAdditionalContext(e.target.value)}
                        rows={3}
                        className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent dark:bg-gray-700 dark:text-white resize-none"
                      />
                    </div>
                  </div>

                  {/* Right Column - Quiz Settings */}
                  <div className="space-y-6">
                    {/* Difficulty */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                        Difficulty Level
                      </label>
                      <div className="grid grid-cols-3 gap-3">
                        {['easy', 'medium', 'hard'].map((level) => (
                          <button
                            key={level}
                            onClick={() => setDifficulty(level)}
                            className={`
                              p-3 rounded-lg border-2 transition-all text-center
                              ${difficulty === level
                                ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20'
                                : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                              }
                            `}
                          >
                            <div className={`w-3 h-3 rounded-full mx-auto mb-2 ${getDifficultyColor(level).replace('text-', 'bg-').replace('bg-', 'bg-')}`} />
                            <p className="font-medium text-gray-900 dark:text-white capitalize">
                              {level}
                            </p>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Question Count */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Number of Questions
                      </label>
                      <div className="flex items-center space-x-4">
                        <input
                          type="range"
                          min="1"
                          max="50"
                          value={questionCount}
                          onChange={(e) => setQuestionCount(parseInt(e.target.value))}
                          className="flex-1 h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer"
                        />
                        <div className="flex items-center space-x-2">
                          <input
                            type="number"
                            min="1"
                            max="50"
                            value={questionCount}
                            onChange={(e) => setQuestionCount(Math.max(1, Math.min(50, parseInt(e.target.value) || 1)))}
                            className="w-16 px-2 py-1 text-center border border-gray-300 dark:border-gray-600 rounded focus:ring-2 focus:ring-purple-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                          />
                          <span className="text-sm text-gray-600 dark:text-gray-400">questions</span>
                        </div>
                      </div>
                      {errors.questionCount && (
                        <p className="mt-2 text-sm text-red-600 dark:text-red-400">
                          {errors.questionCount}
                        </p>
                      )}
                    </div>

                    {/* Quiz Preview */}
                    <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                      <h4 className="font-medium text-gray-900 dark:text-white mb-3 flex items-center">
                        <Target className="w-4 h-4 mr-2" />
                        Quiz Preview
                      </h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Topic:</span>
                          <span className="font-medium text-gray-900 dark:text-white">
                            {generationMode === 'syllabus' ? selectedTopic || 'Not selected' : customTopic || 'Not specified'}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Difficulty:</span>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(difficulty)}`}>
                            {difficulty}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Questions:</span>
                          <span className="font-medium text-gray-900 dark:text-white">{questionCount}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Est. Time:</span>
                          <span className="font-medium text-gray-900 dark:text-white flex items-center">
                            <Clock className="w-3 h-3 mr-1" />
                            {getEstimatedTime(questionCount, difficulty)} min
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* AI Tips */}
                    <div className="p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                      <h4 className="font-medium text-blue-800 dark:text-blue-200 mb-2 flex items-center">
                        <Lightbulb className="w-4 h-4 mr-2" />
                        AI Generation Tips
                      </h4>
                      <ul className="text-sm text-blue-700 dark:text-blue-300 space-y-1">
                        <li>• Be specific with your topic for better questions</li>
                        <li>• Add context for more targeted content</li>
                        <li>• Higher difficulty creates more complex questions</li>
                        <li>• You can edit questions after generation</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between p-6 border-t border-gray-200 dark:border-gray-700">
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  {generating && (
                    <div className="flex items-center space-x-2">
                      <Loader className="w-4 h-4 animate-spin" />
                      <span>Generating quiz with AI...</span>
                    </div>
                  )}
                </div>
                
                <div className="flex items-center space-x-3">
                  <button
                    onClick={onClose}
                    className="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                    disabled={generating}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleGenerate}
                    disabled={generating || (!selectedTopic && !customTopic.trim())}
                    className="flex items-center space-x-2 px-6 py-2 bg-purple-600 hover:bg-purple-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
                  >
                    {generating ? (
                      <>
                        <Loader className="w-4 h-4 animate-spin" />
                        <span>Generating...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4" />
                        <span>Generate Quiz</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}

export default QuizGenerator