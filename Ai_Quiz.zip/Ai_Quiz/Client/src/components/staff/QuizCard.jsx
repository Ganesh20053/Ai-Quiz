import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  Edit3, 
  Trash2, 
  Copy, 
  Send, 
  Clock, 
  Users, 
  BookOpen, 
  Target,
  MoreVertical,
  Eye,
  Download,
  BarChart3,
  Calendar
} from 'lucide-react'

const QuizCard = ({ quiz, onEdit, onDelete, onDuplicate, onAssign, onPublish, onArchive }) => {
  const [showMenu, setShowMenu] = useState(false)

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300'
      case 'medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300'
      case 'hard': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300'
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300'
    }
  }

  const getSourceIcon = (source) => {
    switch (source) {
      case 'syllabus': return '📚'
      case 'custom': return '🧠'
      case 'template': return '📋'
      default: return '📝'
    }
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    })
  }

  const getStatusColor = (isActive, assignments = []) => {
    if (!isActive) return 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400'
    if (assignments.length > 0) return 'bg-blue-100 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400'
    return 'bg-green-100 text-green-600 dark:bg-green-900/20 dark:text-green-400'
  }

  const getStatusText = (isActive, assignments = []) => {
    if (!isActive) return 'Draft'
    if (assignments.length > 0) return 'Published & Assigned'
    return 'Published'
  }

  return (
    <motion.div
      whileHover={{ y: -2 }}
      className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden hover:shadow-md transition-all duration-200"
    >
      {/* Header */}
      <div className="p-6 pb-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-2">
              <span className="text-lg">{getSourceIcon(quiz.source)}</span>
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(quiz.isActive, quiz.assignments)}`}>
                {getStatusText(quiz.isActive, quiz.assignments)}
              </span>
              {quiz.isActive && (
                <span className="flex items-center space-x-1 text-green-600 dark:text-green-400">
                  <CheckCircle className="w-3 h-3" />
                  <span className="text-xs font-medium">Live</span>
                </span>
              )}
            </div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white line-clamp-2 mb-1">
              {quiz.title}
            </h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2">
              {quiz.description || `Quiz on ${quiz.topic}`}
            </p>
          </div>
          
          {/* Menu */}
          <div className="relative">
            <button
              onClick={() => setShowMenu(!showMenu)}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
            >
              <MoreVertical className="w-4 h-4 text-gray-600 dark:text-gray-300" />
            </button>
            
            {showMenu && (
              <>
                <div 
                  className="fixed inset-0 z-10" 
                  onClick={() => setShowMenu(false)}
                />
                <div className="absolute right-0 top-full mt-1 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 z-20">
                  <div className="py-1">
                    <button
                      onClick={() => {
                        onEdit()
                        setShowMenu(false)
                      }}
                      className="w-full flex items-center space-x-2 px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                    >
                      <Edit3 className="w-4 h-4" />
                      <span>Edit Quiz</span>
                    </button>
                    <button
                      onClick={() => {
                        onDuplicate()
                        setShowMenu(false)
                      }}
                      className="w-full flex items-center space-x-2 px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                    >
                      <Copy className="w-4 h-4" />
                      <span>Duplicate</span>
                    </button>
                    {!quiz.isActive && (
                      <button
                        onClick={() => {
                          onPublish()
                          setShowMenu(false)
                        }}
                        className="w-full flex items-center space-x-2 px-4 py-2 text-sm text-green-700 dark:text-green-300 hover:bg-green-50 dark:hover:bg-green-900/20"
                      >
                        <Send className="w-4 h-4" />
                        <span>Publish</span>
                      </button>
                    )}
                    {quiz.isActive && quiz.status !== 'archived' && (
                      <button
                        onClick={() => {
                          onArchive()
                          setShowMenu(false)
                        }}
                        className="w-full flex items-center space-x-2 px-4 py-2 text-sm text-orange-700 dark:text-orange-300 hover:bg-orange-50 dark:hover:bg-orange-900/20"
                      >
                        <Download className="w-4 h-4" />
                        <span>Archive</span>
                      </button>
                    )}
                    <button
                      onClick={() => {
                        // Handle preview
                        setShowMenu(false)
                      }}
                      className="w-full flex items-center space-x-2 px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                    >
                      <Eye className="w-4 h-4" />
                      <span>Preview</span>
                    </button>
                    <button
                      onClick={() => {
                        // Handle analytics
                        setShowMenu(false)
                      }}
                      className="w-full flex items-center space-x-2 px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                    >
                      <BarChart3 className="w-4 h-4" />
                      <span>Analytics</span>
                    </button>
                    <button
                      onClick={() => {
                        // Handle export
                        setShowMenu(false)
                      }}
                      className="w-full flex items-center space-x-2 px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                    >
                      <Download className="w-4 h-4" />
                      <span>Export</span>
                    </button>
                    <div className="border-t border-gray-200 dark:border-gray-600 my-1" />
                    <button
                      onClick={() => {
                        onDelete()
                        setShowMenu(false)
                      }}
                      className="w-full flex items-center space-x-2 px-4 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20"
                    >
                      <Trash2 className="w-4 h-4" />
                      <span>Delete</span>
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Topic and Difficulty */}
        <div className="flex items-center space-x-2 mb-4">
          <span className="px-2 py-1 bg-blue-100 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 rounded-full text-xs font-medium">
            {quiz.topic}
          </span>
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(quiz.difficulty)}`}>
            {quiz.difficulty}
          </span>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-4">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-1 text-gray-600 dark:text-gray-400 mb-1">
              <BookOpen className="w-4 h-4" />
            </div>
            <p className="text-lg font-semibold text-gray-900 dark:text-white">
              {quiz.totalQuestions || quiz.questions?.length || 0}
            </p>
            <p className="text-xs text-gray-600 dark:text-gray-400">Questions</p>
          </div>
          
          <div className="text-center">
            <div className="flex items-center justify-center space-x-1 text-gray-600 dark:text-gray-400 mb-1">
              <Clock className="w-4 h-4" />
            </div>
            <p className="text-lg font-semibold text-gray-900 dark:text-white">
              {quiz.timeLimit || 30}
            </p>
            <p className="text-xs text-gray-600 dark:text-gray-400">Minutes</p>
          </div>
          
          <div className="text-center">
            <div className="flex items-center justify-center space-x-1 text-gray-600 dark:text-gray-400 mb-1">
              <Users className="w-4 h-4" />
            </div>
            <p className="text-lg font-semibold text-gray-900 dark:text-white">
              {quiz.assignments?.length || 0}
            </p>
            <p className="text-xs text-gray-600 dark:text-gray-400">Assigned</p>
          </div>
        </div>

        {/* Creation Date */}
        <div className="flex items-center space-x-2 text-xs text-gray-500 dark:text-gray-400 mb-4">
          <Calendar className="w-3 h-3" />
          <span>Created {formatDate(quiz.createdAt)}</span>
          {quiz.isActive && (
            <>
              <span>•</span>
              <span className="text-green-600 dark:text-green-400 font-medium">Students can access</span>
            </>
          )}
        </div>

        {/* Performance Indicator */}
        {quiz.analytics && (
          <div className="mb-4">
            <div className="flex items-center justify-between text-xs text-gray-600 dark:text-gray-400 mb-1">
              <span>Average Score</span>
              <span>{Math.round(quiz.analytics.averageScore || 0)}%</span>
            </div>
            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
              <div 
                className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${quiz.analytics.averageScore || 0}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="px-6 py-4 bg-gray-50 dark:bg-gray-700/50 border-t border-gray-200 dark:border-gray-600">
        <div className="flex items-center justify-between">
          <button
            onClick={onEdit}
            className="flex items-center space-x-2 px-3 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-white dark:hover:bg-gray-700 rounded-lg transition-colors"
          >
            <Edit3 className="w-4 h-4" />
            <span>Edit</span>
          </button>
          
          <div className="flex items-center space-x-2">
            {!quiz.isActive && (
              <button
                onClick={onPublish}
                className="flex items-center space-x-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors text-sm font-medium"
              >
                <Send className="w-4 h-4" />
                <span>Publish</span>
              </button>
            )}
          
          <button
            onClick={onAssign}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors text-sm font-medium"
          >
            <Send className="w-4 h-4" />
            <span>Assign</span>
          </button>
          </div>
        </div>
      </div>

      {/* Assignment Status */}
      {quiz.assignments && quiz.assignments.length > 0 && (
        <div className="px-6 py-2 bg-blue-50 dark:bg-blue-900/20 border-t border-blue-200 dark:border-blue-800">
          <div className="flex items-center justify-between text-sm">
            <span className="text-blue-700 dark:text-blue-300">
              Assigned to {quiz.assignments.length} student{quiz.assignments.length !== 1 ? 's' : ''}
            </span>
            <span className="text-blue-600 dark:text-blue-400">
              {quiz.assignments.filter(a => a.status === 'completed').length} completed
            </span>
          </div>
        </div>
      )}
    </motion.div>
  )
}

export default QuizCard