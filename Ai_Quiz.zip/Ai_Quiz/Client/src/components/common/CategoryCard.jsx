import React from 'react'
import { motion } from 'framer-motion'

const CategoryCard = ({ category, onClick, isSelected = false }) => {
  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -2 }}
      whileTap={{ scale: 0.98 }}
      className={`
        relative cursor-pointer rounded-xl p-6 shadow-lg border-2 transition-all duration-300
        ${isSelected 
          ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20 dark:border-blue-400' 
          : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:border-gray-300 dark:hover:border-gray-600'
        }
      `}
      onClick={onClick}
      role="button"
      tabIndex={0}
      aria-label={`Select ${category.name} category`}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault()
          onClick()
        }
      }}
    >
      {/* Background Pattern */}
      <div className={`
        absolute inset-0 rounded-xl opacity-5
        ${category.color} 
      `} />
      
      {/* Content */}
      <div className="relative z-10">
        {/* Icon */}
        <div className={`
          inline-flex items-center justify-center w-16 h-16 rounded-lg mb-4
          ${category.color} bg-opacity-10
        `}>
          <span className="text-3xl" role="img" aria-label={category.name}>
            {category.icon}
          </span>
        </div>
        
        {/* Title */}
        <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
          {category.name}
        </h3>
        
        {/* Description */}
        <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
          {getDescription(category.id)}
        </p>
        
        {/* Stats */}
        <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
          <span>{getQuizCount(category.id)} quizzes</span>
          <span className={`
            px-2 py-1 rounded-full text-white font-medium
            ${category.color}
          `}>
            {getDifficulty(category.id)}
          </span>
        </div>
      </div>
      
      {/* Selection Indicator */}
      {isSelected && (
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="absolute top-3 right-3 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center"
        >
          <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
          </svg>
        </motion.div>
      )}
    </motion.div>
  )
}

// Helper functions to get category-specific data
const getDescription = (categoryId) => {
  const descriptions = {
    science: 'Explore physics, chemistry, biology and more',
    arts: 'Discover painting, music, literature and creativity',
    medical: 'Learn anatomy, diseases, treatments and health',
    history: 'Journey through time and historical events',
    mathematics: 'Master numbers, equations and problem solving',
    literature: 'Dive into classic and modern literary works',
    geography: 'Explore countries, capitals and world knowledge',
    technology: 'Understand computers, AI and digital innovation'
  }
  return descriptions[categoryId] || 'Learn and test your knowledge'
}

const getQuizCount = (categoryId) => {
  const counts = {
    science: 150,
    arts: 120,
    medical: 200,
    history: 180,
    mathematics: 250,
    literature: 100,
    geography: 140,
    technology: 160
  }
  return counts[categoryId] || 100
}

const getDifficulty = (categoryId) => {
  const difficulties = {
    science: 'Mixed',
    arts: 'Easy',
    medical: 'Hard',
    history: 'Medium',
    mathematics: 'Hard',
    literature: 'Medium',
    geography: 'Easy',
    technology: 'Mixed'
  }
  return difficulties[categoryId] || 'Mixed'
}

export default CategoryCard