import { useEffect, useState } from 'react';

const VoiceButton = ({ onCommand }) => {
  const [listening, setListening] = useState(false);

  useEffect(() => {
    if (!('webkitSpeechRecognition' in window)) {
      alert('Voice recognition not supported');
      return;
    }

    const recognition = new webkitSpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onresult = (event) => {
      const command = event.results[0][0].transcript.trim().toLowerCase();
      if (onCommand) onCommand(command);
    };

    if (listening) {
      recognition.start();
    } else {
      recognition.stop();
    }

    return () => recognition.stop();
  }, [listening]);

  return (
    <button
      className={`px-4 py-2 rounded-full ${
        listening ? 'bg-red-500' : 'bg-green-500'
      } text-white font-bold shadow`}
      onClick={() => setListening(!listening)}
    >
      {listening ? '🎙️ Stop' : '🎤 Start Voice'}
    </button>
  );
};

export default VoiceButton;
