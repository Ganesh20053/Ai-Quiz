import React from 'react';
import { AlertTriangle, RefreshCw, Home } from 'lucide-react';
import { useTheme } from '../../contexts/ThemeContext';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    this.setState({
      error: error,
      errorInfo: errorInfo
    });
    
    // Log error to console for debugging
    console.error('Error Boundary caught an error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return <ErrorFallback 
        error={this.state.error} 
        errorInfo={this.state.errorInfo}
        resetError={() => this.setState({ hasError: false, error: null, errorInfo: null })}
      />;
    }

    return this.props.children;
  }
}

const ErrorFallback = ({ error, errorInfo, resetError }) => {
  const theme = useTheme();

  const handleReload = () => {
    window.location.reload();
  };

  const handleGoHome = () => {
    window.location.href = '/staff/dashboard';
  };

  return (
    <div className={`min-h-screen ${theme.colors.bg.secondary} flex items-center justify-center p-4`}>
      <div className={`max-w-md w-full ${theme.colors.bg.card} rounded-2xl ${theme.shadows.xl} ${theme.colors.border.primary} border p-8 text-center`}>
        <div className={`w-16 h-16 mx-auto mb-6 ${theme.colors.bg.tertiary} rounded-full flex items-center justify-center`}>
          <AlertTriangle className={`w-8 h-8 text-red-600`} />
        </div>
        
        <h2 className={`text-xl font-bold ${theme.colors.text.primary} mb-4`}>
          Oops! Something went wrong
        </h2>
        
        <p className={`${theme.colors.text.secondary} mb-6`}>
          We encountered an unexpected error. This has been logged and we'll look into it.
        </p>

        {process.env.NODE_ENV === 'development' && error && (
          <details className={`mb-6 text-left p-4 ${theme.colors.bg.tertiary} rounded-lg`}>
            <summary className={`cursor-pointer font-medium ${theme.colors.text.primary} mb-2`}>
              Error Details (Development)
            </summary>
            <div className={`text-xs ${theme.colors.text.secondary} font-mono`}>
              <p className="mb-2"><strong>Error:</strong> {error.toString()}</p>
              {errorInfo && (
                <pre className="whitespace-pre-wrap overflow-auto max-h-32">
                  {errorInfo.componentStack}
                </pre>
              )}
            </div>
          </details>
        )}
        
        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={resetError}
            className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 ${theme.colors.button.secondary} rounded-lg font-medium transition-all transform hover:scale-105`}
          >
            <RefreshCw className="w-4 h-4" />
            Try Again
          </button>
          
          <button
            onClick={handleReload}
            className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 ${theme.colors.button.primary} rounded-lg font-medium transition-all transform hover:scale-105`}
          >
            <RefreshCw className="w-4 h-4" />
            Reload Page
          </button>
          
          <button
            onClick={handleGoHome}
            className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 ${theme.colors.button.secondary} rounded-lg font-medium transition-all transform hover:scale-105`}
          >
            <Home className="w-4 h-4" />
            Go Home
          </button>
        </div>
      </div>
    </div>
  );
};

export default ErrorBoundary;
