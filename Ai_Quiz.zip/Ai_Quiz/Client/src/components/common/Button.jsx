import React from 'react'

const Button = ({ 
  children, 
  label, 
  onClick, 
  type = "button", 
  className = "", 
  disabled = false,
  ...props 
}) => (
  <button
    type={type}
    onClick={onClick}
    disabled={disabled}
    className={`bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded shadow disabled:opacity-50 disabled:cursor-not-allowed ${className}`}
    {...props}
  >
    {children || label}
  </button>
);

export default Button;
