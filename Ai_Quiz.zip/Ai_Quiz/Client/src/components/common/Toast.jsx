import React, { useState, useEffect } from 'react';
import { CheckCircle, XCircle, AlertCircle, Info, X, Copy, Eye, EyeOff } from 'lucide-react';
import { useTheme } from '../../contexts/ThemeContext';

const Toast = ({ 
  type = 'info', 
  title, 
  message, 
  password, 
  email,
  duration = 8000, 
  onClose,
  showCopyButton = false 
}) => {
  const theme = useTheme();
  const [isVisible, setIsVisible] = useState(true);
  const [showPassword, setShowPassword] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(onClose, 300); // Wait for animation to complete
    }, duration);

    return () => clearTimeout(timer);
  }, [duration, onClose]);

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    // Could add a mini toast here for copy confirmation
  };

  const getIcon = () => {
    switch (type) {
      case 'success':
        return <CheckCircle className="w-6 h-6 text-green-600" />;
      case 'error':
        return <XCircle className="w-6 h-6 text-red-600" />;
      case 'warning':
        return <AlertCircle className="w-6 h-6 text-yellow-600" />;
      default:
        return <Info className="w-6 h-6 text-blue-600" />;
    }
  };

  const getBackgroundColor = () => {
    switch (type) {
      case 'success':
        return theme.isDarkMode ? 'bg-green-900/20 border-green-800' : 'bg-green-50 border-green-200';
      case 'error':
        return theme.isDarkMode ? 'bg-red-900/20 border-red-800' : 'bg-red-50 border-red-200';
      case 'warning':
        return theme.isDarkMode ? 'bg-yellow-900/20 border-yellow-800' : 'bg-yellow-50 border-yellow-200';
      default:
        return theme.isDarkMode ? 'bg-blue-900/20 border-blue-800' : 'bg-blue-50 border-blue-200';
    }
  };

  return (
    <div
      className={`
        fixed top-4 right-4 z-50 max-w-md w-full
        ${theme.colors.bg.card} ${getBackgroundColor()} border rounded-xl ${theme.shadows.xl}
        transform transition-all duration-300 ease-in-out
        ${isVisible ? 'translate-x-0 opacity-100' : 'translate-x-full opacity-0'}
      `}
    >
      <div className="p-4">
        <div className="flex items-start gap-3">
          <div className="flex-shrink-0">
            {getIcon()}
          </div>
          
          <div className="flex-1 min-w-0">
            <h4 className={`text-sm font-semibold ${theme.colors.text.primary} mb-1`}>
              {title}
            </h4>
            <p className={`text-sm ${theme.colors.text.secondary} mb-3`}>
              {message}
            </p>
            
            {email && (
              <div className={`p-3 ${theme.colors.bg.tertiary} rounded-lg mb-3`}>
                <div className="flex items-center justify-between mb-2">
                  <span className={`text-xs font-medium ${theme.colors.text.secondary}`}>
                    Email sent to:
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-sm font-mono ${theme.colors.text.primary}`}>
                    {email}
                  </span>
                  <button
                    onClick={() => copyToClipboard(email)}
                    className={`p-1 rounded ${theme.colors.hover.card} transition-all`}
                    title="Copy email"
                  >
                    <Copy className="w-3 h-3" />
                  </button>
                </div>
              </div>
            )}
            
            {password && (
              <div className={`p-3 ${theme.colors.bg.tertiary} rounded-lg`}>
                <div className="flex items-center justify-between mb-2">
                  <span className={`text-xs font-medium ${theme.colors.text.secondary}`}>
                    Temporary Password:
                  </span>
                  <button
                    onClick={() => setShowPassword(!showPassword)}
                    className={`p-1 rounded ${theme.colors.hover.card} transition-all`}
                    title={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                  </button>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-sm font-mono ${theme.colors.text.primary} ${
                    showPassword ? '' : 'filter blur-sm select-none'
                  }`}>
                    {password}
                  </span>
                  {showPassword && (
                    <button
                      onClick={() => copyToClipboard(password)}
                      className={`p-1 rounded ${theme.colors.hover.card} transition-all`}
                      title="Copy password"
                    >
                      <Copy className="w-3 h-3" />
                    </button>
                  )}
                </div>
                <p className={`text-xs ${theme.colors.text.tertiary} mt-1`}>
                  Student should change this password after first login
                </p>
              </div>
            )}
          </div>
          
          <button
            onClick={() => {
              setIsVisible(false);
              setTimeout(onClose, 300);
            }}
            className={`flex-shrink-0 p-1 rounded ${theme.colors.hover.card} transition-all`}
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Toast;
