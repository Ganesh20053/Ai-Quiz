const WelcomeMessage = () => {
  return (
    <div className="text-2xl font-semibold text-center my-4 text-green-700">
      👋 Welcome to the AI Quiz App!
    </div>
  );
};

export default WelcomeMessage;
