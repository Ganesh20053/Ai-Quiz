import React, { useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { initializeAuth } from '../features/auth/authSlice';
import {
  selectIsAuthenticated,
  selectUser,
  selectRedirectTo
} from '../features/auth/authSlice';
import ErrorBoundary from '../components/common/ErrorBoundary';

// Auth Components
import Login from '../features/auth/Login';
import Signup from '../features/auth/Signup';
import ForgotPassword from '../features/auth/ForgotPassword';
import ResetPassword from '../features/auth/ResetPassword';

// Dashboard Pages
import AdminDashboard from '../pages/AdminDashboard';
import StaffDashboard from '../pages/StaffDashboard';
import StudentHome from '../features/student/Home';

// Student Pages
import StudentProfile from '../features/student/Profile';
import StudentRewards from '../features/student/Rewards';
import StudentStreaks from '../features/student/Streaks';
import StudentAssignments from '../features/student/StudentAssignments';
import TakeQuizPage from '../pages/TakeQuizPage';
import QuizResultsPage from '../pages/QuizResultsPage';

// Classroom Management Pages
import AllClassroomsPage from '../pages/AllClassroomsPage';
import StaffAssignmentsPage from '../pages/StaffAssignmentsPage';
import ClassroomDetailPage from '../pages/ClassroomDetailPage';
import ClassroomQuizzesPage from '../pages/ClassroomQuizzesPage';
import ClassroomStudentsPage from '../pages/ClassroomStudentsPage';
import QuizEditPage from '../pages/QuizEditPage';
import QuizCreatePage from '../pages/staff/QuizCreatePage';
import QuizCreateAI from '../pages/staff/QuizCreateAI';
import QuizCreateSyllabus from '../pages/staff/QuizCreateSyllabus';
import QuizCreateManual from '../pages/staff/QuizCreateManual';

// Public Pages
import NotFound from '../pages/NotFound';

// Protected Route Component
const ProtectedRoute = ({ children, allowedRoles = [] }) => {
  const isAuthenticated = useSelector(selectIsAuthenticated);
  const user = useSelector(selectUser);

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles.length > 0 && !allowedRoles.includes(user?.role)) {
    // Redirect to appropriate dashboard based on user role
    switch (user?.role) {
      case 'admin':
        return <Navigate to="/admin/dashboard" replace />;
      case 'staff':
        return <Navigate to="/staff/dashboard" replace />;
      case 'student':
        // Special redirect for disabled students
        return <Navigate to={user?.isDisabled ? "/student/assignments" : "/student/dashboard"} replace />;
      default:
        return <Navigate to="/student/dashboard" replace />;
    }
  }

  return children;
};

// Role-based Redirect for Authenticated Users
const RoleBasedRoute = ({ children }) => {
  const redirectTo = useSelector(selectRedirectTo);
  const user = useSelector(selectUser);

  if (redirectTo) {
    return <Navigate to={redirectTo} replace />;
  }

  // Special handling for disabled students - always redirect to assignments
  if (user?.role === 'student' && user?.isDisabled) {
    return <Navigate to="/student/assignments" replace />;
  }

  return children;
};

const AppRouter = () => {
  const dispatch = useDispatch();
  const isAuthenticated = useSelector(selectIsAuthenticated);
  const user = useSelector(selectUser);

  useEffect(() => {
    dispatch(initializeAuth());
  }, [dispatch]);

  return (
    <Routes>
        {/* Public Auth Routes */}
        <Route path="/login" element={
          isAuthenticated ? (
            <RoleBasedRoute>
              {/* Special redirect for disabled students */}
              {user?.role === 'student' && user?.isDisabled ? (
                <Navigate to="/student/assignments" replace />
              ) : (
                <Navigate to={`/${user?.role || 'student'}/dashboard`} replace />
              )}
            </RoleBasedRoute>
          ) : (
            <Login />
          )
        } />

        <Route path="/signup" element={
          isAuthenticated ? (
            <RoleBasedRoute>
              <Navigate to={`/${user?.role || 'student'}/dashboard`} replace />
            </RoleBasedRoute>
          ) : (
            <Signup />
          )
        } />

        <Route path="/forgot-password" element={
          isAuthenticated ? (
            <Navigate to={`/${user?.role || 'student'}/dashboard`} replace />
          ) : (
            <ForgotPassword />
          )
        } />

        <Route path="/reset-password" element={
          isAuthenticated ? (
            <Navigate to={`/${user?.role || 'student'}/dashboard`} replace />
          ) : (
            <ResetPassword />
          )
        } />

        {/* Protected Routes */}
        <Route path="/admin/dashboard" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <AdminDashboard />
          </ProtectedRoute>
        } />

        <Route path="/staff/dashboard" element={
          <ProtectedRoute allowedRoles={['staff']}>
            <StaffDashboard />
          </ProtectedRoute>
        } />

        {/* Staff Classroom Management Routes */}
        <Route path="/staff/classrooms" element={
          <ProtectedRoute allowedRoles={['staff']}>
            <AllClassroomsPage />
          </ProtectedRoute>
        } />

        <Route path="/staff/assignments" element={
          <ProtectedRoute allowedRoles={['staff']}>
            <StaffAssignmentsPage />
          </ProtectedRoute>
        } />

        <Route path="/staff/classrooms/:classroomId" element={
          <ProtectedRoute allowedRoles={['staff']}>
            <ClassroomDetailPage />
          </ProtectedRoute>
        } />

        <Route path="/staff/classrooms/:classroomId/quizzes" element={
          <ProtectedRoute allowedRoles={['staff']}>
            <ClassroomQuizzesPage />
          </ProtectedRoute>
        } />

        <Route path="/staff/classrooms/:classroomId/students" element={
          <ProtectedRoute allowedRoles={['staff']}>
            <ErrorBoundary>
              <ClassroomStudentsPage />
            </ErrorBoundary>
          </ProtectedRoute>
        } />

        <Route path="/staff/classrooms/:classroomId/quizzes/new" element={<QuizCreatePage />} />
        <Route path="/staff/classrooms/:classroomId/quizzes/new/ai" element={<QuizCreateAI />} />
        <Route path="/staff/classrooms/:classroomId/quizzes/new/syllabus" element={<QuizCreateSyllabus />} />
        <Route path="/staff/classrooms/:classroomId/quizzes/new/manual" element={<QuizCreateManual />} />

        {/* Quiz Management Routes */}
        <Route path="/staff/classrooms/:classroomId/quizzes/:quizId/edit" element={
          <ProtectedRoute allowedRoles={['staff']}>
            <QuizEditPage />
          </ProtectedRoute>
        } />

        {/* General Classroom Routes (accessible by staff and students) */}
        <Route path="/classroom/:classroomId" element={
          <ProtectedRoute allowedRoles={['staff', 'student']}>
            <ClassroomDetailPage />
          </ProtectedRoute>
        } />

        {/* Student Routes */}
        <Route path="/student/dashboard" element={
          <ProtectedRoute allowedRoles={['student']}>
            <StudentHome />
          </ProtectedRoute>
        } />

        <Route path="/student/profile" element={
          <ProtectedRoute allowedRoles={['student']}>
            <StudentProfile />
          </ProtectedRoute>
        } />

        <Route path="/student/rewards" element={
          <ProtectedRoute allowedRoles={['student']}>
            <StudentRewards />
          </ProtectedRoute>
        } />

        <Route path="/student/streaks" element={
          <ProtectedRoute allowedRoles={['student']}>
            <StudentStreaks />
          </ProtectedRoute>
        } />

        <Route path="/student/assignments" element={
          <ProtectedRoute allowedRoles={['student']}>
            <StudentAssignments />
          </ProtectedRoute>
        } />

        <Route path="/student/quiz/:assignmentId" element={
          <ProtectedRoute allowedRoles={['student']}>
            <TakeQuizPage />
          </ProtectedRoute>
        } />

        <Route path="/student/quiz/:assignmentId/results" element={
          <ProtectedRoute allowedRoles={['student']}>
            <QuizResultsPage />
          </ProtectedRoute>
        } />

        {/* Fallback 404 */}
        <Route path="*" element={<NotFound />} />
      </Routes>
  );
};

export default AppRouter;
