// src/main.jsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';
import { BrowserRouter } from 'react-router-dom';

// Initialize cleanup service for temporary data management
import './services/cleanupService';

// Add future flags to suppress React Router v7 warnings
const router = {
  future: {
    v7_startTransition: true,
    v7_relativeSplatPath: true
  }
};

ReactDOM.createRoot(document.getElementById('root')).render(
  <BrowserRouter {...router}>
    <App />
  </BrowserRouter>
);
