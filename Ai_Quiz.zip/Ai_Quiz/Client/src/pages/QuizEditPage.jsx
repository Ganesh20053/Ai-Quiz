import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Button from '../components/common/Button';
import Loader from '../components/common/Loader';

const QuizEditPage = () => {
  const { quizId, classroomId } = useParams();
  const navigate = useNavigate();
  const [quiz, setQuiz] = useState(null);
  const [classroom, setClassroom] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  // Form state
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    subject: '',
    grade: '',
    timeLimit: 30,
    passingScore: 70,
    isActive: true,
    questions: []
  });

  useEffect(() => {
    if (quizId && classroomId) {
      fetchQuizAndClassroom();
    }
  }, [quizId, classroomId]);

  const fetchQuizAndClassroom = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      
      // Fetch classroom details
      const classroomResponse = await fetch(`/api/classroom/${classroomId}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!classroomResponse.ok) {
        throw new Error(`HTTP error! status: ${classroomResponse.status}`);
      }

      const classroomData = await classroomResponse.json();
      setClassroom(classroomData.data);
      
      // Fetch quiz details
      const quizResponse = await fetch(`/api/quizzes/${quizId}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!quizResponse.ok) {
        throw new Error(`HTTP error! status: ${quizResponse.status}`);
      }

      const quizData = await quizResponse.json();
      const quiz = quizData.data;
      
      setQuiz(quiz);
      setFormData({
        title: quiz.title || '',
        description: quiz.description || '',
        subject: quiz.subject || classroomData.data.subject || '',
        grade: quiz.grade || classroomData.data.grade || '',
        timeLimit: quiz.settings?.timeLimit || 30,
        passingScore: quiz.settings?.passingScore || 70,
        isActive: quiz.isActive !== false,
        questions: quiz.questions || []
      });

    } catch (err) {
      setError(err.message);
      console.error('Error fetching quiz and classroom:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleQuestionChange = (questionIndex, field, value) => {
    setFormData(prev => ({
      ...prev,
      questions: prev.questions.map((q, index) => 
        index === questionIndex 
          ? { ...q, [field]: value }
          : q
      )
    }));
  };

  const handleOptionChange = (questionIndex, optionIndex, field, value) => {
    setFormData(prev => ({
      ...prev,
      questions: prev.questions.map((q, qIndex) => 
        qIndex === questionIndex 
          ? {
              ...q,
              options: q.options.map((opt, oIndex) => 
                oIndex === optionIndex 
                  ? { ...opt, [field]: value }
                  : opt
              )
            }
          : q
      )
    }));
  };

  const addQuestion = () => {
    const newQuestion = {
      question: '',
      type: 'multiple-choice',
      options: [
        { text: '', isCorrect: true },
        { text: '', isCorrect: false },
        { text: '', isCorrect: false },
        { text: '', isCorrect: false }
      ],
      correctAnswer: '',
      explanation: '',
      points: 1
    };

    setFormData(prev => ({
      ...prev,
      questions: [...prev.questions, newQuestion]
    }));
  };

  const removeQuestion = (questionIndex) => {
    setFormData(prev => ({
      ...prev,
      questions: prev.questions.filter((_, index) => index !== questionIndex)
    }));
  };

  const addOption = (questionIndex) => {
    setFormData(prev => ({
      ...prev,
      questions: prev.questions.map((q, index) => 
        index === questionIndex 
          ? {
              ...q,
              options: [...q.options, { text: '', isCorrect: false }]
            }
          : q
      )
    }));
  };

  const removeOption = (questionIndex, optionIndex) => {
    setFormData(prev => ({
      ...prev,
      questions: prev.questions.map((q, qIndex) => 
        qIndex === questionIndex 
          ? {
              ...q,
              options: q.options.filter((_, oIndex) => oIndex !== optionIndex)
            }
          : q
      )
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      setSaving(true);
      const token = localStorage.getItem('token');

      // Validate required fields
      if (!formData.title.trim()) {
        alert('Quiz title is required!');
        return;
      }

      if (formData.questions.length === 0) {
        alert('At least one question is required!');
        return;
      }

      // Validate questions
      for (let i = 0; i < formData.questions.length; i++) {
        const question = formData.questions[i];
        if (!question.question.trim()) {
          alert(`Question ${i + 1} text is required!`);
          return;
        }

        if (question.type === 'multiple-choice') {
          if (!question.options || question.options.length < 2) {
            alert(`Question ${i + 1} must have at least 2 options!`);
            return;
          }
          
          const hasCorrectAnswer = question.options.some(opt => opt.isCorrect);
          if (!hasCorrectAnswer) {
            alert(`Question ${i + 1} must have one correct answer!`);
            return;
          }
        } else if (question.type === 'true-false' || question.type === 'short-answer') {
          if (!question.correctAnswer.trim()) {
            alert(`Question ${i + 1} must have a correct answer!`);
            return;
          }
        }
      }

      const updateData = {
        title: formData.title.trim(),
        description: formData.description.trim(),
        subject: formData.subject.trim(),
        grade: formData.grade.trim(),
        questions: formData.questions,
        settings: {
          timeLimit: parseInt(formData.timeLimit) || 30,
          passingScore: parseInt(formData.passingScore) || 70
        },
        isActive: formData.isActive,
        classroom: classroomId // Ensure classroom association
      };

      console.log('Updating quiz with data:', updateData);

      const response = await fetch(`/api/quizzes/${quizId}`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(updateData)
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      console.log('Quiz update response:', result);

      alert('Quiz updated successfully!');
      navigate(`/staff/classrooms/${classroomId}/quizzes`);

    } catch (err) {
      console.error('Error updating quiz:', err);
      alert(`Failed to update quiz: ${err.message}`);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex justify-center items-center">
        <Loader size="lg" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex justify-center items-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Error</h2>
          <p className="text-gray-600 mb-4">{error}</p>
          <Button
            onClick={() => navigate('/staff/classrooms')}
            className="bg-indigo-600 text-white hover:bg-indigo-700"
          >
            Back to Classrooms
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div>
              <div className="flex items-center space-x-3">
                <Button
                  onClick={() => navigate(`/staff/classrooms/${classroomId}/quizzes`)}
                  className="bg-gray-100 text-gray-700 hover:bg-gray-200"
                >
                  ← Back to Quizzes
                </Button>
                <div>
                  <h1 className="text-3xl font-bold text-gray-900">
                    Edit Quiz: {quiz?.title || 'Loading...'}
                  </h1>
                  <p className="mt-1 text-sm text-gray-500">
                    {classroom?.name ? `Classroom: ${classroom.name}` : 'Loading classroom...'} - Update quiz details and questions
                  </p>
                </div>
              </div>
            </div>
            <div className="flex space-x-3">
              <Button
                onClick={handleSubmit}
                disabled={saving}
                className="bg-green-600 text-white hover:bg-green-700 disabled:opacity-50"
              >
                {saving ? 'Saving...' : 'Save Changes'}
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Basic Quiz Information */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Quiz Information</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Quiz Title *
                </label>
                <input
                  type="text"
                  name="title"
                  value={formData.title}
                  onChange={handleInputChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Subject
                </label>
                <input
                  type="text"
                  name="subject"
                  value={formData.subject}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Grade Level
                </label>
                <input
                  type="text"
                  name="grade"
                  value={formData.grade}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Time Limit (minutes)
                </label>
                <input
                  type="number"
                  name="timeLimit"
                  value={formData.timeLimit}
                  onChange={handleInputChange}
                  min="1"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Passing Score (%)
                </label>
                <input
                  type="number"
                  name="passingScore"
                  value={formData.passingScore}
                  onChange={handleInputChange}
                  min="0"
                  max="100"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="flex items-center">
                <input
                  type="checkbox"
                  name="isActive"
                  checked={formData.isActive}
                  onChange={handleInputChange}
                  className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                />
                <label className="ml-2 block text-sm text-gray-900">
                  Active Quiz
                </label>
              </div>
            </div>

            <div className="mt-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description
              </label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                rows="3"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Questions */}
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-semibold text-gray-900">
                Questions ({formData.questions.length})
              </h2>
              <Button
                type="button"
                onClick={addQuestion}
                className="bg-indigo-600 text-white hover:bg-indigo-700"
              >
                + Add Question
              </Button>
            </div>

            {formData.questions.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500">No questions added yet.</p>
                <Button
                  type="button"
                  onClick={addQuestion}
                  className="mt-2 bg-indigo-600 text-white hover:bg-indigo-700"
                >
                  Add First Question
                </Button>
              </div>
            ) : (
              <div className="space-y-6">
                {formData.questions.map((question, questionIndex) => (
                  <div key={questionIndex} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex justify-between items-start mb-4">
                      <h3 className="text-lg font-medium text-gray-900">
                        Question {questionIndex + 1}
                      </h3>
                      <Button
                        type="button"
                        onClick={() => removeQuestion(questionIndex)}
                        className="text-red-600 hover:text-red-800"
                      >
                        Remove
                      </Button>
                    </div>

                    <div className="space-y-4">
                      {/* Question Text */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Question Text *
                        </label>
                        <textarea
                          value={question.question}
                          onChange={(e) => handleQuestionChange(questionIndex, 'question', e.target.value)}
                          required
                          rows="2"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>

                      {/* Question Type */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Question Type
                        </label>
                        <select
                          value={question.type}
                          onChange={(e) => handleQuestionChange(questionIndex, 'type', e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        >
                          <option value="multiple-choice">Multiple Choice</option>
                          <option value="true-false">True/False</option>
                          <option value="short-answer">Short Answer</option>
                        </select>
                      </div>

                      {/* Options for Multiple Choice */}
                      {question.type === 'multiple-choice' && (
                        <div>
                          <div className="flex justify-between items-center mb-2">
                            <label className="block text-sm font-medium text-gray-700">
                              Options *
                            </label>
                            <Button
                              type="button"
                              onClick={() => addOption(questionIndex)}
                              className="text-sm bg-gray-100 text-gray-700 hover:bg-gray-200"
                            >
                              + Add Option
                            </Button>
                          </div>
                          <div className="space-y-2">
                            {question.options.map((option, optionIndex) => (
                              <div key={optionIndex} className="flex items-center space-x-2">
                                <input
                                  type="radio"
                                  name={`correct-${questionIndex}`}
                                  checked={option.isCorrect}
                                  onChange={() => {
                                    // Set all options to false, then set this one to true
                                    setFormData(prev => ({
                                      ...prev,
                                      questions: prev.questions.map((q, qIndex) => 
                                        qIndex === questionIndex 
                                          ? {
                                              ...q,
                                              options: q.options.map((opt, oIndex) => ({
                                                ...opt,
                                                isCorrect: oIndex === optionIndex
                                              }))
                                            }
                                          : q
                                      )
                                    }));
                                  }}
                                  className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300"
                                />
                                <input
                                  type="text"
                                  value={option.text}
                                  onChange={(e) => handleOptionChange(questionIndex, optionIndex, 'text', e.target.value)}
                                  placeholder={`Option ${optionIndex + 1}`}
                                  className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                />
                                {question.options.length > 2 && (
                                  <Button
                                    type="button"
                                    onClick={() => removeOption(questionIndex, optionIndex)}
                                    className="text-red-600 hover:text-red-800"
                                  >
                                    ×
                                  </Button>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Correct Answer for True/False and Short Answer */}
                      {(question.type === 'true-false' || question.type === 'short-answer') && (
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Correct Answer *
                          </label>
                          {question.type === 'true-false' ? (
                            <select
                              value={question.correctAnswer}
                              onChange={(e) => handleQuestionChange(questionIndex, 'correctAnswer', e.target.value)}
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            >
                              <option value="">Select answer</option>
                              <option value="True">True</option>
                              <option value="False">False</option>
                            </select>
                          ) : (
                            <input
                              type="text"
                              value={question.correctAnswer}
                              onChange={(e) => handleQuestionChange(questionIndex, 'correctAnswer', e.target.value)}
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            />
                          )}
                        </div>
                      )}

                      {/* Explanation */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Explanation
                        </label>
                        <textarea
                          value={question.explanation}
                          onChange={(e) => handleQuestionChange(questionIndex, 'explanation', e.target.value)}
                          rows="2"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>

                      {/* Points */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Points
                        </label>
                        <input
                          type="number"
                          value={question.points}
                          onChange={(e) => handleQuestionChange(questionIndex, 'points', parseInt(e.target.value) || 1)}
                          min="1"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Save Button */}
          <div className="flex justify-end space-x-3">
            <Button
              type="button"
              onClick={() => navigate(`/staff/classrooms/${classroomId}/quizzes`)}
              className="bg-gray-100 text-gray-700 hover:bg-gray-200"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={saving}
              className="bg-green-600 text-white hover:bg-green-700 disabled:opacity-50"
            >
              {saving ? 'Saving...' : 'Save Quiz'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default QuizEditPage; 