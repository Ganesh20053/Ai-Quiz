import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTheme } from '../contexts/ThemeContext';
import Button from '../components/common/Button';
import Loader from '../components/common/Loader';
import ThemeToggle from '../components/common/ThemeToggle';
import EditAssignmentModal from '../components/assignment/EditAssignmentModal';
import {
  ArrowLeft, Award, BookOpen, Users, Calendar, Clock,
  TrendingUp, CheckCircle, XCircle, Eye, Edit3, Trash2,
  BarChart3, Target, Activity, RefreshCw
} from 'lucide-react';

const StaffAssignmentsPage = () => {
  const navigate = useNavigate();
  const theme = useTheme();
  
  const [assignments, setAssignments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedAssignment, setSelectedAssignment] = useState(null);
  const [language, setLanguage] = useState('english');

  useEffect(() => {
    fetchAssignments();
  }, []);

  const fetchAssignments = async () => {
    setLoading(true);
    setError(null);
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/classroom/assignments/with-stats', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        setAssignments(data.assignments || []);
      } else {
        const errorData = await response.json();
        setError(errorData.message || 'Failed to fetch assignments');
      }
    } catch (err) {
      console.error('Error fetching assignments:', err);
      setError('Failed to fetch assignments. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAssignment = async (assignmentId) => {
    if (!window.confirm('Are you sure you want to delete this assignment? This action cannot be undone.')) {
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/classroom/assignments/${assignmentId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        alert('Assignment deleted successfully!');
        fetchAssignments();
      } else {
        const errorData = await response.json();
        alert(`Failed to delete assignment: ${errorData.message || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error deleting assignment:', error);
      alert('Failed to delete assignment. Please try again.');
    }
  };

  const handleEditAssignment = (assignment) => {
    setSelectedAssignment(assignment);
    setShowEditModal(true);
  };

  const handleAssignmentSave = () => {
    setShowEditModal(false);
    setSelectedAssignment(null);
    fetchAssignments();
    alert('Assignment updated successfully!');
  };

  const getCompletionPercentage = (completed, total) => {
    if (total === 0) return 0;
    return Math.round((completed / total) * 100);
  };

  const getStatusColor = (percentage) => {
    if (percentage >= 80) return 'text-green-600 bg-green-100';
    if (percentage >= 60) return 'text-yellow-600 bg-yellow-100';
    if (percentage >= 40) return 'text-orange-600 bg-orange-100';
    return 'text-red-600 bg-red-100';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex justify-center items-center">
        <Loader size="lg" />
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${theme.colors.bg.secondary} transition-colors duration-300`}>
      {/* Header */}
      <div className={`${theme.colors.bg.primary} ${theme.shadows.md} ${theme.colors.border.primary} border-b backdrop-blur-lg bg-opacity-95 sticky top-0 z-50`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row lg:justify-between lg:items-center py-6 space-y-4 lg:space-y-0">
            <div className="flex-1">
              <div className="flex items-center gap-4 mb-2">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl flex items-center justify-center shadow-lg">
                    <Award className="w-6 h-6 text-white" />
                  </div>
                  <h1 className={`text-3xl font-bold ${theme.colors.text.primary}`}>
                    {language === 'tamil' ? 'வினாடி வினா ஒதுக்கீடுகள்' : 'Quiz Assignments'}
                  </h1>
                </div>
              </div>
              <p className={`text-sm ${theme.colors.text.secondary}`}>
                {language === 'tamil'
                  ? 'உங்கள் வினாடி வினா ஒதுக்கீடுகள் மற்றும் மாணவர் முன்னேற்றத்தை நிர்வகிக்கவும்'
                  : 'Manage your quiz assignments and track student progress'
                }
              </p>
            </div>

            <div className="flex items-center space-x-4">
              <ThemeToggle size="sm" />
              
              <Button
                onClick={fetchAssignments}
                className="bg-indigo-600 text-white flex items-center gap-2 px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors"
              >
                <RefreshCw className="w-4 h-4" />
                {language === 'tamil' ? 'புதுப்பிக்கவும்' : 'Refresh'}
              </Button>

              <Button
                onClick={() => navigate('/staff/classrooms')}
                className={`${theme.colors.button.secondary} flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all transform hover:scale-105`}
              >
                <ArrowLeft className="w-4 h-4" />
                {language === 'tamil' ? 'வகுப்பறைகளுக்கு திரும்பு' : 'Back to Classrooms'}
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {error ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <XCircle className="w-8 h-8 text-red-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Error Loading Assignments</h3>
            <p className="text-gray-600 mb-6">{error}</p>
            <Button
              onClick={fetchAssignments}
              className="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition-colors"
            >
              Try Again
            </Button>
          </div>
        ) : assignments.length === 0 ? (
          <div className={`text-center py-12 ${theme.colors.bg.primary} rounded-2xl border ${theme.colors.border.light}`}>
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Award className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className={`text-xl font-semibold ${theme.colors.text.primary} mb-2`}>
              {language === 'tamil' ? 'ஒதுக்கீடுகள் இல்லை' : 'No Assignments Yet'}
            </h3>
            <p className={`${theme.colors.text.secondary} mb-6`}>
              {language === 'tamil'
                ? 'உங்கள் வகுப்பறைகளில் வினாடி வினாக்களை ஒதுக்க ஆரம்பிக்கவும்'
                : 'Start by assigning quizzes to your classrooms to see them here.'
              }
            </p>
            <Button
              onClick={() => navigate('/staff/classrooms')}
              className="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition-colors"
            >
              {language === 'tamil' ? 'வகுப்பறைகளுக்கு செல்லவும்' : 'Go to Classrooms'}
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {assignments.map((assignment) => {
              const completionPercentage = getCompletionPercentage(
                assignment.completedCount || 0,
                assignment.totalStudents || 0
              );
              
              return (
                <div
                  key={assignment._id}
                  className={`${theme.colors.bg.primary} rounded-2xl shadow-lg border ${theme.colors.border.light} overflow-hidden hover:shadow-xl transition-all duration-300`}
                >
                  {/* Assignment Header */}
                  <div className="bg-gradient-to-r from-purple-500 to-pink-600 p-6 text-white">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="text-lg font-bold mb-1 line-clamp-2">
                          {assignment.quiz?.title || 'Untitled Quiz'}
                        </h3>
                        <p className="text-purple-100 text-sm">
                          {assignment.classroom?.name || 'Unknown Classroom'}
                        </p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => handleEditAssignment(assignment)}
                          className="p-2 text-white hover:bg-white/20 rounded-lg transition-colors"
                          title="Edit Assignment"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteAssignment(assignment._id)}
                          className="p-2 text-white hover:bg-red-500/20 rounded-lg transition-colors"
                          title="Delete Assignment"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Completion Progress */}
                  <div className="p-6">
                    <div className="mb-6">
                      <div className="flex items-center justify-between mb-2">
                        <span className={`text-sm font-medium ${theme.colors.text.secondary}`}>
                          Student Progress
                        </span>
                        <span className={`text-sm font-bold ${getStatusColor(completionPercentage).split(' ')[0]}`}>
                          {completionPercentage}%
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <div
                          className={`h-3 rounded-full transition-all duration-500 ${
                            completionPercentage >= 80 ? 'bg-green-500' :
                            completionPercentage >= 60 ? 'bg-yellow-500' :
                            completionPercentage >= 40 ? 'bg-orange-500' : 'bg-red-500'
                          }`}
                          style={{ width: `${completionPercentage}%` }}
                        />
                      </div>
                      <div className="flex items-center justify-between mt-2 text-xs text-gray-600">
                        <span>{assignment.completedCount || 0} completed</span>
                        <span>{assignment.totalStudents || 0} total students</span>
                      </div>
                    </div>

                    {/* Assignment Details */}
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <BookOpen className="w-4 h-4 text-indigo-600" />
                          <span className={`text-sm ${theme.colors.text.secondary}`}>Questions</span>
                        </div>
                        <span className={`font-semibold ${theme.colors.text.primary}`}>
                          {assignment.quiz?.questions?.length || 0}
                        </span>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Calendar className="w-4 h-4 text-green-600" />
                          <span className={`text-sm ${theme.colors.text.secondary}`}>Due Date</span>
                        </div>
                        <span className={`font-semibold ${theme.colors.text.primary}`}>
                          {assignment.dueDate 
                            ? new Date(assignment.dueDate).toLocaleDateString()
                            : 'No due date'
                          }
                        </span>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Clock className="w-4 h-4 text-orange-600" />
                          <span className={`text-sm ${theme.colors.text.secondary}`}>Time Limit</span>
                        </div>
                        <span className={`font-semibold ${theme.colors.text.primary}`}>
                          {assignment.timeLimit ? `${assignment.timeLimit} min` : 'No limit'}
                        </span>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Activity className="w-4 h-4 text-purple-600" />
                          <span className={`text-sm ${theme.colors.text.secondary}`}>Status</span>
                        </div>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          assignment.isActive 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-gray-100 text-gray-800'
                        }`}>
                          {assignment.isActive ? 'Active' : 'Inactive'}
                        </span>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="mt-6 flex space-x-3">
                      <Button
                        onClick={() => handleEditAssignment(assignment)}
                        className="flex-1 bg-indigo-50 text-indigo-700 py-2 px-4 rounded-lg hover:bg-indigo-100 transition-colors text-sm font-medium"
                      >
                        Edit
                      </Button>
                      <Button
                        onClick={() => handleDeleteAssignment(assignment._id)}
                        className="flex-1 bg-red-50 text-red-700 py-2 px-4 rounded-lg hover:bg-red-100 transition-colors text-sm font-medium"
                      >
                        Delete
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Edit Assignment Modal */}
      <EditAssignmentModal
        isOpen={showEditModal}
        onClose={() => {
          setShowEditModal(false);
          setSelectedAssignment(null);
        }}
        assignment={selectedAssignment}
        onSave={handleAssignmentSave}
      />
    </div>
  );
};

export default StaffAssignmentsPage;
