import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import Button from '../components/common/Button';
import Loader from '../components/common/Loader';
import Modal from '../components/common/Modal';
import AddClassroom from '../features/classroom/AddClassroom';
import AssignQuiz from '../features/classroom/AssignQuiz';
import ThemeToggle from '../components/common/ThemeToggle';
import { useTheme } from '../contexts/ThemeContext';
import {
  Search, Filter, Plus, Users, BookOpen, Calendar,
  Globe, Settings, MoreVertical, Eye, Edit3, Trash2,
  Star, TrendingUp, Clock, Award, ChevronDown, Grid3X3,
  List, SortAsc, SortDesc, RefreshCw, Download, ArrowLeft
} from 'lucide-react';

const AllClassroomsPage = () => {
  const navigate = useNavigate();
  const user = useSelector(state => state.auth.user);
  const theme = useTheme();

  // Data state
  const [classrooms, setClassrooms] = useState([]);
  const [filteredClassrooms, setFilteredClassrooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // UI state
  const [showAddClassroomModal, setShowAddClassroomModal] = useState(false);
  const [showAssignQuizModal, setShowAssignQuizModal] = useState(false);
  const [selectedClassroomForQuiz, setSelectedClassroomForQuiz] = useState(null);
  const [language, setLanguage] = useState('english');
  const [viewMode, setViewMode] = useState('grid'); // grid, list

  // Filter and search state
  const [filter, setFilter] = useState('all'); // all, regular, disabled, mixed
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('newest'); // newest, oldest, name, students
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    fetchClassrooms();
  }, []);

  // Filter and search effect
  useEffect(() => {
    let filtered = [...classrooms];

    // Apply type filter
    if (filter !== 'all') {
      filtered = filtered.filter(classroom => classroom.classType === filter);
    }

    // Apply search filter
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(classroom =>
        classroom.name?.toLowerCase().includes(term) ||
        classroom.subject?.toLowerCase().includes(term) ||
        classroom.description?.toLowerCase().includes(term) ||
        classroom.grade?.toLowerCase().includes(term)
      );
    }

    // Apply sorting
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'newest':
          return new Date(b.createdAt) - new Date(a.createdAt);
        case 'oldest':
          return new Date(a.createdAt) - new Date(b.createdAt);
        case 'name':
          return (a.name || '').localeCompare(b.name || '');
        case 'students':
          return (b.students?.length || 0) - (a.students?.length || 0);
        default:
          return 0;
      }
    });

    setFilteredClassrooms(filtered);
  }, [classrooms, filter, searchTerm, sortBy]);

  const fetchClassrooms = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const response = await fetch('/api/classroom', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        if (response.status === 401) {
          throw new Error('Unauthorized. Please login again.');
        }
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success && data.data && data.data.all) {
        setClassrooms(data.data.all);
        setFilteredClassrooms(data.data.all);
      } else {
        setClassrooms([]);
        setFilteredClassrooms([]);
      }
    } catch (err) {
      setError(err.message);
      console.error('Error fetching classrooms:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleClassroomClick = (classroom) => {
    navigate(`/staff/classrooms/${classroom._id}`);
  };

  const handleAddClassroom = () => {
    setShowAddClassroomModal(true);
  };

  const handleDeleteClassroom = async (classroomId, classroomName) => {
    if (!window.confirm(`Are you sure you want to delete "${classroomName}"? This action cannot be undone.`)) {
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/classroom/${classroomId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      // Remove from local state
      setClassrooms(classrooms.filter(c => c._id !== classroomId));
      alert('Classroom deleted successfully!');
    } catch (err) {
      console.error('Error deleting classroom:', err);
      alert('Failed to delete classroom. Please try again.');
    }
  };

  const handleClassroomCreated = (classroom) => {
    setShowAddClassroomModal(false);
    fetchClassrooms(); // Refresh the list
  };

  const handleAssignQuiz = (classroom) => {
    setSelectedClassroomForQuiz(classroom);
    setShowAssignQuizModal(true);
  };

  const handleQuizAssigned = (assignment) => {
    setShowAssignQuizModal(false);
    setSelectedClassroomForQuiz(null);

    // Show success message
    const message = language === 'tamil'
      ? `வினாடி வினா வெற்றிகரமாக ஒதுக்கப்பட்டது! ${selectedClassroomForQuiz?.name} வகுப்பில் உள்ள அனைத்து மாணவர்களுக்கும் அனுப்பப்பட்டது.`
      : `Quiz assigned successfully! Sent to all students in ${selectedClassroomForQuiz?.name}.`;

    alert(message);
    console.log('Quiz assigned successfully:', assignment);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'inactive': return 'bg-gray-100 text-gray-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  const getClassTypeColor = (classType) => {
    switch (classType) {
      case 'regular': return 'bg-blue-100 text-blue-800';
      case 'disabled': return 'bg-purple-100 text-purple-800';
      case 'mixed': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };



  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex justify-center items-center">
        <Loader size="lg" />
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${theme.colors.bg.secondary} transition-colors duration-300`}>
      {/* Enhanced Header */}
      <div className={`${theme.colors.bg.primary} ${theme.shadows.md} ${theme.colors.border.primary} border-b backdrop-blur-lg bg-opacity-95 sticky top-0 z-50`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row lg:justify-between lg:items-center py-6 space-y-4 lg:space-y-0">
            <div className="flex-1">
              <div className="flex items-center gap-4 mb-2">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                    <BookOpen className="w-6 h-6 text-white" />
                  </div>
                  <h1 className={`text-3xl font-bold ${theme.colors.text.primary}`}>
                    {language === 'tamil' ? 'அனைத்து வகுப்பறைகள்' : 'All Classrooms'}
                  </h1>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setLanguage('english')}
                    className={`px-3 py-1 rounded-full text-sm font-medium transition-all ${
                      language === 'english'
                        ? 'bg-blue-600 text-white shadow-lg'
                        : `${theme.colors.bg.tertiary} ${theme.colors.text.secondary} hover:${theme.colors.text.primary} hover:shadow-md`
                    }`}
                  >
                    🇺🇸 EN
                  </button>
                  <button
                    onClick={() => setLanguage('tamil')}
                    className={`px-3 py-1 rounded-full text-sm font-medium transition-all ${
                      language === 'tamil'
                        ? 'bg-orange-600 text-white shadow-lg'
                        : `${theme.colors.bg.tertiary} ${theme.colors.text.secondary} hover:${theme.colors.text.primary} hover:shadow-md`
                    }`}
                  >
                    🇮🇳 TA
                  </button>
                </div>
              </div>
              <p className={`text-sm ${theme.colors.text.secondary}`}>
                {language === 'tamil'
                  ? 'உங்கள் வகுப்பறைகள், மாணவர்கள் மற்றும் வினாடி வினாக்களை நிர்வகிக்கவும்'
                  : 'Manage your classrooms, students, and quizzes'
                }
              </p>
            </div>

            <div className="flex items-center space-x-4">
              {/* Theme Toggle */}
              <ThemeToggle size="sm" />

              <Button
                onClick={() => navigate('/staff/dashboard')}
                className={`${theme.colors.button.secondary} flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all transform hover:scale-105`}
              >
                <ArrowLeft className="w-4 h-4" />
                {language === 'tamil' ? 'டாஷ்போர்டுக்கு திரும்பு' : 'Back to Dashboard'}
              </Button>

              <Button
                onClick={() => navigate('/staff/assignments')}
                className="bg-gradient-to-r from-purple-600 to-pink-600 text-white flex items-center gap-2 px-6 py-2 rounded-lg font-medium transition-all transform hover:scale-105 shadow-lg hover:from-purple-700 hover:to-pink-700"
              >
                <Award className="w-4 h-4" />
                {language === 'tamil' ? 'ஒதுக்கீடுகள்' : 'View Assignments'}
              </Button>

              <Button
                onClick={handleAddClassroom}
                className={`${theme.colors.button.primary} flex items-center gap-2 px-6 py-2 rounded-lg font-medium transition-all transform hover:scale-105 shadow-lg`}
              >
                <Plus className="w-4 h-4" />
                {language === 'tamil' ? 'புதிய வகுப்பறை' : 'Create Classroom'}
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced Search and Filters */}
      <div className={`${theme.colors.bg.secondary} ${theme.colors.border.primary} border-b`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search Bar */}
            <div className="flex-1 relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className={`h-5 w-5 ${theme.colors.text.tertiary}`} />
              </div>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className={`block w-full pl-10 pr-3 py-3 ${theme.colors.border.secondary} border rounded-xl leading-5 ${theme.colors.bg.card} ${theme.colors.text.primary} placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all ${theme.shadows.sm}`}
                placeholder={language === 'tamil'
                  ? 'வகுப்பறை பெயர், பாடம் அல்லது விளக்கத்தில் தேடுங்கள்...'
                  : 'Search classrooms by name, subject, or description...'
                }
              />
            </div>

            {/* View Mode Toggle */}
            <div className={`flex items-center ${theme.colors.bg.card} rounded-xl ${theme.colors.border.secondary} border p-1 ${theme.shadows.sm}`}>
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded-lg transition-all ${
                  viewMode === 'grid'
                    ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md'
                    : `${theme.colors.text.secondary} hover:${theme.colors.text.primary} ${theme.colors.hover.card}`
                }`}
                title={language === 'tamil' ? 'கிரிட் காட்சி' : 'Grid View'}
              >
                <Grid3X3 className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded-lg transition-all ${
                  viewMode === 'list'
                    ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md'
                    : `${theme.colors.text.secondary} hover:${theme.colors.text.primary} ${theme.colors.hover.card}`
                }`}
                title={language === 'tamil' ? 'பட்டியல் காட்சி' : 'List View'}
              >
                <List className="w-4 h-4" />
              </button>
            </div>

            {/* Sort Dropdown */}
            <div className="relative">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className={`appearance-none ${theme.colors.bg.card} ${theme.colors.border.secondary} border rounded-xl px-4 py-3 pr-10 ${theme.colors.text.primary} focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all ${theme.shadows.sm}`}
              >
                <option value="newest">{language === 'tamil' ? 'புதியது முதல்' : 'Newest First'}</option>
                <option value="oldest">{language === 'tamil' ? 'பழையது முதல்' : 'Oldest First'}</option>
                <option value="name">{language === 'tamil' ? 'பெயர் வரிசை' : 'Name A-Z'}</option>
                <option value="students">{language === 'tamil' ? 'மாணவர் எண்ணிக்கை' : 'Most Students'}</option>
              </select>
              <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none">
                <ChevronDown className={`w-4 h-4 ${theme.colors.text.tertiary}`} />
              </div>
            </div>

            {/* Refresh Button */}
            <button
              onClick={fetchClassrooms}
              className={`flex items-center gap-2 px-4 py-3 ${theme.colors.bg.card} ${theme.colors.border.secondary} border rounded-xl ${theme.colors.text.secondary} hover:${theme.colors.text.primary} ${theme.colors.hover.card} transition-all transform hover:scale-105 ${theme.shadows.sm}`}
              title={language === 'tamil' ? 'புதுப்பிக்கவும்' : 'Refresh'}
            >
              <RefreshCw className="w-4 h-4" />
              <span className="hidden sm:inline">
                {language === 'tamil' ? 'புதுப்பிக்கவும்' : 'Refresh'}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-wrap gap-2 bg-white p-2 rounded-lg shadow-sm border">
          {[
            {
              key: 'all',
              label: language === 'tamil' ? 'அனைத்து வகுப்புகள்' : 'All Classes',
              count: classrooms.length,
              icon: '📚'
            },
            {
              key: 'regular',
              label: language === 'tamil' ? 'வழக்கமான' : 'Regular',
              count: classrooms.filter(c => c.classType === 'regular').length,
              icon: '👥'
            },
            {
              key: 'disabled',
              label: language === 'tamil' ? 'மாற்றுத்திறனாளி' : 'Disabled',
              count: classrooms.filter(c => c.classType === 'disabled').length,
              icon: '♿'
            },
            {
              key: 'mixed',
              label: language === 'tamil' ? 'கலப்பு' : 'Mixed',
              count: classrooms.filter(c => c.classType === 'mixed').length,
              icon: '🌈'
            }
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setFilter(tab.key)}
              className={`flex items-center gap-2 py-3 px-4 rounded-lg text-sm font-medium transition-all ${
                filter === tab.key
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg scale-105'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50 hover:shadow-md'
              }`}
            >
              <span className="text-lg">{tab.icon}</span>
              <span>{tab.label}</span>
              <span className={`px-2 py-1 rounded-full text-xs ${
                filter === tab.key
                  ? 'bg-white/20 text-white'
                  : 'bg-gray-100 text-gray-600'
              }`}>
                {tab.count}
              </span>
            </button>
          ))}
        </div>

        {/* Results Summary */}
        <div className="mt-4 flex items-center justify-between">
          <p className="text-sm text-gray-600">
            {language === 'tamil'
              ? `${filteredClassrooms.length} வகுப்பறைகள் ${classrooms.length} இல் காட்டப்படுகின்றன`
              : `Showing ${filteredClassrooms.length} of ${classrooms.length} classrooms`
            }
            {searchTerm && (
              <span className="ml-2 text-indigo-600 font-medium">
                {language === 'tamil'
                  ? `"${searchTerm}" க்கான தேடல் முடிவுகள்`
                  : `for "${searchTerm}"`
                }
              </span>
            )}
          </p>

          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="text-sm text-gray-500 hover:text-gray-700 underline"
            >
              {language === 'tamil' ? 'தேடலை அழிக்கவும்' : 'Clear search'}
            </button>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-8">
        {error ? (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-red-400" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-red-800">Error loading classrooms</h3>
                <p className="text-sm text-red-700 mt-1">{error}</p>
                <button 
                  onClick={fetchClassrooms}
                  className="mt-2 text-sm text-red-600 hover:text-red-500 underline"
                >
                  Try again
                </button>
              </div>
            </div>
          </div>
        ) : filteredClassrooms.length === 0 ? (
          <div className="text-center py-12">
            <div className="mx-auto h-16 w-16 text-gray-400 mb-4">
              {searchTerm ? (
                <Search className="w-full h-full" />
              ) : (
                <BookOpen className="w-full h-full" />
              )}
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {searchTerm
                ? (language === 'tamil' ? 'தேடல் முடிவுகள் இல்லை' : 'No search results')
                : (language === 'tamil' ? 'வகுப்பறைகள் இல்லை' : 'No classrooms found')
              }
            </h3>
            <p className="text-sm text-gray-500 mb-6 max-w-md mx-auto">
              {searchTerm
                ? (language === 'tamil'
                    ? `"${searchTerm}" க்கான தேடல் முடிவுகள் கிடைக்கவில்லை. வேறு சொற்களை முயற்சிக்கவும்.`
                    : `No classrooms found matching "${searchTerm}". Try different search terms.`
                  )
                : (filter === 'all'
                    ? (language === 'tamil'
                        ? 'புதிய வகுப்பறையை உருவாக்குவதன் மூலம் தொடங்குங்கள்.'
                        : 'Get started by creating your first classroom.'
                      )
                    : (language === 'tamil'
                        ? `${filter} வகுப்பறைகள் கிடைக்கவில்லை.`
                        : `No ${filter} classrooms found.`
                      )
                  )
              }
            </p>
            <div className="flex gap-4 justify-center">
              {searchTerm && (
                <Button
                  onClick={() => setSearchTerm('')}
                  className="bg-gray-100 text-gray-700 hover:bg-gray-200"
                >
                  {language === 'tamil' ? 'தேடலை அழிக்கவும்' : 'Clear Search'}
                </Button>
              )}
              <Button
                onClick={handleAddClassroom}
                className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:from-indigo-700 hover:to-purple-700 flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                {language === 'tamil' ? 'வகுப்பறை உருவாக்கவும்' : 'Create Classroom'}
              </Button>
            </div>
          </div>
        ) : (
          <div className={`${viewMode === 'grid'
            ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'
            : 'space-y-4'
          }`}>
            {filteredClassrooms.map((classroom) => (
              <div
                key={classroom._id}
                className={`bg-white rounded-xl shadow-md overflow-hidden border border-gray-100 hover:shadow-xl transition-all cursor-pointer transform hover:scale-[1.02] ${
                  viewMode === 'list' ? 'flex items-center' : ''
                }`}
                onClick={() => handleClassroomClick(classroom)}
              >
                {/* Classroom Header */}
                <div className={`bg-gradient-to-r from-blue-500 to-indigo-600 text-white ${
                  viewMode === 'list' ? 'p-4 w-64 flex-shrink-0' : 'p-6'
                }`}>
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <h3 className={`font-bold mb-1 ${viewMode === 'list' ? 'text-base' : 'text-lg'}`}>
                        {classroom.name}
                      </h3>
                      <p className="text-blue-100 text-sm">{classroom.subject}</p>
                      {viewMode === 'list' && classroom.grade && (
                        <p className="text-blue-200 text-xs mt-1">{classroom.grade}</p>
                      )}
                    </div>
                    <div className="flex flex-col items-end space-y-2">
                      <div className="flex items-center space-x-2">
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(classroom.isActive ? 'active' : 'inactive')}`}>
                          {classroom.isActive
                            ? (language === 'tamil' ? 'செயலில்' : 'Active')
                            : (language === 'tamil' ? 'செயலில் இல்லை' : 'Inactive')
                          }
                        </span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteClassroom(classroom._id, classroom.name);
                          }}
                          className="p-1 text-red-200 hover:text-red-100 hover:bg-red-500/20 rounded transition-all"
                          title={language === 'tamil' ? 'வகுப்பறையை நீக்கவும்' : 'Delete classroom'}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getClassTypeColor(classroom.classType)}`}>
                        {classroom.classType === 'regular'
                          ? (language === 'tamil' ? 'வழக்கமான' : 'Regular')
                          : classroom.classType === 'disabled'
                          ? (language === 'tamil' ? 'மாற்றுத்திறனாளி' : 'Disabled')
                          : classroom.classType === 'mixed'
                          ? (language === 'tamil' ? 'கலப்பு' : 'Mixed')
                          : classroom.classType
                        }
                      </span>
                    </div>
                  </div>
                </div>

                {/* Classroom Content */}
                <div className={`${viewMode === 'list' ? 'flex-1 p-4' : 'p-6'}`}>
                  <div className={`${viewMode === 'list' ? 'flex items-center justify-between' : 'space-y-4'}`}>
                    {/* Stats */}
                    <div className={`${viewMode === 'list' ? 'flex gap-6' : 'grid grid-cols-2 gap-4'}`}>
                      <div className={`${viewMode === 'list' ? 'flex items-center gap-2' : 'text-center'}`}>
                        <Users className="w-4 h-4 text-indigo-600" />
                        <div>
                          <div className={`${viewMode === 'list' ? 'text-lg' : 'text-2xl'} font-bold text-gray-900`}>
                            {classroom.students?.length || 0}
                          </div>
                          <div className="text-xs text-gray-500">
                            {language === 'tamil' ? 'மாணவர்கள்' : 'Students'}
                          </div>
                        </div>
                      </div>
                      <div className={`${viewMode === 'list' ? 'flex items-center gap-2' : 'text-center'}`}>
                        <Award className="w-4 h-4 text-green-600" />
                        <div>
                          <div className={`${viewMode === 'list' ? 'text-lg' : 'text-2xl'} font-bold text-gray-900`}>
                            {classroom.maxStudents - (classroom.students?.length || 0)}
                          </div>
                          <div className="text-xs text-gray-500">
                            {language === 'tamil' ? 'கிடைக்கும்' : 'Available'}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Details */}
                    <div className={`${viewMode === 'list' ? 'flex items-center gap-4' : 'space-y-2'}`}>
                      <div className="flex items-center text-sm text-gray-600">
                        <Clock className="w-4 h-4 mr-2 text-blue-600" />
                        <span>{classroom.grade} • {classroom.semester}</span>
                      </div>
                      <div className="flex items-center text-sm text-gray-600">
                        <Calendar className="w-4 h-4 mr-2 text-purple-600" />
                        <span>{classroom.academicYear}</span>
                      </div>
                      {classroom.description && viewMode === 'grid' && (
                        <p className="text-sm text-gray-600 line-clamp-2">{classroom.description}</p>
                      )}
                    </div>

                    {/* Quick Actions */}
                    {viewMode === 'grid' && (
                      <div className="pt-4 border-t border-gray-100">
                        <div className="text-sm text-gray-500 mb-3">
                          {language === 'tamil' ? 'விரைவு செயல்கள்:' : 'Quick Actions:'}
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                          <Button
                            onClick={(e) => {
                              e.stopPropagation();
                              navigate(`/staff/classrooms/${classroom._id}/students`);
                            }}
                            className="flex items-center justify-center gap-1 bg-indigo-50 text-indigo-700 py-2 px-2 rounded-lg hover:bg-indigo-100 transition-all text-xs font-medium"
                          >
                            <Users className="w-3 h-3" />
                            {language === 'tamil' ? 'மாணவர்கள்' : 'Students'}
                          </Button>
                          <Button
                            onClick={(e) => {
                              e.stopPropagation();
                              navigate(`/staff/classrooms/${classroom._id}/quizzes`);
                            }}
                            className="flex items-center justify-center gap-1 bg-green-50 text-green-700 py-2 px-2 rounded-lg hover:bg-green-100 transition-all text-xs font-medium"
                          >
                            <BookOpen className="w-3 h-3" />
                            {language === 'tamil' ? 'வினாடி வினா' : 'Quizzes'}
                          </Button>
                          <Button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleAssignQuiz(classroom);
                            }}
                            className="flex items-center justify-center gap-1 bg-purple-50 text-purple-700 py-2 px-2 rounded-lg hover:bg-purple-100 transition-all text-xs font-medium"
                            disabled={!classroom.students || classroom.students.length === 0}
                            title={!classroom.students || classroom.students.length === 0
                              ? (language === 'tamil' ? 'வகுப்பில் மாணவர்கள் இல்லை' : 'No students in classroom')
                              : (language === 'tamil' ? 'வினாடி வினா ஒதுக்கவும்' : 'Assign quiz to all students')
                            }
                          >
                            <Award className="w-3 h-3" />
                            {language === 'tamil' ? 'ஒதுக்கு' : 'Assign'}
                          </Button>
                        </div>
                      </div>
                    )}

                    {/* List View Actions */}
                    {viewMode === 'list' && (
                      <div className="flex items-center gap-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            navigate(`/staff/classrooms/${classroom._id}/students`);
                          }}
                          className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                          title={language === 'tamil' ? 'மாணவர்களை நிர்வகிக்கவும்' : 'Manage Students'}
                        >
                          <Users className="w-4 h-4" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            navigate(`/staff/classrooms/${classroom._id}/quizzes`);
                          }}
                          className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-all"
                          title={language === 'tamil' ? 'வினாடி வினாக்களை நிர்வகிக்கவும்' : 'Manage Quizzes'}
                        >
                          <BookOpen className="w-4 h-4" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            // Add more actions menu
                          }}
                          className="p-2 text-gray-600 hover:bg-gray-50 rounded-lg transition-all"
                          title={language === 'tamil' ? 'மேலும் விருப்பங்கள்' : 'More options'}
                        >
                          <MoreVertical className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Classroom Modal */}
      <AddClassroom
        isOpen={showAddClassroomModal}
        onClose={() => setShowAddClassroomModal(false)}
        onSuccess={handleClassroomCreated}
      />

      {/* Assign Quiz Modal */}
      {selectedClassroomForQuiz && (
        <AssignQuiz
          isOpen={showAssignQuizModal}
          onClose={() => {
            setShowAssignQuizModal(false);
            setSelectedClassroomForQuiz(null);
          }}
          classroom={selectedClassroomForQuiz}
          onSuccess={handleQuizAssigned}
        />
      )}
    </div>
  );
};

export default AllClassroomsPage; 