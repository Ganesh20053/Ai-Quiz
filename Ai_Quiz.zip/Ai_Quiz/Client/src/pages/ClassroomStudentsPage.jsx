import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Button from '../components/common/Button';
import Loader from '../components/common/Loader';
import Modal from '../components/common/Modal';
import ThemeToggle from '../components/common/ThemeToggle';
import AssignQuiz from '../features/classroom/AssignQuiz';
import { useTheme } from '../contexts/ThemeContext';
import { useToast } from '../contexts/ToastContext';
import {
  Users, Plus, Search, Filter, ArrowLeft, UserPlus,
  Mail, GraduationCap, Eye, Edit3, Trash2, MoreVertical,
  UserCheck, UserX, Calendar, Clock, Award, Star,
  Grid3X3, List, RefreshCw, Download, Upload, BookOpen
} from 'lucide-react';

const ClassroomStudentsPage = () => {
  const { classroomId } = useParams();
  const navigate = useNavigate();
  const theme = useTheme();
  const { showStudentCreated, showError, showSuccess } = useToast();

  // Data state
  const [classroom, setClassroom] = useState(null);
  const [students, setStudents] = useState([]);
  const [allStudents, setAllStudents] = useState([]);
  const [filteredStudents, setFilteredStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // UI state
  const [showAddStudentModal, setShowAddStudentModal] = useState(false);
  const [showAddExistingStudentModal, setShowAddExistingStudentModal] = useState(false);
  const [showRemoveStudentModal, setShowRemoveStudentModal] = useState(false);
  const [showAssignQuizModal, setShowAssignQuizModal] = useState(false);
  const [showAssignQuizToNormalModal, setShowAssignQuizToNormalModal] = useState(false);
  const [showAssignQuizToDisabledModal, setShowAssignQuizToDisabledModal] = useState(false);
  const [studentToRemove, setStudentToRemove] = useState(null);
  const [viewMode, setViewMode] = useState('grid');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all'); // all, regular, disabled
  const [selectedStudentGroup, setSelectedStudentGroup] = useState('all'); // 'all', 'normal', 'disabled'
  const [allStudentsLoaded, setAllStudentsLoaded] = useState(false);

  // Form state
  const [studentForm, setStudentForm] = useState({
    name: '',
    email: '',
    grade: '',
    rollNo: '',
    isDisabled: false
  });
  const [selectedStudents, setSelectedStudents] = useState([]);

  useEffect(() => {
    if (classroomId) {
      fetchClassroomAndStudents();
      // Fetch all students in background (non-blocking)
      fetchAllStudents().catch(console.error);
    }
  }, [classroomId]);

  // Filter and search effect with group-based filtering
  useEffect(() => {
    let filtered = [...students];

    // Apply group filter first (this is the main filter)
    if (selectedStudentGroup === 'normal') {
      filtered = filtered.filter(student => !student.isDisabled);
    } else if (selectedStudentGroup === 'disabled') {
      filtered = filtered.filter(student => student.isDisabled);
    }
    // If selectedStudentGroup is 'all', show all students

    // Apply additional type filter (for backward compatibility)
    if (filterType !== 'all') {
      filtered = filtered.filter(student =>
        filterType === 'disabled' ? student.isDisabled : !student.isDisabled
      );
    }

    // Apply search filter
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(student =>
        student.name?.toLowerCase().includes(term) ||
        student.email?.toLowerCase().includes(term) ||
        student.grade?.toLowerCase().includes(term)
      );
    }

    setFilteredStudents(filtered);
  }, [students, filterType, searchTerm, selectedStudentGroup]);

  const fetchClassroomAndStudents = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      
      // Fetch classroom details
      const classroomResponse = await fetch(`/api/classroom/${classroomId}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!classroomResponse.ok) {
        throw new Error(`HTTP error! status: ${classroomResponse.status}`);
      }

      const classroomData = await classroomResponse.json();
      setClassroom(classroomData.data || {});

      // Fetch students in this classroom
      const studentsResponse = await fetch(`/api/classroom/${classroomId}/students`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (studentsResponse.ok) {
        const studentsData = await studentsResponse.json();
        const students = studentsData.data?.students || [];
        // Only apply fallbacks for truly missing data
        const validatedStudents = students.map(student => ({
          ...student,
          _id: student._id || '',
          name: student.name || 'Unknown Student',
          email: student.email || 'No email',
          grade: student.grade || 'No grade',
          isDisabled: Boolean(student.isDisabled)
        }));
        setStudents(validatedStudents);
      } else {
        console.warn('Failed to fetch classroom students:', studentsResponse.status);
        setStudents([]);
      }

    } catch (err) {
      setError(err.message);
      console.error('Error fetching classroom and students:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchAllStudents = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        console.warn('No authentication token found');
        setAllStudents([]);
        return;
      }

      const response = await fetch('/api/auth/students', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        // The backend returns data directly in the data field
        setAllStudents(Array.isArray(data.data) ? data.data : []);
        setAllStudentsLoaded(true);
      } else {
        const errorText = await response.text();
        console.warn('Failed to fetch all students:', response.status, errorText);
        // Set empty array as fallback - this is not critical for the page to work
        setAllStudents([]);
        setAllStudentsLoaded(false);
      }
    } catch (err) {
      console.error('Error fetching all students:', err);
      // Set empty array as fallback - this is not critical for the page to work
      setAllStudents([]);
      setAllStudentsLoaded(false);
    }
  };

  const handleStudentFormChange = (e) => {
    const { name, value, type, checked } = e.target;
    setStudentForm(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmitNewStudent = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/auth/students', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          name: studentForm.name,
          email: studentForm.email,
          grade: studentForm.grade,
          isDisabled: studentForm.isDisabled,
          rollNo: studentForm.rollNo || undefined
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.success && data.data && data.data.id) {
        // Add the new student to the classroom
        await addStudentToClassroom(data.data.id);

        // Show beautiful success toast with password info
        showStudentCreated({
          name: data.data.name,
          email: data.data.email,
          password: data.data.password
        });

        setShowAddStudentModal(false);
        setStudentForm({
          name: '',
          email: '',
          grade: '',
          isDisabled: false,
          rollNo: ''
        });
        fetchClassroomAndStudents();
        fetchAllStudents();
      } else {
        throw new Error('Invalid response format from server');
      }
    } catch (err) {
      console.error('Error creating student:', err);
      setError(`Failed to create student: ${err.message}`);
      showError(
        'Failed to Create Student',
        `There was an error creating the student account: ${err.message}`
      );
    }
  };

  const addStudentToClassroom = async (studentId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/classroom/${classroomId}/students`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          studentIds: [studentId]
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
    } catch (err) {
      console.error('Error adding student to classroom:', err);
      throw err;
    }
  };

  const handleAddExistingStudents = async () => {
    if (selectedStudents.length === 0) {
      alert('Please select at least one student.');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/classroom/${classroomId}/students`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          studentIds: selectedStudents
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      setShowAddExistingStudentModal(false);
      setSelectedStudents([]);
      fetchClassroomAndStudents();
      showSuccess(
        'Students Added Successfully! 🎉',
        `${selectedStudents.length} student${selectedStudents.length > 1 ? 's' : ''} have been added to the classroom.`
      );
    } catch (err) {
      console.error('Error adding students to classroom:', err);
      showError(
        'Failed to Add Students',
        'There was an error adding students to the classroom. Please try again.'
      );
    }
  };

  const handleRemoveStudent = (studentId, studentName) => {
    setStudentToRemove({ id: studentId, name: studentName });
    setShowRemoveStudentModal(true);
  };

  const handleQuizAssigned = (assignment) => {
    setShowAssignQuizModal(false);
    setShowAssignQuizToNormalModal(false);
    setShowAssignQuizToDisabledModal(false);
    showSuccess(
      'Quiz Assigned Successfully! 📚',
      `Quiz has been assigned to selected students in ${classroom?.name}.`
    );
  };

  // Helper functions to separate students
  const getNormalStudents = () => students.filter(student => !student.isDisabled);
  const getDisabledStudents = () => students.filter(student => student.isDisabled);

  // Get filtered students based on selected group
  const getFilteredStudentsByGroup = () => {
    let baseStudents = students;

    if (selectedStudentGroup === 'normal') {
      baseStudents = getNormalStudents();
    } else if (selectedStudentGroup === 'disabled') {
      baseStudents = getDisabledStudents();
    }

    // Apply search filter
    if (searchTerm) {
      baseStudents = baseStudents.filter(student =>
        student.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.grade?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    return baseStudents;
  };

  const executeRemoveStudent = async (isCompleteDelete = false) => {
    if (!studentToRemove) return;

    try {
      const token = localStorage.getItem('token');
      const endpoint = isCompleteDelete
        ? `/api/classroom/${classroomId}/students/${studentToRemove.id}/permanent`
        : `/api/classroom/${classroomId}/students/${studentToRemove.id}`;

      const response = await fetch(endpoint, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      // Remove from local state
      setStudents(students.filter(s => s._id !== studentToRemove.id));

      if (isCompleteDelete) {
        showSuccess(
          'Student Deleted Permanently! 🗑️',
          `${studentToRemove.name} has been completely deleted from the database.`
        );
        // Also refresh the all students list since the student is completely gone
        fetchAllStudents();
      } else {
        showSuccess(
          'Student Removed from Classroom',
          `${studentToRemove.name} has been removed from this classroom but their account still exists.`
        );
      }

      // Close modal and reset state
      setShowRemoveStudentModal(false);
      setStudentToRemove(null);
    } catch (err) {
      console.error('Error removing/deleting student:', err);
      showError(
        isCompleteDelete ? 'Failed to Delete Student' : 'Failed to Remove Student',
        `There was an error ${isCompleteDelete ? 'deleting' : 'removing'} the student. Please try again.`
      );
    }
  };

  const getStudentTypeColor = (isDisabled) => {
    return isDisabled ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex justify-center items-center">
        <Loader size="lg" />
      </div>
    );
  }

  if (error) {
    return (
      <div className={`min-h-screen ${theme.colors.bg.secondary} flex justify-center items-center`}>
        <div className={`text-center p-8 ${theme.colors.bg.card} rounded-2xl ${theme.shadows.xl} max-w-md mx-4`}>
          <div className={`w-16 h-16 mx-auto mb-4 ${theme.colors.bg.tertiary} rounded-full flex items-center justify-center`}>
            <Users className={`w-8 h-8 ${theme.colors.text.tertiary}`} />
          </div>
          <h2 className={`text-2xl font-bold ${theme.colors.text.primary} mb-4`}>Something went wrong</h2>
          <p className={`${theme.colors.text.secondary} mb-6`}>{error}</p>
          <Button
            onClick={() => navigate('/staff/classrooms')}
            className={`${theme.colors.button.primary} px-6 py-3 rounded-lg font-medium`}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Classrooms
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${theme.colors.bg.secondary} transition-colors duration-300`}>
      {/* Enhanced Header */}
      <div className={`${theme.colors.bg.primary} ${theme.shadows.md} ${theme.colors.border.primary} border-b backdrop-blur-lg bg-opacity-95 sticky top-0 z-50`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row lg:justify-between lg:items-center py-6 space-y-4 lg:space-y-0">
            <div className="flex-1">
              <div className="flex items-center space-x-4 mb-2">
                <Button
                  onClick={() => navigate('/staff/classrooms')}
                  className={`${theme.colors.button.secondary} flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all transform hover:scale-105`}
                >
                  <ArrowLeft className="w-4 h-4" />
                  Back to Classrooms
                </Button>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                    <Users className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h1 className={`text-2xl lg:text-3xl font-bold ${theme.colors.text.primary}`}>
                      {classroom?.name}
                    </h1>
                    <div className="flex items-center gap-2 mt-1">
                      <span className={`text-sm ${theme.colors.text.secondary}`}>
                        {filteredStudents.length} of {students.length} students
                      </span>
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        classroom?.classType === 'regular'
                          ? theme.isDarkMode ? 'bg-blue-900/30 text-blue-300' : 'bg-blue-100 text-blue-700'
                          : classroom?.classType === 'disabled'
                          ? theme.isDarkMode ? 'bg-purple-900/30 text-purple-300' : 'bg-purple-100 text-purple-700'
                          : theme.isDarkMode ? 'bg-orange-900/30 text-orange-300' : 'bg-orange-100 text-orange-700'
                      }`}>
                        {classroom?.classType} class
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              {/* Theme Toggle */}
              <ThemeToggle size="sm" />

              {/* Enhanced Action Buttons */}
              <div className="flex space-x-3">
                {/* Assign to All Students */}
                <Button
                  onClick={() => setShowAssignQuizModal(true)}
                  disabled={students.length === 0}
                  title={students.length === 0 ? "No students in classroom to assign quiz" : `Assign quiz to all ${students.length} students in this classroom`}
                  className={`${theme.colors.button.primary} flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all transform hover:scale-105 ${students.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  <BookOpen className="w-4 h-4" />
                  Assign to All
                  {students.length > 0 ? (
                    <span className="text-xs ml-1 bg-white/20 px-2 py-1 rounded-full">
                      {students.length} student{students.length !== 1 ? 's' : ''}
                    </span>
                  ) : (
                    <span className="text-xs ml-1">(No Students)</span>
                  )}
                </Button>

                {/* Assign to Normal Students */}
                <Button
                  onClick={() => setShowAssignQuizToNormalModal(true)}
                  disabled={getNormalStudents().length === 0}
                  title={getNormalStudents().length === 0 ? "No normal students in classroom" : `Assign quiz to ${getNormalStudents().length} normal students`}
                  className={`bg-blue-600 hover:bg-blue-700 text-white flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all transform hover:scale-105 ${getNormalStudents().length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  <Users className="w-4 h-4" />
                  Normal Students
                  <span className="text-xs ml-1 bg-white/20 px-2 py-1 rounded-full">
                    {getNormalStudents().length}
                  </span>
                </Button>

                {/* Assign to Students with Disabilities */}
                <Button
                  onClick={() => setShowAssignQuizToDisabledModal(true)}
                  disabled={getDisabledStudents().length === 0}
                  title={getDisabledStudents().length === 0 ? "No students with disabilities in classroom" : `Assign quiz to ${getDisabledStudents().length} students with disabilities`}
                  className={`bg-purple-600 hover:bg-purple-700 text-white flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all transform hover:scale-105 ${getDisabledStudents().length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  <UserCheck className="w-4 h-4" />
                  Disabled Students
                  <span className="text-xs ml-1 bg-white/20 px-2 py-1 rounded-full">
                    {getDisabledStudents().length}
                  </span>
                </Button>

                {/* Debug Test Button */}
                <Button
                  onClick={async () => {
                    try {
                      const token = localStorage.getItem('token');
                      console.log('🧪 Testing assign-quiz route...');
                      const response = await fetch(`/api/classroom/${classroomId}/assign-quiz`, {
                        method: 'POST',
                        headers: {
                          'Authorization': `Bearer ${token}`,
                          'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                          quizId: 'test-quiz-id',
                          assignmentType: 'all'
                        })
                      });
                      console.log('📡 Test response status:', response.status);
                      const data = await response.json();
                      console.log('📝 Test response data:', data);
                      alert(`Test result: ${response.status} - Check console`);
                    } catch (error) {
                      console.error('❌ Test error:', error);
                      alert(`Test failed: ${error.message}`);
                    }
                  }}
                  className="bg-orange-600 text-white px-3 py-1 rounded text-sm"
                >
                  Test Route
                </Button>
                <Button
                  onClick={() => setShowAddExistingStudentModal(true)}
                  disabled={!allStudentsLoaded}
                  title={!allStudentsLoaded ? "Cannot load existing students list" : "Add existing students to this classroom"}
                  className={`${theme.colors.button.secondary} flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all transform hover:scale-105 ${!allStudentsLoaded ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  <UserPlus className="w-4 h-4" />
                  Add Existing
                  {!allStudentsLoaded && <span className="text-xs ml-1">(Unavailable)</span>}
                </Button>
                <Button
                  onClick={() => setShowAddStudentModal(true)}
                  className={`${theme.colors.button.success} flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all transform hover:scale-105 shadow-lg`}
                >
                  <Plus className="w-4 h-4" />
                  Create New
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Student Group Selection */}
      <div className={`${theme.colors.bg.primary}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-gray-800 dark:to-gray-700 rounded-2xl p-6 border border-blue-200 dark:border-gray-600">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-600" />
              Student Groups
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* All Students */}
              <div
                onClick={() => setSelectedStudentGroup('all')}
                className={`cursor-pointer p-4 rounded-xl border-2 transition-all transform hover:scale-105 ${
                  selectedStudentGroup === 'all'
                    ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                    : 'border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 hover:border-blue-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-white">All Students</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-300">View all students</p>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-blue-600">{students.length}</div>
                    <div className="text-xs text-gray-500">Total</div>
                  </div>
                </div>
              </div>

              {/* Normal Students */}
              <div
                onClick={() => setSelectedStudentGroup('normal')}
                className={`cursor-pointer p-4 rounded-xl border-2 transition-all transform hover:scale-105 ${
                  selectedStudentGroup === 'normal'
                    ? 'border-green-500 bg-green-50 dark:bg-green-900/20'
                    : 'border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 hover:border-green-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-white">Normal Students</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-300">Regular learning mode</p>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-green-600">{getNormalStudents().length}</div>
                    <div className="text-xs text-gray-500">Normal</div>
                  </div>
                </div>
              </div>

              {/* Students with Disabilities */}
              <div
                onClick={() => setSelectedStudentGroup('disabled')}
                className={`cursor-pointer p-4 rounded-xl border-2 transition-all transform hover:scale-105 ${
                  selectedStudentGroup === 'disabled'
                    ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20'
                    : 'border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 hover:border-purple-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-white">Students with Disabilities</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-300">Accessible learning mode</p>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-purple-600">{getDisabledStudents().length}</div>
                    <div className="text-xs text-gray-500">Disabled</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className={`${theme.colors.bg.secondary} ${theme.colors.border.primary} border-b`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search Bar */}
            <div className="flex-1 relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className={`h-5 w-5 ${theme.colors.text.tertiary}`} />
              </div>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className={`block w-full pl-10 pr-3 py-3 ${theme.colors.border.secondary} border rounded-xl leading-5 ${theme.colors.bg.card} ${theme.colors.text.primary} placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all ${theme.shadows.sm}`}
                placeholder="Search students by name, email, or grade..."
              />
            </div>

            {/* Filter Buttons */}
            <div className={`flex items-center ${theme.colors.bg.card} rounded-xl ${theme.colors.border.secondary} border p-1 ${theme.shadows.sm}`}>
              {[
                { key: 'all', label: 'All Students', icon: Users },
                { key: 'regular', label: 'Regular', icon: UserCheck },
                { key: 'disabled', label: 'Special Needs', icon: UserX }
              ].map(({ key, label, icon: Icon }) => (
                <button
                  key={key}
                  onClick={() => setFilterType(key)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    filterType === key
                      ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md'
                      : `${theme.colors.text.secondary} hover:${theme.colors.text.primary} ${theme.colors.hover.card}`
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="hidden sm:inline">{label}</span>
                </button>
              ))}
            </div>

            {/* View Mode Toggle */}
            <div className={`flex items-center ${theme.colors.bg.card} rounded-xl ${theme.colors.border.secondary} border p-1 ${theme.shadows.sm}`}>
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded-lg transition-all ${
                  viewMode === 'grid'
                    ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md'
                    : `${theme.colors.text.secondary} hover:${theme.colors.text.primary} ${theme.colors.hover.card}`
                }`}
                title="Grid View"
              >
                <Grid3X3 className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded-lg transition-all ${
                  viewMode === 'list'
                    ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md'
                    : `${theme.colors.text.secondary} hover:${theme.colors.text.primary} ${theme.colors.hover.card}`
                }`}
                title="List View"
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Enhanced Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {[
            {
              title: 'Total Students',
              value: students.length,
              icon: Users,
              color: 'blue',
              gradient: 'from-blue-500 to-cyan-500',
              bgColor: theme.isDarkMode ? 'bg-blue-900/20' : 'bg-blue-50'
            },
            {
              title: 'Regular Students',
              value: students.filter(s => !s.isDisabled).length,
              icon: UserCheck,
              color: 'green',
              gradient: 'from-green-500 to-emerald-500',
              bgColor: theme.isDarkMode ? 'bg-green-900/20' : 'bg-green-50'
            },
            {
              title: 'Special Needs',
              value: students.filter(s => s.isDisabled).length,
              icon: UserX,
              color: 'purple',
              gradient: 'from-purple-500 to-pink-500',
              bgColor: theme.isDarkMode ? 'bg-purple-900/20' : 'bg-purple-50'
            },
            {
              title: 'Filtered Results',
              value: filteredStudents.length,
              icon: Filter,
              color: 'orange',
              gradient: 'from-orange-500 to-red-500',
              bgColor: theme.isDarkMode ? 'bg-orange-900/20' : 'bg-orange-50'
            }
          ].map((stat, index) => (
            <div
              key={index}
              className={`${theme.colors.bg.card} rounded-2xl ${theme.shadows.lg} ${theme.colors.border.primary} border overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:scale-105 group`}
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-3 rounded-xl ${stat.bgColor} group-hover:scale-110 transition-transform duration-300`}>
                    <stat.icon className={`w-6 h-6 text-${stat.color}-600`} />
                  </div>
                </div>

                <div>
                  <p className={`text-sm font-medium ${theme.colors.text.secondary} mb-1`}>
                    {stat.title}
                  </p>
                  <p className={`text-3xl font-bold ${theme.colors.text.primary} mb-2`}>
                    {stat.value}
                  </p>
                  <div className={`w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2`}>
                    <div
                      className={`bg-gradient-to-r ${stat.gradient} h-2 rounded-full transition-all duration-1000 ease-out`}
                      style={{ width: `${Math.min((stat.value / Math.max(students.length, 1)) * 100, 100)}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Enhanced Students List */}
        {students.length === 0 ? (
          <div className={`text-center py-16 ${theme.colors.bg.card} rounded-2xl ${theme.shadows.lg} ${theme.colors.border.primary} border`}>
            <div className={`mx-auto w-20 h-20 ${theme.colors.bg.tertiary} rounded-full flex items-center justify-center mb-6`}>
              <Users className={`w-10 h-10 ${theme.colors.text.tertiary}`} />
            </div>
            <h3 className={`text-xl font-semibold ${theme.colors.text.primary} mb-2`}>No students enrolled</h3>
            <p className={`${theme.colors.text.secondary} mb-8 max-w-md mx-auto`}>
              Get started by adding students to this classroom. You can add existing students or create new ones.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                onClick={() => setShowAddExistingStudentModal(true)}
                className={`${theme.colors.button.secondary} flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all transform hover:scale-105`}
              >
                <UserPlus className="w-5 h-5" />
                Add Existing Student
              </Button>
              <Button
                onClick={() => setShowAddStudentModal(true)}
                className={`${theme.colors.button.success} flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all transform hover:scale-105 shadow-lg`}
              >
                <Plus className="w-5 h-5" />
                Create New Student
              </Button>
            </div>
          </div>
        ) : filteredStudents.length === 0 ? (
          <div className={`text-center py-16 ${theme.colors.bg.card} rounded-2xl ${theme.shadows.lg} ${theme.colors.border.primary} border`}>
            <div className={`mx-auto w-20 h-20 ${theme.colors.bg.tertiary} rounded-full flex items-center justify-center mb-6`}>
              <Search className={`w-10 h-10 ${theme.colors.text.tertiary}`} />
            </div>
            <h3 className={`text-xl font-semibold ${theme.colors.text.primary} mb-2`}>No students found</h3>
            <p className={`${theme.colors.text.secondary} mb-8 max-w-md mx-auto`}>
              No students match your current search and filter criteria. Try adjusting your filters or search terms.
            </p>
            <Button
              onClick={() => {
                setSearchTerm('');
                setFilterType('all');
              }}
              className={`${theme.colors.button.secondary} px-6 py-3 rounded-lg font-medium`}
            >
              Clear Filters
            </Button>
          </div>
        ) : (
          <div className={`${theme.colors.bg.card} rounded-2xl ${theme.shadows.lg} overflow-hidden ${theme.colors.border.primary} border`}>
            <div className={`px-6 py-4 ${theme.colors.border.light} border-b flex items-center justify-between`}>
              <div className="flex items-center gap-3">
                <Users className={`w-5 h-5 ${theme.colors.text.primary}`} />
                <h3 className={`text-lg font-semibold ${theme.colors.text.primary}`}>
                  Enrolled Students ({filteredStudents.length})
                </h3>
              </div>
              {searchTerm && (
                <span className={`text-sm ${theme.colors.text.secondary}`}>
                  Showing results for "{searchTerm}"
                </span>
              )}
            </div>

            {viewMode === 'grid' ? (
              <div className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredStudents.map((student) => (
                    <div
                      key={student._id}
                      className={`${theme.colors.bg.card} rounded-xl ${theme.shadows.md} ${theme.colors.border.secondary} border p-6 hover:shadow-xl transition-all duration-300 transform hover:scale-105 group`}
                    >
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center space-x-3">
                          <div className={`h-12 w-12 rounded-full bg-gradient-to-r ${
                            student.isDisabled
                              ? 'from-purple-500 to-pink-500'
                              : 'from-blue-500 to-indigo-500'
                          } flex items-center justify-center shadow-lg`}>
                            <span className="text-sm font-bold text-white">
                              {student.name ? student.name.split(' ').map(n => n[0]).join('').toUpperCase() : '?'}
                            </span>
                          </div>
                          <div>
                            <h4 className={`font-semibold ${theme.colors.text.primary} group-hover:text-indigo-600 transition-colors`}>
                              {student.name || 'Unknown Student'}
                            </h4>
                            <p className={`text-sm ${theme.colors.text.secondary}`}>
                              {student.email || 'No email'}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center space-x-1">
                          <button
                            onClick={() => handleRemoveStudent(student._id)}
                            className={`p-2 rounded-lg ${theme.colors.hover.card} text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20 transition-all opacity-0 group-hover:opacity-100`}
                            title="Remove student"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className={`text-sm ${theme.colors.text.secondary}`}>Grade:</span>
                          <span className={`text-sm font-medium ${theme.colors.text.primary}`}>
                            {student.grade || 'No grade'}
                          </span>
                        </div>

                        <div className="flex items-center justify-between">
                          <span className={`text-sm ${theme.colors.text.secondary}`}>Type:</span>
                          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                            student.isDisabled
                              ? theme.isDarkMode ? 'bg-purple-900/30 text-purple-300 border border-purple-800' : 'bg-purple-100 text-purple-700 border border-purple-200'
                              : theme.isDarkMode ? 'bg-green-900/30 text-green-300 border border-green-800' : 'bg-green-100 text-green-700 border border-green-200'
                          }`}>
                            {student.isDisabled ? 'Special Needs' : 'Regular'}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className={`divide-y ${theme.colors.border.light}`}>
                {filteredStudents.map((student) => (
                  <div key={student._id} className={`px-6 py-4 flex items-center justify-between ${theme.colors.hover.card} transition-all group`}>
                    <div className="flex items-center space-x-4">
                      <div className="flex-shrink-0">
                        <div className={`h-10 w-10 rounded-full bg-gradient-to-r ${
                          student.isDisabled
                            ? 'from-purple-500 to-pink-500'
                            : 'from-blue-500 to-indigo-500'
                        } flex items-center justify-center shadow-lg`}>
                          <span className="text-sm font-medium text-white">
                            {student.name ? student.name.split(' ').map(n => n[0]).join('').toUpperCase() : '?'}
                          </span>
                        </div>
                      </div>
                      <div>
                        <h4 className={`text-sm font-medium ${theme.colors.text.primary} group-hover:text-indigo-600 transition-colors`}>
                          {student.name || 'Unknown Student'}
                        </h4>
                        <p className={`text-sm ${theme.colors.text.secondary}`}>{student.email || 'No email'}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <span className={`text-xs ${theme.colors.text.tertiary}`}>{student.grade || 'No grade'}</span>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            student.isDisabled
                              ? theme.isDarkMode ? 'bg-purple-900/30 text-purple-300' : 'bg-purple-100 text-purple-700'
                              : theme.isDarkMode ? 'bg-green-900/30 text-green-300' : 'bg-green-100 text-green-700'
                          }`}>
                            {student.isDisabled ? 'Special Needs' : 'Regular'}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => handleRemoveStudent(student._id, student.name)}
                        className={`p-2 rounded-lg ${theme.colors.hover.card} text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20 transition-all opacity-0 group-hover:opacity-100`}
                        title="Remove student"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Create New Student Modal */}
      <Modal
        isOpen={showAddStudentModal}
        onClose={() => setShowAddStudentModal(false)}
        title="Create New Student"
        size="md"
      >
        <form onSubmit={handleSubmitNewStudent} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              name="name"
              value={studentForm.name}
              onChange={handleStudentFormChange}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
              placeholder="John Doe"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Email <span className="text-red-500">*</span>
            </label>
            <input
              type="email"
              name="email"
              value={studentForm.email}
              onChange={handleStudentFormChange}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
              placeholder="john@example.com"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Roll Number
            </label>
            <input
              type="text"
              name="rollNo"
              value={studentForm.rollNo}
              onChange={handleStudentFormChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
              placeholder="e.g., 2024001, A-101"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Grade <span className="text-red-500">*</span>
            </label>
            <select
              name="grade"
              value={studentForm.grade}
              onChange={handleStudentFormChange}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition appearance-none bg-white"
            >
              <option value="">Select Grade</option>
              {[...Array(12)].map((_, i) => (
                <option key={i} value={`${i+1}th`}>{i+1}th Grade</option>
              ))}
            </select>
          </div>
          
          <div className="flex items-center">
            <input
              type="checkbox"
              name="isDisabled"
              checked={studentForm.isDisabled}
              onChange={handleStudentFormChange}
              className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
            />
            <label className="ml-2 block text-sm text-gray-900">
              Student with disabilities
            </label>
          </div>
          
          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-sm text-yellow-700">
                  A default password will be generated and sent to the student's email.
                </p>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3 pt-4">
            <Button
              type="submit"
              className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-r from-green-500 via-blue-500 to-purple-600 text-white py-3 rounded-xl shadow-lg hover:scale-[1.02] hover:shadow-xl transition-all duration-300"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
              </svg>
              Add Student
            </Button>

            <Button
              type="button"
              onClick={() => setShowAddStudentModal(false)}
              className="flex-1 flex items-center justify-center gap-2 bg-white text-gray-800 py-3 rounded-xl border border-gray-300 hover:bg-gray-100 hover:scale-[1.02] transition-all duration-300"
            >
              <svg className="w-5 h-5 text-red-500" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              </svg>
              Cancel
            </Button>
          </div>
        </form>
      </Modal>

      {/* Add Existing Student Modal */}
      <Modal
        isOpen={showAddExistingStudentModal}
        onClose={() => setShowAddExistingStudentModal(false)}
        title="Add Existing Students"
        size="lg"
      >
        <div className="space-y-4">
          <p className="text-sm text-gray-600">
            Select students to add to this classroom. Only students not already enrolled are shown.
          </p>
          
          <div className="max-h-96 overflow-y-auto border border-gray-200 rounded-lg">
            {allStudents
              .filter(student => !students.some(s => s._id === student._id))
              .map((student) => (
                <div key={student._id} className="flex items-center space-x-3 p-3 hover:bg-gray-50 border-b border-gray-100 last:border-b-0">
                  <input
                    type="checkbox"
                    checked={selectedStudents.includes(student._id)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedStudents([...selectedStudents, student._id]);
                      } else {
                        setSelectedStudents(selectedStudents.filter(id => id !== student._id));
                      }
                    }}
                    className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                  />
                  <div className="flex-1">
                    <h4 className="text-sm font-medium text-gray-900">{student.name}</h4>
                    <p className="text-sm text-gray-500">{student.email}</p>
                    <div className="flex items-center space-x-2 mt-1">
                      <span className="text-xs text-gray-500">{student.grade}</span>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStudentTypeColor(student.isDisabled)}`}>
                        {student.isDisabled ? 'Disabled' : 'Regular'}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
          </div>

          {allStudents.filter(student => !students.some(s => s._id === student._id)).length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <p>All available students are already enrolled in this classroom.</p>
            </div>
          )}
          
          <div className="flex justify-end space-x-3 pt-4">
            <Button
              onClick={() => setShowAddExistingStudentModal(false)}
              className="bg-gray-100 text-gray-700 hover:bg-gray-200"
            >
              Cancel
            </Button>
            <Button
              onClick={handleAddExistingStudents}
              disabled={selectedStudents.length === 0}
              className="bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Add Selected Students ({selectedStudents.length})
            </Button>
          </div>
        </div>
      </Modal>

      {/* Remove Student Modal */}
      <Modal
        isOpen={showRemoveStudentModal}
        onClose={() => {
          setShowRemoveStudentModal(false);
          setStudentToRemove(null);
        }}
        title="Remove Student"
        size="md"
      >
        <div className="space-y-6">
          {studentToRemove && (
            <>
              <div className={`p-4 ${theme.colors.bg.tertiary} rounded-lg`}>
                <h3 className={`text-lg font-semibold ${theme.colors.text.primary} mb-2`}>
                  What would you like to do with "{studentToRemove.name}"?
                </h3>
                <p className={`text-sm ${theme.colors.text.secondary}`}>
                  Choose how you want to handle this student's removal.
                </p>
              </div>

              <div className="space-y-4">
                {/* Remove from Classroom Option */}
                <div className={`p-4 border-2 border-blue-200 rounded-lg ${theme.colors.bg.card} hover:border-blue-300 transition-colors`}>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mt-1">
                      <span className="text-blue-600 text-sm font-bold">1</span>
                    </div>
                    <div className="flex-1">
                      <h4 className={`font-semibold ${theme.colors.text.primary} mb-1`}>
                        Remove from Classroom Only
                      </h4>
                      <p className={`text-sm ${theme.colors.text.secondary} mb-3`}>
                        Remove the student from this classroom but keep their account. They can be added to other classrooms.
                      </p>
                      <Button
                        onClick={() => executeRemoveStudent(false)}
                        className={`${theme.colors.button.secondary} px-4 py-2 rounded-lg font-medium transition-all`}
                      >
                        Remove from Classroom
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Delete Completely Option */}
                <div className={`p-4 border-2 border-red-200 rounded-lg ${theme.colors.bg.card} hover:border-red-300 transition-colors`}>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-red-100 rounded-full flex items-center justify-center mt-1">
                      <span className="text-red-600 text-sm font-bold">2</span>
                    </div>
                    <div className="flex-1">
                      <h4 className={`font-semibold ${theme.colors.text.primary} mb-1`}>
                        Delete Permanently from Database
                      </h4>
                      <p className={`text-sm ${theme.colors.text.secondary} mb-2`}>
                        ⚠️ <strong>Warning:</strong> This will permanently delete the student account and all their data.
                      </p>
                      <ul className={`text-xs ${theme.colors.text.tertiary} mb-3 space-y-1`}>
                        <li>• Delete the student account completely</li>
                        <li>• Remove them from ALL classrooms</li>
                        <li>• Delete all their quiz attempts and data</li>
                        <li>• This action cannot be undone</li>
                      </ul>
                      <Button
                        onClick={() => {
                          if (window.confirm(`⚠️ Are you absolutely sure you want to PERMANENTLY DELETE "${studentToRemove.name}" from the database? This action cannot be undone!`)) {
                            executeRemoveStudent(true);
                          }
                        }}
                        className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg font-medium transition-all"
                      >
                        Delete Permanently
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-4 border-t">
                <Button
                  onClick={() => {
                    setShowRemoveStudentModal(false);
                    setStudentToRemove(null);
                  }}
                  className={`${theme.colors.button.secondary} px-4 py-2 rounded-lg font-medium`}
                >
                  Cancel
                </Button>
              </div>
            </>
          )}
        </div>
      </Modal>

      {/* Assign Quiz Modal - All Students */}
      <AssignQuiz
        isOpen={showAssignQuizModal}
        onClose={() => setShowAssignQuizModal(false)}
        classroom={classroom}
        onSuccess={handleQuizAssigned}
        title="Assign Quiz to All Students"
        targetStudents={students}
      />

      {/* Assign Quiz Modal - Normal Students */}
      <AssignQuiz
        isOpen={showAssignQuizToNormalModal}
        onClose={() => setShowAssignQuizToNormalModal(false)}
        classroom={{
          ...classroom,
          classType: 'normal' // Override to ensure normal settings
        }}
        onSuccess={handleQuizAssigned}
        title="Assign Quiz to Normal Students"
        targetStudents={getNormalStudents()}
        assignmentType="normal"
      />

      {/* Assign Quiz Modal - Students with Disabilities */}
      <AssignQuiz
        isOpen={showAssignQuizToDisabledModal}
        onClose={() => setShowAssignQuizToDisabledModal(false)}
        classroom={{
          ...classroom,
          classType: 'disabled' // Override to ensure accessibility settings
        }}
        onSuccess={handleQuizAssigned}
        title="Assign Quiz to Students with Disabilities"
        targetStudents={getDisabledStudents()}
        assignmentType="disabled"
      />
    </div>
  );
};

export default ClassroomStudentsPage; 