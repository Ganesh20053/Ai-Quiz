import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Button from '../components/common/Button';
import Loader from '../components/common/Loader';

const Quiz = () => {
  const { quizId, classroomId } = useParams();
  const navigate = useNavigate();
  const [quiz, setQuiz] = useState(null);
  const [classroom, setClassroom] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (quizId && classroomId) {
      fetchQuizAndClassroom();
    }
  }, [quizId, classroomId]);

  const fetchQuizAndClassroom = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      
      // Fetch classroom details
      const classroomResponse = await fetch(`/api/classroom/${classroomId}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!classroomResponse.ok) {
        throw new Error(`HTTP error! status: ${classroomResponse.status}`);
      }

      const classroomData = await classroomResponse.json();
      setClassroom(classroomData.data);
      
      // Fetch quiz details
      const quizResponse = await fetch(`/api/quizzes/${quizId}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!quizResponse.ok) {
        throw new Error(`HTTP error! status: ${quizResponse.status}`);
      }

      const quizData = await quizResponse.json();
      setQuiz(quizData.data);

    } catch (err) {
      setError(err.message);
      console.error('Error fetching quiz and classroom:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleEditQuiz = () => {
    navigate(`/staff/classrooms/${classroomId}/quizzes/${quizId}/edit`);
  };

  const handleAssignQuiz = () => {
    navigate(`/staff/classrooms/${classroomId}?tab=assignments&quizId=${quizId}`);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex justify-center items-center">
        <Loader size="lg" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex justify-center items-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Error</h2>
          <p className="text-gray-600 mb-4">{error}</p>
          <Button
            onClick={() => navigate('/staff/classrooms')}
            className="bg-indigo-600 text-white hover:bg-indigo-700"
          >
            Back to Classrooms
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div>
              <div className="flex items-center space-x-3">
                <Button
                  onClick={() => navigate(`/staff/classrooms/${classroomId}/quizzes`)}
                  className="bg-gray-100 text-gray-700 hover:bg-gray-200"
                >
                  ← Back to Quizzes
                </Button>
                <div>
                  <h1 className="text-3xl font-bold text-gray-900">
                    {quiz?.title || 'Quiz Details'}
                  </h1>
                  <p className="mt-1 text-sm text-gray-500">
                    {classroom?.name ? `Classroom: ${classroom.name}` : 'Loading classroom...'}
                  </p>
                </div>
              </div>
            </div>
            <div className="flex space-x-3">
              <Button
                onClick={handleEditQuiz}
                className="bg-indigo-600 text-white hover:bg-indigo-700"
              >
                Edit Quiz
              </Button>
              <Button
                onClick={handleAssignQuiz}
                className="bg-green-600 text-white hover:bg-green-700"
              >
                Assign Quiz
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {quiz && (
          <div className="space-y-8">
            {/* Quiz Information */}
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Quiz Information</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                  <p className="text-gray-900">{quiz.title}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Subject</label>
                  <p className="text-gray-900">{quiz.subject || 'Not specified'}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Grade Level</label>
                  <p className="text-gray-900">{quiz.grade || 'Not specified'}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    quiz.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                  }`}>
                    {quiz.isActive ? 'Active' : 'Inactive'}
                  </span>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Time Limit</label>
                  <p className="text-gray-900">{quiz.settings?.timeLimit || 'No limit'} minutes</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Passing Score</label>
                  <p className="text-gray-900">{quiz.settings?.passingScore || 'Not set'}%</p>
                </div>
              </div>
              {quiz.description && (
                <div className="mt-6">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                  <p className="text-gray-900">{quiz.description}</p>
                </div>
              )}
            </div>

            {/* Questions */}
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">
                Questions ({quiz.questions?.length || 0})
              </h2>
              {quiz.questions && quiz.questions.length > 0 ? (
                <div className="space-y-4">
                  {quiz.questions.map((question, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4">
                      <h3 className="font-medium text-gray-900 mb-2">
                        Question {index + 1}
                      </h3>
                      <p className="text-gray-700 mb-3">{question.question}</p>
                      
                      {question.type === 'multiple-choice' && question.options && (
                        <div className="space-y-2">
                          {question.options.map((option, optIndex) => (
                            <div key={optIndex} className="flex items-center space-x-2">
                              <span className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                                option.isCorrect 
                                  ? 'border-green-500 bg-green-500 text-white' 
                                  : 'border-gray-300'
                              }`}>
                                {option.isCorrect && '✓'}
                              </span>
                              <span className="text-gray-700">{option.text}</span>
                            </div>
                          ))}
                        </div>
                      )}
                      
                      {(question.type === 'true-false' || question.type === 'short-answer') && (
                        <div>
                          <p className="text-sm text-gray-600">
                            <strong>Correct Answer:</strong> {question.correctAnswer}
                          </p>
                        </div>
                      )}
                      
                      {question.explanation && (
                        <div className="mt-2 p-2 bg-blue-50 rounded">
                          <p className="text-sm text-blue-800">
                            <strong>Explanation:</strong> {question.explanation}
                          </p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500">No questions added to this quiz yet.</p>
              )}
            </div>

            {/* Quiz Statistics */}
            {quiz.submissions && quiz.submissions.length > 0 && (
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Quiz Statistics</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900">{quiz.submissions.length}</div>
                    <div className="text-sm text-gray-500">Total Submissions</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900">
                      {quiz.averageScore ? `${quiz.averageScore.toFixed(1)}%` : 'N/A'}
                    </div>
                    <div className="text-sm text-gray-500">Average Score</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900">
                      {quiz.completionRate ? `${quiz.completionRate.toFixed(1)}%` : 'N/A'}
                    </div>
                    <div className="text-sm text-gray-500">Completion Rate</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Quiz;
