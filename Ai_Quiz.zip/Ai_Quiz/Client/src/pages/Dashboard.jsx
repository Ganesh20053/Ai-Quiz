import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function Dashboard() {
  const nav = useNavigate();

  return (
    <div className="dashboard">
      <h1>Welcome to Quiz App</h1>
      <button onClick={() => nav('/quiz')}>Start Quiz</button>
    </div>
  );
}
