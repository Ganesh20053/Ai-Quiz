import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  Activity, Database, Zap, AlertCircle, CheckCircle, Clock, 
  TrendingUp, BarChart3, RefreshCw, Eye, Download, Filter
} from 'lucide-react';

const LogMonitoring = () => {
  const [geminiMetrics, setGeminiMetrics] = useState(null);
  const [quizMetrics, setQuizMetrics] = useState(null);
  const [logStats, setLogStats] = useState(null);
  const [recentLogs, setRecentLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedLogType, setSelectedLogType] = useState('combined');
  const [autoRefresh, setAutoRefresh] = useState(false);

  useEffect(() => {
    fetchAllData();
    
    let interval;
    if (autoRefresh) {
      interval = setInterval(fetchAllData, 30000); // Refresh every 30 seconds
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [autoRefresh]);

  const fetchAllData = async () => {
    try {
      const token = localStorage.getItem('token');
      const headers = { Authorization: `Bearer ${token}` };

      const [geminiRes, quizRes, statsRes, logsRes] = await Promise.all([
        axios.get('/api/logs/gemini-metrics', { headers }),
        axios.get('/api/logs/quiz-metrics', { headers }),
        axios.get('/api/logs/stats', { headers }),
        axios.get(`/api/logs/recent?type=${selectedLogType}&limit=50`, { headers })
      ]);

      setGeminiMetrics(geminiRes.data.data);
      setQuizMetrics(quizRes.data.data);
      setLogStats(statsRes.data.data);
      setRecentLogs(logsRes.data.data.entries);
    } catch (error) {
      console.error('Failed to fetch log data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatTime = (timeStr) => {
    if (!timeStr) return 'N/A';
    return timeStr.replace('ms', ' ms').replace('s', ' sec');
  };

  const getStatusColor = (errorRate) => {
    const rate = parseFloat(errorRate);
    if (rate < 5) return 'text-green-600';
    if (rate < 15) return 'text-yellow-600';
    return 'text-red-600';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="flex items-center gap-3">
          <RefreshCw className="w-6 h-6 animate-spin text-blue-600" />
          <span className="text-lg text-gray-600 dark:text-gray-300">Loading monitoring data...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">System Monitoring</h1>
            <p className="text-gray-600 dark:text-gray-400">Monitor Gemini API usage and quiz operations</p>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setAutoRefresh(!autoRefresh)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                autoRefresh 
                  ? 'bg-green-100 text-green-700 dark:bg-green-900/20 dark:text-green-300' 
                  : 'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300'
              }`}
            >
              <Activity className="w-4 h-4" />
              Auto Refresh {autoRefresh ? 'ON' : 'OFF'}
            </button>
            <button
              onClick={fetchAllData}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
              Refresh
            </button>
          </div>
        </div>

        {/* Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {/* Gemini API Status */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <Zap className="w-8 h-8 text-purple-600" />
                <h3 className="font-semibold text-gray-900 dark:text-white">Gemini API</h3>
              </div>
              <div className={`flex items-center gap-1 ${getStatusColor(geminiMetrics?.errorRate || '0%')}`}>
                {parseFloat(geminiMetrics?.errorRate || '0') < 5 ? (
                  <CheckCircle className="w-5 h-5" />
                ) : (
                  <AlertCircle className="w-5 h-5" />
                )}
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Total Requests</span>
                <span className="font-semibold text-gray-900 dark:text-white">
                  {geminiMetrics?.totalRequests || 0}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Error Rate</span>
                <span className={`font-semibold ${getStatusColor(geminiMetrics?.errorRate || '0%')}`}>
                  {geminiMetrics?.errorRate || '0%'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Avg Response</span>
                <span className="font-semibold text-gray-900 dark:text-white">
                  {formatTime(geminiMetrics?.avgResponseTime)}
                </span>
              </div>
            </div>
          </div>

          {/* Quiz Operations */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
            <div className="flex items-center gap-3 mb-4">
              <BarChart3 className="w-8 h-8 text-green-600" />
              <h3 className="font-semibold text-gray-900 dark:text-white">Quiz Operations</h3>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Total Quizzes</span>
                <span className="font-semibold text-gray-900 dark:text-white">
                  {quizMetrics?.totalQuizzes || 0}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">AI Generated</span>
                <span className="font-semibold text-blue-600">
                  {quizMetrics?.aiGeneratedQuizzes || 0}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Avg Questions</span>
                <span className="font-semibold text-gray-900 dark:text-white">
                  {quizMetrics?.avgQuestionsPerQuiz || '0'}
                </span>
              </div>
            </div>
          </div>

          {/* System Uptime */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
            <div className="flex items-center gap-3 mb-4">
              <Clock className="w-8 h-8 text-blue-600" />
              <h3 className="font-semibold text-gray-900 dark:text-white">System Status</h3>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Uptime</span>
                <span className="font-semibold text-gray-900 dark:text-white">
                  {formatTime(geminiMetrics?.uptime)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Log Entries</span>
                <span className="font-semibold text-gray-900 dark:text-white">
                  {logStats?.combined?.entries || 0}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Log Size</span>
                <span className="font-semibold text-gray-900 dark:text-white">
                  {logStats?.combined?.sizeFormatted || '0 Bytes'}
                </span>
              </div>
            </div>
          </div>

          {/* Performance */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
            <div className="flex items-center gap-3 mb-4">
              <TrendingUp className="w-8 h-8 text-orange-600" />
              <h3 className="font-semibold text-gray-900 dark:text-white">Performance</h3>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Success Rate</span>
                <span className="font-semibold text-green-600">
                  {geminiMetrics?.totalRequests > 0 
                    ? `${(100 - parseFloat(geminiMetrics.errorRate)).toFixed(1)}%`
                    : '100%'
                  }
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Total Questions</span>
                <span className="font-semibold text-gray-900 dark:text-white">
                  {quizMetrics?.totalQuestions || 0}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Syllabus Based</span>
                <span className="font-semibold text-purple-600">
                  {quizMetrics?.syllabusBasedQuizzes || 0}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Logs */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <Eye className="w-6 h-6 text-gray-600" />
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white">Recent Logs</h3>
            </div>
            <select
              value={selectedLogType}
              onChange={(e) => setSelectedLogType(e.target.value)}
              className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              <option value="combined">All Logs</option>
              <option value="gemini-api">Gemini API</option>
              <option value="quiz-operations">Quiz Operations</option>
              <option value="error">Errors Only</option>
            </select>
          </div>
          
          <div className="max-h-96 overflow-y-auto">
            {recentLogs.length > 0 ? (
              <div className="space-y-2">
                {recentLogs.map((log, index) => (
                  <div key={index} className="p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-gray-900 dark:text-white">
                        {log.level?.toUpperCase() || 'INFO'}
                      </span>
                      <span className="text-xs text-gray-500 dark:text-gray-400">
                        {new Date(log.timestamp).toLocaleString()}
                      </span>
                    </div>
                    <p className="text-sm text-gray-700 dark:text-gray-300">
                      {log.message || log.raw || 'No message'}
                    </p>
                    {log.service && (
                      <span className="inline-block mt-1 px-2 py-1 bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-300 text-xs rounded">
                        {log.service}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                No recent logs found
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default LogMonitoring;
