import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { ArrowLeft, Clock, BookOpen, User, AlertCircle, Mic, Volume2 } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import Button from '../components/common/Button';
import Loader from '../components/common/Loader';
import RegularQuiz from '../components/quiz/RegularQuiz';
import VoiceControlledQuiz from '../components/quiz/VoiceControlledQuiz';

const TakeQuizPage = () => {
  const { assignmentId } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const theme = useTheme();
  const user = useSelector(state => state.auth.user);
  const [searchParams] = useSearchParams();

  const [assignment, setAssignment] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [quizStarted, setQuizStarted] = useState(false);

  // Voice mode detection
  const isVoiceMode = searchParams.get('mode') === 'voice' || user?.isDisabled;
  const [voiceControlReady, setVoiceControlReady] = useState(false);

  useEffect(() => {
    fetchAssignment();
  }, [assignmentId]);

  const fetchAssignment = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/classroom/assignments/${assignmentId}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        setAssignment(data.assignment);
      } else {
        const errorData = await response.json();
        setError(errorData.message || 'Failed to load assignment');
      }
    } catch (err) {
      console.error('Error fetching assignment:', err);
      setError('Failed to load assignment. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleStartQuiz = () => {
    setQuizStarted(true);
  };

  const handleQuizComplete = (result) => {
    console.log('Quiz completed:', result);
    // Navigate back to assignments with success message
    navigate('/student/assignments', { 
      state: { 
        message: 'Quiz completed successfully!',
        type: 'success'
      }
    });
  };

  const handleQuizClose = () => {
    // Navigate back to assignments
    navigate('/student/assignments');
  };

  if (loading) {
    return (
      <div className={`min-h-screen ${theme.colors.bg.secondary} flex items-center justify-center`}>
        <div className="text-center">
          <Loader size="lg" />
          <p className={`mt-4 text-lg ${theme.colors.text.secondary}`}>
            Loading quiz...
          </p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={`min-h-screen ${theme.colors.bg.secondary} flex items-center justify-center`}>
        <div className="text-center max-w-md mx-auto p-6">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertCircle className="w-8 h-8 text-red-600" />
          </div>
          <h2 className={`text-2xl font-bold ${theme.colors.text.primary} mb-2`}>
            Error Loading Quiz
          </h2>
          <p className={`${theme.colors.text.secondary} mb-6`}>
            {error}
          </p>
          <div className="flex space-x-4 justify-center">
            <Button
              onClick={() => navigate('/student/assignments')}
              className={`${theme.colors.button.secondary} px-6 py-2 rounded-lg`}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Assignments
            </Button>
            <Button
              onClick={fetchAssignment}
              className={`${theme.colors.button.primary} px-6 py-2 rounded-lg`}
            >
              Try Again
            </Button>
          </div>
        </div>
      </div>
    );
  }

  if (!assignment) {
    return (
      <div className={`min-h-screen ${theme.colors.bg.secondary} flex items-center justify-center`}>
        <div className="text-center">
          <h2 className={`text-2xl font-bold ${theme.colors.text.primary}`}>
            Assignment not found
          </h2>
          <Button
            onClick={() => navigate('/student/assignments')}
            className={`${theme.colors.button.primary} px-6 py-2 rounded-lg mt-4`}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Assignments
          </Button>
        </div>
      </div>
    );
  }

  // If quiz is started, show the appropriate quiz component
  if (quizStarted) {
    return (
      <div className={`min-h-screen ${theme.colors.bg.secondary}`}>
        {isVoiceMode ? (
          <VoiceControlledQuiz
            quiz={assignment.quiz}
            assignment={assignment}
            onComplete={handleQuizComplete}
            onClose={handleQuizClose}
            isFullPage={true}
            user={user}
          />
        ) : (
          <RegularQuiz
            quiz={assignment.quiz}
            assignment={assignment}
            onComplete={handleQuizComplete}
            onClose={handleQuizClose}
            isFullPage={true}
          />
        )}
      </div>
    );
  }

  // Show quiz preview/start page
  return (
    <div className={`min-h-screen ${theme.colors.bg.secondary}`}>
      {/* Header */}
      <div className={`${theme.colors.bg.primary} shadow-sm border-b ${theme.colors.border.primary}`}>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Button
              onClick={() => navigate('/student/assignments')}
              className={`${theme.colors.button.secondary} p-2 rounded-lg`}
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className={`text-xl font-semibold ${theme.colors.text.primary}`}>
              Quiz Preview
            </h1>
            <div></div>
          </div>
        </div>
      </div>

      {/* Quiz Preview Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className={`${theme.colors.bg.primary} rounded-2xl shadow-lg p-8`}>
          {/* Quiz Header */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <BookOpen className="w-8 h-8 text-white" />
            </div>
            <h2 className={`text-3xl font-bold ${theme.colors.text.primary} mb-2`}>
              {assignment.quiz?.title || 'Quiz'}
            </h2>
            <p className={`text-lg ${theme.colors.text.secondary}`}>
              {assignment.classroom?.name}
            </p>
            {isVoiceMode && (
              <div className="mt-4 inline-flex items-center space-x-2 px-4 py-2 bg-purple-100 dark:bg-purple-900/30 rounded-full">
                <Mic className="w-5 h-5 text-purple-600" />
                <span className="text-purple-800 dark:text-purple-200 font-medium">
                  Voice Control Mode
                </span>
                <Volume2 className="w-5 h-5 text-purple-600" />
              </div>
            )}
          </div>

          {/* Quiz Details */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="text-center p-4 bg-blue-50 rounded-xl">
              <BookOpen className="w-8 h-8 text-blue-600 mx-auto mb-2" />
              <div className={`text-2xl font-bold ${theme.colors.text.primary}`}>
                {assignment.quiz?.questions?.length || 0}
              </div>
              <div className={`text-sm ${theme.colors.text.secondary}`}>
                Questions
              </div>
            </div>

            <div className="text-center p-4 bg-green-50 rounded-xl">
              <Clock className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <div className={`text-2xl font-bold ${theme.colors.text.primary}`}>
                {assignment.settings?.timeLimit || assignment.quiz?.timeLimit || 'No limit'}
              </div>
              <div className={`text-sm ${theme.colors.text.secondary}`}>
                {assignment.settings?.timeLimit || assignment.quiz?.timeLimit ? 'Minutes' : 'Time Limit'}
              </div>
            </div>

            <div className="text-center p-4 bg-purple-50 rounded-xl">
              <User className="w-8 h-8 text-purple-600 mx-auto mb-2" />
              <div className={`text-2xl font-bold ${theme.colors.text.primary}`}>
                {user?.name || 'Student'}
              </div>
              <div className={`text-sm ${theme.colors.text.secondary}`}>
                Taking Quiz
              </div>
            </div>
          </div>

          {/* Quiz Description */}
          {assignment.quiz?.description && (
            <div className="mb-8">
              <h3 className={`text-lg font-semibold ${theme.colors.text.primary} mb-3`}>
                Description
              </h3>
              <p className={`${theme.colors.text.secondary} leading-relaxed`}>
                {assignment.quiz.description}
              </p>
            </div>
          )}

          {/* Instructions */}
          {assignment.instructions && (
            <div className="mb-8">
              <h3 className={`text-lg font-semibold ${theme.colors.text.primary} mb-3`}>
                Instructions
              </h3>
              <p className={`${theme.colors.text.secondary} leading-relaxed`}>
                {assignment.instructions}
              </p>
            </div>
          )}

          {/* Due Date */}
          {assignment.settings?.dueDate && (
            <div className="mb-8 p-4 bg-yellow-50 rounded-xl border border-yellow-200">
              <div className="flex items-center">
                <Clock className="w-5 h-5 text-yellow-600 mr-2" />
                <span className={`font-medium ${theme.colors.text.primary}`}>
                  Due Date: {new Date(assignment.settings.dueDate).toLocaleDateString()}
                </span>
              </div>
            </div>
          )}

          {/* Voice Mode Instructions */}
          {isVoiceMode && (
            <div className="mb-8 p-6 bg-purple-50 dark:bg-purple-900/20 rounded-xl border border-purple-200 dark:border-purple-700">
              <h3 className="text-lg font-semibold text-purple-800 dark:text-purple-200 mb-4 flex items-center">
                <Mic className="w-5 h-5 mr-2" />
                Voice Control Instructions
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <h4 className="font-medium text-purple-700 dark:text-purple-300 mb-2">Navigation Commands:</h4>
                  <ul className="space-y-1 text-purple-600 dark:text-purple-400">
                    <li>• "next question" - Move to next question</li>
                    <li>• "previous question" - Go back to previous</li>
                    <li>• "repeat question" - Hear question again</li>
                    <li>• "skip question" - Skip current question</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium text-purple-700 dark:text-purple-300 mb-2">Answer Commands:</h4>
                  <ul className="space-y-1 text-purple-600 dark:text-purple-400">
                    <li>• "select option A" - Choose option A</li>
                    <li>• "select option B" - Choose option B</li>
                    <li>• "select option C" - Choose option C</li>
                    <li>• "select option D" - Choose option D</li>
                  </ul>
                </div>
              </div>
              <div className="mt-4 p-3 bg-purple-100 dark:bg-purple-800/30 rounded">
                <p className="text-sm text-purple-700 dark:text-purple-300">
                  <strong>Quiz Control:</strong> Say "submit quiz" to finish, "help" for more commands, or "stop listening" to pause voice control.
                </p>
              </div>
            </div>
          )}

          {/* Start Quiz Button */}
          <div className="text-center">
            <Button
              onClick={handleStartQuiz}
              className={`${isVoiceMode
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700'
                : 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700'
              } text-white px-8 py-4 rounded-xl text-lg font-semibold transition-all transform hover:scale-105 shadow-lg flex items-center space-x-2 mx-auto`}
            >
              {isVoiceMode && <Mic className="w-5 h-5" />}
              <span>{isVoiceMode ? 'Start Voice-Controlled Quiz' : 'Start Quiz'}</span>
              {isVoiceMode && <Volume2 className="w-5 h-5" />}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TakeQuizPage;
