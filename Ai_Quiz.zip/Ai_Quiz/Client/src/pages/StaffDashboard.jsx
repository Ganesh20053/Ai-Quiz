import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { logoutUser } from '../features/auth/authSlice';
import { selectUser } from '../features/auth/authSlice';
import { fetchClassrooms } from '../features/classroom/classroomSlice';
import Button from '../components/common/Button';
import Loader from '../components/common/Loader';
import ClassroomList from '../components/classroom/ClassroomList';
import QuizCreator from '../components/quiz/QuizCreator';
import AddClassroom from '../features/classroom/AddClassroom';
import AssignQuiz from '../features/classroom/AssignQuiz';
import StudentList from '../features/classroom/StudentList';
import EditAssignmentModal from '../components/assignment/EditAssignmentModal';
import ThemeToggle from '../components/common/ThemeToggle';
import { useTheme } from '../contexts/ThemeContext';
import {
  Users, BookOpen, TrendingUp, Award, Plus, Settings,
  BarChart3, Calendar, Clock, Star, ArrowRight, Eye,
  PieChart, Activity, Target, Zap, Globe, Bell, Trash2
} from 'lucide-react';

const StaffDashboard = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const user = useSelector(selectUser);
  const { classrooms, loading, error } = useSelector(state => state.classroom);
  const theme = useTheme();

  const [isLoading, setIsLoading] = useState(false);
  const [showAddStudentModal, setShowAddStudentModal] = useState(false);
  const [showAddClassroomModal, setShowAddClassroomModal] = useState(false);
  const [showAssignQuizModal, setShowAssignQuizModal] = useState(false);
  const [showQuizCreator, setShowQuizCreator] = useState(false);
  const [selectedClassroom, setSelectedClassroom] = useState(null);
  const [currentView, setCurrentView] = useState('dashboard');
  const [stats, setStats] = useState({
    totalStudents: 0,
    activeQuizzes: 0,
    completedQuizzes: 0,
    averageScore: 0,
    totalClassrooms: 0
  });
  const [assignedQuizzes, setAssignedQuizzes] = useState([]);
  const [loadingAssignments, setLoadingAssignments] = useState(false);
  const [showEditAssignmentModal, setShowEditAssignmentModal] = useState(false);
  const [selectedAssignment, setSelectedAssignment] = useState(null);
  const [studentForm, setStudentForm] = useState({
    name: '',
    email: '',
    rollNo: '',
    grade: '',
    isDisabled: false
  });

  // Get the classrooms array from the state structure
  const classroomsArray = classrooms?.all || [];

  useEffect(() => {
    // Fetch classrooms when component mounts
    if (user?.id) {
      dispatch(fetchClassrooms(user.id));
    }
  }, [dispatch, user?.id]);

  useEffect(() => {
    fetchDashboardStats();
  }, [classroomsArray]);

  useEffect(() => {
    if (currentView === 'assignments') {
      fetchAssignedQuizzes();
    }
  }, [currentView]);

  const fetchDashboardStats = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/classroom/stats', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        if (data.success) {
          setStats(data.data);
        }
      }
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
    }
  };

  const handleLogout = async () => {
    setIsLoading(true);
    try {
      await dispatch(logoutUser()).unwrap();
    } catch (error) {
      console.error('Logout failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddStudent = () => {
    setShowAddStudentModal(true);
  };

  const handleAddClassroom = () => {
    setShowAddClassroomModal(true);
  };

  const handleClassroomSelect = (classroom) => {
    setSelectedClassroom(classroom);
    setShowAssignQuizModal(true);
  };

  const handleCreateClassroom = () => {
    setCurrentView('classrooms');
  };

  const handleQuizCreated = (quiz) => {
    setShowQuizCreator(false);
    setSelectedClassroom(null);
    console.log('Quiz created:', quiz);
  };

  const handleStudentFormChange = (e) => {
    const { name, value, type, checked } = e.target;
    setStudentForm(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmitStudent = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/auth/students', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          ...studentForm,
          role: 'student',
          password: 'defaultPassword123' // This should be generated server-side
        })
      });

      if (response.ok) {
        const data = await response.json();
        console.log('Student added:', data);
    setShowAddStudentModal(false);
    setStudentForm({ name: '', email: '', rollNo: '', grade: '', isDisabled: false });
        // Refresh dashboard stats
        fetchDashboardStats();
      } else {
        const errorData = await response.json();
        alert(`Failed to add student: ${errorData.message}`);
      }
    } catch (error) {
      console.error('Error adding student:', error);
      alert('Failed to add student. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleClassroomCreated = (classroom) => {
    setShowAddClassroomModal(false);
    setCurrentView('classrooms');
    fetchDashboardStats();
  };

  const handleQuizAssigned = (assignment) => {
    setShowAssignQuizModal(false);
    setSelectedClassroom(null);
    console.log('Quiz assigned:', assignment);
    fetchAssignedQuizzes(); // Refresh the assignments list
  };

  // Fetch assigned quizzes
  const fetchAssignedQuizzes = async () => {
    setLoadingAssignments(true);
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/classroom/assignments', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        setAssignedQuizzes(data.assignments || []);
      } else {
        console.error('Failed to fetch assigned quizzes');
      }
    } catch (error) {
      console.error('Error fetching assigned quizzes:', error);
    } finally {
      setLoadingAssignments(false);
    }
  };

  // Delete assignment
  const handleDeleteAssignment = async (assignmentId) => {
    if (!window.confirm('Are you sure you want to delete this assignment? This action cannot be undone.')) {
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/classroom/assignments/${assignmentId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        alert('Assignment deleted successfully!');
        fetchAssignedQuizzes(); // Refresh the list
      } else {
        const errorData = await response.json();
        alert(`Failed to delete assignment: ${errorData.message || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error deleting assignment:', error);
      alert('Failed to delete assignment. Please try again.');
    }
  };

  // Edit assignment
  const handleEditAssignment = (assignment) => {
    setSelectedAssignment(assignment);
    setShowEditAssignmentModal(true);
  };

  // Handle assignment save
  const handleAssignmentSave = (updatedAssignment) => {
    setShowEditAssignmentModal(false);
    setSelectedAssignment(null);
    fetchAssignedQuizzes(); // Refresh the list
    alert('Assignment updated successfully!');
  };

  // Quick actions buttons data
  const quickActions = [
    {
      id: 'manage-classrooms',
      onClick: () => navigate('/staff/classrooms'),
      icon: (
        <svg className="w-6 h-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
        </svg>
      ),
      label: 'Manage Classrooms',
      bgColor: 'bg-indigo-50',
      hoverColor: 'hover:bg-indigo-100',
      iconBg: 'bg-indigo-100'
    },
    {
      id: 'manage-students',
      onClick: () => setCurrentView('students'),
      icon: (
        <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z" />
        </svg>
      ),
      label: 'Manage Students',
      bgColor: 'bg-blue-50',
      hoverColor: 'hover:bg-blue-100',
      iconBg: 'bg-blue-100'
    },
    {
      id: 'add-student',
      onClick: handleAddStudent,
      icon: (
        <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
        </svg>
      ),
      label: 'Add Student',
      bgColor: 'bg-green-50',
      hoverColor: 'hover:bg-green-100',
      iconBg: 'bg-green-100'
    },
    {
      id: 'create-classroom',
      onClick: handleAddClassroom,
      icon: (
        <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
        </svg>
      ),
      label: 'Create Classroom',
      bgColor: 'bg-purple-50',
      hoverColor: 'hover:bg-purple-100',
      iconBg: 'bg-purple-100'
    }
  ];

  return (
    <div className={`min-h-screen ${theme.colors.bg.secondary} transition-colors duration-300`}>
      {/* Enhanced Header */}
      <header className={`${theme.colors.bg.primary} ${theme.shadows.md} ${theme.colors.border.primary} border-b backdrop-blur-lg bg-opacity-95 sticky top-0 z-50`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-6">
              {/* Logo and Title */}
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                <div>
                  <span className="text-xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                    QuizMaster Pro
                  </span>
                  <span className={`ml-3 px-3 py-1 rounded-full text-xs font-medium ${theme.isDarkMode ? 'bg-indigo-900/30 text-indigo-300' : 'bg-indigo-100 text-indigo-800'}`}>
                    STAFF PORTAL
                  </span>
                </div>
              </div>

              {/* Navigation Tabs */}
              <div className={`hidden md:flex space-x-1 ${theme.isDarkMode ? 'bg-gray-800' : 'bg-gray-100'} rounded-lg p-1`}>
                {[
                  { key: 'dashboard', label: 'Dashboard', icon: BarChart3 },
                  { key: 'classrooms', label: 'Classrooms', icon: BookOpen },
                  { key: 'students', label: 'Students', icon: Users },
                  { key: 'assignments', label: 'Assignments', icon: Award }
                ].map(({ key, label, icon: Icon }) => (
                  <button
                    key={key}
                    onClick={() => setCurrentView(key)}
                    className={`
                      flex items-center gap-2 px-4 py-2 rounded-md font-medium text-sm transition-all duration-200
                      ${currentView === key
                        ? `${theme.isDarkMode ? 'bg-gray-700 text-indigo-400' : 'bg-white text-indigo-600'} shadow-md`
                        : `${theme.colors.text.secondary} hover:${theme.colors.text.primary} ${theme.colors.hover.card}`
                      }
                    `}
                  >
                    <Icon className="w-4 h-4" />
                    {label}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center space-x-4">
              {/* Theme Toggle */}
              <ThemeToggle size="sm" />

              {/* Notifications */}
              <button className={`p-2 rounded-lg ${theme.colors.hover.card} transition-all relative`}>
                <Bell className={`w-5 h-5 ${theme.colors.text.secondary}`} />
                <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></span>
              </button>

              {/* User Profile Dropdown */}
              <div className="relative group">
                <div className="flex items-center gap-3 cursor-pointer">
                  <div className="hidden sm:block text-right">
                    <p className={`text-sm font-medium ${theme.colors.text.primary}`}>
                      {user?.name}
                    </p>
                    <p className={`text-xs ${theme.colors.text.tertiary}`}>
                      Staff Member
                    </p>
                  </div>
                  <div className="w-10 h-10 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full flex items-center justify-center shadow-lg">
                    <span className="text-white font-semibold">
                      {user?.name?.charAt(0).toUpperCase()}
                    </span>
                  </div>
                </div>

                {/* Dropdown Menu */}
                <div className={`absolute right-0 mt-2 w-56 ${theme.colors.bg.card} rounded-xl ${theme.shadows.lg} ${theme.colors.border.primary} border py-2 z-50 invisible group-hover:visible transition-all duration-200 transform scale-95 group-hover:scale-100`}>
                  <div className={`px-4 py-3 border-b ${theme.colors.border.light}`}>
                    <p className={`text-sm font-medium ${theme.colors.text.primary}`}>
                      {user?.name}
                    </p>
                    <p className={`text-xs ${theme.colors.text.tertiary}`}>
                      {user?.email}
                    </p>
                  </div>

                  <div className="py-1">
                    <button className={`w-full text-left px-4 py-2 text-sm ${theme.colors.text.secondary} hover:${theme.colors.text.primary} ${theme.colors.hover.card} flex items-center gap-3`}>
                      <Settings className="w-4 h-4" />
                      Settings
                    </button>
                    <button className={`w-full text-left px-4 py-2 text-sm ${theme.colors.text.secondary} hover:${theme.colors.text.primary} ${theme.colors.hover.card} flex items-center gap-3`}>
                      <Activity className="w-4 h-4" />
                      Activity Log
                    </button>
                  </div>

                  <div className={`border-t ${theme.colors.border.light} pt-1`}>
                    <button
                      onClick={handleLogout}
                      className={`w-full text-left px-4 py-2 text-sm text-red-600 hover:text-red-700 ${theme.colors.hover.card} flex items-center gap-3`}
                    >
                      {isLoading ? (
                        <>
                          <div className="w-4 h-4 border-2 border-red-600 border-t-transparent rounded-full animate-spin"></div>
                          Signing out...
                        </>
                      ) : (
                        <>
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                          </svg>
                          Sign out
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Enhanced Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Dashboard View */}
        {currentView === 'dashboard' && (
          <>
            {/* Enhanced Welcome Banner */}
            <div className={`${theme.gradients.primary} rounded-2xl ${theme.shadows.xl} overflow-hidden mb-8 relative`}>
              <div className="absolute inset-0 bg-black/10"></div>
              <div className="relative p-8 md:p-12">
                <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                        <Star className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h1 className="text-3xl md:text-4xl font-bold text-white mb-1">
                          Welcome back, {user?.name}!
                        </h1>
                        <p className="text-white/80 text-lg">
                          Ready to inspire minds today?
                        </p>
                      </div>
                    </div>
                    <p className="text-white/90 max-w-2xl text-lg leading-relaxed">
                      You have <span className="font-semibold text-white">{stats.activeQuizzes} active quizzes</span> and
                      <span className="font-semibold text-white"> {stats.totalStudents} students</span> enrolled across
                      <span className="font-semibold text-white"> {stats.totalClassrooms} classrooms</span>.
                    </p>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-3">
                    <Button
                      onClick={handleAddStudent}
                      className="bg-white/20 backdrop-blur-sm text-white border border-white/30 hover:bg-white/30 px-6 py-3 rounded-xl font-semibold transition-all transform hover:scale-105 flex items-center gap-2"
                    >
                      <Plus className="w-5 h-5" />
                      Add Student
                    </Button>
                    <Button
                      onClick={() => navigate('/staff/classrooms')}
                      className="bg-white text-indigo-600 hover:bg-gray-50 px-6 py-3 rounded-xl font-semibold transition-all transform hover:scale-105 flex items-center gap-2 shadow-lg"
                    >
                      <BookOpen className="w-5 h-5" />
                      Manage Classrooms
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            {/* Enhanced Statistics Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {[
                {
                  title: 'Total Students',
                  value: stats.totalStudents,
                  icon: Users,
                  color: 'blue',
                  gradient: 'from-blue-500 to-cyan-500',
                  bgColor: theme.isDarkMode ? 'bg-blue-900/20' : 'bg-blue-50',
                  change: '+12%',
                  changeType: 'increase'
                },
                {
                  title: 'Active Quizzes',
                  value: stats.activeQuizzes,
                  icon: BookOpen,
                  color: 'green',
                  gradient: 'from-green-500 to-emerald-500',
                  bgColor: theme.isDarkMode ? 'bg-green-900/20' : 'bg-green-50',
                  change: '+8%',
                  changeType: 'increase'
                },
                {
                  title: 'Total Classrooms',
                  value: stats.totalClassrooms,
                  icon: Globe,
                  color: 'purple',
                  gradient: 'from-purple-500 to-pink-500',
                  bgColor: theme.isDarkMode ? 'bg-purple-900/20' : 'bg-purple-50',
                  change: '+3%',
                  changeType: 'increase'
                },
                {
                  title: 'Average Score',
                  value: `${stats.averageScore}%`,
                  icon: TrendingUp,
                  color: 'orange',
                  gradient: 'from-orange-500 to-red-500',
                  bgColor: theme.isDarkMode ? 'bg-orange-900/20' : 'bg-orange-50',
                  change: '+5%',
                  changeType: 'increase'
                }
              ].map((stat, index) => (
                <div
                  key={index}
                  className={`${theme.colors.bg.card} rounded-2xl ${theme.shadows.lg} ${theme.colors.border.primary} border overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:scale-105 group`}
                >
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className={`p-3 rounded-xl ${stat.bgColor} group-hover:scale-110 transition-transform duration-300`}>
                        <stat.icon className={`w-6 h-6 text-${stat.color}-600`} />
                      </div>
                      <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                        stat.changeType === 'increase'
                          ? theme.isDarkMode ? 'bg-green-900/30 text-green-300' : 'bg-green-100 text-green-700'
                          : theme.isDarkMode ? 'bg-red-900/30 text-red-300' : 'bg-red-100 text-red-700'
                      }`}>
                        {stat.change}
                      </div>
                    </div>

                    <div>
                      <p className={`text-sm font-medium ${theme.colors.text.secondary} mb-1`}>
                        {stat.title}
                      </p>
                      <p className={`text-3xl font-bold ${theme.colors.text.primary} mb-2`}>
                        {stat.value}
                      </p>
                      <div className={`w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2`}>
                        <div
                          className={`bg-gradient-to-r ${stat.gradient} h-2 rounded-full transition-all duration-1000 ease-out`}
                          style={{ width: `${Math.min((stat.value / 100) * 100, 100)}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Enhanced Quick Actions */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <div className={`${theme.colors.bg.card} rounded-2xl ${theme.shadows.lg} overflow-hidden ${theme.colors.border.primary} border`}>
                  <div className={`px-6 py-4 ${theme.colors.border.light} border-b flex justify-between items-center`}>
                    <div className="flex items-center gap-3">
                      <Activity className={`w-5 h-5 ${theme.colors.text.primary}`} />
                      <h3 className={`text-lg font-semibold ${theme.colors.text.primary}`}>Recent Activities</h3>
                    </div>
                    <button
                      onClick={() => navigate('/staff/classrooms')}
                      className={`text-sm font-medium text-indigo-600 hover:text-indigo-500 flex items-center gap-2 px-3 py-1 rounded-lg ${theme.colors.hover.card} transition-all`}
                    >
                      View All Classrooms
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                  <div className={`divide-y ${theme.colors.border.light}`}>
                    {loading ? (
                      <div className="p-8 text-center">
                        <Loader size="lg" />
                        <p className={`mt-4 ${theme.colors.text.secondary}`}>Loading activities...</p>
                      </div>
                    ) : classroomsArray.length === 0 ? (
                      <div className="p-8 text-center">
                        <div className={`w-16 h-16 mx-auto mb-4 ${theme.colors.bg.tertiary} rounded-full flex items-center justify-center`}>
                          <BookOpen className={`w-8 h-8 ${theme.colors.text.tertiary}`} />
                        </div>
                        <p className={`${theme.colors.text.secondary} mb-4`}>
                          No recent activities. Create your first classroom to get started.
                        </p>
                        <Button
                          onClick={() => navigate('/staff/classrooms')}
                          className={`${theme.colors.button.primary} px-4 py-2 rounded-lg font-medium`}
                        >
                          Create Classroom
                        </Button>
                      </div>
                    ) : (
                      classroomsArray.slice(0, 3).map((classroom) => (
                        <div key={`activity-${classroom._id}`} className={`p-6 ${theme.colors.hover.card} transition-all cursor-pointer group`}>
                          <div className="flex items-start justify-between">
                        <div className="flex-shrink-0">
                          <div className="p-2 bg-blue-100 rounded-full">
                            <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                            </svg>
                          </div>
                        </div>
                        <div className="ml-4 flex-1">
                          <div className="flex items-center justify-between">
                                <p className="text-sm font-medium text-gray-900">{classroom.name}</p>
                                <p className="text-xs text-gray-500">
                                  {new Date(classroom.createdAt).toLocaleDateString()}
                                </p>
                          </div>
                              <p className="text-sm text-gray-500">{classroom.subject} • {classroom.grade}</p>
                              <div className="mt-2">
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                  {classroom.students?.length || 0} students
                            </span>
                          </div>
                        </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>

              {/* Quick Actions */}
              <div>
                <div className="bg-white rounded-xl shadow-md overflow-hidden">
                  <div className="px-6 py-4 border-b border-gray-200">
                    <h3 className="text-lg font-semibold text-gray-900">Quick Actions</h3>
                  </div>
                  <div className="p-6 grid grid-cols-2 gap-4">
                    {quickActions.map((action) => (
                    <Button 
                        key={action.id}
                        onClick={action.onClick}
                        className={`flex flex-col items-center justify-center p-4 ${action.bgColor} rounded-lg ${action.hoverColor} transition-colors`}
                      >
                        <div className={`p-3 ${action.iconBg} rounded-full mb-2`}>
                          {action.icon}
                      </div>
                        <span className="text-sm font-medium text-gray-900">{action.label}</span>
                    </Button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </>
        )}

        {/* Classrooms View */}
        {currentView === 'classrooms' && (
          <ClassroomList
            onClassroomSelect={handleClassroomSelect}
            onCreateClassroom={handleAddClassroom}
          />
        )}

        {/* Students View */}
        {currentView === 'students' && (
          <StudentList />
        )}

        {/* Assignments View */}
        {currentView === 'assignments' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="mb-8">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className={`text-3xl font-bold ${theme.colors.text.primary}`}>
                    Quiz Assignments
                  </h2>
                  <p className={`mt-2 ${theme.colors.text.secondary}`}>
                    Manage all your quiz assignments across classrooms
                  </p>
                </div>
                <div className="flex items-center space-x-4">
                  <Button
                    onClick={() => fetchAssignedQuizzes()}
                    className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors"
                  >
                    <Activity className="w-4 h-4" />
                    Refresh
                  </Button>
                </div>
              </div>
            </div>

            {loadingAssignments ? (
              <div className="flex justify-center items-center h-64">
                <Loader size="lg" />
              </div>
            ) : assignedQuizzes.length === 0 ? (
              <div className={`text-center py-12 ${theme.colors.bg.primary} rounded-2xl border ${theme.colors.border.light}`}>
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className={`text-xl font-semibold ${theme.colors.text.primary} mb-2`}>
                  No Quiz Assignments Yet
                </h3>
                <p className={`${theme.colors.text.secondary} mb-6`}>
                  Start by assigning quizzes to your classrooms to see them here.
                </p>
                <Button
                  onClick={() => setCurrentView('classrooms')}
                  className="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition-colors"
                >
                  Go to Classrooms
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                {assignedQuizzes.map((assignment) => (
                  <div
                    key={assignment._id}
                    className={`${theme.colors.bg.primary} rounded-2xl shadow-lg border ${theme.colors.border.light} overflow-hidden hover:shadow-xl transition-all duration-300`}
                  >
                    {/* Assignment Header */}
                    <div className="bg-gradient-to-r from-indigo-500 to-purple-600 p-6 text-white">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="text-lg font-bold mb-1 line-clamp-2">
                            {assignment.quiz?.title || 'Untitled Quiz'}
                          </h3>
                          <p className="text-indigo-100 text-sm">
                            {assignment.classroom?.name || 'Unknown Classroom'}
                          </p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => handleEditAssignment(assignment)}
                            className="p-2 text-white hover:bg-white/20 rounded-lg transition-colors"
                            title="Edit Assignment"
                          >
                            <Settings className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteAssignment(assignment._id)}
                            className="p-2 text-white hover:bg-red-500/20 rounded-lg transition-colors"
                            title="Delete Assignment"
                          >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Assignment Details */}
                    <div className="p-6">
                      <div className="space-y-4">
                        {/* Quiz Info */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <BookOpen className="w-4 h-4 text-indigo-600" />
                            <span className={`text-sm ${theme.colors.text.secondary}`}>Questions</span>
                          </div>
                          <span className={`font-semibold ${theme.colors.text.primary}`}>
                            {assignment.quiz?.questions?.length || 0}
                          </span>
                        </div>

                        {/* Due Date */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Calendar className="w-4 h-4 text-green-600" />
                            <span className={`text-sm ${theme.colors.text.secondary}`}>Due Date</span>
                          </div>
                          <span className={`font-semibold ${theme.colors.text.primary}`}>
                            {assignment.dueDate
                              ? new Date(assignment.dueDate).toLocaleDateString()
                              : 'No due date'
                            }
                          </span>
                        </div>

                        {/* Time Limit */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Clock className="w-4 h-4 text-orange-600" />
                            <span className={`text-sm ${theme.colors.text.secondary}`}>Time Limit</span>
                          </div>
                          <span className={`font-semibold ${theme.colors.text.primary}`}>
                            {assignment.timeLimit ? `${assignment.timeLimit} min` : 'No limit'}
                          </span>
                        </div>

                        {/* Students Count */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Users className="w-4 h-4 text-blue-600" />
                            <span className={`text-sm ${theme.colors.text.secondary}`}>Students</span>
                          </div>
                          <span className={`font-semibold ${theme.colors.text.primary}`}>
                            {assignment.classroom?.students?.length || 0}
                          </span>
                        </div>

                        {/* Status */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Activity className="w-4 h-4 text-purple-600" />
                            <span className={`text-sm ${theme.colors.text.secondary}`}>Status</span>
                          </div>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            assignment.isActive
                              ? 'bg-green-100 text-green-800'
                              : 'bg-gray-100 text-gray-800'
                          }`}>
                            {assignment.isActive ? 'Active' : 'Inactive'}
                          </span>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="mt-6 flex space-x-3">
                        <Button
                          onClick={() => handleEditAssignment(assignment)}
                          className="flex-1 bg-indigo-50 text-indigo-700 py-2 px-4 rounded-lg hover:bg-indigo-100 transition-colors text-sm font-medium"
                        >
                          Edit
                        </Button>
                        <Button
                          onClick={() => handleDeleteAssignment(assignment._id)}
                          className="flex-1 bg-red-50 text-red-700 py-2 px-4 rounded-lg hover:bg-red-100 transition-colors text-sm font-medium"
                        >
                          Delete
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>

      {/* Add Student Modal */}
      {showAddStudentModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden">
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-6 text-white">
              <h3 className="text-xl font-bold">Add New Student</h3>
              <p className="text-indigo-100">Fill in the student details below</p>
            </div>
            <form onSubmit={handleSubmitStudent} className="p-6 space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                  Full Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={studentForm.name}
                  onChange={handleStudentFormChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                  placeholder="John Doe"
                />
              </div>
              
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  Email Address <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={studentForm.email}
                  onChange={handleStudentFormChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                  placeholder="john@example.com"
                />
              </div>
              
              <div>
                <label htmlFor="rollNo" className="block text-sm font-medium text-gray-700 mb-1">
                  Roll Number <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="rollNo"
                  name="rollNo"
                  value={studentForm.rollNo}
                  onChange={handleStudentFormChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                  placeholder="2023-001"
                />
              </div>
              
              <div>
                <label htmlFor="grade" className="block text-sm font-medium text-gray-700 mb-1">
                  Grade <span className="text-red-500">*</span>
                </label>
                <select
                  id="grade"
                  name="grade"
                  value={studentForm.grade}
                  onChange={handleStudentFormChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition appearance-none bg-white"
                >
                  <option value="">Select Grade</option>
                  {[...Array(12)].map((_, i) => (
                    <option key={`grade-${i}`} value={`${i+1}th`}>{i+1}th Grade</option>
                  ))}
                </select>
              </div>
              
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="isDisabled"
                  name="isDisabled"
                  checked={studentForm.isDisabled}
                  onChange={handleStudentFormChange}
                  className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                />
                <label htmlFor="isDisabled" className="ml-2 block text-sm text-gray-900">
                  Student with disabilities
                </label>
              </div>
              
              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <svg className="h-5 w-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm text-yellow-700">
                      A default password will be generated and sent to the student's email.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-3 pt-4">
  <Button
    type="submit"
                  disabled={isLoading}
                  className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-r from-green-500 via-blue-500 to-purple-600 text-white py-3 rounded-xl shadow-lg hover:scale-[1.02] hover:shadow-xl transition-all duration-300 disabled:opacity-50"
  >
                  {isLoading ? (
                    <Loader size="sm" />
                  ) : (
                    <>
    <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
    </svg>
    Add Student
                    </>
                  )}
  </Button>

  <Button
    type="button"
    onClick={() => setShowAddStudentModal(false)}
    className="flex-1 flex items-center justify-center gap-2 bg-white text-gray-800 py-3 rounded-xl border border-gray-300 hover:bg-gray-100 hover:scale-[1.02] transition-all duration-300"
  >
    <svg className="w-5 h-5 text-red-500" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
    Cancel
  </Button>
</div>
            </form>
          </div>
        </div>
      )}

      {/* Add Classroom Modal */}
      <AddClassroom
        isOpen={showAddClassroomModal}
        onClose={() => setShowAddClassroomModal(false)}
        onSuccess={handleClassroomCreated}
      />

      {/* Assign Quiz Modal */}
      <AssignQuiz
        isOpen={showAssignQuizModal}
        onClose={() => setShowAssignQuizModal(false)}
        classroom={selectedClassroom}
        onSuccess={handleQuizAssigned}
      />

      {/* Quiz Creator Modal */}
      {showQuizCreator && selectedClassroom && (
        <QuizCreator
          classroom={selectedClassroom}
          onQuizCreated={handleQuizCreated}
          onClose={() => {
            setShowQuizCreator(false)
            setSelectedClassroom(null)
          }}
        />
      )}

      {/* Edit Assignment Modal */}
      <EditAssignmentModal
        isOpen={showEditAssignmentModal}
        onClose={() => {
          setShowEditAssignmentModal(false);
          setSelectedAssignment(null);
        }}
        assignment={selectedAssignment}
        onSave={handleAssignmentSave}
      />
    </div>
  );
};

export default StaffDashboard;