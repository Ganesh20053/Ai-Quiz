import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../../api/auth.js';
import {
  Plus, Search, Filter, Eye, Edit3, Trash2, Clock, Users,
  BookOpen, Award, Calendar, ChevronDown, MoreVertical,
  Brain, Sparkles, Globe, CheckCircle, XCircle, AlertCircle,
  ArrowLeft, RefreshCw, Download, Share2, Copy, Settings,
  BarChart3, TrendingUp, Star, Zap
} from 'lucide-react';

const ClassroomQuizzes = () => {
  const { classroomId } = useParams();
  const navigate = useNavigate();

  // State management
  const [quizzes, setQuizzes] = useState([]);
  const [filteredQuizzes, setFilteredQuizzes] = useState([]);
  const [classroom, setClassroom] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterDifficulty, setFilterDifficulty] = useState('all');
  const [sortBy, setSortBy] = useState('newest');
  const [viewMode, setViewMode] = useState('grid'); // grid or list
  const [selectedQuizzes, setSelectedQuizzes] = useState([]);
  const [showFilters, setShowFilters] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(null);

  // Fetch classroom and quizzes data
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError(null);
      try {
        // Fetch classroom info and quizzes in parallel
        const [classroomRes, quizzesRes] = await Promise.all([
          api.get(`/classroom/${classroomId}`),
          api.get(`/staff/classrooms/${classroomId}/quizzes`)
        ]);

        setClassroom(classroomRes.data.data);
        const quizzesData = Array.isArray(quizzesRes.data.quizzes) ? quizzesRes.data.quizzes : [];
        setQuizzes(quizzesData);
        setFilteredQuizzes(quizzesData);
      } catch (err) {
        setError(
          err.response?.data?.message ||
          err.message ||
          'Failed to load data. Please try again.'
        );
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [classroomId]);

  // Filter and search functionality
  useEffect(() => {
    let filtered = [...quizzes];

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(quiz =>
        quiz.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        quiz.subject?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        quiz.topic?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Status filter
    if (filterStatus !== 'all') {
      filtered = filtered.filter(quiz => quiz.status === filterStatus);
    }

    // Difficulty filter
    if (filterDifficulty !== 'all') {
      filtered = filtered.filter(quiz => quiz.difficulty === filterDifficulty);
    }

    // Sort
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'newest':
          return new Date(b.createdAt) - new Date(a.createdAt);
        case 'oldest':
          return new Date(a.createdAt) - new Date(b.createdAt);
        case 'title':
          return (a.title || '').localeCompare(b.title || '');
        case 'questions':
          return (b.questions?.length || 0) - (a.questions?.length || 0);
        default:
          return 0;
      }
    });

    setFilteredQuizzes(filtered);
  }, [quizzes, searchTerm, filterStatus, filterDifficulty, sortBy]);

  // Action handlers
  const handleView = (quizId) => {
    navigate(`/staff/classrooms/${classroomId}/quizzes/${quizId}`);
  };

  const handleEdit = (quizId) => {
    navigate(`/staff/classrooms/${classroomId}/quizzes/${quizId}/edit`);
  };

  const handleDelete = async (quizId) => {
    const quiz = quizzes.find(q => q._id === quizId);
    if (!window.confirm(`Are you sure you want to delete "${quiz?.title || 'this quiz'}"? This action cannot be undone.`)) return;

    setDeleteLoading(quizId);
    try {
      await api.delete(`/quizzes/${quizId}`);
      setQuizzes(prev => prev.filter(q => q._id !== quizId));
      // Show success message
      const successDiv = document.createElement('div');
      successDiv.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
      successDiv.textContent = 'Quiz deleted successfully!';
      document.body.appendChild(successDiv);
      setTimeout(() => document.body.removeChild(successDiv), 3000);
    } catch (err) {
      alert(
        err.response?.data?.message ||
        err.message ||
        'Failed to delete quiz.'
      );
    } finally {
      setDeleteLoading(null);
    }
  };

  const handleBulkDelete = async () => {
    if (selectedQuizzes.length === 0) return;
    if (!window.confirm(`Are you sure you want to delete ${selectedQuizzes.length} selected quiz(es)?`)) return;

    try {
      await Promise.all(selectedQuizzes.map(id => api.delete(`/quizzes/${id}`)));
      setQuizzes(prev => prev.filter(q => !selectedQuizzes.includes(q._id)));
      setSelectedQuizzes([]);
    } catch (err) {
      alert('Failed to delete some quizzes.');
    }
  };

  const handleAddQuiz = () => {
    navigate(`/staff/classrooms/${classroomId}/quizzes/new`);
  };

  const handleDuplicate = async (quizId) => {
    try {
      const quiz = quizzes.find(q => q._id === quizId);
      // Navigate to create new quiz with pre-filled data
      navigate(`/staff/classrooms/${classroomId}/quizzes/new`, {
        state: { duplicateFrom: quiz }
      });
    } catch (err) {
      alert('Failed to duplicate quiz.');
    }
  };

  const toggleQuizSelection = (quizId) => {
    setSelectedQuizzes(prev =>
      prev.includes(quizId)
        ? prev.filter(id => id !== quizId)
        : [...prev, quizId]
    );
  };

  const selectAllQuizzes = () => {
    setSelectedQuizzes(
      selectedQuizzes.length === filteredQuizzes.length
        ? []
        : filteredQuizzes.map(q => q._id)
    );
  };

  // Utility functions
  const getStatusColor = (status) => {
    switch (status) {
      case 'published': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400';
      case 'draft': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400';
      case 'archived': return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
    }
  };

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400';
      case 'medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400';
      case 'hard': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-slate-900 dark:to-indigo-950 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-blue-400/20 to-purple-600/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-tr from-indigo-400/20 to-pink-600/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-r from-cyan-400/10 to-blue-600/10 rounded-full blur-3xl animate-spin-slow"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

        {/* Header Section */}
        <div className="mb-12">
          {/* Navigation & Title */}
          <div className="flex items-center gap-6 mb-8">
            <button
              onClick={() => navigate(`/staff/classrooms/${classroomId}`)}
              className="group p-3 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-2xl shadow-lg border border-white/20 dark:border-gray-700/20 hover:shadow-xl transition-all duration-300 hover:scale-105"
            >
              <ArrowLeft className="w-6 h-6 text-gray-600 dark:text-gray-400 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors" />
            </button>
            <div className="flex-1">
              <div className="flex items-center gap-4 mb-2">
                <h1 className="text-5xl font-black bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent">
                  Quiz Hub
                </h1>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-sm font-medium text-green-600 dark:text-green-400">Live</span>
                </div>
              </div>
              <div className="flex items-center gap-4 text-gray-600 dark:text-gray-400">
                <div className="flex items-center gap-2">
                  <BookOpen className="w-5 h-5" />
                  <span className="font-medium">{classroom?.name || 'Loading classroom...'}</span>
                </div>
                <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
                <div className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  <span className="font-medium">{filteredQuizzes.length} quiz{filteredQuizzes.length !== 1 ? 'es' : ''}</span>
                </div>
                <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  <span className="font-medium">Active</span>
                </div>
              </div>
            </div>
          </div>

          {/* Modern Control Panel */}
          <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-white/30 dark:border-gray-700/30 relative overflow-hidden">
            {/* Decorative Elements */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-full blur-2xl"></div>
            <div className="absolute bottom-0 left-0 w-24 h-24 bg-gradient-to-tr from-indigo-500/10 to-pink-500/10 rounded-full blur-2xl"></div>

            <div className="relative z-10">
              {/* Top Row - Search & Quick Stats */}
              <div className="flex flex-col lg:flex-row gap-6 items-start lg:items-center justify-between mb-6">

                {/* Enhanced Search */}
                <div className="flex-1 max-w-2xl">
                  <div className="relative group">
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-2xl blur-xl group-hover:blur-2xl transition-all duration-300"></div>
                    <div className="relative bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm rounded-2xl border border-white/50 dark:border-gray-700/50 overflow-hidden">
                      <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                      <input
                        type="text"
                        placeholder="Search quizzes by title, subject, or topic..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full pl-12 pr-4 py-4 bg-transparent text-gray-900 dark:text-white placeholder-gray-500 focus:outline-none text-lg"
                      />
                      {searchTerm && (
                        <button
                          onClick={() => setSearchTerm('')}
                          className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                        >
                          <XCircle className="w-5 h-5" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Quick Stats */}
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-6 px-6 py-3 bg-gradient-to-r from-green-500/10 to-emerald-500/10 rounded-2xl border border-green-500/20">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                        {quizzes.filter(q => q.status === 'published').length}
                      </div>
                      <div className="text-xs text-green-600/80 dark:text-green-400/80 font-medium">Published</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-yellow-600 dark:text-yellow-400">
                        {quizzes.filter(q => q.status === 'draft').length}
                      </div>
                      <div className="text-xs text-yellow-600/80 dark:text-yellow-400/80 font-medium">Drafts</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                        {quizzes.filter(q => q.aiGenerated).length}
                      </div>
                      <div className="text-xs text-purple-600/80 dark:text-purple-400/80 font-medium">AI Generated</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Filters & Actions Row */}
              <div className="flex flex-col xl:flex-row gap-4 items-start xl:items-center justify-between">

                {/* Advanced Filters */}
                <div className="flex flex-wrap gap-3">
                  <div className="relative">
                    <select
                      value={filterStatus}
                      onChange={(e) => setFilterStatus(e.target.value)}
                      className="appearance-none px-4 py-3 pr-10 bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm border border-white/50 dark:border-gray-700/50 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all text-sm font-medium"
                    >
                      <option value="all">📊 All Status</option>
                      <option value="published">✅ Published</option>
                      <option value="draft">📝 Draft</option>
                      <option value="archived">📦 Archived</option>
                    </select>
                    <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
                  </div>

                  <div className="relative">
                    <select
                      value={filterDifficulty}
                      onChange={(e) => setFilterDifficulty(e.target.value)}
                      className="appearance-none px-4 py-3 pr-10 bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm border border-white/50 dark:border-gray-700/50 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all text-sm font-medium"
                    >
                      <option value="all">🎯 All Levels</option>
                      <option value="easy">🟢 Easy</option>
                      <option value="medium">🟡 Medium</option>
                      <option value="hard">🔴 Hard</option>
                    </select>
                    <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
                  </div>

                  <div className="relative">
                    <select
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value)}
                      className="appearance-none px-4 py-3 pr-10 bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm border border-white/50 dark:border-gray-700/50 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all text-sm font-medium"
                    >
                      <option value="newest">🕒 Newest First</option>
                      <option value="oldest">⏰ Oldest First</option>
                      <option value="title">🔤 By Title</option>
                      <option value="questions">📊 By Questions</option>
                    </select>
                    <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
                  </div>

                  {(searchTerm || filterStatus !== 'all' || filterDifficulty !== 'all') && (
                    <button
                      onClick={() => {
                        setSearchTerm('');
                        setFilterStatus('all');
                        setFilterDifficulty('all');
                      }}
                      className="px-4 py-3 bg-gray-500/10 hover:bg-gray-500/20 text-gray-600 dark:text-gray-400 rounded-xl font-medium transition-all"
                    >
                      <RefreshCw className="w-4 h-4 inline mr-2" />
                      Clear
                    </button>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3">
                  {selectedQuizzes.length > 0 && (
                    <div className="flex items-center gap-3">
                      <div className="px-3 py-2 bg-blue-500/10 text-blue-600 dark:text-blue-400 rounded-xl text-sm font-medium">
                        {selectedQuizzes.length} selected
                      </div>
                      <button
                        onClick={handleBulkDelete}
                        className="px-4 py-3 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white rounded-xl font-medium transition-all transform hover:scale-105 shadow-lg"
                      >
                        <Trash2 className="w-4 h-4 inline mr-2" />
                        Delete
                      </button>
                    </div>
                  )}

                  <button
                    onClick={handleAddQuiz}
                    className="group px-8 py-4 bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 hover:from-blue-700 hover:via-purple-700 hover:to-indigo-700 text-white rounded-2xl font-bold transition-all transform hover:scale-105 shadow-2xl relative overflow-hidden"
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                    <div className="relative flex items-center gap-3">
                      <div className="p-1 bg-white/20 rounded-lg">
                        <Plus className="w-5 h-5" />
                      </div>
                      <span>Create Quiz</span>
                      <Sparkles className="w-4 h-4 opacity-75" />
                    </div>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        {loading ? (
          <div className="flex items-center justify-center py-32">
            <div className="text-center">
              <div className="relative mb-8">
                {/* Animated Rings */}
                <div className="w-24 h-24 mx-auto relative">
                  <div className="absolute inset-0 border-4 border-blue-200 dark:border-blue-800 rounded-full animate-spin"></div>
                  <div className="absolute inset-2 border-4 border-purple-200 dark:border-purple-800 rounded-full animate-spin-reverse"></div>
                  <div className="absolute inset-4 border-4 border-indigo-200 dark:border-indigo-800 rounded-full animate-spin"></div>
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                    <Brain className="w-8 h-8 text-blue-600 dark:text-blue-400 animate-pulse" />
                  </div>
                </div>
                {/* Floating Particles */}
                <div className="absolute -top-4 -left-4 w-2 h-2 bg-blue-500 rounded-full animate-bounce"></div>
                <div className="absolute -top-2 -right-6 w-1.5 h-1.5 bg-purple-500 rounded-full animate-bounce delay-300"></div>
                <div className="absolute -bottom-4 -right-2 w-2 h-2 bg-indigo-500 rounded-full animate-bounce delay-700"></div>
              </div>
              <div className="space-y-3">
                <h3 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  Loading Quiz Hub
                </h3>
                <p className="text-gray-600 dark:text-gray-400 text-lg">Preparing your amazing quizzes...</p>
                <div className="flex items-center justify-center gap-2 mt-4">
                  <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                  <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse delay-150"></div>
                  <div className="w-2 h-2 bg-indigo-500 rounded-full animate-pulse delay-300"></div>
                </div>
              </div>
            </div>
          </div>
        ) : error ? (
          <div className="flex items-center justify-center py-32">
            <div className="text-center max-w-lg mx-auto">
              <div className="relative mb-8">
                <div className="w-32 h-32 bg-gradient-to-br from-red-100 to-red-200 dark:from-red-900/20 dark:to-red-800/20 rounded-3xl mx-auto flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-red-500/10 to-red-600/10 animate-pulse"></div>
                  <XCircle className="w-16 h-16 text-red-500 relative z-10" />
                </div>
                {/* Error particles */}
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-4">
                  <div className="w-1 h-1 bg-red-400 rounded-full animate-ping"></div>
                </div>
              </div>
              <div className="space-y-4">
                <h3 className="text-3xl font-bold text-red-800 dark:text-red-400">Houston, we have a problem!</h3>
                <p className="text-red-600 dark:text-red-400 text-lg leading-relaxed">{error}</p>
                <div className="pt-4">
                  <button
                    onClick={() => window.location.reload()}
                    className="group px-8 py-4 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white rounded-2xl font-bold transition-all transform hover:scale-105 shadow-2xl relative overflow-hidden"
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                    <div className="relative flex items-center gap-3">
                      <RefreshCw className="w-5 h-5 group-hover:animate-spin" />
                      <span>Try Again</span>
                    </div>
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : filteredQuizzes.length === 0 ? (
          <div className="flex items-center justify-center py-32">
            <div className="text-center max-w-2xl mx-auto">
              {searchTerm || filterStatus !== 'all' || filterDifficulty !== 'all' ? (
                <>
                  {/* No Search Results */}
                  <div className="relative mb-8">
                    <div className="w-32 h-32 bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-800/50 dark:to-gray-700/50 rounded-3xl mx-auto flex items-center justify-center relative overflow-hidden">
                      <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 animate-pulse"></div>
                      <Search className="w-16 h-16 text-gray-400 relative z-10" />
                    </div>
                    <div className="absolute top-4 right-4 w-3 h-3 bg-yellow-400 rounded-full animate-ping"></div>
                  </div>
                  <div className="space-y-4">
                    <h3 className="text-3xl font-bold text-gray-800 dark:text-gray-200">No matches found</h3>
                    <p className="text-gray-600 dark:text-gray-400 text-lg">We couldn't find any quizzes matching your criteria</p>
                    <div className="flex flex-wrap gap-2 justify-center mt-6">
                      {searchTerm && (
                        <span className="px-3 py-1 bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-400 rounded-full text-sm">
                          "{searchTerm}"
                        </span>
                      )}
                      {filterStatus !== 'all' && (
                        <span className="px-3 py-1 bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-400 rounded-full text-sm">
                          {filterStatus}
                        </span>
                      )}
                      {filterDifficulty !== 'all' && (
                        <span className="px-3 py-1 bg-purple-100 dark:bg-purple-900/20 text-purple-800 dark:text-purple-400 rounded-full text-sm">
                          {filterDifficulty}
                        </span>
                      )}
                    </div>
                    <div className="pt-6">
                      <button
                        onClick={() => {
                          setSearchTerm('');
                          setFilterStatus('all');
                          setFilterDifficulty('all');
                        }}
                        className="group px-8 py-4 bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-700 hover:to-gray-800 text-white rounded-2xl font-bold transition-all transform hover:scale-105 shadow-2xl relative overflow-hidden"
                      >
                        <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                        <div className="relative flex items-center gap-3">
                          <RefreshCw className="w-5 h-5" />
                          <span>Clear All Filters</span>
                        </div>
                      </button>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  {/* Empty State */}
                  <div className="relative mb-12">
                    <div className="w-40 h-40 bg-gradient-to-br from-blue-100 via-purple-100 to-indigo-100 dark:from-blue-900/20 dark:via-purple-900/20 dark:to-indigo-900/20 rounded-3xl mx-auto flex items-center justify-center relative overflow-hidden">
                      <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-purple-500/10 animate-pulse"></div>
                      <BookOpen className="w-20 h-20 text-blue-600 dark:text-blue-400 relative z-10" />
                    </div>
                    {/* Floating elements */}
                    <Sparkles className="w-8 h-8 text-yellow-500 absolute -top-2 -right-2 animate-bounce" />
                    <Star className="w-6 h-6 text-purple-500 absolute top-8 -left-4 animate-pulse" />
                    <Zap className="w-5 h-5 text-blue-500 absolute bottom-8 -right-6 animate-ping" />
                  </div>
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-4xl font-black bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent mb-4">
                        Your Quiz Journey Starts Here!
                      </h3>
                      <p className="text-gray-600 dark:text-gray-400 text-xl leading-relaxed">
                        Create engaging, interactive quizzes that captivate your students and enhance their learning experience
                      </p>
                    </div>

                    {/* Feature highlights */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 my-12">
                      <div className="text-center p-6 bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm rounded-2xl border border-white/20 dark:border-gray-700/20">
                        <Brain className="w-12 h-12 text-purple-600 mx-auto mb-3" />
                        <h4 className="font-bold text-gray-800 dark:text-gray-200 mb-2">AI-Powered</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Generate questions instantly with advanced AI</p>
                      </div>
                      <div className="text-center p-6 bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm rounded-2xl border border-white/20 dark:border-gray-700/20">
                        <Globe className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                        <h4 className="font-bold text-gray-800 dark:text-gray-200 mb-2">Multi-Language</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Support for Tamil, English, and more</p>
                      </div>
                      <div className="text-center p-6 bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm rounded-2xl border border-white/20 dark:border-gray-700/20">
                        <Zap className="w-12 h-12 text-indigo-600 mx-auto mb-3" />
                        <h4 className="font-bold text-gray-800 dark:text-gray-200 mb-2">Instant Creation</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">From idea to quiz in seconds</p>
                      </div>
                    </div>

                    <div className="pt-4">
                      <button
                        onClick={handleAddQuiz}
                        className="group px-12 py-6 bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 hover:from-blue-700 hover:via-purple-700 hover:to-indigo-700 text-white rounded-3xl font-black text-xl transition-all transform hover:scale-105 shadow-2xl relative overflow-hidden"
                      >
                        <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                        <div className="relative flex items-center gap-4">
                          <div className="p-2 bg-white/20 rounded-xl">
                            <Plus className="w-8 h-8" />
                          </div>
                          <span>Create Your First Quiz</span>
                          <Sparkles className="w-6 h-6 opacity-75 animate-pulse" />
                        </div>
                      </button>
                      <p className="text-gray-500 dark:text-gray-400 mt-6 text-lg">
                        Join thousands of educators creating amazing learning experiences
                      </p>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        ) : (
          <>
            {/* Enhanced Bulk Actions Bar */}
            {selectedQuizzes.length > 0 && (
              <div className="mb-8 bg-gradient-to-r from-blue-50 via-purple-50 to-indigo-50 dark:from-blue-900/20 dark:via-purple-900/20 dark:to-indigo-900/20 backdrop-blur-sm border border-blue-200/50 dark:border-blue-800/50 rounded-2xl p-6 shadow-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-6">
                    <div className="flex items-center gap-3">
                      <input
                        type="checkbox"
                        checked={selectedQuizzes.length === filteredQuizzes.length}
                        onChange={selectAllQuizzes}
                        className="w-5 h-5 text-blue-600 bg-white border-2 border-blue-300 rounded-lg focus:ring-2 focus:ring-blue-500 transition-all"
                      />
                      <div className="text-blue-800 dark:text-blue-200">
                        <div className="font-bold text-lg">
                          {selectedQuizzes.length} quiz{selectedQuizzes.length !== 1 ? 'es' : ''} selected
                        </div>
                        <div className="text-sm opacity-75">Ready for bulk operations</div>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setSelectedQuizzes([])}
                      className="px-4 py-2 bg-gray-500/10 hover:bg-gray-500/20 text-gray-600 dark:text-gray-400 rounded-xl font-medium transition-all"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleBulkDelete}
                      className="group px-6 py-3 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white rounded-xl font-bold transition-all transform hover:scale-105 shadow-lg relative overflow-hidden"
                    >
                      <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                      <div className="relative flex items-center gap-2">
                        <Trash2 className="w-4 h-4" />
                        <span>Delete Selected</span>
                      </div>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Stunning Quiz Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 2xl:grid-cols-3 gap-8">
              {filteredQuizzes.map((quiz, index) => (
                <div
                  key={quiz._id}
                  className="group relative bg-white/80 dark:bg-gray-800/80 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/30 dark:border-gray-700/30 overflow-hidden hover:shadow-3xl transition-all duration-500 transform hover:-translate-y-2 hover:scale-[1.02]"
                  style={{
                    animationDelay: `${index * 100}ms`,
                    animation: 'fadeInUp 0.6s ease-out forwards'
                  }}
                >
                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 via-purple-500/5 to-indigo-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

                  {/* Decorative Elements */}
                  <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                  <div className="absolute bottom-0 left-0 w-24 h-24 bg-gradient-to-tr from-indigo-500/10 to-pink-500/10 rounded-full blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

                  {/* Quiz Header */}
                  <div className="relative z-10 p-8 pb-6">
                    <div className="flex items-start justify-between mb-6">
                      <div className="flex items-start gap-4 flex-1">
                        <div className="mt-1">
                          <input
                            type="checkbox"
                            checked={selectedQuizzes.includes(quiz._id)}
                            onChange={() => toggleQuizSelection(quiz._id)}
                            className="w-5 h-5 text-blue-600 bg-white border-2 border-blue-300 rounded-lg focus:ring-2 focus:ring-blue-500 transition-all"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="text-2xl font-black text-gray-900 dark:text-white mb-2 line-clamp-2 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                            {quiz.title || 'Untitled Quiz'}
                          </h3>
                          <div className="flex items-center gap-3 mb-3">
                            {quiz.aiGenerated && (
                              <div className="flex items-center gap-2 px-3 py-1 bg-gradient-to-r from-purple-500/10 to-indigo-500/10 rounded-full border border-purple-500/20">
                                <Brain className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                                <span className="text-sm font-bold text-purple-600 dark:text-purple-400">AI Generated</span>
                                {quiz.language === 'tamil' && (
                                  <span className="text-lg">🇮🇳</span>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Enhanced Status Badge */}
                      <div className="flex flex-col items-end gap-2">
                        <div className={`px-4 py-2 rounded-2xl text-sm font-bold shadow-lg ${getStatusColor(quiz.status)} relative overflow-hidden`}>
                          <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                          <div className="relative flex items-center gap-2">
                            {quiz.status === 'published' && <CheckCircle className="w-4 h-4" />}
                            {quiz.status === 'draft' && <AlertCircle className="w-4 h-4" />}
                            {quiz.status === 'archived' && <XCircle className="w-4 h-4" />}
                            <span>{quiz.status?.charAt(0).toUpperCase() + quiz.status?.slice(1) || 'Draft'}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Quiz Description */}
                    <div className="mb-6">
                      <p className="text-gray-600 dark:text-gray-400 text-base leading-relaxed line-clamp-3">
                        {quiz.description || 'No description available for this quiz.'}
                      </p>
                    </div>

                    {/* Enhanced Metadata Tags */}
                    <div className="flex flex-wrap gap-3 mb-6">
                      <div className={`px-4 py-2 rounded-2xl text-sm font-bold shadow-md ${getDifficultyColor(quiz.difficulty)} relative overflow-hidden`}>
                        <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                        <div className="relative">
                          {quiz.difficulty === 'easy' && '🟢'}
                          {quiz.difficulty === 'medium' && '🟡'}
                          {quiz.difficulty === 'hard' && '🔴'}
                          <span className="ml-1">{quiz.difficulty?.charAt(0).toUpperCase() + quiz.difficulty?.slice(1) || 'Medium'}</span>
                        </div>
                      </div>

                      <div className="px-4 py-2 bg-gradient-to-r from-blue-500/10 to-indigo-500/10 text-blue-800 dark:text-blue-400 rounded-2xl text-sm font-bold shadow-md border border-blue-500/20 relative overflow-hidden">
                        <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                        <div className="relative flex items-center gap-2">
                          <BookOpen className="w-4 h-4" />
                          <span>{quiz.questions?.length || 0} Questions</span>
                        </div>
                      </div>

                      {quiz.subject && (
                        <div className="px-4 py-2 bg-gradient-to-r from-gray-500/10 to-gray-600/10 text-gray-800 dark:text-gray-400 rounded-2xl text-sm font-bold shadow-md border border-gray-500/20 relative overflow-hidden">
                          <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                          <div className="relative">{quiz.subject}</div>
                        </div>
                      )}
                    </div>

                    {/* Enhanced Stats Grid */}
                    <div className="grid grid-cols-3 gap-4 mb-6">
                      <div className="text-center p-3 bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm rounded-xl border border-white/20 dark:border-gray-700/20">
                        <Clock className="w-5 h-5 text-blue-600 mx-auto mb-1" />
                        <div className="text-sm font-bold text-gray-900 dark:text-white">{quiz.settings?.timeLimit || 30}min</div>
                        <div className="text-xs text-gray-500 dark:text-gray-400">Duration</div>
                      </div>
                      <div className="text-center p-3 bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm rounded-xl border border-white/20 dark:border-gray-700/20">
                        <Award className="w-5 h-5 text-yellow-600 mx-auto mb-1" />
                        <div className="text-sm font-bold text-gray-900 dark:text-white">{quiz.settings?.passingScore || 70}%</div>
                        <div className="text-xs text-gray-500 dark:text-gray-400">Pass Score</div>
                      </div>
                      <div className="text-center p-3 bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm rounded-xl border border-white/20 dark:border-gray-700/20">
                        <Calendar className="w-5 h-5 text-green-600 mx-auto mb-1" />
                        <div className="text-sm font-bold text-gray-900 dark:text-white">{formatDate(quiz.createdAt)}</div>
                        <div className="text-xs text-gray-500 dark:text-gray-400">Created</div>
                      </div>
                    </div>
                  </div>

                  {/* Stunning Action Buttons */}
                  <div className="relative z-10 px-8 pb-8">
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      {/* Primary Actions */}
                      <button
                        onClick={() => handleView(quiz._id)}
                        className="group px-6 py-4 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white rounded-2xl font-bold transition-all transform hover:scale-105 shadow-xl relative overflow-hidden"
                      >
                        <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                        <div className="relative flex items-center justify-center gap-3">
                          <Eye className="w-5 h-5" />
                          <span>View Quiz</span>
                        </div>
                      </button>

                      <button
                        onClick={() => handleEdit(quiz._id)}
                        className="group px-6 py-4 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white rounded-2xl font-bold transition-all transform hover:scale-105 shadow-xl relative overflow-hidden"
                      >
                        <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                        <div className="relative flex items-center justify-center gap-3">
                          <Edit3 className="w-5 h-5" />
                          <span>Edit Quiz</span>
                        </div>
                      </button>
                    </div>

                    {/* Secondary Actions */}
                    <div className="flex gap-3">
                      <button
                        onClick={() => handleDuplicate(quiz._id)}
                        className="group flex-1 px-4 py-3 bg-gradient-to-r from-purple-500/10 to-indigo-500/10 hover:from-purple-500/20 hover:to-indigo-500/20 text-purple-700 dark:text-purple-400 rounded-xl font-bold transition-all transform hover:scale-105 border border-purple-500/20 hover:border-purple-500/40 relative overflow-hidden"
                        title="Duplicate Quiz"
                      >
                        <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                        <div className="relative flex items-center justify-center gap-2">
                          <Copy className="w-4 h-4" />
                          <span>Duplicate</span>
                        </div>
                      </button>

                      <button
                        onClick={() => handleDelete(quiz._id)}
                        disabled={deleteLoading === quiz._id}
                        className="group flex-1 px-4 py-3 bg-gradient-to-r from-red-500/10 to-red-600/10 hover:from-red-500/20 hover:to-red-600/20 text-red-700 dark:text-red-400 rounded-xl font-bold transition-all transform hover:scale-105 border border-red-500/20 hover:border-red-500/40 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none relative overflow-hidden"
                        title="Delete Quiz"
                      >
                        <div className="absolute inset-0 bg-gradient-to-r from-red-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                        <div className="relative flex items-center justify-center gap-2">
                          {deleteLoading === quiz._id ? (
                            <>
                              <RefreshCw className="w-4 h-4 animate-spin" />
                              <span>Deleting...</span>
                            </>
                          ) : (
                            <>
                              <Trash2 className="w-4 h-4" />
                              <span>Delete</span>
                            </>
                          )}
                        </div>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Custom CSS for animations */}
      <style>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes spin-slow {
          from {
            transform: rotate(0deg);
          }
          to {
            transform: rotate(360deg);
          }
        }

        @keyframes spin-reverse {
          from {
            transform: rotate(360deg);
          }
          to {
            transform: rotate(0deg);
          }
        }

        .animate-spin-slow {
          animation: spin-slow 20s linear infinite;
        }

        .animate-spin-reverse {
          animation: spin-reverse 3s linear infinite;
        }

        .line-clamp-2 {
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }

        .line-clamp-3 {
          display: -webkit-box;
          -webkit-line-clamp: 3;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }

        .shadow-3xl {
          box-shadow: 0 35px 60px -12px rgba(0, 0, 0, 0.25);
        }
      `}</style>
    </div>
  );
};

export default ClassroomQuizzes;