import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import {
  ArrowLeft, Plus, Trash2, Edit3, Save, Eye, EyeOff,
  CheckCircle, AlertCircle, Loader2, BookOpen, Target,
  Clock, Award, Lightbulb, Globe, FileText, Settings
} from 'lucide-react';

const DIFFICULTIES = [
  { value: 'easy', label: 'Easy', icon: '🟢', description: 'Basic level questions' },
  { value: 'medium', label: 'Medium', icon: '🟡', description: 'Intermediate level questions' },
  { value: 'hard', label: 'Hard', icon: '🔴', description: 'Advanced level questions' }
];

const QUESTION_TYPES = [
  { value: 'multiple-choice', label: 'Multiple Choice', icon: '📝', description: 'Questions with 4 answer options' },
  { value: 'true-false', label: 'True/False', icon: '✅', description: 'Simple true or false questions' },
  { value: 'short-answer', label: 'Short Answer', icon: '💭', description: 'Open-ended text responses' }
];

const defaultQuestion = () => ({
  id: Date.now() + Math.random(),
  question: '',
  type: 'multiple-choice',
  options: { A: '', B: '', C: '', D: '' },
  correctAnswer: 'A',
  explanation: '',
  points: 1,
  isEditing: true
});

const QuizCreateManual = () => {
  const { classroomId } = useParams();
  const navigate = useNavigate();

  // Basic quiz info
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [subject, setSubject] = useState('');
  const [topic, setTopic] = useState('');
  const [difficulty, setDifficulty] = useState('medium');
  const [language, setLanguage] = useState('english');

  // Questions
  const [questions, setQuestions] = useState([defaultQuestion()]);

  // Quiz settings
  const [timeLimit, setTimeLimit] = useState(30);
  const [passingScore, setPassingScore] = useState(70);
  const [shuffleQuestions, setShuffleQuestions] = useState(true);
  const [showResults, setShowResults] = useState(true);
  const [allowRetake, setAllowRetake] = useState(false);

  // UI state
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [currentStep, setCurrentStep] = useState(1);
  const [classroom, setClassroom] = useState(null);

  // Fetch classroom info
  useEffect(() => {
    const fetchClassroom = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get(`/api/classrooms/${classroomId}`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        setClassroom(response.data.data);
        setSubject(response.data.data.subject || '');
      } catch (err) {
        console.error('Failed to fetch classroom:', err);
      }
    };

    if (classroomId) {
      fetchClassroom();
    }
  }, [classroomId]);

  // Question handlers
  const handleQuestionChange = (idx, field, value) => {
    setQuestions((prev) =>
      prev.map((q, i) =>
        i === idx ? { ...q, [field]: value } : q
      )
    );
  };

  const handleOptionChange = (idx, opt, value) => {
    setQuestions((prev) =>
      prev.map((q, i) =>
        i === idx ? { ...q, options: { ...q.options, [opt]: value } } : q
      )
    );
  };

  const handleCorrectAnswerChange = (idx, value) => {
    setQuestions((prev) =>
      prev.map((q, i) =>
        i === idx ? { ...q, correctAnswer: value } : q
      )
    );
  };

  const toggleQuestionEdit = (idx) => {
    setQuestions((prev) =>
      prev.map((q, i) =>
        i === idx ? { ...q, isEditing: !q.isEditing } : q
      )
    );
  };

  const addQuestion = () => {
    setQuestions((prev) => [...prev, defaultQuestion()]);
  };

  const removeQuestion = (idx) => {
    if (questions.length > 1) {
      setQuestions((prev) => prev.filter((_, i) => i !== idx));
    }
  };

  const duplicateQuestion = (idx) => {
    const questionToDuplicate = questions[idx];
    const duplicatedQuestion = {
      ...questionToDuplicate,
      id: Date.now() + Math.random(),
      question: questionToDuplicate.question + ' (Copy)',
      isEditing: true
    };
    setQuestions((prev) => [
      ...prev.slice(0, idx + 1),
      duplicatedQuestion,
      ...prev.slice(idx + 1)
    ]);
  };

  // Validation
  const validateQuiz = () => {
    if (!title.trim()) {
      setError('Please enter a quiz title');
      return false;
    }

    if (questions.length === 0) {
      setError('Please add at least one question');
      return false;
    }

    const invalidQuestions = questions.filter(q =>
      !q.question.trim() ||
      (q.type === 'multiple-choice' && !Object.values(q.options).every(opt => opt.trim())) ||
      !q.correctAnswer
    );

    if (invalidQuestions.length > 0) {
      setError(`Please complete all questions. ${invalidQuestions.length} question(s) are incomplete.`);
      return false;
    }

    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateQuiz()) {
      return;
    }

    setSaving(true);
    setError(null);
    setSuccess(null);

    try {
      const token = localStorage.getItem('token');

      const quizData = {
        title,
        description: description || `Manual quiz on ${topic || subject}`,
        classroomId,
        subject: subject || classroom?.subject || 'General',
        topic: topic || 'General',
        difficulty,
        language,
        questions: questions.map(q => ({
          question: q.question,
          type: q.type,
          options: q.type === 'multiple-choice' ? q.options : undefined,
          correctAnswer: q.correctAnswer,
          explanation: q.explanation,
          points: q.points || 1,
          difficulty: q.difficulty || difficulty
        })),
        settings: {
          timeLimit,
          passingScore,
          shuffleQuestions,
          showResults,
          showCorrectAnswers: true,
          allowRetake,
          maxAttempts: allowRetake ? 3 : 1
        },
        status: 'draft',
        manuallyCreated: true
      };

      await axios.post('/api/quizzes', quizData, {
        headers: { Authorization: `Bearer ${token}` }
      });

      setSuccess('🎉 Quiz created successfully!');
      setTimeout(() => navigate(`/staff/classrooms/${classroomId}/quizzes`), 2000);

    } catch (err) {
      console.error('Quiz creation error:', err);
      setError(err.response?.data?.message || err.message || 'Failed to create quiz');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={() => navigate(`/staff/classrooms/${classroomId}/quizzes`)}
            className="p-2 bg-white dark:bg-gray-800 rounded-lg shadow-md hover:shadow-lg transition-all"
          >
            <ArrowLeft className="w-5 h-5 text-gray-600 dark:text-gray-400" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
              Create Manual Quiz
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              Design custom questions for {classroom?.name || 'your classroom'}
            </p>
          </div>
        </div>

        {/* Error/Success Messages */}
        {error && (
          <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl flex items-center gap-3">
            <AlertCircle className="w-5 h-5 text-red-600" />
            <span className="text-red-700 dark:text-red-300">{error}</span>
          </div>
        )}

        {success && (
          <div className="mb-6 p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-xl flex items-center gap-3">
            <CheckCircle className="w-5 h-5 text-green-600" />
            <span className="text-green-700 dark:text-green-300">{success}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Quiz Information */}
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 p-8">
            <div className="flex items-center gap-4 mb-6">
              <Target className="w-6 h-6 text-blue-600" />
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Quiz Information</h2>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              {/* Title */}
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Quiz Title *
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  placeholder="Enter quiz title..."
                  required
                />
              </div>

              {/* Description */}
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Description
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows="3"
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none"
                  placeholder="Brief description of the quiz..."
                />
              </div>

              {/* Subject */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Subject
                </label>
                <input
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  placeholder="Subject area..."
                />
              </div>

              {/* Topic */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Topic
                </label>
                <input
                  type="text"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  placeholder="Specific topic..."
                />
              </div>

              {/* Language Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Quiz Language
                </label>
                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setLanguage('english')}
                    className={`flex-1 px-4 py-3 rounded-lg font-medium transition-all ${
                      language === 'english'
                        ? 'bg-blue-600 text-white shadow-lg'
                        : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                    }`}
                  >
                    🇺🇸 English
                  </button>
                  <button
                    type="button"
                    onClick={() => setLanguage('tamil')}
                    className={`flex-1 px-4 py-3 rounded-lg font-medium transition-all ${
                      language === 'tamil'
                        ? 'bg-orange-600 text-white shadow-lg'
                        : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                    }`}
                  >
                    🇮🇳 Tamil
                  </button>
                </div>
              </div>

              {/* Difficulty */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Difficulty Level
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {DIFFICULTIES.map((diff) => (
                    <button
                      key={diff.value}
                      type="button"
                      onClick={() => setDifficulty(diff.value)}
                      className={`p-3 rounded-lg text-center transition-all ${
                        difficulty === diff.value
                          ? 'bg-blue-600 text-white shadow-lg'
                          : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                      }`}
                    >
                      <div className="text-lg">{diff.icon}</div>
                      <div className="text-sm font-medium">{diff.label}</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Questions Section */}
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 p-8">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-4">
                <FileText className="w-6 h-6 text-purple-600" />
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Questions</h2>
                <span className="px-3 py-1 bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 rounded-full text-sm font-medium">
                  {questions.length} question{questions.length !== 1 ? 's' : ''}
                </span>
              </div>
              <button
                type="button"
                onClick={addQuestion}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white rounded-lg font-medium transition-all transform hover:scale-105"
              >
                <Plus className="w-4 h-4" />
                Add Question
              </button>
            </div>

            <div className="space-y-6">
              {questions.map((question, index) => (
                <div
                  key={question.id}
                  className="border border-gray-200 dark:border-gray-600 rounded-xl p-6 hover:shadow-lg transition-all"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                        {index + 1}
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          difficulty === 'easy' ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300' :
                          difficulty === 'medium' ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-300' :
                          'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300'
                        }`}>
                          {difficulty}
                        </span>
                        <span className="px-2 py-1 text-xs bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded-full">
                          {question.type}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => toggleQuestionEdit(index)}
                        className={`p-2 rounded-lg transition-all ${
                          question.isEditing
                            ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-600'
                            : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600'
                        }`}
                      >
                        {question.isEditing ? <EyeOff className="w-4 h-4" /> : <Edit3 className="w-4 h-4" />}
                      </button>
                      <button
                        type="button"
                        onClick={() => duplicateQuestion(index)}
                        className="p-2 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-all"
                        title="Duplicate question"
                      >
                        <BookOpen className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => removeQuestion(index)}
                        className="p-2 bg-red-100 dark:bg-red-900/30 text-red-600 rounded-lg hover:bg-red-200 dark:hover:bg-red-900/50 transition-all"
                        disabled={questions.length === 1}
                        title="Delete question"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {question.isEditing ? (
                    <div className="space-y-4">
                      {/* Question Text Editor */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Question Text *
                        </label>
                        <textarea
                          value={question.question}
                          onChange={(e) => handleQuestionChange(index, 'question', e.target.value)}
                          rows="3"
                          className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none"
                          placeholder={language === 'tamil' ? 'உங்கள் கேள்வியை இங்கே எழுதுங்கள்...' : 'Enter your question here...'}
                          required
                        />
                      </div>

                      {/* Question Type */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Question Type
                        </label>
                        <div className="grid grid-cols-3 gap-2">
                          {QUESTION_TYPES.map((type) => (
                            <button
                              key={type.value}
                              type="button"
                              onClick={() => handleQuestionChange(index, 'type', type.value)}
                              className={`p-3 rounded-lg text-center transition-all ${
                                question.type === type.value
                                  ? 'bg-blue-600 text-white shadow-lg'
                                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                              }`}
                            >
                              <div className="text-lg">{type.icon}</div>
                              <div className="text-xs font-medium">{type.label}</div>
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Options for Multiple Choice */}
                      {question.type === 'multiple-choice' && (
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Answer Options *
                          </label>
                          <div className="grid md:grid-cols-2 gap-4">
                            {Object.entries(question.options).map(([key, value]) => (
                              <div key={key}>
                                <div className="flex gap-2">
                                  <input
                                    type="text"
                                    value={value}
                                    onChange={(e) => handleOptionChange(index, key, e.target.value)}
                                    className="flex-1 px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                                    placeholder={language === 'tamil' ? `விருப்பம் ${key}...` : `Option ${key}...`}
                                    required
                                  />
                                  <button
                                    type="button"
                                    onClick={() => handleCorrectAnswerChange(index, key)}
                                    className={`px-4 py-3 rounded-lg font-medium transition-all ${
                                      question.correctAnswer === key
                                        ? 'bg-green-600 text-white'
                                        : 'bg-gray-200 dark:bg-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-500'
                                    }`}
                                    title="Set as correct answer"
                                  >
                                    {question.correctAnswer === key ? '✓' : key}
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* True/False Options */}
                      {question.type === 'true-false' && (
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Correct Answer *
                          </label>
                          <div className="flex gap-4">
                            <button
                              type="button"
                              onClick={() => handleCorrectAnswerChange(index, 'true')}
                              className={`flex-1 px-4 py-3 rounded-lg font-medium transition-all ${
                                question.correctAnswer === 'true'
                                  ? 'bg-green-600 text-white'
                                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                              }`}
                            >
                              ✅ {language === 'tamil' ? 'உண்மை' : 'True'}
                            </button>
                            <button
                              type="button"
                              onClick={() => handleCorrectAnswerChange(index, 'false')}
                              className={`flex-1 px-4 py-3 rounded-lg font-medium transition-all ${
                                question.correctAnswer === 'false'
                                  ? 'bg-red-600 text-white'
                                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                              }`}
                            >
                              ❌ {language === 'tamil' ? 'பொய்' : 'False'}
                            </button>
                          </div>
                        </div>
                      )}

                      {/* Explanation */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Explanation (Optional)
                        </label>
                        <textarea
                          value={question.explanation}
                          onChange={(e) => handleQuestionChange(index, 'explanation', e.target.value)}
                          rows="2"
                          className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none"
                          placeholder={language === 'tamil' ? 'இந்த பதில் ஏன் சரியானது என்பதை விளக்குங்கள்...' : 'Explain why this answer is correct...'}
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {/* Question Display */}
                      <div>
                        <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
                          {question.question || 'No question text'}
                        </h4>
                      </div>

                      {/* Options Display */}
                      {question.type === 'multiple-choice' && (
                        <div className="grid md:grid-cols-2 gap-3">
                          {Object.entries(question.options).map(([key, value]) => (
                            <div
                              key={key}
                              className={`p-3 rounded-lg border ${
                                question.correctAnswer === key
                                  ? 'border-green-500 bg-green-50 dark:bg-green-900/20'
                                  : 'border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-700'
                              }`}
                            >
                              <div className="flex items-center gap-3">
                                <span className={`w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold ${
                                  question.correctAnswer === key
                                    ? 'bg-green-500 text-white'
                                    : 'bg-gray-300 dark:bg-gray-600 text-gray-700 dark:text-gray-300'
                                }`}>
                                  {key}
                                </span>
                                <span className="text-gray-900 dark:text-white">{value || 'No option text'}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* True/False Display */}
                      {question.type === 'true-false' && (
                        <div className="flex gap-4">
                          <div className={`flex-1 p-3 rounded-lg border text-center ${
                            question.correctAnswer === 'true'
                              ? 'border-green-500 bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-300'
                              : 'border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 text-gray-600 dark:text-gray-400'
                          }`}>
                            ✅ {language === 'tamil' ? 'உண்மை' : 'True'}
                          </div>
                          <div className={`flex-1 p-3 rounded-lg border text-center ${
                            question.correctAnswer === 'false'
                              ? 'border-red-500 bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300'
                              : 'border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 text-gray-600 dark:text-gray-400'
                          }`}>
                            ❌ {language === 'tamil' ? 'பொய்' : 'False'}
                          </div>
                        </div>
                      )}

                      {/* Explanation Display */}
                      {question.explanation && (
                        <div className="p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                          <div className="flex items-start gap-3">
                            <Lightbulb className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                            <div>
                              <h5 className="font-medium text-blue-900 dark:text-blue-100 mb-1">
                                {language === 'tamil' ? 'விளக்கம்' : 'Explanation'}
                              </h5>
                              <p className="text-blue-800 dark:text-blue-200 text-sm">{question.explanation}</p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Save Section */}
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-2xl p-8 text-center">
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
              {language === 'tamil' ? 'உங்கள் வினாடி வினாவை சேமிக்க தயாரா?' : 'Ready to Save Your Quiz?'}
            </h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6 max-w-2xl mx-auto">
              {language === 'tamil'
                ? 'சேமித்த பிறகு, இந்த வினாடி வினா உங்கள் மாணவர்களுக்கு கிடைக்கும். நீங்கள் எப்போது வேண்டுமானாலும் இதை திருத்தலாம்.'
                : 'Once saved, this quiz will be available for your students to take. You can always edit it later from the quiz management page.'
              }
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                type="button"
                onClick={() => navigate(`/staff/classrooms/${classroomId}/quizzes`)}
                className="px-8 py-4 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-xl font-bold hover:bg-gray-50 dark:hover:bg-gray-800 transition-all"
              >
                {language === 'tamil' ? '← रद्द करें' : '← Cancel'}
              </button>
              <button
                type="submit"
                disabled={saving || !title.trim() || questions.length === 0}
                className="px-8 py-4 bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 hover:from-blue-700 hover:via-purple-700 hover:to-indigo-700 text-white rounded-xl font-bold shadow-lg hover:shadow-xl transform hover:scale-[1.02] transition-all duration-200 flex items-center gap-3 justify-center disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {saving ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    {language === 'tamil' ? 'सेव हो रहा है...' : 'Saving Quiz...'}
                  </>
                ) : (
                  <>
                    <Save className="w-5 h-5" />
                    {language === 'tamil' ? 'वினाडी वینা सेव करें' : 'Save Quiz'} ({questions.length} {language === 'tamil' ? 'கேள்விகள்' : 'questions'})
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default QuizCreateManual;