import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

export default function QuizCreatePage() {
  const navigate = useNavigate();
  const { classroomId } = useParams();
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  const creationMethods = [
    {
      id: 'ai',
      title: 'AI-Powered Generation',
      subtitle: 'Generate with Gemini AI',
      description: 'Create intelligent quizzes instantly using advanced AI technology tailored to your requirements.',
      icon: '🤖',
      gradient: 'from-blue-600 via-purple-600 to-pink-600',
      hoverGradient: 'from-blue-700 via-purple-700 to-pink-700',
      route: `/staff/classrooms/${classroomId}/quizzes/new/ai`,
      features: ['Smart question generation', 'Multiple difficulty levels', 'Instant creation', 'Customizable topics']
    },
    {
      id: 'syllabus',
      title: 'Syllabus-Based Creation',
      subtitle: 'Upload & Analyze Syllabus',
      description: 'Upload your syllabus and let AI extract key topics to generate comprehensive quizzes.',
      icon: '📚',
      gradient: 'from-green-500 via-emerald-500 to-teal-500',
      hoverGradient: 'from-green-600 via-emerald-600 to-teal-600',
      route: `/staff/classrooms/${classroomId}/quizzes/new/syllabus`,
      features: ['Document analysis', 'Topic extraction', 'Curriculum alignment', 'Comprehensive coverage']
    },
    {
      id: 'manual',
      title: 'Manual Creation',
      subtitle: 'Create Manually',
      description: 'Build your quiz from scratch with complete control over every question and answer.',
      icon: '✏️',
      gradient: 'from-orange-500 via-red-500 to-pink-500',
      hoverGradient: 'from-orange-600 via-red-600 to-pink-600',
      route: `/staff/classrooms/${classroomId}/quizzes/new/manual`,
      features: ['Full customization', 'Question bank', 'Rich text editor', 'Media support']
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-gray-900 dark:to-gray-800 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-20 w-72 h-72 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob"></div>
        <div className="absolute top-40 right-20 w-72 h-72 bg-yellow-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000"></div>
        <div className="absolute -bottom-8 left-40 w-72 h-72 bg-pink-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-4000"></div>
      </div>

      <div className="relative z-10 min-h-screen flex items-center justify-center py-12 px-4">
        <div className={`max-w-6xl w-full mx-auto transition-all duration-1000 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          {/* Header Section */}
          <div className="text-center mb-16">
            <div className="mb-8">
              <span className="inline-block px-6 py-3 bg-gradient-to-r from-blue-100 to-purple-100 text-blue-800 rounded-full text-sm font-semibold mb-6 shadow-lg">
                🚀 Quiz Creation Hub
              </span>
            </div>

            <h1 className="text-6xl md:text-7xl font-extrabold mb-8 leading-tight">
              <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                Create Amazing
              </span>
              <br />
              <span className="text-gray-900 dark:text-white">Quizzes</span>
            </h1>

            <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto mb-12 leading-relaxed">
              Choose your preferred method to create engaging, interactive quizzes that inspire learning and measure knowledge effectively.
            </p>
          </div>

          {/* Creation Methods Grid */}
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {creationMethods.map((method, index) => (
              <div
                key={method.id}
                className={`group relative bg-white/90 dark:bg-gray-900/90 backdrop-blur-lg rounded-3xl shadow-2xl hover:shadow-purple-500/25 transform hover:scale-105 transition-all duration-500 border border-gray-200/50 dark:border-gray-700/50 overflow-hidden ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
                style={{ transitionDelay: `${index * 200}ms` }}
              >
                {/* Gradient Background */}
                <div className={`absolute inset-0 bg-gradient-to-br ${method.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-500`}></div>

                <div className="relative z-10 p-8">
                  {/* Icon */}
                  <div className="text-6xl mb-6 transform group-hover:scale-110 transition-transform duration-300">
                    {method.icon}
                  </div>

                  {/* Content */}
                  <h3 className="text-2xl font-bold mb-3 text-gray-900 dark:text-white group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-blue-600 group-hover:to-purple-600 group-hover:bg-clip-text transition-all duration-300">
                    {method.title}
                  </h3>

                  <p className="text-gray-600 dark:text-gray-300 mb-6 leading-relaxed">
                    {method.description}
                  </p>

                  {/* Features */}
                  <ul className="space-y-2 mb-8">
                    {method.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                        <svg className="w-4 h-4 mr-2 text-green-500" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                        {feature}
                      </li>
                    ))}
                  </ul>

                  {/* Action Button */}
                  <button
                    onClick={() => navigate(method.route)}
                    className={`w-full px-6 py-4 bg-gradient-to-r ${method.gradient} hover:bg-gradient-to-r hover:${method.hoverGradient} text-white font-bold rounded-2xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 flex items-center justify-center gap-3`}
                  >
                    <span>{method.subtitle}</span>
                    <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                    </svg>
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Stats Section */}
          <div className="grid grid-cols-3 gap-8 max-w-2xl mx-auto">
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600 dark:text-purple-400">AI-Powered</div>
              <div className="text-gray-600 dark:text-gray-400">Smart Generation</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">Instant</div>
              <div className="text-gray-600 dark:text-gray-400">Quiz Creation</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-pink-600 dark:text-pink-400">100%</div>
              <div className="text-gray-600 dark:text-gray-400">Customizable</div>
            </div>
          </div>
        </div>
      </div>

      {/* Custom Styles */}
      <style jsx>{`
        @keyframes blob {
          0% { transform: translate(0px, 0px) scale(1); }
          33% { transform: translate(30px, -50px) scale(1.1); }
          66% { transform: translate(-20px, 20px) scale(0.9); }
          100% { transform: translate(0px, 0px) scale(1); }
        }
        .animate-blob {
          animation: blob 7s infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
        .animation-delay-4000 {
          animation-delay: 4s;
        }
      `}</style>
    </div>
  );
}