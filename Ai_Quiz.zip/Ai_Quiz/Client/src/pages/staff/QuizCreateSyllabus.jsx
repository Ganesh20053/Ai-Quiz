import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../../api/auth.js';
import axios from 'axios';
import {
  ArrowLeft, Upload, FileText, Brain, Sparkles, Edit3, Save, Plus, Trash2,
  CheckCircle, AlertCircle, Loader2, BookOpen, Target, Clock, Award,
  RefreshCw, Eye, EyeOff, ChevronDown, ChevronUp, Settings, Download,
  FileCheck, Zap, Lightbulb, Search, Filter
} from 'lucide-react';

const DIFFICULTIES = [
  {
    value: 'easy',
    label: 'Easy',
    color: 'from-green-400 to-green-600',
    bgColor: 'bg-green-50 dark:bg-green-900/20',
    textColor: 'text-green-700 dark:text-green-300',
    icon: '🟢',
    description: 'Basic concepts and simple recall questions'
  },
  {
    value: 'medium',
    label: 'Medium',
    color: 'from-yellow-400 to-orange-500',
    bgColor: 'bg-orange-50 dark:bg-orange-900/20',
    textColor: 'text-orange-700 dark:text-orange-300',
    icon: '🟡',
    description: 'Application and analysis level questions'
  },
  {
    value: 'hard',
    label: 'Hard',
    color: 'from-red-400 to-red-600',
    bgColor: 'bg-red-50 dark:bg-red-900/20',
    textColor: 'text-red-700 dark:text-red-300',
    icon: '🔴',
    description: 'Complex synthesis and evaluation questions'
  },
];

const QuizCreateSyllabus = () => {
  const { classroomId } = useParams();
  const navigate = useNavigate();

  // File upload state
  const [syllabusFile, setSyllabusFile] = useState(null);
  const [syllabusText, setSyllabusText] = useState('');
  const [uploadMethod, setUploadMethod] = useState('file'); // 'file' or 'text'
  const [uploading, setUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);

  // Processing state
  const [step, setStep] = useState(1); // 1=upload, 2=processing, 3=topics, 4=quiz, 5=review, 6=success
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [progress, setProgress] = useState(0);
  const [isLoaded, setIsLoaded] = useState(false);

  // Syllabus analysis state
  const [syllabusAnalysis, setSyllabusAnalysis] = useState(null);
  const [selectedTopics, setSelectedTopics] = useState([]);
  const [quizSettings, setQuizSettings] = useState({
    questionCount: 10,
    difficulty: 'medium',
    questionType: 'multiple-choice',
    timeLimit: 30,
    passingScore: 70
  });

  // Quiz state
  const [title, setTitle] = useState('');
  const [questions, setQuestions] = useState([]);
  const [saving, setSaving] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState(null);
  const [classroom, setClassroom] = useState(null);

  // Language selection state
  const [selectedLanguage, setSelectedLanguage] = useState('english');

  // Initialize component
  useEffect(() => {
    const fetchClassroom = async () => {
      try {
        const response = await api.get(`/classroom/${classroomId}`);
        setClassroom(response.data.data);
      } catch (err) {
        console.error('Failed to fetch classroom:', err);
        setError('Failed to load classroom data');
      }
    };
    fetchClassroom();
    setIsLoaded(true);
  }, [classroomId]);

  // Handle file drag and drop
  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (validateFile(file)) {
        setSyllabusFile(file);
        setError(null);
      }
    }
  };

  // Validate file type and size
  const validateFile = (file) => {
    const allowedTypes = ['text/plain', 'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    const maxSize = 10 * 1024 * 1024; // 10MB

    if (!allowedTypes.includes(file.type)) {
      setError('Please upload a .txt, .pdf, .doc, or .docx file');
      return false;
    }

    if (file.size > maxSize) {
      setError('File size must be less than 10MB');
      return false;
    }

    return true;
  };

  // Handle file selection
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file && validateFile(file)) {
      setSyllabusFile(file);
      setError(null);
    }
  };

  // Process syllabus (file upload or text input)
  const handleProcessSyllabus = async () => {
    if (!syllabusFile && !syllabusText.trim()) {
      setError('Please upload a file or enter syllabus text');
      return;
    }

    setStep(2);
    setError(null);
    setProgress(0);

    try {
      let response;

      // Progress simulation
      const progressInterval = setInterval(() => {
        setProgress(prev => Math.min(prev + 10, 90));
      }, 500);

      if (syllabusFile) {
        // File upload
        const formData = new FormData();
        formData.append('syllabus', syllabusFile);

        response = await api.post('/ai/process-syllabus', formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        });
      } else {
        // Text input
        response = await api.post('/ai/process-syllabus', {
          syllabusText: syllabusText
        });
      }

      clearInterval(progressInterval);
      setProgress(100);

      const analysis = response.data.data;
      setSyllabusAnalysis(analysis);

      // Auto-select all topics initially
      setSelectedTopics(analysis.topics || []);

      setTimeout(() => {
        setStep(3);
        const fileType = syllabusFile ? (syllabusFile.name.toLowerCase().endsWith('.pdf') ? 'PDF' : 'text file') : 'text content';
        setSuccess(`Successfully analyzed ${fileType} and found ${analysis.topics?.length || 0} topics! ${syllabusFile?.name.toLowerCase().endsWith('.pdf') ? '📄 PDF processed successfully!' : ''}`);
      }, 1000);

    } catch (err) {
      setError(err.response?.data?.message || err.message || 'Failed to process syllabus');
      setStep(1);
      setProgress(0);
    }
  };

  // Handle topic selection
  const toggleTopicSelection = (topic) => {
    setSelectedTopics(prev => {
      const isSelected = prev.some(t => t.title === topic.title);
      if (isSelected) {
        return prev.filter(t => t.title !== topic.title);
      } else {
        return [...prev, topic];
      }
    });
  };

  // Select all topics
  const selectAllTopics = () => {
    setSelectedTopics(syllabusAnalysis.topics || []);
  };

  // Clear all topic selections
  const clearAllTopics = () => {
    setSelectedTopics([]);
  };

  // Handle quiz settings change
  const handleQuizSettingsChange = (field, value) => {
    setQuizSettings(prev => ({ ...prev, [field]: value }));
  };

  // Generate quiz from selected topics
  const handleGenerateQuiz = async () => {
    if (selectedTopics.length === 0) {
      setError('Please select at least one topic');
      return;
    }

    setStep(4);
    setError(null);
    setProgress(0);

    try {
      // Progress simulation
      const progressInterval = setInterval(() => {
        setProgress(prev => Math.min(prev + 15, 90));
      }, 800);

      const response = await api.post('/ai/generate-from-topics', {
        selectedTopics,
        questionCount: quizSettings.questionCount,
        difficulty: quizSettings.difficulty,
        questionType: quizSettings.questionType,
        subject: syllabusAnalysis.subject || classroom?.subject || 'General',
        language: selectedLanguage
      });

      clearInterval(progressInterval);
      setProgress(100);

      const quiz = response.data.data;
      const defaultTitle = `${syllabusAnalysis.subject || classroom?.subject || 'Syllabus'} Quiz - ${selectedLanguage === 'tamil' ? 'Tamil' : 'English'}`;
      setTitle(quiz.quizTitle || defaultTitle);

      const processedQuestions = quiz.questions.map((q, index) => ({
        id: Date.now() + index,
        question: q.question || '',
        options: q.options || { A: '', B: '', C: '', D: '' },
        correctAnswer: q.correctAnswer || 'A',
        explanation: q.explanation || '',
        type: quizSettings.questionType,
        difficulty: q.difficulty || quizSettings.difficulty,
        topic: q.topic || 'General',
        subtopic: q.subtopic || '',
        bloomsLevel: q.bloomsLevel || 'knowledge',
        points: q.points || 1,
        isEditing: false
      }));

      setQuestions(processedQuestions);

      setTimeout(() => {
        setStep(5);
        setSuccess(`Successfully generated ${processedQuestions.length} questions from selected topics!`);
      }, 1000);

    } catch (err) {
      setError(err.response?.data?.message || err.message || 'Failed to generate quiz from topics');
      setStep(3);
      setProgress(0);
    }
  };

  // Question editing functions
  const handleQuestionChange = (idx, field, value) => {
    setQuestions((prev) =>
      prev.map((q, i) =>
        i === idx ? { ...q, [field]: value } : q
      )
    );
  };

  const handleOptionChange = (idx, opt, value) => {
    setQuestions((prev) =>
      prev.map((q, i) =>
        i === idx ? { ...q, options: { ...q.options, [opt]: value } } : q
      )
    );
  };

  const handleCorrectAnswerChange = (idx, value) => {
    setQuestions((prev) =>
      prev.map((q, i) =>
        i === idx ? { ...q, correctAnswer: value } : q
      )
    );
  };

  // Toggle question editing mode
  const toggleQuestionEdit = (idx) => {
    setQuestions(prev =>
      prev.map((q, i) =>
        i === idx ? { ...q, isEditing: !q.isEditing } : q
      )
    );
  };

  // Add new question
  const addQuestion = () => {
    const newQuestion = {
      id: Date.now(),
      question: '',
      options: { A: '', B: '', C: '', D: '' },
      correctAnswer: 'A',
      explanation: '',
      type: quizSettings.questionType,
      difficulty: quizSettings.difficulty,
      topic: 'Custom',
      subtopic: '',
      bloomsLevel: 'knowledge',
      points: 1,
      isEditing: true
    };
    setQuestions(prev => [...prev, newQuestion]);
  };

  // Remove question
  const removeQuestion = (idx) => {
    if (window.confirm('Are you sure you want to remove this question?')) {
      setQuestions(prev => prev.filter((_, i) => i !== idx));
    }
  };

  // Duplicate question
  const duplicateQuestion = (idx) => {
    const questionToDuplicate = questions[idx];
    const duplicatedQuestion = {
      ...questionToDuplicate,
      id: Date.now(),
      question: questionToDuplicate.question + ' (Copy)',
      isEditing: true
    };
    setQuestions(prev => [...prev, duplicatedQuestion]);
  };

  // Save quiz
  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setSuccess(null);

    // Validation
    if (!title.trim()) {
      setError('Please enter a quiz title');
      setSaving(false);
      return;
    }

    if (questions.length === 0) {
      setError('Please add at least one question to the quiz');
      setSaving(false);
      return;
    }

    // Validate that all questions have content
    const invalidQuestions = questions.filter(q =>
      !q.question.trim() ||
      !Object.values(q.options).every(opt => opt.trim()) ||
      !q.correctAnswer
    );

    if (invalidQuestions.length > 0) {
      setError(`Please complete all questions. ${invalidQuestions.length} question(s) are incomplete.`);
      setSaving(false);
      return;
    }

    try {
      const token = localStorage.getItem('token');

      const quizData = {
        title,
        description: `Quiz generated from syllabus covering: ${selectedTopics.map(t => t.title).join(', ')}`,
        classroomId: classroomId,
        subject: syllabusAnalysis?.subject || classroom?.subject || 'General',
        topic: selectedTopics.map(t => t.title).join(', '),
        difficulty: quizSettings.difficulty,
        questions: questions.map(q => ({
          question: q.question,
          type: q.type || 'multiple-choice',
          options: q.options,
          correctAnswer: q.correctAnswer,
          explanation: q.explanation,
          points: q.points || 1,
          difficulty: q.difficulty || quizSettings.difficulty
        })),
        settings: {
          timeLimit: quizSettings.timeLimit,
          passingScore: quizSettings.passingScore,
          shuffleQuestions: true,
          showResults: true,
          showCorrectAnswers: true,
          allowRetake: false,
          maxAttempts: 1
        },
        syllabusGenerated: true,
        status: 'draft'
      };

      console.log('Sending quiz data:', quizData); // Debug log

      const response = await axios.post('/api/quizzes', quizData, {
        headers: { Authorization: `Bearer ${token}` },
      });

      console.log('Quiz creation response:', response.data); // Debug log

      setStep(6);
      setSuccess('🎉 Quiz created successfully! Students can now take this quiz.');

      setTimeout(() => {
        navigate(`/staff/classrooms/${classroomId}/quizzes`);
      }, 2000);

    } catch (err) {
      console.error('Quiz creation error:', err); // Debug log
      console.error('Error response:', err.response?.data); // Debug log

      const errorMessage = err.response?.data?.message || err.message || 'Failed to create quiz';
      setError(errorMessage);

      // If it's a validation error, don't change the step
      if (err.response?.status === 400) {
        // Stay on current step for user to fix the issue
      } else {
        // For other errors, you might want to go back to a previous step
      }
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-20 w-72 h-72 bg-green-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob"></div>
        <div className="absolute top-40 right-20 w-72 h-72 bg-emerald-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000"></div>
        <div className="absolute -bottom-8 left-40 w-72 h-72 bg-teal-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-4000"></div>
      </div>

      <div className="relative z-10 min-h-screen py-8 px-4">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <button
              onClick={() => navigate(`/staff/classrooms/${classroomId}/quizzes/new`)}
              className="flex items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              Back to Quiz Options
            </button>
            <div className="text-sm text-gray-500 dark:text-gray-400">
              Step {step} of 6
            </div>
          </div>

          {/* Progress Bar */}
          <div className="mb-8">
            <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400 mb-2">
              <span>Upload</span>
              <span>Process</span>
              <span>Topics</span>
              <span>Generate</span>
              <span>Review</span>
              <span>Complete</span>
            </div>
            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
              <div
                className="bg-gradient-to-r from-green-600 to-emerald-600 h-2 rounded-full transition-all duration-500"
                style={{ width: `${(step / 6) * 100}%` }}
              ></div>
            </div>
          </div>

          {/* Error Display */}
          {error && (
            <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0" />
              <span className="text-red-700 dark:text-red-300">{error}</span>
            </div>
          )}

          {/* Success Display */}
          {success && (
            <div className="mb-6 p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-xl flex items-center gap-3">
              <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400 flex-shrink-0" />
              <span className="text-green-700 dark:text-green-300">{success}</span>
            </div>
          )}

          {/* Step Content */}
          {step === 1 && (
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-12">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full mb-6">
                  <BookOpen className="w-8 h-8 text-white" />
                </div>
                <h1 className="text-4xl md:text-5xl font-extrabold mb-6 leading-tight">
                  <span className="bg-gradient-to-r from-green-600 via-emerald-600 to-teal-600 bg-clip-text text-transparent">
                    Syllabus-Powered
                  </span>
                  <br />
                  <span className="text-gray-900 dark:text-white">Quiz Generation</span>
                </h1>
                <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto mb-8">
                  Upload your syllabus and let AI analyze it to extract key topics and generate comprehensive quizzes automatically.
                </p>
              </div>

              {/* Upload Methods */}
              <div className="grid md:grid-cols-2 gap-8 mb-8">
                <div
                  className={`p-6 rounded-2xl border-2 border-dashed transition-all cursor-pointer ${
                    uploadMethod === 'file'
                      ? 'border-green-500 bg-green-50 dark:bg-green-900/20'
                      : 'border-gray-300 dark:border-gray-600 hover:border-green-400'
                  }`}
                  onClick={() => setUploadMethod('file')}
                >
                  <div className="text-center">
                    <Upload className="w-12 h-12 mx-auto mb-4 text-green-600" />
                    <h3 className="text-xl font-bold mb-2 text-gray-900 dark:text-white">Upload File</h3>
                    <p className="text-gray-600 dark:text-gray-300 mb-4">
                      Upload your syllabus as a PDF, DOC, DOCX, or TXT file
                    </p>
                    {uploadMethod === 'file' && (
                      <div className="mt-4">
                        <div
                          className={`border-2 border-dashed rounded-lg p-8 transition-colors ${
                            dragActive
                              ? 'border-green-500 bg-green-100 dark:bg-green-900/30'
                              : 'border-gray-300 dark:border-gray-600'
                          }`}
                          onDragEnter={handleDrag}
                          onDragLeave={handleDrag}
                          onDragOver={handleDrag}
                          onDrop={handleDrop}
                        >
                          <input
                            type="file"
                            accept=".pdf,.doc,.docx,.txt"
                            onChange={handleFileChange}
                            className="hidden"
                            id="file-upload"
                          />
                          <label htmlFor="file-upload" className="cursor-pointer">
                            <div className="text-center">
                              <FileText className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                {syllabusFile ? syllabusFile.name : 'Click to browse or drag and drop your file here'}
                              </p>
                              <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                                ✅ PDF & TXT supported • 📄 DOC/DOCX coming soon • Max 10MB
                              </p>
                            </div>
                          </label>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                <div
                  className={`p-6 rounded-2xl border-2 border-dashed transition-all cursor-pointer ${
                    uploadMethod === 'text'
                      ? 'border-green-500 bg-green-50 dark:bg-green-900/20'
                      : 'border-gray-300 dark:border-gray-600 hover:border-green-400'
                  }`}
                  onClick={() => setUploadMethod('text')}
                >
                  <div className="text-center">
                    <Edit3 className="w-12 h-12 mx-auto mb-4 text-green-600" />
                    <h3 className="text-xl font-bold mb-2 text-gray-900 dark:text-white">Paste Text</h3>
                    <p className="text-gray-600 dark:text-gray-300 mb-4">
                      Copy and paste your syllabus content directly
                    </p>
                    {uploadMethod === 'text' && (
                      <div className="mt-4">
                        <textarea
                          value={syllabusText}
                          onChange={(e) => setSyllabusText(e.target.value)}
                          placeholder="Paste your syllabus content here..."
                          rows="8"
                          className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all resize-none"
                        />
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Process Button */}
              <div className="text-center">
                <button
                  onClick={handleProcessSyllabus}
                  disabled={uploading || (!syllabusFile && !syllabusText.trim())}
                  className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-bold py-4 px-8 rounded-xl shadow-lg hover:shadow-xl transform hover:scale-[1.02] transition-all duration-200 flex items-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Brain className="w-5 h-5" />
                  {uploading ? 'Processing...' : 'Analyze Syllabus with AI'}
                </button>
              </div>
            </div>
          )}

          {/* Step 2: Processing with Enhanced Loading Animation */}
          {step === 2 && (
            <div className="text-center py-16">
              <div className="relative inline-flex items-center justify-center w-32 h-32 mb-8">
                {/* Outer rotating ring */}
                <div className="absolute inset-0 border-4 border-green-200 dark:border-green-800 rounded-full animate-spin"></div>
                {/* Inner pulsing circle */}
                <div className="absolute inset-4 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full animate-pulse"></div>
                {/* Center icon */}
                <div className="relative z-10 bg-white dark:bg-gray-800 rounded-full p-4">
                  <Brain className="w-8 h-8 text-green-600 animate-pulse" />
                </div>
                {/* Floating particles */}
                <div className="absolute top-2 left-8 w-2 h-2 bg-green-400 rounded-full animate-bounce delay-100"></div>
                <div className="absolute top-8 right-2 w-2 h-2 bg-emerald-400 rounded-full animate-bounce delay-300"></div>
                <div className="absolute bottom-2 left-2 w-2 h-2 bg-teal-400 rounded-full animate-bounce delay-500"></div>
                <div className="absolute bottom-8 right-8 w-2 h-2 bg-green-500 rounded-full animate-bounce delay-700"></div>
              </div>

              <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
                🧠 Analyzing Your Syllabus...
              </h3>
              <p className="text-lg text-gray-600 dark:text-gray-400 mb-8 max-w-md mx-auto">
                Our AI is carefully reading through your content and extracting key topics for quiz generation
              </p>

              {/* Enhanced Progress Bar */}
              <div className="max-w-md mx-auto mb-6">
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-4 relative overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-green-600 via-emerald-500 to-teal-500 h-4 rounded-full transition-all duration-500 relative"
                    style={{ width: `${progress}%` }}
                  >
                    {/* Shimmer effect */}
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-pulse"></div>
                  </div>
                </div>
                <div className="flex justify-between text-sm text-gray-500 dark:text-gray-400 mt-2">
                  <span>Processing...</span>
                  <span>{progress}%</span>
                </div>
              </div>

              {/* Processing steps indicator */}
              <div className="flex justify-center space-x-8 text-sm">
                <div className={`flex items-center gap-2 ${progress > 20 ? 'text-green-600' : 'text-gray-400'}`}>
                  <div className={`w-2 h-2 rounded-full ${progress > 20 ? 'bg-green-500 animate-pulse' : 'bg-gray-300'}`}></div>
                  Reading Content
                </div>
                <div className={`flex items-center gap-2 ${progress > 50 ? 'text-green-600' : 'text-gray-400'}`}>
                  <div className={`w-2 h-2 rounded-full ${progress > 50 ? 'bg-green-500 animate-pulse' : 'bg-gray-300'}`}></div>
                  Extracting Topics
                </div>
                <div className={`flex items-center gap-2 ${progress > 80 ? 'text-green-600' : 'text-gray-400'}`}>
                  <div className={`w-2 h-2 rounded-full ${progress > 80 ? 'bg-green-500 animate-pulse' : 'bg-gray-300'}`}></div>
                  Finalizing Analysis
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Topic Selection with Language Choice */}
          {step === 3 && syllabusAnalysis && (
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-12">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full mb-6">
                  <CheckCircle className="w-8 h-8 text-white" />
                </div>
                <h1 className="text-4xl md:text-5xl font-extrabold mb-6 leading-tight">
                  <span className="bg-gradient-to-r from-green-600 via-emerald-600 to-teal-600 bg-clip-text text-transparent">
                    Topics Extracted!
                  </span>
                </h1>
                <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto mb-8">
                  We found <span className="font-bold text-green-600">{syllabusAnalysis.topics?.length || 0} topics</span> in your syllabus.
                  Select the topics you want to include and choose your preferred language.
                </p>
              </div>

              {/* Language Selection */}
              <div className="mb-8">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4 text-center">
                  🌐 Choose Quiz Language
                </h3>
                <div className="flex justify-center gap-4">
                  <button
                    onClick={() => setSelectedLanguage('english')}
                    className={`px-8 py-4 rounded-xl font-bold transition-all duration-200 flex items-center gap-3 ${
                      selectedLanguage === 'english'
                        ? 'bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-lg scale-105'
                        : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600 hover:shadow-md'
                    }`}
                  >
                    🇺🇸 English
                  </button>
                  <button
                    onClick={() => setSelectedLanguage('tamil')}
                    className={`px-8 py-4 rounded-xl font-bold transition-all duration-200 flex items-center gap-3 ${
                      selectedLanguage === 'tamil'
                        ? 'bg-gradient-to-r from-orange-600 to-red-600 text-white shadow-lg scale-105'
                        : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600 hover:shadow-md'
                    }`}
                  >
                    🇮🇳 Tamil
                  </button>
                </div>
              </div>

              {/* Topic Selection */}
              <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 p-8">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                    📚 Select Topics for Quiz
                  </h3>
                  <div className="flex gap-3">
                    <button
                      onClick={selectAllTopics}
                      className="px-4 py-2 text-sm bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 rounded-lg hover:bg-green-200 dark:hover:bg-green-900/50 transition-colors"
                    >
                      Select All
                    </button>
                    <button
                      onClick={clearAllTopics}
                      className="px-4 py-2 text-sm bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                    >
                      Clear All
                    </button>
                  </div>
                </div>

                <div className="grid gap-4 mb-8">
                  {syllabusAnalysis.topics?.map((topic, index) => (
                    <div
                      key={index}
                      onClick={() => toggleTopicSelection(topic)}
                      className={`p-6 rounded-xl border-2 cursor-pointer transition-all duration-200 ${
                        selectedTopics.some(t => t.title === topic.title)
                          ? 'border-green-500 bg-green-50 dark:bg-green-900/20 shadow-md scale-[1.02]'
                          : 'border-gray-200 dark:border-gray-600 hover:border-green-300 hover:shadow-sm'
                      }`}
                    >
                      <div className="flex items-start gap-4">
                        <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center mt-1 ${
                          selectedTopics.some(t => t.title === topic.title)
                            ? 'border-green-500 bg-green-500'
                            : 'border-gray-300 dark:border-gray-600'
                        }`}>
                          {selectedTopics.some(t => t.title === topic.title) && (
                            <CheckCircle className="w-4 h-4 text-white" />
                          )}
                        </div>
                        <div className="flex-1">
                          <h4 className="text-lg font-bold text-gray-900 dark:text-white mb-2">
                            {topic.title}
                          </h4>
                          <p className="text-gray-600 dark:text-gray-400 mb-3">
                            {topic.description}
                          </p>
                          {topic.subtopics && topic.subtopics.length > 0 && (
                            <div className="flex flex-wrap gap-2">
                              {topic.subtopics.slice(0, 5).map((subtopic, subIndex) => (
                                <span
                                  key={subIndex}
                                  className="px-3 py-1 text-xs bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded-full"
                                >
                                  {subtopic}
                                </span>
                              ))}
                              {topic.subtopics.length > 5 && (
                                <span className="px-3 py-1 text-xs bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded-full">
                                  +{topic.subtopics.length - 5} more
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Generate Quiz Button */}
                <div className="text-center">
                  <button
                    onClick={handleGenerateQuiz}
                    disabled={selectedTopics.length === 0}
                    className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-bold py-4 px-8 rounded-xl shadow-lg hover:shadow-xl transform hover:scale-[1.02] transition-all duration-200 flex items-center gap-3 mx-auto disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Sparkles className="w-5 h-5" />
                    Generate Quiz in {selectedLanguage === 'tamil' ? 'Tamil' : 'English'}
                    <span className="bg-white/20 px-2 py-1 rounded-full text-sm">
                      {selectedTopics.length} topic{selectedTopics.length !== 1 ? 's' : ''}
                    </span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="text-center py-16">
              <div className="relative inline-flex items-center justify-center w-32 h-32 mb-8">
                {/* Outer rotating rings */}
                <div className="absolute inset-0 border-4 border-green-200 dark:border-green-800 rounded-full animate-spin"></div>
                <div className="absolute inset-2 border-4 border-emerald-300 dark:border-emerald-700 rounded-full animate-spin" style={{ animationDirection: 'reverse', animationDuration: '3s' }}></div>

                {/* Center pulsing circle */}
                <div className="absolute inset-8 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full animate-pulse"></div>

                {/* Center icon */}
                <div className="relative z-10 bg-white dark:bg-gray-800 rounded-full p-4">
                  <Sparkles className="w-8 h-8 text-green-600 animate-pulse" />
                </div>

                {/* Floating question marks */}
                <div className="absolute top-4 left-8 w-3 h-3 bg-blue-400 rounded-full animate-bounce delay-100">
                  <span className="text-xs text-white font-bold">?</span>
                </div>
                <div className="absolute top-8 right-4 w-3 h-3 bg-purple-400 rounded-full animate-bounce delay-300">
                  <span className="text-xs text-white font-bold">?</span>
                </div>
                <div className="absolute bottom-4 left-4 w-3 h-3 bg-indigo-400 rounded-full animate-bounce delay-500">
                  <span className="text-xs text-white font-bold">?</span>
                </div>
                <div className="absolute bottom-8 right-8 w-3 h-3 bg-teal-400 rounded-full animate-bounce delay-700">
                  <span className="text-xs text-white font-bold">?</span>
                </div>
              </div>

              <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
                🎯 Crafting Your Quiz...
              </h3>
              <p className="text-lg text-gray-600 dark:text-gray-400 mb-8 max-w-md mx-auto">
                AI is creating personalized questions from your selected topics in <span className="font-semibold text-green-600">{selectedLanguage === 'tamil' ? 'Tamil' : 'English'}</span>
              </p>

              {/* Enhanced Progress Bar */}
              <div className="max-w-md mx-auto mb-6">
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-4 relative overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-green-600 via-emerald-500 to-teal-500 h-4 rounded-full transition-all duration-500 relative"
                    style={{ width: `${progress}%` }}
                  >
                    {/* Shimmer effect */}
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-pulse"></div>
                  </div>
                </div>
                <div className="flex justify-between text-sm text-gray-500 dark:text-gray-400 mt-2">
                  <span>Generating...</span>
                  <span>{progress}%</span>
                </div>
              </div>

              {/* Generation steps indicator */}
              <div className="flex justify-center space-x-8 text-sm">
                <div className={`flex items-center gap-2 ${progress > 25 ? 'text-green-600' : 'text-gray-400'}`}>
                  <div className={`w-2 h-2 rounded-full ${progress > 25 ? 'bg-green-500 animate-pulse' : 'bg-gray-300'}`}></div>
                  Analyzing Topics
                </div>
                <div className={`flex items-center gap-2 ${progress > 50 ? 'text-green-600' : 'text-gray-400'}`}>
                  <div className={`w-2 h-2 rounded-full ${progress > 50 ? 'bg-green-500 animate-pulse' : 'bg-gray-300'}`}></div>
                  Creating Questions
                </div>
                <div className={`flex items-center gap-2 ${progress > 80 ? 'text-green-600' : 'text-gray-400'}`}>
                  <div className={`w-2 h-2 rounded-full ${progress > 80 ? 'bg-green-500 animate-pulse' : 'bg-gray-300'}`}></div>
                  Finalizing Quiz
                </div>
              </div>

              {/* Selected topics preview */}
              <div className="mt-8 max-w-2xl mx-auto">
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-3">Generating questions for:</p>
                <div className="flex flex-wrap justify-center gap-2">
                  {selectedTopics.slice(0, 5).map((topic, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 text-xs bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 rounded-full animate-pulse"
                      style={{ animationDelay: `${index * 200}ms` }}
                    >
                      {topic.title}
                    </span>
                  ))}
                  {selectedTopics.length > 5 && (
                    <span className="px-3 py-1 text-xs bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded-full">
                      +{selectedTopics.length - 5} more
                    </span>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Step 5: Review and Edit Quiz */}
          {step === 5 && (
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-8">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full mb-6">
                  <Edit3 className="w-8 h-8 text-white" />
                </div>
                <h1 className="text-4xl md:text-5xl font-extrabold mb-6 leading-tight">
                  <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent">
                    Review & Edit Quiz
                  </span>
                </h1>
                <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto mb-8">
                  Your quiz has been generated! Review the questions below and make any necessary edits before saving.
                </p>
              </div>

              {/* Quiz Title Editor */}
              <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 p-8 mb-8">
                <div className="flex items-center gap-4 mb-6">
                  <Target className="w-6 h-6 text-blue-600" />
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Quiz Details</h3>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Quiz Title
                    </label>
                    <input
                      type="text"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                      placeholder="Enter quiz title..."
                    />
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2 px-4 py-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
                      <Clock className="w-4 h-4 text-blue-600" />
                      <span className="text-sm font-medium text-blue-700 dark:text-blue-300">
                        {questions.length} Questions
                      </span>
                    </div>
                    <div className="flex items-center gap-2 px-4 py-2 bg-green-100 dark:bg-green-900/30 rounded-lg">
                      <Award className="w-4 h-4 text-green-600" />
                      <span className="text-sm font-medium text-green-700 dark:text-green-300">
                        {selectedLanguage === 'tamil' ? 'Tamil' : 'English'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Questions Editor */}
              <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 p-8 mb-8">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-4">
                    <FileText className="w-6 h-6 text-purple-600" />
                    <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Questions</h3>
                  </div>
                  <button
                    onClick={addQuestion}
                    className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white rounded-lg font-medium transition-all transform hover:scale-105"
                  >
                    <Plus className="w-4 h-4" />
                    Add Question
                  </button>
                </div>

                <div className="space-y-6">
                  {questions.map((question, index) => (
                    <div
                      key={question.id}
                      className="border border-gray-200 dark:border-gray-600 rounded-xl p-6 hover:shadow-lg transition-all"
                    >
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                            {index + 1}
                          </div>
                          <div className="flex items-center gap-2">
                            <span className={`px-2 py-1 text-xs rounded-full ${
                              question.difficulty === 'easy' ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300' :
                              question.difficulty === 'medium' ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-300' :
                              'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300'
                            }`}>
                              {question.difficulty}
                            </span>
                            <span className="px-2 py-1 text-xs bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded-full">
                              {question.topic}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => toggleQuestionEdit(index)}
                            className={`p-2 rounded-lg transition-all ${
                              question.isEditing
                                ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-600'
                                : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600'
                            }`}
                          >
                            {question.isEditing ? <EyeOff className="w-4 h-4" /> : <Edit3 className="w-4 h-4" />}
                          </button>
                          <button
                            onClick={() => duplicateQuestion(index)}
                            className="p-2 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-all"
                          >
                            <RefreshCw className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => removeQuestion(index)}
                            className="p-2 bg-red-100 dark:bg-red-900/30 text-red-600 rounded-lg hover:bg-red-200 dark:hover:bg-red-900/50 transition-all"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {question.isEditing ? (
                        <div className="space-y-4">
                          {/* Question Text Editor */}
                          <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                              Question
                            </label>
                            <textarea
                              value={question.question}
                              onChange={(e) => handleQuestionChange(index, 'question', e.target.value)}
                              rows="3"
                              className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none"
                              placeholder="Enter your question..."
                            />
                          </div>

                          {/* Options Editor */}
                          <div className="grid md:grid-cols-2 gap-4">
                            {Object.entries(question.options).map(([key, value]) => (
                              <div key={key}>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                  Option {key}
                                  {question.correctAnswer === key && (
                                    <span className="ml-2 px-2 py-1 text-xs bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300 rounded-full">
                                      Correct
                                    </span>
                                  )}
                                </label>
                                <div className="flex gap-2">
                                  <input
                                    type="text"
                                    value={value}
                                    onChange={(e) => handleOptionChange(index, key, e.target.value)}
                                    className="flex-1 px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                                    placeholder={`Option ${key}...`}
                                  />
                                  <button
                                    onClick={() => handleCorrectAnswerChange(index, key)}
                                    className={`px-4 py-3 rounded-lg font-medium transition-all ${
                                      question.correctAnswer === key
                                        ? 'bg-green-600 text-white'
                                        : 'bg-gray-200 dark:bg-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-500'
                                    }`}
                                  >
                                    {question.correctAnswer === key ? '✓' : 'Set'}
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>

                          {/* Explanation Editor */}
                          <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                              Explanation
                            </label>
                            <textarea
                              value={question.explanation}
                              onChange={(e) => handleQuestionChange(index, 'explanation', e.target.value)}
                              rows="2"
                              className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none"
                              placeholder="Explain why this answer is correct..."
                            />
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {/* Question Display */}
                          <div>
                            <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
                              {question.question}
                            </h4>
                          </div>

                          {/* Options Display */}
                          <div className="grid md:grid-cols-2 gap-3">
                            {Object.entries(question.options).map(([key, value]) => (
                              <div
                                key={key}
                                className={`p-3 rounded-lg border ${
                                  question.correctAnswer === key
                                    ? 'border-green-500 bg-green-50 dark:bg-green-900/20'
                                    : 'border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-700'
                                }`}
                              >
                                <div className="flex items-center gap-3">
                                  <span className={`w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold ${
                                    question.correctAnswer === key
                                      ? 'bg-green-500 text-white'
                                      : 'bg-gray-300 dark:bg-gray-600 text-gray-700 dark:text-gray-300'
                                  }`}>
                                    {key}
                                  </span>
                                  <span className="text-gray-900 dark:text-white">{value}</span>
                                </div>
                              </div>
                            ))}
                          </div>

                          {/* Explanation Display */}
                          {question.explanation && (
                            <div className="p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                              <div className="flex items-start gap-3">
                                <Lightbulb className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                                <div>
                                  <h5 className="font-medium text-blue-900 dark:text-blue-100 mb-1">Explanation</h5>
                                  <p className="text-blue-800 dark:text-blue-200 text-sm">{question.explanation}</p>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Save Quiz Section */}
              <div className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-2xl p-8 text-center">
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                  Ready to Save Your Quiz?
                </h3>
                <p className="text-gray-600 dark:text-gray-300 mb-6 max-w-2xl mx-auto">
                  Once saved, this quiz will be available for your students to take. You can always edit it later from the quiz management page.
                </p>

                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <button
                    onClick={() => setStep(3)}
                    className="px-8 py-4 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-xl font-bold hover:bg-gray-50 dark:hover:bg-gray-800 transition-all"
                  >
                    ← Back to Topics
                  </button>
                  <button
                    onClick={handleSave}
                    disabled={saving || !title.trim() || questions.length === 0}
                    className="px-8 py-4 bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 hover:from-blue-700 hover:via-purple-700 hover:to-indigo-700 text-white rounded-xl font-bold shadow-lg hover:shadow-xl transform hover:scale-[1.02] transition-all duration-200 flex items-center gap-3 justify-center disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {saving ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        Saving Quiz...
                      </>
                    ) : (
                      <>
                        <Save className="w-5 h-5" />
                        Save Quiz ({questions.length} questions)
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          )}

          {step === 6 && (
            <div className="text-center py-16 space-y-6">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full mb-6">
                <CheckCircle className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-3xl font-bold text-gray-900 dark:text-white">
                Quiz Created Successfully!
              </h3>
              <p className="text-gray-600 dark:text-gray-400 max-w-md mx-auto">
                Your syllabus-based quiz has been created and is ready for students to take.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button
                  onClick={() => navigate(`/staff/classrooms/${classroomId}/quizzes`)}
                  className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-bold py-4 px-8 rounded-xl shadow-lg hover:shadow-xl transform hover:scale-[1.02] transition-all duration-200"
                >
                  View All Quizzes
                </button>
                <button
                  onClick={() => {
                    setStep(1);
                    setSyllabusFile(null);
                    setSyllabusText('');
                    setSyllabusAnalysis(null);
                    setSelectedTopics([]);
                    setQuestions([]);
                    setTitle('');
                  }}
                  className="border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 font-bold py-4 px-8 rounded-xl transition-all duration-200"
                >
                  Create Another Quiz
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Custom Styles */}
      <style>{`
        @keyframes blob {
          0% { transform: translate(0px, 0px) scale(1); }
          33% { transform: translate(30px, -50px) scale(1.1); }
          66% { transform: translate(-20px, 20px) scale(0.9); }
          100% { transform: translate(0px, 0px) scale(1); }
        }
        .animate-blob {
          animation: blob 7s infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
        .animation-delay-4000 {
          animation-delay: 4s;
        }

        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        .animate-shimmer {
          animation: shimmer 2s infinite;
        }

        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
        .animate-float {
          animation: float 3s ease-in-out infinite;
        }

        .delay-100 { animation-delay: 0.1s; }
        .delay-300 { animation-delay: 0.3s; }
        .delay-500 { animation-delay: 0.5s; }
        .delay-700 { animation-delay: 0.7s; }
      `}</style>
    </div>
  );
};

export default QuizCreateSyllabus; 