import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../../api/auth.js';
import {
  ArrowLeft, Brain, Sparkles, Edit3, Save, Plus, Trash2, CheckCircle,
  AlertCircle, Loader2, Wand2, BookOpen, Target, Clock, Award,
  RefreshCw, Eye, EyeOff, ChevronDown, ChevronUp, Settings, Lightbulb
} from 'lucide-react';

const DIFFICULTIES = [
  {
    value: 'easy',
    label: 'Easy',
    color: 'from-green-400 to-green-600',
    bgColor: 'bg-green-50 dark:bg-green-900/20',
    textColor: 'text-green-700 dark:text-green-300',
    icon: '🟢',
    description: 'Basic concepts and simple recall questions'
  },
  {
    value: 'medium',
    label: 'Medium',
    color: 'from-yellow-400 to-orange-500',
    bgColor: 'bg-orange-50 dark:bg-orange-900/20',
    textColor: 'text-orange-700 dark:text-orange-300',
    icon: '🟡',
    description: 'Application and analysis level questions'
  },
  {
    value: 'hard',
    label: 'Hard',
    color: 'from-red-400 to-red-600',
    bgColor: 'bg-red-50 dark:bg-red-900/20',
    textColor: 'text-red-700 dark:text-red-300',
    icon: '🔴',
    description: 'Complex synthesis and evaluation questions'
  },
];

const LANGUAGES = [
  {
    value: 'english',
    label: 'English',
    flag: '🇺🇸',
    description: 'Generate quiz in English'
  },
  {
    value: 'tamil',
    label: 'தமிழ் (Tamil)',
    flag: '🇮🇳',
    description: 'Generate quiz in Tamil'
  }
];

const QUESTION_TYPES = [
  {
    value: 'multiple-choice',
    label: 'Multiple Choice',
    icon: '📝',
    description: 'Questions with 4 answer options'
  },
  {
    value: 'true-false',
    label: 'True/False',
    icon: '✅',
    description: 'Simple true or false questions'
  },
  {
    value: 'short-answer',
    label: 'Short Answer',
    icon: '💭',
    description: 'Open-ended text responses'
  },
];

const SUBJECTS = [
  'Mathematics', 'Science', 'English', 'History', 'Geography', 'Physics',
  'Chemistry', 'Biology', 'Computer Science', 'Art', 'Music', 'Physical Education',
  'Economics', 'Psychology', 'Philosophy', 'Literature', 'Statistics', 'Engineering'
];

const FOCUS_AREAS = [
  'Problem Solving', 'Critical Thinking', 'Conceptual Understanding', 'Practical Application',
  'Memory Recall', 'Analysis & Synthesis', 'Creative Thinking', 'Real-world Scenarios'
];

const defaultQuestion = () => ({
  question: '',
  options: { A: '', B: '', C: '', D: '' },
  correctAnswer: 'A',
  explanation: '',
  type: 'multiple_choice'
});

const QuizCreateAI = () => {
  const { classroomId } = useParams();
  const navigate = useNavigate();

  // Enhanced form state with more options
  const [formData, setFormData] = useState({
    topic: '',
    subject: '',
    difficulty: 'medium',
    numQuestions: 10,
    questionType: 'multiple_choice',
    language: 'english',
    includeExplanations: true,
    focusAreas: [],
    learningObjectives: '',
    timeLimit: 30,
    passingScore: 70,
    bloomsLevel: 'mixed',
    contextType: 'academic',
    includeImages: false,
    adaptiveDifficulty: false
  });

  const [step, setStep] = useState(1); // 1=input, 2=loading, 3=review, 4=success
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [progress, setProgress] = useState(0);
  const [isLoaded, setIsLoaded] = useState(false);

  // Quiz state
  const [title, setTitle] = useState('');
  const [questions, setQuestions] = useState([]);
  const [saving, setSaving] = useState(false);
  const [classroom, setClassroom] = useState(null);
  const [editingQuestion, setEditingQuestion] = useState(null);
  const [showAdvanced, setShowAdvanced] = useState(false);

  // Fetch classroom data and initialize
  useEffect(() => {
    const fetchClassroom = async () => {
      try {
        const response = await api.get(`/classroom/${classroomId}`);
        setClassroom(response.data.data);
        setFormData(prev => ({
          ...prev,
          subject: response.data.data.subject || '',
          topic: response.data.data.subject || ''
        }));
      } catch (err) {
        console.error('Failed to fetch classroom:', err);
        setError('Failed to load classroom data');
      }
    };
    fetchClassroom();
    setIsLoaded(true);
  }, [classroomId]);

  // Handle form input changes
  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setError(null);
  };

  // Handle focus areas selection
  const toggleFocusArea = (area) => {
    setFormData(prev => ({
      ...prev,
      focusAreas: prev.focusAreas.includes(area)
        ? prev.focusAreas.filter(a => a !== area)
        : [...prev.focusAreas, area]
    }));
  };

  // Validate form data
  const validateForm = () => {
    if (!formData.topic.trim()) {
      setError('Please enter a topic for your quiz');
      return false;
    }
    if (formData.numQuestions < 1 || formData.numQuestions > 50) {
      setError('Number of questions must be between 1 and 50');
      return false;
    }
    return true;
  };

  // Auto-save quiz to MongoDB after generation
  const autoSaveQuiz = async (quizTitle, generatedQuestions) => {
    try {
      const finalTitle = quizTitle || `${formData.topic} - ${formData.difficulty.charAt(0).toUpperCase() + formData.difficulty.slice(1)} Quiz`;

      if (!finalTitle) {
        throw new Error('Quiz title is required');
      }

      if (!classroomId) {
        throw new Error('Classroom ID is required');
      }

      const quizData = {
        title: finalTitle,
        description: `AI-generated quiz on ${formData.topic} (${formData.language === 'tamil' ? 'தமிழ்' : 'English'})`,
        classroomId: classroomId,
        subject: formData.subject,
        topic: formData.topic,
        difficulty: formData.difficulty,
        language: formData.language,
        questions: generatedQuestions.map(q => ({
          question: q.question,
          type: 'multiple-choice',
          options: q.options ? Object.entries(q.options).map(([key, text]) => ({
            text: text,
            isCorrect: key === q.correctAnswer
          })) : [],
          correctAnswer: q.correctAnswer,
          explanation: q.explanation,
          points: q.points || 1,
          difficulty: q.difficulty || formData.difficulty
        })),
        settings: {
          timeLimit: formData.timeLimit || 30,
          passingScore: formData.passingScore || 70,
          shuffleQuestions: true,
          showResults: true,
          showCorrectAnswers: true,
          allowRetake: false,
          maxAttempts: 1
        },
        aiGenerated: true,
        status: 'published' // Auto-publish the quiz
      };

      console.log('Auto-saving quiz to MongoDB:', quizData);
      const response = await api.post('/quizzes', quizData);

      console.log('Quiz saved successfully:', response.data);
      return response.data;
    } catch (error) {
      console.error('Auto-save failed:', error);
      throw error;
    }
  };

  // Enhanced quiz generation with comprehensive AI integration
  const handleGenerate = async (e) => {
    e.preventDefault();

    if (!validateForm()) return;

    setStep(2);
    setError(null);
    setSuccess(null);
    setQuestions([]);
    setProgress(0);

    // Declare progressInterval outside try-catch so it's accessible in both blocks
    let progressInterval;

    try {
      // Enhanced progress simulation with realistic stages
      const progressStages = [
        { progress: 20, message: 'Analyzing requirements...' },
        { progress: 40, message: 'Generating questions...' },
        { progress: 60, message: 'Creating answer options...' },
        { progress: 80, message: 'Adding explanations...' },
        { progress: 95, message: 'Finalizing quiz...' }
      ];

      let currentStage = 0;
      progressInterval = setInterval(() => {
        if (currentStage < progressStages.length) {
          setProgress(progressStages[currentStage].progress);
          currentStage++;
        }
      }, 800);

      // Build comprehensive prompt for Gemini
      const focusAreasText = formData.focusAreas.length > 0
        ? `Focus Areas: ${formData.focusAreas.join(', ')}`
        : '';

      // Auto-detect subject from topic if not provided
      const subjectToUse = formData.subject || 'General Knowledge';

      const languageInstruction = formData.language === 'tamil'
        ? 'Generate all questions, options, and explanations in Tamil language (தமிழ்). Use proper Tamil grammar and vocabulary.'
        : 'Generate all questions, options, and explanations in English language.';

      const prompt = `Create a comprehensive educational quiz about "${formData.topic}". Generate questions that are directly related to this specific topic.

QUIZ SPECIFICATIONS:
- Main Topic: ${formData.topic}
- Subject Area: ${subjectToUse} (inferred from topic)
- Difficulty Level: ${formData.difficulty}
- Number of Questions: ${formData.numQuestions}
- Question Type: ${formData.questionType}
- Language: ${formData.language === 'tamil' ? 'Tamil (தமிழ்)' : 'English'}
- ${focusAreasText}
- Learning Objectives: ${formData.learningObjectives || 'Understanding and application of the topic'}
- Context: ${formData.contextType}
- Bloom's Taxonomy Level: ${formData.bloomsLevel}

LANGUAGE REQUIREMENT:
${languageInstruction}

IMPORTANT: All questions must be specifically about "${formData.topic}". Do not generate generic questions.

REQUIREMENTS:
1. Create educationally sound questions appropriate for ${formData.difficulty} difficulty
2. Each multiple choice question must have exactly 4 options (A, B, C, D)
3. Include detailed explanations for correct answers
4. Ensure questions test various cognitive levels
5. Make questions engaging and relevant to real-world applications
6. Vary question complexity within the difficulty level
7. Include diverse question formats within the chosen type
8. Ensure cultural sensitivity and inclusivity

RESPONSE FORMAT:
You MUST return ONLY a valid JSON object. Do not include any text before or after the JSON. Do not use markdown formatting or code blocks.

Return this exact JSON structure:
{
  "quizTitle": "Engaging and descriptive title for the quiz",
  "description": "Brief description of what the quiz covers and its learning objectives",
  "estimatedTime": ${formData.timeLimit},
  "questions": [
    {
      "question": "Clear, well-formatted question text",
      "options": {
        "A": "First option",
        "B": "Second option",
        "C": "Third option",
        "D": "Fourth option"
      },
      "correctAnswer": "A",
      "explanation": "Detailed explanation of why this answer is correct and why others are wrong",
      "difficulty": "${formData.difficulty}",
      "topic": "Specific subtopic or concept",
      "bloomsLevel": "knowledge/comprehension/application/analysis/synthesis/evaluation",
      "points": 1
    }
  ]
}

CRITICAL: Generate exactly ${formData.numQuestions} questions. Return ONLY the JSON object above with no additional text, explanations, or formatting.`;

      const res = await api.post('/ai/gemini', { prompt }, {
        timeout: 30000 // 30 second timeout
      });

      clearInterval(progressInterval);
      setProgress(100);

      // Parse and validate response
      let aiQuiz;
      try {
        aiQuiz = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
      } catch (parseError) {
        throw new Error('Invalid response format from AI service');
      }

      // Validate quiz structure
      if (!aiQuiz.questions || !Array.isArray(aiQuiz.questions)) {
        throw new Error('Invalid quiz structure received');
      }

      // Set quiz data with enhanced structure
      const generatedTitle = aiQuiz.quizTitle || `${formData.topic} - ${formData.difficulty.charAt(0).toUpperCase() + formData.difficulty.slice(1)} Quiz`;
      setTitle(generatedTitle);

      const processedQuestions = aiQuiz.questions.map((q, index) => ({
        id: Date.now() + index,
        question: q.question || '',
        options: q.options || { A: '', B: '', C: '', D: '' },
        correctAnswer: q.correctAnswer || 'A',
        explanation: q.explanation || '',
        type: formData.questionType,
        difficulty: q.difficulty || formData.difficulty,
        topic: q.topic || formData.topic,
        bloomsLevel: q.bloomsLevel || 'knowledge',
        points: q.points || 1,
        isEditing: false
      }));

      setQuestions(processedQuestions);

      // Auto-save the quiz to MongoDB immediately after generation
      try {
        const savedQuiz = await autoSaveQuiz(generatedTitle, processedQuestions);

        setTimeout(() => {
          setStep(4); // Skip review step, go directly to success
          setSuccess(`🎉 Successfully generated and saved ${processedQuestions.length} AI-powered questions to MongoDB! Quiz ID: ${savedQuiz.data?.quiz?._id || 'Generated'}`);

          // Auto-redirect to quizzes list after 3 seconds
          setTimeout(() => {
            navigate(`/staff/classrooms/${classroomId}/quizzes`);
          }, 3000);
        }, 1000);

      } catch (saveError) {
        console.error('Failed to auto-save quiz:', saveError);
        // If auto-save fails, still show the review step
        setTimeout(() => {
          setStep(3);
          setError(`Quiz generated successfully, but failed to save automatically: ${saveError.message}. You can still save it manually.`);
        }, 1000);
      }

    } catch (err) {
      // Clear progress interval if it exists
      if (progressInterval) {
        clearInterval(progressInterval);
      }
      console.error('Quiz generation error:', err);

      let errorMessage = 'Failed to generate quiz. Please try again.';

      if (err.response?.data?.error === 'API_KEY_MISSING') {
        errorMessage = 'Gemini API key is not configured. Please contact your administrator to set up the API key.';
      } else if (err.response?.data?.error === 'INVALID_API_KEY') {
        errorMessage = 'Invalid Gemini API key. Please contact your administrator to update the API key.';
      } else if (err.response?.data?.error === 'API_ACCESS_DENIED') {
        errorMessage = 'Gemini API access denied. Please contact your administrator to check API permissions.';
      } else if (err.response?.data?.message) {
        errorMessage = err.response.data.message;
      }

      setError(errorMessage);
      setStep(1);
      setProgress(0);
    }
  };

  // Enhanced question editing functions
  const handleQuestionChange = (idx, field, value) => {
    setQuestions((prev) =>
      prev.map((q, i) =>
        i === idx ? { ...q, [field]: value } : q
      )
    );
  };

  const handleOptionChange = (idx, opt, value) => {
    setQuestions((prev) =>
      prev.map((q, i) =>
        i === idx ? { ...q, options: { ...q.options, [opt]: value } } : q
      )
    );
  };

  const handleCorrectAnswerChange = (idx, value) => {
    setQuestions((prev) =>
      prev.map((q, i) =>
        i === idx ? { ...q, correctAnswer: value } : q
      )
    );
  };

  // Toggle question editing mode
  const toggleQuestionEdit = (idx) => {
    setQuestions(prev =>
      prev.map((q, i) =>
        i === idx ? { ...q, isEditing: !q.isEditing } : q
      )
    );
  };

  // Add new question
  const addQuestion = () => {
    const newQuestion = {
      ...defaultQuestion(),
      id: Date.now(),
      isEditing: true
    };
    setQuestions(prev => [...prev, newQuestion]);
  };

  // Remove question with confirmation
  const removeQuestion = (idx) => {
    if (window.confirm('Are you sure you want to remove this question?')) {
      setQuestions(prev => prev.filter((_, i) => i !== idx));
    }
  };

  // Duplicate question
  const duplicateQuestion = (idx) => {
    const questionToDuplicate = questions[idx];
    const duplicatedQuestion = {
      ...questionToDuplicate,
      id: Date.now(),
      question: questionToDuplicate.question + ' (Copy)',
      isEditing: true
    };
    setQuestions(prev => [...prev, duplicatedQuestion]);
  };

  // Regenerate single question
  const regenerateQuestion = async (idx) => {
    try {
      const currentQuestion = questions[idx];

      const languageInstruction = formData.language === 'tamil'
        ? 'Generate the question, options, and explanation in Tamil language (தமிழ்). Use proper Tamil grammar and vocabulary.'
        : 'Generate the question, options, and explanation in English language.';

      const prompt = `Generate a single ${formData.questionType} question specifically about "${formData.topic}" at ${formData.difficulty} difficulty level.

      LANGUAGE REQUIREMENT: ${languageInstruction}

      The question must be directly related to the topic "${formData.topic}". Do not generate generic questions.

      You MUST return ONLY a valid JSON object. Do not include any text before or after the JSON.

      Return this exact JSON structure:
      {
        "question": "Question text",
        "options": {"A": "Option A", "B": "Option B", "C": "Option C", "D": "Option D"},
        "correctAnswer": "A",
        "explanation": "Detailed explanation"
      }

      CRITICAL: Return ONLY the JSON object above with no additional text or formatting.`;

      const res = await api.post('/ai/gemini', { prompt });

      const newQuestion = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;

      setQuestions(prev =>
        prev.map((q, i) =>
          i === idx ? {
            ...q,
            ...newQuestion,
            id: q.id,
            type: formData.questionType,
            difficulty: formData.difficulty,
            topic: formData.topic
          } : q
        )
      );
    } catch (err) {
      setError('Failed to regenerate question');
    }
  };

  // Enhanced save quiz with better data structure
  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setSuccess(null);

    try {
      // Ensure we have a title and classroom
      const finalTitle = title || `${formData.topic} - ${formData.difficulty.charAt(0).toUpperCase() + formData.difficulty.slice(1)} Quiz`;

      if (!finalTitle) {
        throw new Error('Quiz title is required');
      }

      if (!classroomId) {
        throw new Error('Classroom ID is required');
      }

      const quizData = {
        title: finalTitle,
        description: `AI-generated quiz on ${formData.topic}`,
        classroomId: classroomId,
        subject: formData.subject,
        topic: formData.topic,
        difficulty: formData.difficulty,
        questions: questions.map(q => ({
          question: q.question,
          type: q.type || 'multiple-choice',
          options: q.options ? Object.entries(q.options).map(([key, text]) => ({
            text: text,
            isCorrect: key === q.correctAnswer
          })) : [],
          correctAnswer: q.correctAnswer,
          explanation: q.explanation,
          points: q.points || 1,
          difficulty: q.difficulty || formData.difficulty
        })),
        settings: {
          timeLimit: formData.timeLimit,
          passingScore: formData.passingScore,
          shuffleQuestions: true,
          showResults: true,
          showCorrectAnswers: true,
          allowRetake: false,
          maxAttempts: 1
        },
        aiGenerated: true,
        status: 'draft'
      };

      console.log('Sending quiz data:', quizData);
      const response = await api.post('/quizzes', quizData);

      setStep(4);
      setSuccess('🎉 Quiz created successfully! Students can now take this quiz.');

      setTimeout(() => {
        navigate(`/staff/classrooms/${classroomId}/quizzes`);
      }, 2000);

    } catch (err) {
      setError(err.response?.data?.message || err.message || 'Failed to create quiz');
    } finally {
      setSaving(false);
    }
  };

  // Render step 1: Input form
  const renderInputForm = () => (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full mb-4">
          <Brain className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white">AI Quiz Generator</h2>
        <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
          Harness the power of AI to create engaging, educational quizzes tailored to your curriculum
        </p>
        <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4 max-w-2xl mx-auto">
          <div className="flex items-center gap-2 text-blue-800 dark:text-blue-200 text-sm">
            <Lightbulb className="w-4 h-4" />
            <span className="font-medium">Note:</span>
            <span>This feature requires a valid Google Gemini API key. If you see API errors, please contact your administrator.</span>
          </div>
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleGenerate} className="space-y-6">
        {/* Basic Information */}
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-xl p-6 space-y-4">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-blue-500" />
            Quiz Details
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Topic *
              </label>
              <input
                type="text"
                value={formData.topic}
                onChange={(e) => handleInputChange('topic', e.target.value)}
                placeholder="e.g., Photosynthesis, World War II, Algebra"
                className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                required
              />
            </div>


          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Difficulty Level
              </label>
              <select
                value={formData.difficulty}
                onChange={(e) => handleInputChange('difficulty', e.target.value)}
                className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              >
                {DIFFICULTIES.map(diff => (
                  <option key={diff.value} value={diff.value}>
                    {diff.icon} {diff.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Number of Questions
              </label>
              <input
                type="number"
                min="1"
                max="50"
                value={formData.numQuestions}
                onChange={(e) => handleInputChange('numQuestions', parseInt(e.target.value))}
                className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Question Type
              </label>
              <select
                value={formData.questionType}
                onChange={(e) => handleInputChange('questionType', e.target.value)}
                className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              >
                {QUESTION_TYPES.map(type => (
                  <option key={type.value} value={type.value}>
                    {type.icon} {type.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Language
              </label>
              <select
                value={formData.language}
                onChange={(e) => handleInputChange('language', e.target.value)}
                className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              >
                {LANGUAGES.map(lang => (
                  <option key={lang.value} value={lang.value}>
                    {lang.flag} {lang.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Advanced Options */}
        <div className="bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 rounded-xl p-6 space-y-4">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Advanced Options</h3>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Focus Areas (Optional)
              </label>
              <input
                type="text"
                value={Array.isArray(formData.focusAreas) ? formData.focusAreas.join(', ') : formData.focusAreas}
                onChange={(e) => handleInputChange('focusAreas', e.target.value.split(',').map(s => s.trim()).filter(s => s))}
                placeholder="e.g., Problem solving, Critical thinking, Applications"
                className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Learning Objectives (Optional)
              </label>
              <textarea
                value={formData.learningObjectives}
                onChange={(e) => handleInputChange('learningObjectives', e.target.value)}
                placeholder="Describe what students should learn from this quiz..."
                rows="3"
                className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Time Limit (minutes)
                </label>
                <input
                  type="number"
                  min="5"
                  max="180"
                  value={formData.timeLimit}
                  onChange={(e) => handleInputChange('timeLimit', parseInt(e.target.value))}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Passing Score (%)
                </label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={formData.passingScore}
                  onChange={(e) => handleInputChange('passingScore', parseInt(e.target.value))}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                />
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <input
                type="checkbox"
                id="includeExplanations"
                checked={formData.includeExplanations}
                onChange={(e) => handleInputChange('includeExplanations', e.target.checked)}
                className="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500 dark:focus:ring-purple-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
              />
              <label htmlFor="includeExplanations" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                Include detailed explanations for answers
              </label>
            </div>
          </div>
        </div>

        {/* Generate Button */}
        <button
          type="submit"
          className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-bold py-4 px-8 rounded-xl shadow-lg hover:shadow-xl transform hover:scale-[1.02] transition-all duration-200 flex items-center justify-center gap-3 text-lg"
        >
          <Brain className="w-6 h-6" />
          Generate Quiz with AI
          <Sparkles className="w-5 h-5" />
        </button>
      </form>
    </div>
  );

  // Main render
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={() => navigate(`/staff/classrooms/${classroomId}/quizzes/new`)}
            className="flex items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Quiz Options
          </button>

          {classroom && (
            <div className="text-right">
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{classroom.name}</h1>
              <p className="text-gray-600 dark:text-gray-400">{classroom.subject}</p>
            </div>
          )}
        </div>

        {/* Progress Steps */}
        <div className="flex items-center justify-center mb-8">
          <div className="flex items-center space-x-4">
            {[
              { step: 1, label: 'Configure', icon: Edit3 },
              { step: 2, label: 'Generate', icon: Brain },
              { step: 3, label: 'Review', icon: CheckCircle },
              { step: 4, label: 'Complete', icon: Save }
            ].map(({ step: stepNum, label, icon: Icon }, index) => (
              <div key={stepNum} className="flex items-center">
                <div className={`flex items-center justify-center w-10 h-10 rounded-full border-2 transition-all ${
                  step >= stepNum
                    ? 'bg-blue-600 border-blue-600 text-white'
                    : 'border-gray-300 text-gray-400'
                }`}>
                  <Icon className="w-5 h-5" />
                </div>
                <span className={`ml-2 text-sm font-medium ${
                  step >= stepNum ? 'text-blue-600' : 'text-gray-400'
                }`}>
                  {label}
                </span>
                {index < 3 && (
                  <div className={`w-12 h-0.5 mx-4 ${
                    step > stepNum ? 'bg-blue-600' : 'bg-gray-300'
                  }`} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-xl p-8">
          {/* Error/Success Messages */}
          {error && (
            <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-red-500" />
              <span className="text-red-700 dark:text-red-300">{error}</span>
            </div>
          )}

          {success && (
            <div className="mb-6 p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg flex items-center gap-3">
              <CheckCircle className="w-5 h-5 text-green-500" />
              <span className="text-green-700 dark:text-green-300">{success}</span>
            </div>
          )}
          {/* Step Content */}
          {step === 1 && renderInputForm()}

          {step === 2 && (
            <div className="text-center py-16 space-y-6">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full mb-6 animate-pulse">
                <Brain className="w-10 h-10 text-white" />
              </div>

              <div className="space-y-4">
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                  AI is crafting your quiz...
                </h3>
                <p className="text-gray-600 dark:text-gray-400 max-w-md mx-auto">
                  Our AI is analyzing your requirements and generating high-quality questions
                </p>
              </div>

              {/* Progress Bar */}
              <div className="max-w-md mx-auto">
                <div className="bg-gray-200 dark:bg-gray-700 rounded-full h-3 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-blue-500 to-purple-600 h-full rounded-full transition-all duration-300 ease-out"
                    style={{ width: `${progress}%` }}
                  />
                </div>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">{progress}% Complete</p>
              </div>

              {/* Loading Animation */}
              <div className="flex items-center justify-center space-x-2">
                <Loader2 className="w-6 h-6 text-blue-500 animate-spin" />
                <span className="text-blue-600 dark:text-blue-400 font-medium">Processing...</span>
              </div>
            </div>
          )}
          {step === 3 && (
            <div className="space-y-8">
              {/* Quiz Header */}
              <div className="text-center space-y-4">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full mb-4">
                  <CheckCircle className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Review Your Quiz</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Review and edit the generated questions before saving
                </p>
              </div>

              <form onSubmit={handleSave} className="space-y-6">
                {/* Quiz Title */}
                <div className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 rounded-xl p-6">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Quiz Title
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Enter quiz title"
                    className="w-full px-4 py-3 text-xl font-bold text-center rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                    required
                  />
                </div>

                {/* Questions */}
                <div className="space-y-6">
                  {questions.map((q, idx) => (
                    <div key={idx} className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 shadow-lg overflow-hidden">
                      {/* Question Header */}
                      <div className="bg-gradient-to-r from-blue-500 to-purple-600 px-6 py-4 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <span className="text-white font-bold text-lg">Question {idx + 1}</span>
                          <span className="bg-white/20 text-white px-2 py-1 rounded-full text-xs">
                            {DIFFICULTIES.find(d => d.value === q.difficulty)?.icon} {q.difficulty}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeQuestion(idx)}
                          className="text-white/80 hover:text-white hover:bg-white/20 p-2 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Question Content */}
                      <div className="p-6 space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Question
                          </label>
                          <textarea
                            value={q.question}
                            onChange={(e) => handleQuestionChange(idx, 'question', e.target.value)}
                            placeholder="Enter question text"
                            rows="2"
                            className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                            required
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Answer Options
                          </label>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            {['A', 'B', 'C', 'D'].map(opt => (
                              <div key={opt} className="relative">
                                <div className="absolute left-3 top-1/2 transform -translate-y-1/2 w-6 h-6 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center text-sm font-medium text-gray-600 dark:text-gray-400">
                                  {opt}
                                </div>
                                <input
                                  type="text"
                                  value={q.options[opt]}
                                  onChange={(e) => handleOptionChange(idx, opt, e.target.value)}
                                  placeholder={`Option ${opt}`}
                                  className="w-full pl-12 pr-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                                  required
                                />
                              </div>
                            ))}
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                              Correct Answer
                            </label>
                            <select
                              value={q.correctAnswer}
                              onChange={(e) => handleCorrectAnswerChange(idx, e.target.value)}
                              className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                            >
                              {['A', 'B', 'C', 'D'].map(opt => (
                                <option key={opt} value={opt}>
                                  {opt} - {q.options[opt]?.substring(0, 30)}...
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Explanation
                          </label>
                          <textarea
                            value={q.explanation}
                            onChange={(e) => handleQuestionChange(idx, 'explanation', e.target.value)}
                            placeholder="Explain why this answer is correct..."
                            rows="2"
                            className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Add Question Button */}
                <button
                  type="button"
                  onClick={addQuestion}
                  className="w-full py-4 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl text-gray-600 dark:text-gray-400 hover:border-blue-500 hover:text-blue-500 transition-colors flex items-center justify-center gap-2"
                >
                  <Plus className="w-5 h-5" />
                  Add Another Question
                </button>

                {/* Save Button */}
                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="flex-1 py-4 px-6 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                  >
                    Back to Edit
                  </button>
                  <button
                    type="submit"
                    disabled={saving}
                    className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-bold py-4 px-6 rounded-xl shadow-lg hover:shadow-xl transform hover:scale-[1.02] transition-all duration-200 flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {saving ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        Saving Quiz...
                      </>
                    ) : (
                      <>
                        <Save className="w-5 h-5" />
                        Save Quiz
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          )}

          {step === 4 && (
            <div className="text-center py-16 space-y-6">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full mb-6">
                <CheckCircle className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-3xl font-bold text-gray-900 dark:text-white">
                Quiz Generated & Saved!
              </h3>
              <p className="text-gray-600 dark:text-gray-400 max-w-md mx-auto">
                Your AI-generated quiz has been automatically saved to MongoDB and is ready for students to take.
                {formData.language === 'tamil' && (
                  <span className="block mt-2 text-sm text-blue-600 dark:text-blue-400">
                    🇮🇳 Quiz generated in Tamil (தமிழ்)
                  </span>
                )}
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button
                  onClick={() => navigate(`/staff/classrooms/${classroomId}/quizzes`)}
                  className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-bold py-4 px-8 rounded-xl shadow-lg hover:shadow-xl transform hover:scale-[1.02] transition-all duration-200"
                >
                  View All Quizzes
                </button>
                <button
                  onClick={() => setStep(1)}
                  className="border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 font-bold py-4 px-8 rounded-xl transition-all duration-200"
                >
                  Create Another Quiz
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Custom Styles */}
      <style>{`
        @keyframes blob {
          0% { transform: translate(0px, 0px) scale(1); }
          33% { transform: translate(30px, -50px) scale(1.1); }
          66% { transform: translate(-20px, 20px) scale(0.9); }
          100% { transform: translate(0px, 0px) scale(1); }
        }
        .animate-blob {
          animation: blob 7s infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
        .animation-delay-4000 {
          animation-delay: 4s;
        }
      `}</style>
    </div>
  );
};

export default QuizCreateAI;