import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import Button from '../components/common/Button';
import Loader from '../components/common/Loader';
import Modal from '../components/common/Modal';
import AssignQuiz from '../features/classroom/AssignQuiz';
import AIQuizGenerator from '../components/quiz/AIQuizGenerator';
import ManualQuizCreator from '../components/quiz/ManualQuizCreator';

const ClassroomDetailPage = () => {
  const { classroomId } = useParams();
  const navigate = useNavigate();
  const user = useSelector(state => state.auth.user);
  const [classroom, setClassroom] = useState(null);
  const [students, setStudents] = useState([]);
  const [quizzes, setQuizzes] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [showAssignQuizModal, setShowAssignQuizModal] = useState(false);
  const [showAddStudentModal, setShowAddStudentModal] = useState(false);
  const [showAIQuizGenerator, setShowAIQuizGenerator] = useState(false);
  const [showManualQuizCreator, setShowManualQuizCreator] = useState(false);
  const [studentForm, setStudentForm] = useState({
    name: '',
    email: '',
    grade: '',
    isDisabled: false
  });

  useEffect(() => {
    if (classroomId) {
      fetchClassroomDetails();
    }
  }, [classroomId]);

  const fetchClassroomDetails = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      
      // Fetch classroom details
      const classroomResponse = await fetch(`/api/classroom/${classroomId}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!classroomResponse.ok) {
        throw new Error(`HTTP error! status: ${classroomResponse.status}`);
      }

      const classroomData = await classroomResponse.json();
      setClassroom(classroomData.data.classroom);

      // Fetch students in this classroom
      const studentsResponse = await fetch(`/api/classroom/${classroomId}/students`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (studentsResponse.ok) {
        const studentsData = await studentsResponse.json();
        setStudents(studentsData.data.students || []);
      }

      // Fetch quizzes for this classroom
      const quizzesResponse = await fetch(`/api/quizzes/classroom/${classroomId}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (quizzesResponse.ok) {
        const quizzesData = await quizzesResponse.json();
        setQuizzes(quizzesData.data.quizzes || []);
      }

      // Fetch assignments for this classroom
      const assignmentsResponse = await fetch(`/api/classroom/${classroomId}/assignments`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (assignmentsResponse.ok) {
        const assignmentsData = await assignmentsResponse.json();
        setAssignments(assignmentsData.data.assignments || []);
      }

    } catch (err) {
      setError(err.message);
      console.error('Error fetching classroom details:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleAddStudent = () => {
    setShowAddStudentModal(true);
  };

  const handleStudentFormChange = (e) => {
    const { name, value, type, checked } = e.target;
    setStudentForm(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmitStudent = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/auth/students', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          ...studentForm,
          role: 'student',
          classroomId: classroomId,
          password: 'defaultPassword123'
        })
      });

      if (response.ok) {
        const result = await response.json();
        console.log('Student added:', result);
        setShowAddStudentModal(false);
        setStudentForm({ name: '', email: '', grade: '', isDisabled: false });
        fetchClassroomDetails(); // Refresh data
      } else {
        throw new Error('Failed to add student');
      }
    } catch (err) {
      console.error('Error adding student:', err);
    }
  };

  const handleAssignQuiz = () => {
    setShowAssignQuizModal(true);
  };

  const handleQuizAssigned = (assignment) => {
    setShowAssignQuizModal(false);
    fetchClassroomDetails(); // Refresh data
  };

  const handleAIQuizGenerated = (quiz) => {
    setShowAIQuizGenerator(false);
    fetchClassroomDetails(); // Refresh data
  };

  const handleManualQuizCreated = (quiz) => {
    setShowManualQuizCreator(false);
    fetchClassroomDetails(); // Refresh data
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'inactive': return 'bg-gray-100 text-gray-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  const getClassTypeColor = (classType) => {
    switch (classType) {
      case 'regular': return 'bg-blue-100 text-blue-800';
      case 'disabled': return 'bg-purple-100 text-purple-800';
      case 'mixed': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex justify-center items-center">
        <Loader size="lg" />
      </div>
    );
  }

  if (error || !classroom) {
    return (
      <div className="min-h-screen bg-gray-50 flex justify-center items-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Error Loading Classroom</h2>
          <p className="text-gray-600 mb-4">{error || 'Classroom not found'}</p>
          <Button onClick={() => navigate(user?.role === 'staff' ? '/staff/classrooms' : '/student/dashboard')}>
            Back to {user?.role === 'staff' ? 'Classrooms' : 'Dashboard'}
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div>
              <div className="flex items-center space-x-4">
                <Button
                  onClick={() => navigate(user?.role === 'staff' ? '/staff/classrooms' : '/student/dashboard')}
                  className="bg-gray-100 text-gray-700 hover:bg-gray-200"
                >
                  ← Back to {user?.role === 'staff' ? 'Classrooms' : 'Dashboard'}
                </Button>
                <div>
                  <h1 className="text-3xl font-bold text-gray-900">{classroom.name}</h1>
                  <p className="mt-1 text-sm text-gray-500">
                    {classroom.subject} • {classroom.grade} • {classroom.semester}
                  </p>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(classroom.isActive ? 'active' : 'inactive')}`}>
                {classroom.isActive ? 'Active' : 'Inactive'}
              </span>
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${getClassTypeColor(classroom.classType)}`}>
                {classroom.classType}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex space-x-8 border-b border-gray-200">
          {[
            { key: 'overview', label: 'Overview' },
            { key: 'students', label: `Students (${students.length})` },
            { key: 'quizzes', label: `Quizzes (${quizzes.length})` },
            { key: 'assignments', label: `Assignments (${assignments.length})` }
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === tab.key
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-8">
        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center">
                  <div className="p-3 rounded-full bg-blue-50">
                    <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z" />
                    </svg>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">Total Students</p>
                    <p className="text-2xl font-semibold text-gray-900">{students.length}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center">
                  <div className="p-3 rounded-full bg-green-50">
                    <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">Active Quizzes</p>
                    <p className="text-2xl font-semibold text-gray-900">{quizzes.filter(q => q.isActive).length}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center">
                  <div className="p-3 rounded-full bg-purple-50">
                    <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                    </svg>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">Assignments</p>
                    <p className="text-2xl font-semibold text-gray-900">{assignments.length}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center">
                  <div className="p-3 rounded-full bg-yellow-50">
                    <svg className="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                    </svg>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">Avg Score</p>
                    <p className="text-2xl font-semibold text-gray-900">85%</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-lg shadow">
              <div className="px-6 py-4 border-b border-gray-200">
                <h3 className="text-lg font-medium text-gray-900">Quick Actions</h3>
              </div>
              <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                {user?.role === 'staff' && (
                  <>
                    <Button
                      onClick={handleAddStudent}
                      className="flex items-center justify-center p-4 bg-indigo-50 rounded-lg hover:bg-indigo-100 transition-colors"
                    >
                      <svg className="w-6 h-6 text-indigo-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                      </svg>
                      Add Student
                    </Button>

                    <Button
                      onClick={() => navigate(`/staff/classrooms/${classroomId}/quizzes/create`)}
                      className="flex items-center justify-center p-4 bg-green-50 rounded-lg hover:bg-green-100 transition-colors"
                    >
                      <svg className="w-6 h-6 text-green-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      Create Quiz
                    </Button>

                    <Button
                      onClick={handleAssignQuiz}
                      className="flex items-center justify-center p-4 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors"
                    >
                      <svg className="w-6 h-6 text-purple-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                      </svg>
                      Assign Quiz
                    </Button>
                  </>
                )}
                {user?.role === 'student' && (
                  <div className="col-span-3 text-center py-8">
                    <div className="mx-auto h-12 w-12 text-blue-400 mb-4">
                      <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C20.168 18.477 18.582 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                      </svg>
                    </div>
                    <h3 className="text-lg font-medium text-gray-900 mb-2">Welcome to {classroom.name}</h3>
                    <p className="text-gray-600 mb-4">View classroom information and check your assignments below.</p>
                    <Button
                      onClick={() => navigate('/student/assignments')}
                      className="bg-blue-600 text-white hover:bg-blue-700"
                    >
                      View My Assignments
                    </Button>
                  </div>
                )}
              </div>
            </div>

            {/* Classroom Details */}
            <div className="bg-white rounded-lg shadow">
              <div className="px-6 py-4 border-b border-gray-200">
                <h3 className="text-lg font-medium text-gray-900">Classroom Details</h3>
              </div>
              <div className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium text-gray-900 mb-3">Basic Information</h4>
                    <dl className="space-y-2">
                      <div>
                        <dt className="text-sm font-medium text-gray-500">Subject</dt>
                        <dd className="text-sm text-gray-900">{classroom.subject}</dd>
                      </div>
                      <div>
                        <dt className="text-sm font-medium text-gray-500">Grade</dt>
                        <dd className="text-sm text-gray-900">{classroom.grade}</dd>
                      </div>
                      <div>
                        <dt className="text-sm font-medium text-gray-500">Semester</dt>
                        <dd className="text-sm text-gray-900">{classroom.semester}</dd>
                      </div>
                      <div>
                        <dt className="text-sm font-medium text-gray-500">Academic Year</dt>
                        <dd className="text-sm text-gray-900">{classroom.academicYear}</dd>
                      </div>
                    </dl>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-3">Settings</h4>
                    <dl className="space-y-2">
                      <div>
                        <dt className="text-sm font-medium text-gray-500">Class Type</dt>
                        <dd className="text-sm text-gray-900">{classroom.classType}</dd>
                      </div>
                      <div>
                        <dt className="text-sm font-medium text-gray-500">Max Students</dt>
                        <dd className="text-sm text-gray-900">{classroom.maxStudents}</dd>
                      </div>
                      <div>
                        <dt className="text-sm font-medium text-gray-500">Status</dt>
                        <dd className="text-sm text-gray-900">{classroom.isActive ? 'Active' : 'Inactive'}</dd>
                      </div>
                      {classroom.description && (
                        <div>
                          <dt className="text-sm font-medium text-gray-500">Description</dt>
                          <dd className="text-sm text-gray-900">{classroom.description}</dd>
                        </div>
                      )}
                    </dl>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Students Tab */}
        {activeTab === 'students' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold text-gray-900">Students</h2>
              {user?.role === 'staff' && (
                <Button onClick={handleAddStudent} className="bg-indigo-600 text-white hover:bg-indigo-700">
                  + Add Student
                </Button>
              )}
            </div>

            {students.length === 0 ? (
              <div className="text-center py-12">
                <div className="mx-auto h-12 w-12 text-gray-400">
                  <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z" />
                  </svg>
                </div>
                <h3 className="mt-2 text-sm font-medium text-gray-900">No students enrolled</h3>
                <p className="mt-1 text-sm text-gray-500">
                  {user?.role === 'staff' ? 'Get started by adding students to this classroom.' : 'This classroom doesn\'t have any students yet.'}
                </p>
                {user?.role === 'staff' && (
                  <div className="mt-6">
                    <Button onClick={handleAddStudent} className="bg-indigo-600 text-white hover:bg-indigo-700">
                      + Add Student
                    </Button>
                  </div>
                )}
              </div>
            ) : (
              <div className="bg-white shadow overflow-hidden sm:rounded-md">
                <ul className="divide-y divide-gray-200">
                  {students.map((student) => (
                    <li key={student._id}>
                      <div className="px-4 py-4 flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-10 w-10">
                            <div className="h-10 w-10 rounded-full bg-gray-300 flex items-center justify-center">
                              <span className="text-sm font-medium text-gray-700">
                                {student.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                              </span>
                            </div>
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">{student.name}</div>
                            <div className="text-sm text-gray-500">{student.email}</div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          {student.isDisabled && (
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                              Disabled
                            </span>
                          )}
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            Enrolled
                          </span>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}

        {/* Quizzes Tab */}
        {activeTab === 'quizzes' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold text-gray-900">Quizzes</h2>
              <div className="flex space-x-3">
                <Button 
                  onClick={() => setShowAIQuizGenerator(true)}
                  className="bg-purple-600 text-white hover:bg-purple-700"
                >
                  🤖 AI Generate
                </Button>
                <Button 
                  onClick={() => setShowManualQuizCreator(true)}
                  className="bg-green-600 text-white hover:bg-green-700"
                >
                  ✏️ Manual Create
                </Button>
              </div>
            </div>

            {quizzes.length === 0 ? (
              <div className="text-center py-12">
                <div className="mx-auto h-12 w-12 text-gray-400">
                  <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h3 className="mt-2 text-sm font-medium text-gray-900">No quizzes created</h3>
                <p className="mt-1 text-sm text-gray-500">Get started by creating a quiz for this classroom.</p>
                <div className="mt-6 flex space-x-3 justify-center">
                  <Button 
                    onClick={() => setShowAIQuizGenerator(true)}
                    className="bg-purple-600 text-white hover:bg-purple-700"
                  >
                    🤖 AI Generate Quiz
                  </Button>
                  <Button 
                    onClick={() => setShowManualQuizCreator(true)}
                    className="bg-green-600 text-white hover:bg-green-700"
                  >
                    ✏️ Manual Create Quiz
                  </Button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {quizzes.map((quiz) => (
                  <div key={quiz._id} className="bg-white rounded-lg shadow p-6">
                    <div className="flex justify-between items-start mb-4">
                      <h3 className="text-lg font-medium text-gray-900">{quiz.title}</h3>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        quiz.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {quiz.isActive ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mb-4">{quiz.description}</p>
                    <div className="space-y-2 mb-4">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-500">Questions:</span>
                        <span className="text-gray-900">{quiz.questions?.length || 0}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-500">Time Limit:</span>
                        <span className="text-gray-900">{quiz.timeLimit || 'No limit'}</span>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button
                        onClick={() => navigate(`/staff/quizzes/${quiz._id}/edit`)}
                        className="flex-1 bg-blue-50 text-blue-700 hover:bg-blue-100 text-sm"
                      >
                        Edit
                      </Button>
                      <Button
                        onClick={() => setShowAssignQuizModal(true)}
                        className="flex-1 bg-green-50 text-green-700 hover:bg-green-100 text-sm"
                      >
                        Assign
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Assignments Tab */}
        {activeTab === 'assignments' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold text-gray-900">Assignments</h2>
              <Button onClick={handleAssignQuiz} className="bg-purple-600 text-white hover:bg-purple-700">
                + Assign Quiz
              </Button>
            </div>

            {assignments.length === 0 ? (
              <div className="text-center py-12">
                <div className="mx-auto h-12 w-12 text-gray-400">
                  <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                  </svg>
                </div>
                <h3 className="mt-2 text-sm font-medium text-gray-900">No assignments</h3>
                <p className="mt-1 text-sm text-gray-500">Get started by assigning a quiz to students.</p>
                <div className="mt-6">
                  <Button onClick={handleAssignQuiz} className="bg-purple-600 text-white hover:bg-purple-700">
                    + Assign Quiz
                  </Button>
                </div>
              </div>
            ) : (
              <div className="bg-white shadow overflow-hidden sm:rounded-md">
                <ul className="divide-y divide-gray-200">
                  {assignments.map((assignment) => (
                    <li key={assignment._id}>
                      <div className="px-4 py-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <h3 className="text-sm font-medium text-gray-900">{assignment.quiz?.title}</h3>
                            <p className="text-sm text-gray-500">Assigned to {assignment.assignmentType} students</p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              assignment.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                            }`}>
                              {assignment.isActive ? 'Active' : 'Inactive'}
                            </span>
                            <Button
                              onClick={() => navigate(`/staff/assignments/${assignment._id}`)}
                              className="text-sm text-indigo-600 hover:text-indigo-500"
                            >
                              View Details
                            </Button>
                          </div>
                        </div>
                        <div className="mt-2 text-sm text-gray-500">
                          <span>Due: {new Date(assignment.dueDate).toLocaleDateString()}</span>
                          {assignment.timeLimit && (
                            <span className="ml-4">Time Limit: {assignment.timeLimit}</span>
                          )}
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Add Student Modal */}
      {showAddStudentModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden">
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-6 text-white">
              <h3 className="text-xl font-bold">Add Student to {classroom.name}</h3>
              <p className="text-indigo-100">Fill in the student details below</p>
            </div>
            <form onSubmit={handleSubmitStudent} className="p-6 space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                  Full Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={studentForm.name}
                  onChange={handleStudentFormChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                  placeholder="John Doe"
                />
              </div>
              
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  Email <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={studentForm.email}
                  onChange={handleStudentFormChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                  placeholder="john@example.com"
                />
              </div>
              
              <div>
                <label htmlFor="grade" className="block text-sm font-medium text-gray-700 mb-1">
                  Grade <span className="text-red-500">*</span>
                </label>
                <select
                  id="grade"
                  name="grade"
                  value={studentForm.grade}
                  onChange={handleStudentFormChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition appearance-none bg-white"
                >
                  <option value="">Select Grade</option>
                  {[...Array(12)].map((_, i) => (
                    <option key={i} value={`${i+1}th`}>{i+1}th Grade</option>
                  ))}
                </select>
              </div>
              
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="isDisabled"
                  name="isDisabled"
                  checked={studentForm.isDisabled}
                  onChange={handleStudentFormChange}
                  className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                />
                <label htmlFor="isDisabled" className="ml-2 block text-sm text-gray-900">
                  Student with disabilities
                </label>
              </div>
              
              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <svg className="h-5 w-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm text-yellow-700">
                      A default password will be generated and sent to the student's email.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-3 pt-4">
                <Button
                  type="submit"
                  className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-r from-green-500 via-blue-500 to-purple-600 text-white py-3 rounded-xl shadow-lg hover:scale-[1.02] hover:shadow-xl transition-all duration-300"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
                  </svg>
                  Add Student
                </Button>

                <Button
                  type="button"
                  onClick={() => setShowAddStudentModal(false)}
                  className="flex-1 flex items-center justify-center gap-2 bg-white text-gray-800 py-3 rounded-xl border border-gray-300 hover:bg-gray-100 hover:scale-[1.02] transition-all duration-300"
                >
                  <svg className="w-5 h-5 text-red-500" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                  Cancel
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Assign Quiz Modal */}
      <AssignQuiz
        isOpen={showAssignQuizModal}
        onClose={() => setShowAssignQuizModal(false)}
        classroom={classroom}
        onSuccess={handleQuizAssigned}
      />

      {/* AI Quiz Generator Modal */}
      <AIQuizGenerator
        isOpen={showAIQuizGenerator}
        onClose={() => setShowAIQuizGenerator(false)}
        onQuizGenerated={handleAIQuizGenerated}
        classroom={classroom}
      />

      {/* Manual Quiz Creator Modal */}
      <ManualQuizCreator
        isOpen={showManualQuizCreator}
        onClose={() => setShowManualQuizCreator(false)}
        onQuizCreated={handleManualQuizCreated}
        classroom={classroom}
      />
    </div>
  );
};

export default ClassroomDetailPage; 