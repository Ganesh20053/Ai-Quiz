import React from 'react';
import ClassroomQuizzes from './staff/ClassroomQuizzes';

const ClassroomQuizzesPage = () => {
  return <ClassroomQuizzes />;
};

export default ClassroomQuizzesPage; 