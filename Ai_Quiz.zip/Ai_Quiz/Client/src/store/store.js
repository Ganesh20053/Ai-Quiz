// src/store/store.js
import { configureStore } from '@reduxjs/toolkit'
import authSlice from '../features/auth/authSlice'
import quizSlice from '../features/quiz/quizSlice'
import studentSlice from '../features/student/studentSlice'
import classroomSlice from '../features/classroom/classroomSlice'
import settingsSlice from '../features/settings/settingsSlice'

export const store = configureStore({
  reducer: {
    auth: authSlice,
    quiz: quizSlice,
    student: studentSlice,
    classroom: classroomSlice,
    settings: settingsSlice,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: ['persist/PERSIST'],
      },
    }),
})
