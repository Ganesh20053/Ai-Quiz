import fs from 'fs';
import path from 'path';

console.log('🔧 Fixing .env file configuration...');
console.log('');

const envPath = path.join(process.cwd(), '.env');

try {
  // Read current .env content
  let envContent = fs.readFileSync(envPath, 'utf8');
  
  console.log('📋 Current .env content:');
  console.log(envContent);
  console.log('');
  
  // Fix the MongoDB configuration line
  envContent = envContent.replace(
    /# JWT Configuration:\/\/localhost:27017\/quiz-app/,
    '# MongoDB Configuration\nMONGODB_URI=mongodb://localhost:27017/quiz-app\n\n# JWT Configuration'
  );
  
  // Write the fixed content back
  fs.writeFileSync(envPath, envContent);
  
  console.log('✅ .env file fixed successfully!');
  console.log('');
  console.log('📋 Updated .env content:');
  console.log(fs.readFileSync(envPath, 'utf8'));
  console.log('');
  console.log('🔄 Please restart your server to apply changes');
  
} catch (error) {
  console.error('❌ Error fixing .env file:', error.message);
  console.log('');
  console.log('🔧 Manual fix required:');
  console.log('1. Open .env file');
  console.log('2. Fix the MongoDB configuration line');
} 