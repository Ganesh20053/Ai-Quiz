import { GoogleGenerativeAI } from "@google/generative-ai";

// Replace with your actual API key from Google AI Studio
const API_KEY = "PASTE_YOUR_API_KEY_HERE";

const genAI = new GoogleGenerativeAI(API_KEY);

async function getQuizFromGemini(topic = "General Knowledge") {
  try {
    // ✅ Correct model name for v1beta
    const model = genAI.getGenerativeModel({ model: "gemini-pro-1.0" });

    const prompt = `
      Generate 5 multiple choice quiz questions on the topic "${topic}".
      Format the response strictly as JSON like this:
      [
        {
          "question": "What is the capital of France?",
          "options": ["Berlin", "Madrid", "Paris", "Rome"],
          "answer": "Paris"
        },
        ...
      ]
    `;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();

    const jsonText = extractJSON(text);
    const quiz = JSON.parse(jsonText);
    console.log("Quiz:", quiz);
    return quiz;

  } catch (error) {
    console.error("Error fetching quiz:", error);
    return [];
  }
}

function extractJSON(text) {
  const jsonMatch = text.match(/```json\s*([\s\S]*?)\s*```/i);
  if (jsonMatch) return jsonMatch[1];
  return text;
}

// Run it
getQuizFromGemini("Computer Science");
