import mongoose from 'mongoose';
import dotenv from 'dotenv';
import { runSeed } from './utils/seedData.js';

// Load environment variables
dotenv.config();

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/quiz-app';

async function main() {
  try {
    console.log('🚀 Starting Database Seeding...');
    console.log('=====================================');
    
    // Connect to MongoDB
    console.log('📡 Connecting to MongoDB...');
    await mongoose.connect(MONGODB_URI);
    console.log('✅ Connected to MongoDB successfully');
    
    // Run seed data
    await runSeed();
    
    console.log('\n🎉 Database seeding completed successfully!');
    console.log('=====================================');
    
  } catch (error) {
    console.error('❌ Seeding failed:', error);
    process.exit(1);
  } finally {
    // Close database connection
    await mongoose.connection.close();
    console.log('📡 Database connection closed');
    process.exit(0);
  }
}

// Run the seeding
main();
