import User from '../models/User.js';
import bcrypt from 'bcryptjs';
import { logUser, logError } from '../config/logger.js';
import { sendWelcomeEmail } from '../utils/emailService.js';

// Get all staff members
export const getAllStaff = async (req, res) => {
  try {
    const staff = await User.find({ role: 'staff' }).select('-password');
    
    logUser('GET_ALL_STAFF', req.user.id, req.user.email, 'admin', { count: staff.length });
    
    res.status(200).json({
      success: true,
      data: staff,
      count: staff.length
    });
  } catch (error) {
    logError('Failed to get all staff', error, { userId: req.user.id });
    res.status(500).json({
      success: false,
      message: 'Failed to get staff members',
      error: error.message
    });
  }
};

// Add new staff member
export const addStaff = async (req, res) => {
  try {
    const { name, email, department, employeeId } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'User with this email already exists'
      });
    }

    // Generate default password
    const defaultPassword = '123456';
    const hashedPassword = await bcrypt.hash(defaultPassword, 12);

    // Create new staff member
    const newStaff = new User({
      name,
      email,
      password: hashedPassword,
      role: 'staff',
      department,
      employeeId
    });

    await newStaff.save();

    // Send welcome email
    try {
      await sendWelcomeEmail(newStaff);
    } catch (emailError) {
      console.error('Failed to send welcome email:', emailError);
    }

    logUser('ADD_STAFF', req.user.id, req.user.email, 'admin', { 
      newStaffId: newStaff._id,
      newStaffEmail: newStaff.email 
    });

    res.status(201).json({
      success: true,
      message: 'Staff member added successfully',
      data: {
        id: newStaff._id,
        name: newStaff.name,
        email: newStaff.email,
        role: newStaff.role,
        department: newStaff.department,
        employeeId: newStaff.employeeId
      }
    });
  } catch (error) {
    logError('Failed to add staff member', error, { userId: req.user.id });
    res.status(500).json({
      success: false,
      message: 'Failed to add staff member',
      error: error.message
    });
  }
};

// Update staff member
export const updateStaff = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, email, department, employeeId, isActive } = req.body;

    const staff = await User.findById(id);
    if (!staff) {
      return res.status(404).json({
        success: false,
        message: 'Staff member not found'
      });
    }

    if (staff.role !== 'staff') {
      return res.status(400).json({
        success: false,
        message: 'User is not a staff member'
      });
    }

    // Update fields
    if (name) staff.name = name;
    if (email) staff.email = email;
    if (department) staff.department = department;
    if (employeeId) staff.employeeId = employeeId;
    if (typeof isActive === 'boolean') staff.isActive = isActive;

    await staff.save();

    logUser('UPDATE_STAFF', req.user.id, req.user.email, 'admin', { 
      staffId: staff._id,
      staffEmail: staff.email 
    });

    res.status(200).json({
      success: true,
      message: 'Staff member updated successfully',
      data: {
        id: staff._id,
        name: staff.name,
        email: staff.email,
        role: staff.role,
        department: staff.department,
        employeeId: staff.employeeId,
        isActive: staff.isActive
      }
    });
  } catch (error) {
    logError('Failed to update staff member', error, { userId: req.user.id });
    res.status(500).json({
      success: false,
      message: 'Failed to update staff member',
      error: error.message
    });
  }
};

// Delete staff member
export const deleteStaff = async (req, res) => {
  try {
    const { id } = req.params;

    const staff = await User.findById(id);
    if (!staff) {
      return res.status(404).json({
        success: false,
        message: 'Staff member not found'
      });
    }

    if (staff.role !== 'staff') {
      return res.status(400).json({
        success: false,
        message: 'User is not a staff member'
      });
    }

    await User.findByIdAndDelete(id);

    logUser('DELETE_STAFF', req.user.id, req.user.email, 'admin', { 
      staffId: staff._id,
      staffEmail: staff.email 
    });

    res.status(200).json({
      success: true,
      message: 'Staff member deleted successfully'
    });
  } catch (error) {
    logError('Failed to delete staff member', error, { userId: req.user.id });
    res.status(500).json({
      success: false,
      message: 'Failed to delete staff member',
      error: error.message
    });
  }
};

// Get admin dashboard stats
export const getDashboardStats = async (req, res) => {
  try {
    const totalStaff = await User.countDocuments({ role: 'staff' });
    const totalStudents = await User.countDocuments({ role: 'student' });
    const activeStaff = await User.countDocuments({ role: 'staff', isActive: true });
    const activeStudents = await User.countDocuments({ role: 'student', isActive: true });

    const stats = {
      totalStaff,
      totalStudents,
      activeStaff,
      activeStudents,
      totalUsers: totalStaff + totalStudents,
      activeUsers: activeStaff + activeStudents
    };

    logUser('GET_DASHBOARD_STATS', req.user.id, req.user.email, 'admin', stats);

    res.status(200).json({
      success: true,
      data: stats
    });
  } catch (error) {
    logError('Failed to get dashboard stats', error, { userId: req.user.id });
    res.status(500).json({
      success: false,
      message: 'Failed to get dashboard stats',
      error: error.message
    });
  }
};
