import QuizAssignment from '../models/QuizAssignment.js';
import Quiz from '../models/Quiz.js';
import Class from '../models/Class.js';
import User from '../models/User.js';
import { logError } from '../config/logger.js';
import { sendQuizAssignmentEmail } from '../utils/emailService.js';

// Create quiz assignment
export const createQuizAssignment = async (req, res) => {
  try {
    console.log('🎯 createQuizAssignment called');
    console.log('📝 Request body:', req.body);
    console.log('👤 User:', req.user?.id);
    console.log('🏫 Classroom ID from params:', req.params.classroomId);

    const {
      quizId,
      assignmentType = 'all',
      assignedStudents = [],
      settings = {},
      instructions = '',
      scheduledFor,
      expiresAt
    } = req.body;

    const teacherId = req.user.id;
    const classroomId = req.params.classroomId; // Get classroomId from URL params

    console.log('🔍 Assignment data:', {
      quizId,
      classroomId,
      assignmentType,
      teacherId
    });

    // Verify quiz exists and belongs to teacher
    const quiz = await Quiz.findOne({ _id: quizId, createdBy: teacherId });
    if (!quiz) {
      return res.status(404).json({
        success: false,
        message: 'Quiz not found'
      });
    }

    // Verify classroom exists and belongs to teacher
    const classroom = await Class.findOne({ _id: classroomId, teacher: teacherId });
    if (!classroom) {
      return res.status(404).json({
        success: false,
        message: 'Classroom not found'
      });
    }

    // Determine which students to assign based on assignment type
    let studentsToAssign = [];

    console.log('🎯 Assignment type:', assignmentType);
    console.log('👥 Classroom students:', classroom.students.length);
    console.log('📋 Classroom students details:', classroom.students.map(s => ({
      id: s.student,
      type: s.studentType,
      active: s.isActive
    })));

    if (assignmentType === 'all') {
      studentsToAssign = classroom.getActiveStudents();
      console.log('🎯 Getting all active students from classroom');
    } else if (assignmentType === 'regular') {
      studentsToAssign = classroom.getRegularStudents();
      console.log('🎯 Getting regular students from classroom');
    } else if (assignmentType === 'disabled') {
      studentsToAssign = classroom.getDisabledStudents();
      console.log('🎯 Getting disabled students from classroom');
    } else if (assignmentType === 'custom') {
      // Verify all custom students exist in classroom
      for (const studentId of assignedStudents) {
        if (!classroom.isStudentEnrolled(studentId)) {
          return res.status(400).json({
            success: false,
            message: `Student ${studentId} is not enrolled in this classroom`
          });
        }
      }
      studentsToAssign = classroom.students.filter(s =>
        s.isActive && assignedStudents.includes(s.student.toString())
      );
      console.log('🎯 Getting custom students from classroom');
    } else {
      // Default to all active students if assignment type is not recognized
      console.log('⚠️ Unknown assignment type, defaulting to all active students');
      studentsToAssign = classroom.getActiveStudents();
    }

    console.log('✅ Students to assign:', studentsToAssign.length);
    console.log('📝 Students details:', studentsToAssign.map(s => ({
      id: s.student,
      type: s.studentType
    })));

    // Create assignment
    const assignment = new QuizAssignment({
      quiz: quizId,
      classroom: classroomId,
      assignedBy: teacherId,
      assignmentType,
      assignedStudents: studentsToAssign.map(student => ({
        student: student.student,
        studentType: student.studentType,
        assignedAt: new Date(),
        isActive: true
      })),
      settings: {
        dueDate: settings.dueDate,
        timeLimit: settings.timeLimit || quiz.settings.timeLimit,
        allowRetake: settings.allowRetake || quiz.settings.allowRetake,
        maxAttempts: settings.maxAttempts || quiz.settings.maxAttempts,
        voiceEnabled: classroom.classType === 'disabled' || classroom.classType === 'mixed',
        autoReadQuestions: true,
        provideAudioFeedback: true,
        allowVoiceControl: classroom.classType === 'disabled' || classroom.classType === 'mixed',
        ...settings
      },
      instructions,
      scheduledFor,
      expiresAt
    });

    await assignment.save();

    // Send assignment notifications
    try {
      const students = await User.find({ 
        _id: { $in: studentsToAssign.map(s => s.student) }
      });
      
      for (const student of students) {
        await sendQuizAssignmentEmail(student, quiz, classroom, assignment);
      }
    } catch (emailError) {
      console.error('Failed to send quiz assignment emails:', emailError);
    }

    res.status(201).json({
      success: true,
      message: 'Quiz assigned successfully',
      data: {
        id: assignment._id,
        quiz: {
          id: quiz._id,
          title: quiz.title,
          description: quiz.description
        },
        classroom: {
          id: classroom._id,
          name: classroom.name,
          classType: classroom.classType
        },
        assignmentType,
        totalAssignedStudents: assignment.totalAssignedStudents,
        disabledStudentsCount: assignment.disabledStudentsCount,
        regularStudentsCount: assignment.regularStudentsCount,
        settings: assignment.settings
      }
    });
  } catch (error) {
    logError('Failed to create quiz assignment', error, { userId: req.user.id });
    res.status(500).json({
      success: false,
      message: 'Failed to create quiz assignment',
      error: error.message
    });
  }
};

// Get all assignments for a teacher across all classrooms
export const getAllTeacherAssignments = async (req, res) => {
  try {
    const teacherId = req.user.id;

    console.log('🎯 Getting all assignments for teacher:', teacherId);

    // Get all assignments for this teacher's classrooms
    const assignments = await QuizAssignment.find({ assignedBy: teacherId })
      .populate({
        path: 'quiz',
        select: 'title description questions timeLimit'
      })
      .populate({
        path: 'classroom',
        select: 'name subject students'
      })
      .sort({ createdAt: -1 });

    console.log('📋 Found assignments:', assignments.length);

    res.json({
      success: true,
      assignments
    });
  } catch (error) {
    console.error('❌ Error fetching teacher assignments:', error);
    logError('Error fetching teacher assignments', error, req);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch assignments'
    });
  }
};

// Get all assignments for a teacher with completion statistics
export const getAllTeacherAssignmentsWithStats = async (req, res) => {
  try {
    const teacherId = req.user.id;

    console.log('🎯 Getting all assignments with stats for teacher:', teacherId);

    // Get all assignments for this teacher's classrooms
    const assignments = await QuizAssignment.find({ assignedBy: teacherId })
      .populate({
        path: 'quiz',
        select: 'title description questions timeLimit'
      })
      .populate({
        path: 'classroom',
        select: 'name subject students'
      })
      .sort({ createdAt: -1 });

    console.log('📋 Found assignments:', assignments.length);

    // Calculate completion statistics for each assignment
    const assignmentsWithStats = await Promise.all(
      assignments.map(async (assignment) => {
        try {
          // Get total students in the classroom
          const totalStudents = assignment.classroom?.students?.length || 0;

          // Get the quiz with submissions to count completed attempts
          const quizWithSubmissions = await Quiz.findById(assignment.quiz._id).select('submissions');

          // Count unique students who have completed this quiz
          const uniqueCompletedStudents = new Set();
          if (quizWithSubmissions?.submissions) {
            quizWithSubmissions.submissions.forEach(submission => {
              if (submission.student && submission.completedAt) {
                uniqueCompletedStudents.add(submission.student.toString());
              }
            });
          }

          const completedCount = uniqueCompletedStudents.size;

          console.log(`📊 Assignment ${assignment._id}: ${completedCount}/${totalStudents} completed`);

          return {
            ...assignment.toObject(),
            totalStudents,
            completedCount,
            completionPercentage: totalStudents > 0 ? Math.round((completedCount / totalStudents) * 100) : 0
          };
        } catch (error) {
          console.error(`❌ Error calculating stats for assignment ${assignment._id}:`, error);
          return {
            ...assignment.toObject(),
            totalStudents: assignment.classroom?.students?.length || 0,
            completedCount: 0,
            completionPercentage: 0
          };
        }
      })
    );

    res.json({
      success: true,
      assignments: assignmentsWithStats
    });
  } catch (error) {
    console.error('❌ Error fetching teacher assignments with stats:', error);
    logError('Error fetching teacher assignments with stats', error, req);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch assignments with statistics'
    });
  }
};

// Get assignments for a classroom
export const getClassroomAssignments = async (req, res) => {
  try {
    const { classroomId } = req.params;
    const teacherId = req.user.id;

    // Verify classroom belongs to teacher
    const classroom = await Class.findOne({ _id: classroomId, teacher: teacherId });
    if (!classroom) {
      return res.status(404).json({
        success: false,
        message: 'Classroom not found'
      });
    }

    const assignments = await QuizAssignment.find({ classroom: classroomId })
      .populate('quiz', 'title description status')
      .populate('assignedStudents.student', 'name email studentId rollNo isDisabled')
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      data: assignments
    });
  } catch (error) {
    logError('Failed to get classroom assignments', error, { userId: req.user.id });
    res.status(500).json({
      success: false,
      message: 'Failed to get assignments',
      error: error.message
    });
  }
};

// Get assignment by ID
export const getAssignmentById = async (req, res) => {
  try {
    const { assignmentId } = req.params;
    const userId = req.user.id;
    const userRole = req.user.role;

    console.log('🔍 Getting assignment by ID:', assignmentId, 'for user:', userId, 'role:', userRole);

    const assignment = await QuizAssignment.findById(assignmentId)
      .populate('quiz', 'title description questions timeLimit submissions')
      .populate('classroom', 'name subject classType')
      .populate('assignedStudents.student', 'name email studentId rollNo isDisabled')
      .populate('assignedBy', 'name email');

    if (!assignment) {
      return res.status(404).json({
        success: false,
        message: 'Assignment not found'
      });
    }

    console.log('📋 Assignment found:', {
      id: assignment._id,
      assignmentType: assignment.assignmentType,
      totalAssignedStudents: assignment.assignedStudents.length,
      assignedStudents: assignment.assignedStudents.map(s => ({
        studentId: s.student._id.toString(),
        isActive: s.isActive,
        studentType: s.studentType
      }))
    });

    // Check access based on user role
    if (userRole === 'student') {
      console.log('👤 Student access check for user:', userId);
      
      // Check if student is assigned to this quiz
      const isAssigned = assignment.assignedStudents.some(
        student => {
          const studentIdMatch = student.student._id.toString() === userId.toString();
          const isActive = student.isActive;
          console.log(`🔍 Checking student ${student.student._id}: match=${studentIdMatch}, active=${isActive}`);
          return studentIdMatch && isActive;
        }
      );

      console.log('✅ Student assignment check result:', isAssigned);

      if (!isAssigned) {
        console.log('❌ Student not assigned to this quiz');
        console.log('📝 Available assigned students:', assignment.assignedStudents.map(s => ({
          id: s.student._id.toString(),
          name: s.student.name,
          isActive: s.isActive
        })));
        
        return res.status(403).json({
          success: false,
          message: 'You are not assigned to this quiz',
          debug: {
            userId: userId,
            assignedStudents: assignment.assignedStudents.map(s => ({
              studentId: s.student._id.toString(),
              isActive: s.isActive
            }))
          }
        });
      }

      // Filter quiz submissions to only include the current student's submissions
      if (assignment.quiz && assignment.quiz.submissions) {
        assignment.quiz.submissions = assignment.quiz.submissions.filter(
          submission => submission.student.toString() === userId.toString()
        );
      }
    } else if (userRole === 'staff') {
      // Verify teacher owns the assignment
      if (assignment.assignedBy._id.toString() !== userId.toString()) {
        return res.status(403).json({
          success: false,
          message: 'Access denied'
        });
      }
    }

    console.log('✅ Access granted, returning assignment');
    res.status(200).json({
      success: true,
      assignment
    });
  } catch (error) {
    console.error('❌ Error fetching assignment by ID:', error);
    logError('Failed to get assignment', error, { userId: req.user.id });
    res.status(500).json({
      success: false,
      message: 'Failed to get assignment',
      error: error.message
    });
  }
};

// Update assignment
export const updateAssignment = async (req, res) => {
  try {
    const { assignmentId } = req.params;
    const teacherId = req.user.id;
    const updateData = req.body;

    const assignment = await QuizAssignment.findById(assignmentId)
      .populate('classroom', 'teacher');

    if (!assignment) {
      return res.status(404).json({
        success: false,
        message: 'Assignment not found'
      });
    }

    // Verify teacher owns the classroom
    if (assignment.classroom.teacher.toString() !== teacherId) {
      return res.status(403).json({
        success: false,
        message: 'Access denied'
      });
    }

    // Update allowed fields
    const allowedFields = [
      'settings', 'instructions', 'scheduledFor', 'expiresAt', 'status'
    ];
    
    for (const field of allowedFields) {
      if (updateData[field] !== undefined) {
        assignment[field] = updateData[field];
      }
    }

    await assignment.save();

    res.status(200).json({
      success: true,
      message: 'Assignment updated successfully',
      data: assignment
    });
  } catch (error) {
    logError('Failed to update assignment', error, { userId: req.user.id });
    res.status(500).json({
      success: false,
      message: 'Failed to update assignment',
      error: error.message
    });
  }
};

// Delete assignment
export const deleteAssignment = async (req, res) => {
  try {
    const { assignmentId } = req.params;
    const teacherId = req.user.id;

    const assignment = await QuizAssignment.findById(assignmentId)
      .populate('classroom', 'teacher');

    if (!assignment) {
      return res.status(404).json({
        success: false,
        message: 'Assignment not found'
      });
    }

    // Verify teacher owns the classroom
    if (assignment.classroom.teacher.toString() !== teacherId) {
      return res.status(403).json({
        success: false,
        message: 'Access denied'
      });
    }

    await QuizAssignment.findByIdAndDelete(assignmentId);

    res.status(200).json({
      success: true,
      message: 'Assignment deleted successfully'
    });
  } catch (error) {
    logError('Failed to delete assignment', error, { userId: req.user.id });
    res.status(500).json({
      success: false,
      message: 'Failed to delete assignment',
      error: error.message
    });
  }
};

// Get assignments for a student
export const getStudentAssignments = async (req, res) => {
  try {
    const studentId = req.user.id;
    console.log('🔍 Getting assignments for student:', studentId);

    // Get all classrooms where this student is enrolled
    const studentClassrooms = await Class.find({
      'students.student': studentId,
      'students.isActive': true
    });

    console.log('🏫 Student is enrolled in classrooms:', studentClassrooms.length);

    if (studentClassrooms.length === 0) {
      console.log('❌ Student is not enrolled in any classrooms');
      return res.status(200).json({
        success: true,
        data: [],
        message: 'Student is not enrolled in any classrooms'
      });
    }

    const classroomIds = studentClassrooms.map(c => c._id);
    console.log('📚 Classroom IDs:', classroomIds);

    // Find all assignments for these classrooms
    const assignments = await QuizAssignment.find({
      classroom: { $in: classroomIds },
      status: 'active'
    })
    .populate('quiz', 'title description status questions submissions')
    .populate('classroom', 'name subject classType')
    .populate('assignedBy', 'name email')
    .sort({ createdAt: -1 });

    console.log('📋 Total assignments found for classrooms:', assignments.length);

    // Filter assignments to only include those where the student is specifically assigned
    const studentAssignments = assignments.filter(assignment => {
      // Check if student is in the assignedStudents array
      const isAssigned = assignment.assignedStudents.some(
        assignedStudent => assignedStudent.student.toString() === studentId.toString() && assignedStudent.isActive
      );

      console.log(`Assignment ${assignment._id}: student assigned = ${isAssigned}`);
      return isAssigned;
    });

    console.log('✅ Final assignments for student:', studentAssignments.length);

    // Filter submissions to only include the current student's submissions
    const filteredAssignments = studentAssignments.map(assignment => {
      const assignmentObj = assignment.toObject();
      if (assignmentObj.quiz && assignmentObj.quiz.submissions) {
        assignmentObj.quiz.submissions = assignmentObj.quiz.submissions.filter(
          submission => submission.student.toString() === studentId.toString()
        );
      }
      return assignmentObj;
    });

    console.log('📤 Returning assignments to student:', filteredAssignments.length);

    res.status(200).json({
      success: true,
      data: filteredAssignments
    });
  } catch (error) {
    console.error('❌ Error getting student assignments:', error);
    logError('Failed to get student assignments', error, { userId: req.user.id });
    res.status(500).json({
      success: false,
      message: 'Failed to get assignments',
      error: error.message
    });
  }
};

// Submit quiz for assignment (for students)
export const submitQuizForAssignment = async (req, res) => {
  try {
    const { assignmentId } = req.params;
    const studentId = req.user.id;
    const {
      answers,
      timeSpent,
      isVoiceControlled = false,
      voiceCommands = [],
      accessibilityLog = []
    } = req.body;

    const assignment = await QuizAssignment.findById(assignmentId)
      .populate('quiz')
      .populate('classroom');

    if (!assignment) {
      return res.status(404).json({
        success: false,
        message: 'Assignment not found'
      });
    }

    // Verify student is assigned to this assignment
    if (!assignment.isStudentAssigned(studentId)) {
      return res.status(403).json({
        success: false,
        message: 'You are not assigned to this quiz'
      });
    }

    // Check if assignment is active
    if (assignment.status !== 'active') {
      return res.status(400).json({
        success: false,
        message: 'This assignment is not active'
      });
    }

    // Check if student is disabled and voice control is required
    const isStudentDisabled = assignment.isStudentDisabled(studentId);
    if (isStudentDisabled && !isVoiceControlled && assignment.settings.allowVoiceControl) {
      return res.status(400).json({
        success: false,
        message: 'Voice control is required for disabled students'
      });
    }

    // Calculate score with enhanced debugging
    const quiz = assignment.quiz;
    let totalScore = 0;
    let correctAnswers = 0;

    console.log('🎯 Server-side score calculation starting');
    console.log('📝 Total questions:', quiz.questions.length);
    console.log('📤 Received answers:', answers);

    answers.forEach((answer, index) => {
      const question = quiz.questions[answer.questionIndex || index];
      if (question) {
        let isCorrect = false;

        console.log(`🔍 Question ${index}:`, {
          questionType: question.type,
          questionOptions: question.options,
          answerSelectedIndex: answer.selectedAnswer,
          answerSelectedOption: answer.selectedOption,
          answerIsCorrect: answer.isCorrect
        });

        if (question.type === 'multiple-choice' || !question.type) {
          // Use selectedAnswer index if available
          if (typeof answer.selectedAnswer === 'number' && answer.selectedAnswer >= 0) {
            isCorrect = question.options[answer.selectedAnswer]?.isCorrect || false;
            console.log(`✅ Using selectedAnswer index ${answer.selectedAnswer}:`, isCorrect);
          } else {
            // Fallback: find option by text
            const selectedOptionIndex = question.options.findIndex(opt => {
              const optText = typeof opt === 'string' ? opt : (opt.text || opt.option || opt.value || String(opt));
              return optText === answer.selectedOption;
            });
            if (selectedOptionIndex !== -1) {
              isCorrect = question.options[selectedOptionIndex]?.isCorrect || false;
              console.log(`✅ Found option by text at index ${selectedOptionIndex}:`, isCorrect);
            }
          }
        } else {
          isCorrect = answer.textAnswer?.toLowerCase() === question.correctAnswer?.toLowerCase();
        }

        console.log(`📊 Question ${index} result:`, isCorrect);

        if (isCorrect) {
          correctAnswers++;
          totalScore += question.points || 1;
        }

        answer.isCorrect = isCorrect;
        answer.pointsEarned = isCorrect ? (question.points || 1) : 0;
      }
    });

    console.log('🏁 Final server calculation:', {
      correctAnswers,
      totalQuestions: quiz.questions.length,
      totalScore
    });

    const percentage = Math.round((correctAnswers / quiz.questions.length) * 100);

    // Create submission
    const submission = {
      student: studentId,
      answers,
      totalScore,
      percentage,
      startedAt: new Date(),
      completedAt: new Date(),
      timeSpent: timeSpent || 0,
      attemptNumber: 1,
      isVoiceControlled,
      voiceCommands,
      accessibilityLog
    };

    // Add submission to quiz
    quiz.submissions.push(submission);
    await quiz.save();

    res.status(200).json({
      success: true,
      message: 'Quiz submitted successfully',
      data: {
        score: correctAnswers,
        totalQuestions: quiz.questions.length,
        percentage,
        timeSpent,
        isVoiceControlled
      }
    });
  } catch (error) {
    logError('Failed to submit quiz', error, { userId: req.user.id });
    res.status(500).json({
      success: false,
      message: 'Failed to submit quiz',
      error: error.message
    });
  }
}; 