import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { logApi, logError, logInfo } from '../config/logger.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Get log statistics and recent entries
export const getLogStats = async (req, res) => {
  try {
    logApi('GET /api/logs/stats', { userId: req.user.id });

    const logsDir = path.join(__dirname, '../logs');
    const stats = {
      geminiAPI: await getLogFileStats(path.join(logsDir, 'gemini-api.log')),
      quizOperations: await getLogFileStats(path.join(logsDir, 'quiz-operations.log')),
      metrics: await getLogFileStats(path.join(logsDir, 'metrics.log')),
      errors: await getLogFileStats(path.join(logsDir, 'error.log')),
      combined: await getLogFileStats(path.join(logsDir, 'combined.log'))
    };

    res.json({
      success: true,
      data: stats,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    logError('Failed to get log stats', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve log statistics'
    });
  }
};

// Get recent log entries
export const getRecentLogs = async (req, res) => {
  try {
    const { type = 'combined', limit = 100 } = req.query;
    logApi(`GET /api/logs/recent?type=${type}&limit=${limit}`, { userId: req.user.id });

    const logsDir = path.join(__dirname, '../logs');
    const logFile = path.join(logsDir, `${type}.log`);

    if (!fs.existsSync(logFile)) {
      return res.status(404).json({
        success: false,
        message: `Log file ${type}.log not found`
      });
    }

    const logs = await getRecentLogEntries(logFile, parseInt(limit));

    res.json({
      success: true,
      data: {
        type,
        entries: logs,
        count: logs.length
      },
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    logError('Failed to get recent logs', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve recent logs'
    });
  }
};

// Get Gemini API metrics
export const getGeminiMetrics = async (req, res) => {
  try {
    logApi('GET /api/logs/gemini-metrics', { userId: req.user.id });

    const logsDir = path.join(__dirname, '../logs');
    const metricsFile = path.join(logsDir, 'metrics.log');

    if (!fs.existsSync(metricsFile)) {
      return res.json({
        success: true,
        data: {
          totalRequests: 0,
          successfulRequests: 0,
          errorCount: 0,
          errorRate: '0%',
          avgResponseTime: '0ms',
          recentMetrics: []
        }
      });
    }

    const recentMetrics = await getRecentLogEntries(metricsFile, 50);
    const geminiMetrics = recentMetrics
      .filter(entry => entry.type === 'gemini-api-metrics')
      .slice(0, 10);

    const latestMetric = geminiMetrics[0] || {};

    res.json({
      success: true,
      data: {
        totalRequests: latestMetric.totalRequests || 0,
        successfulRequests: latestMetric.successfulRequests || 0,
        errorCount: latestMetric.errorCount || 0,
        errorRate: latestMetric.errorRate || '0%',
        avgResponseTime: latestMetric.avgResponseTime || '0ms',
        uptime: latestMetric.uptime || '0s',
        recentMetrics: geminiMetrics
      },
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    logError('Failed to get Gemini metrics', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve Gemini API metrics'
    });
  }
};

// Get quiz operations metrics
export const getQuizMetrics = async (req, res) => {
  try {
    logApi('GET /api/logs/quiz-metrics', { userId: req.user.id });

    const logsDir = path.join(__dirname, '../logs');
    const metricsFile = path.join(logsDir, 'metrics.log');

    if (!fs.existsSync(metricsFile)) {
      return res.json({
        success: true,
        data: {
          totalQuizzes: 0,
          aiGeneratedQuizzes: 0,
          syllabusBasedQuizzes: 0,
          manualQuizzes: 0,
          totalQuestions: 0,
          avgQuestionsPerQuiz: '0',
          recentMetrics: []
        }
      });
    }

    const recentMetrics = await getRecentLogEntries(metricsFile, 50);
    const quizMetrics = recentMetrics
      .filter(entry => entry.type === 'quiz-operations-metrics')
      .slice(0, 10);

    const latestMetric = quizMetrics[0] || {};

    res.json({
      success: true,
      data: {
        totalQuizzes: latestMetric.totalQuizzes || 0,
        aiGeneratedQuizzes: latestMetric.aiGeneratedQuizzes || 0,
        syllabusBasedQuizzes: latestMetric.syllabusBasedQuizzes || 0,
        manualQuizzes: latestMetric.manualQuizzes || 0,
        totalQuestions: latestMetric.totalQuestions || 0,
        avgQuestionsPerQuiz: latestMetric.avgQuestionsPerQuiz || '0',
        uptime: latestMetric.uptime || '0s',
        recentMetrics: quizMetrics
      },
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    logError('Failed to get quiz metrics', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve quiz operations metrics'
    });
  }
};

// Helper function to get log file statistics
async function getLogFileStats(filePath) {
  try {
    if (!fs.existsSync(filePath)) {
      return {
        exists: false,
        size: 0,
        entries: 0,
        lastModified: null
      };
    }

    const stats = fs.statSync(filePath);
    const content = fs.readFileSync(filePath, 'utf8');
    const lines = content.split('\n').filter(line => line.trim());

    return {
      exists: true,
      size: stats.size,
      entries: lines.length,
      lastModified: stats.mtime.toISOString(),
      sizeFormatted: formatBytes(stats.size)
    };
  } catch (error) {
    return {
      exists: false,
      size: 0,
      entries: 0,
      lastModified: null,
      error: error.message
    };
  }
}

// Helper function to get recent log entries
async function getRecentLogEntries(filePath, limit = 100) {
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    const lines = content.split('\n').filter(line => line.trim());
    
    return lines
      .slice(-limit)
      .reverse()
      .map(line => {
        try {
          return JSON.parse(line);
        } catch {
          return { raw: line, timestamp: new Date().toISOString() };
        }
      });
  } catch (error) {
    return [];
  }
}

// Helper function to format bytes
function formatBytes(bytes, decimals = 2) {
  if (bytes === 0) return '0 Bytes';

  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];

  const i = Math.floor(Math.log(bytes) / Math.log(k));

  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}
