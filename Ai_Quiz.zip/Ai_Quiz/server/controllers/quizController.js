import Quiz from '../models/Quiz.js'
import Class from '../models/Class.js'
import User from '../models/User.js'
import { logApi, logError, logInfo, logUser } from '../config/logger.js'
import quizOperationsLogger from '../utils/quizLogger.js'

// Get all quizzes for a teacher
export const getTeacherQuizzes = async (req, res) => {
  try {
    const { status, classroomId, page = 1, limit = 10 } = req.query
    const skip = (page - 1) * limit

    logApi('Get Teacher Quizzes Request', {
      userId: req.user.id,
      status,
      classroomId,
      page,
      limit
    })

    const filter = { createdBy: req.user.id }
    
    if (status) {
      filter.status = status
    }
    
    if (classroomId) {
      filter.classroom = classroomId
    }

    const quizzes = await Quiz.find(filter)
      .populate('classroom', 'name subject grade')
      .populate('submissions.student', 'name email')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit))

    const total = await Quiz.countDocuments(filter)

    logInfo('Teacher Quizzes Retrieved', {
      userId: req.user.id,
      quizCount: quizzes.length,
      total
    })

    res.json({
      success: true,
      data: {
        quizzes: quizzes.map(quiz => ({
          _id: quiz._id,
          title: quiz.title,
          description: quiz.description,
          status: quiz.status,
          questionCount: quiz.questionCount,
          totalPoints: quiz.totalPoints,
          averageScore: quiz.averageScore,
          completionRate: quiz.completionRate,
          classroom: quiz.classroom,
          aiGenerated: quiz.aiGenerated,
          createdAt: quiz.createdAt,
          submissions: quiz.submissions.length
        })),
        pagination: {
          current: parseInt(page),
          total: Math.ceil(total / limit),
          hasNext: page * limit < total,
          hasPrev: page > 1
        }
      }
    })

    } catch (error) {
    logError('Get Teacher Quizzes Error', {
      error: error.message,
      stack: error.stack,
      userId: req.user.id
    })

    res.status(500).json({
      success: false,
      message: 'Failed to retrieve quizzes',
      error: process.env.NODE_ENV === 'development' ? error.message : 'Internal server error'
    })
  }
}

// Get a specific quiz by ID
export const getQuizById = async (req, res) => {
  try {
    const { quizId } = req.params

    logApi('Get Quiz By ID Request', {
      quizId,
      userId: req.user.id
    })

    const quiz = await Quiz.findById(quizId)
      .populate('classroom', 'name subject grade classCode')
      .populate('createdBy', 'name email')
      .populate('submissions.student', 'name email')

    if (!quiz) {
      return res.status(404).json({
        success: false,
        message: 'Quiz not found'
      })
    }

    // Check if user has access to this quiz
    if (quiz.createdBy._id.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this quiz'
      })
    }

    logInfo('Quiz Retrieved', {
      quizId,
      userId: req.user.id,
      title: quiz.title
    })

    res.json({
      success: true,
      data: {
        _id: quiz._id,
        title: quiz.title,
        description: quiz.description,
        status: quiz.status,
        questions: quiz.questions,
        settings: quiz.settings,
        classroom: quiz.classroom,
        createdBy: quiz.createdBy,
        totalPoints: quiz.totalPoints,
        questionCount: quiz.questionCount,
        averageScore: quiz.averageScore,
        completionRate: quiz.completionRate,
        submissions: quiz.submissions,
        aiGenerated: quiz.aiGenerated,
        aiPrompt: quiz.aiPrompt,
        scheduledFor: quiz.scheduledFor,
        expiresAt: quiz.expiresAt,
        createdAt: quiz.createdAt,
        updatedAt: quiz.updatedAt,
        subject: quiz.subject,
        grade: quiz.grade,
        isActive: quiz.isActive
      }
    })

    } catch (error) {
    logError('Get Quiz By ID Error', {
      error: error.message,
      stack: error.stack,
      quizId: req.params.quizId,
      userId: req.user.id
    })

    res.status(500).json({
      success: false,
      message: 'Failed to retrieve quiz',
      error: process.env.NODE_ENV === 'development' ? error.message : 'Internal server error'
    })
  }
}

// Create a new quiz
export const createQuiz = async (req, res) => {
  const startTime = Date.now();
  const operationId = quizOperationsLogger.logQuizCreationStart({
    title: req.body.title,
    type: req.body.syllabusGenerated ? 'syllabus-based' : (req.body.aiGenerated ? 'ai-generated' : 'manual'),
    difficulty: req.body.difficulty,
    questions: req.body.questions,
    classroomId: req.body.classroomId,
    userId: req.user.id,
    subject: req.body.subject,
    topic: req.body.topic
  });

  try {
    const {
      title,
      description,
      classroomId,
      questions,
      settings = {}
    } = req.body

    logApi('Create Quiz Request', {
      title,
      classroomId,
      questionCount: questions?.length || 0,
      userId: req.user.id
    })

    if (!title || !classroomId) {
      return res.status(400).json({
        success: false,
        message: 'Title and classroom are required'
      })
    }

    // Validate classroom exists and user has access
    const classroom = await Class.findById(classroomId)
    if (!classroom) {
      return res.status(404).json({
        success: false,
        message: 'Classroom not found'
      })
    }
    
    if (classroom.teacher.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this classroom'
      })
    }

    // Create the quiz
    const quiz = new Quiz({
      title,
      description,
      classroom: classroomId,
      createdBy: req.user.id,
      questions: questions || [],
      settings: {
        timeLimit: settings.timeLimit || 30,
        passingScore: settings.passingScore || 60,
        allowRetake: settings.allowRetake || false,
        maxAttempts: settings.maxAttempts || 1,
        shuffleQuestions: settings.shuffleQuestions !== false,
        showResults: settings.showResults !== false,
        showCorrectAnswers: settings.showCorrectAnswers || false,
        requirePassword: settings.requirePassword || false,
        password: settings.password || null
      },
      status: 'draft'
    })

    await quiz.save()
    const creationTime = Date.now() - startTime;

    // Log successful quiz creation
    quizOperationsLogger.logQuizCreationSuccess(operationId, {
      _id: quiz._id,
      title: quiz.title,
      type: req.body.syllabusGenerated ? 'syllabus-based' : (req.body.aiGenerated ? 'ai-generated' : 'manual'),
      difficulty: req.body.difficulty,
      questions: quiz.questions,
      classroomId: quiz.classroom,
      userId: req.user.id
    }, creationTime);

    logInfo('Quiz Created Successfully', {
      quizId: quiz._id,
      title,
      classroomId,
      userId: req.user.id,
      creationTime: `${creationTime}ms`
    })

    res.status(201).json({
      success: true,
      data: {
        quiz: {
          _id: quiz._id,
          title: quiz.title,
          description: quiz.description,
          status: quiz.status,
          questionCount: quiz.questionCount,
          totalPoints: quiz.totalPoints,
          createdAt: quiz.createdAt
        }
      },
      message: 'Quiz created successfully'
    })

    } catch (error) {
    // Log quiz creation error
    quizOperationsLogger.logQuizCreationError(operationId, error, {
      title: req.body.title,
      type: req.body.syllabusGenerated ? 'syllabus-based' : (req.body.aiGenerated ? 'ai-generated' : 'manual'),
      classroomId: req.body.classroomId,
      userId: req.user.id
    });

    logError('Create Quiz Error', {
      error: error.message,
      stack: error.stack,
      userId: req.user.id
    })

    res.status(500).json({
      success: false,
      message: 'Failed to create quiz',
      error: process.env.NODE_ENV === 'development' ? error.message : 'Internal server error'
    })
  }
}

// Update a quiz
export const updateQuiz = async (req, res) => {
  try {
    const { quizId } = req.params
    const updateData = req.body

    logApi('Update Quiz Request', {
      quizId,
      updateFields: Object.keys(updateData),
      userId: req.user.id
    })

    const quiz = await Quiz.findById(quizId)
    if (!quiz) {
      return res.status(404).json({
        success: false,
        message: 'Quiz not found'
      })
    }

    if (quiz.createdBy.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this quiz'
      })
    }

    // Update allowed fields
    const allowedFields = [
      'title', 
      'description', 
      'subject',
      'grade',
      'questions', 
      'settings', 
      'isActive',
      'scheduledFor', 
      'expiresAt'
    ]
    const filteredData = {}
    
    allowedFields.forEach(field => {
      if (updateData[field] !== undefined) {
        filteredData[field] = updateData[field]
      }
    })

    const updatedQuiz = await Quiz.findByIdAndUpdate(
      quizId,
      filteredData,
      { new: true, runValidators: true }
    )

    logInfo('Quiz Updated Successfully', {
      quizId,
      userId: req.user.id,
      updatedFields: Object.keys(filteredData)
    })

    res.json({
      success: true,
      data: {
        quiz: {
          _id: updatedQuiz._id,
          title: updatedQuiz.title,
          description: updatedQuiz.description,
          status: updatedQuiz.status,
          questionCount: updatedQuiz.questionCount,
          totalPoints: updatedQuiz.totalPoints,
          updatedAt: updatedQuiz.updatedAt
        }
      },
      message: 'Quiz updated successfully'
    })

    } catch (error) {
    logError('Update Quiz Error', {
      error: error.message,
      stack: error.stack,
      quizId: req.params.quizId,
      userId: req.user.id
    })

    res.status(500).json({
      success: false,
      message: 'Failed to update quiz',
      error: process.env.NODE_ENV === 'development' ? error.message : 'Internal server error'
    })
  }
}

// Delete a quiz
export const deleteQuiz = async (req, res) => {
  try {
    const { quizId } = req.params

    logApi('Delete Quiz Request', {
      quizId,
      userId: req.user.id
    })

    const quiz = await Quiz.findById(quizId)
    if (!quiz) {
      return res.status(404).json({
        success: false,
        message: 'Quiz not found'
      })
    }

    if (quiz.createdBy.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this quiz'
      })
    }

    // Also delete related quiz assignments
    const { default: QuizAssignment } = await import('../models/QuizAssignment.js');
    const deletedAssignments = await QuizAssignment.deleteMany({ quiz: quizId });

    // Delete the quiz
    await Quiz.findByIdAndDelete(quizId)

    logInfo('Quiz Deleted Successfully', {
      quizId,
      userId: req.user.id,
      title: quiz.title,
      deletedAssignments: deletedAssignments.deletedCount
    })

    res.json({
      success: true,
      message: 'Quiz deleted successfully'
    })

  } catch (error) {
    logError('Delete Quiz Error', {
      error: error.message,
      stack: error.stack,
      quizId: req.params.quizId,
      userId: req.user.id
    })

    res.status(500).json({
      success: false,
      message: 'Failed to delete quiz',
      error: process.env.NODE_ENV === 'development' ? error.message : 'Internal server error'
    })
  }
}

// Publish a quiz
export const publishQuiz = async (req, res) => {
  try {
    const { quizId } = req.params

    logApi('Publish Quiz Request', {
      quizId,
      userId: req.user.id
    })

    const quiz = await Quiz.findById(quizId)
    if (!quiz) {
      return res.status(404).json({
        success: false,
        message: 'Quiz not found'
      })
    }

    if (quiz.createdBy.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this quiz'
      })
    }

    if (quiz.questions.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Cannot publish quiz with no questions'
      })
    }

    quiz.status = 'published'
    quiz.isActive = true
    await quiz.save()

    logInfo('Quiz Published Successfully', {
      quizId,
      userId: req.user.id,
      title: quiz.title
    })

    res.json({
      success: true,
      data: {
        quiz: {
          _id: quiz._id,
          title: quiz.title,
          status: quiz.status,
          isActive: quiz.isActive,
          updatedAt: quiz.updatedAt
        }
      },
      message: 'Quiz published successfully'
    })

    } catch (error) {
    logError('Publish Quiz Error', {
      error: error.message,
      stack: error.stack,
      quizId: req.params.quizId,
      userId: req.user.id
    })

    res.status(500).json({
      success: false,
      message: 'Failed to publish quiz',
      error: process.env.NODE_ENV === 'development' ? error.message : 'Internal server error'
    })
  }
}

// Archive a quiz
export const archiveQuiz = async (req, res) => {
  try {
    const { quizId } = req.params

    logApi('Archive Quiz Request', {
      quizId,
      userId: req.user.id
    })

    const quiz = await Quiz.findById(quizId)
    if (!quiz) {
      return res.status(404).json({
        success: false,
        message: 'Quiz not found'
      })
    }

    if (quiz.createdBy.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this quiz'
      })
    }

    quiz.status = 'archived'
    quiz.isActive = false
    await quiz.save()

    logInfo('Quiz Archived Successfully', {
      quizId,
      userId: req.user.id,
      title: quiz.title
    })

    res.json({
      success: true,
      data: {
        quiz: {
          _id: quiz._id,
          title: quiz.title,
          status: quiz.status,
          isActive: quiz.isActive,
          updatedAt: quiz.updatedAt
        }
      },
      message: 'Quiz archived successfully'
    })

  } catch (error) {
    logError('Archive Quiz Error', {
      error: error.message,
      stack: error.stack,
      quizId: req.params.quizId,
      userId: req.user.id
    })

    res.status(500).json({
      success: false,
      message: 'Failed to archive quiz',
      error: process.env.NODE_ENV === 'development' ? error.message : 'Internal server error'
    })
  }
}

// Get quiz statistics
export const getQuizStatistics = async (req, res) => {
  try {
    const { quizId } = req.params

    logApi('Get Quiz Statistics Request', {
      quizId,
      userId: req.user.id
    })

    const quiz = await Quiz.findById(quizId)
      .populate('submissions.student', 'name email')
      .populate('classroom', 'name subject grade')

    if (!quiz) {
      return res.status(404).json({
        success: false,
        message: 'Quiz not found'
      })
    }

    if (quiz.createdBy.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this quiz'
      })
    }

    const stats = quiz.getStatistics()

    logInfo('Quiz Statistics Retrieved', {
      quizId,
      userId: req.user.id,
      submissionCount: stats.totalSubmissions
    })

    res.json({
      success: true,
      data: {
        quiz: {
          _id: quiz._id,
          title: quiz.title,
          classroom: quiz.classroom
        },
        statistics: stats,
        submissions: quiz.submissions.map(submission => ({
          student: submission.student,
          totalScore: submission.totalScore,
          percentage: submission.percentage,
          timeSpent: submission.timeSpent,
          completedAt: submission.completedAt,
          attemptNumber: submission.attemptNumber
        }))
      }
    })

  } catch (error) {
    logError('Get Quiz Statistics Error', {
      error: error.message,
      stack: error.stack,
      quizId: req.params.quizId,
      userId: req.user.id
    })

    res.status(500).json({
      success: false,
      message: 'Failed to get quiz statistics',
      error: process.env.NODE_ENV === 'development' ? error.message : 'Internal server error'
    })
  }
}

// Get quizzes for a specific classroom
export const getClassroomQuizzes = async (req, res) => {
  try {
    const { classroomId } = req.params
    const { status, page = 1, limit = 10 } = req.query
    const skip = (page - 1) * limit

    logApi('Get Classroom Quizzes Request', {
      classroomId,
      status,
      page,
      limit,
      userId: req.user.id
    })

    // Validate classroom exists and user has access
    const classroom = await Class.findById(classroomId)
    if (!classroom) {
      return res.status(404).json({
        success: false,
        message: 'Classroom not found'
      })
    }
    
    if (classroom.teacher.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this classroom'
      })
    }

    const filter = { classroom: classroomId }
    if (status) {
      filter.status = status
    }

    const quizzes = await Quiz.find(filter)
      .populate('submissions.student', 'name email')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit))

    const total = await Quiz.countDocuments(filter)

    logInfo('Classroom Quizzes Retrieved', {
      classroomId,
      userId: req.user.id,
      quizCount: quizzes.length,
      total
    })

    res.json({
      success: true,
      data: {
        classroom: {
          _id: classroom._id,
          name: classroom.name,
          subject: classroom.subject,
          grade: classroom.grade
        },
        quizzes: quizzes.map(quiz => ({
          _id: quiz._id,
          title: quiz.title,
          description: quiz.description,
          status: quiz.status,
          questionCount: quiz.questionCount,
          totalPoints: quiz.totalPoints,
          averageScore: quiz.averageScore,
          completionRate: quiz.completionRate,
          aiGenerated: quiz.aiGenerated,
          createdAt: quiz.createdAt,
          submissions: quiz.submissions.length
        })),
        pagination: {
          current: parseInt(page),
          total: Math.ceil(total / limit),
          hasNext: page * limit < total,
          hasPrev: page > 1
        }
      }
    })

  } catch (error) {
    logError('Get Classroom Quizzes Error', {
      error: error.message,
      stack: error.stack,
      classroomId: req.params.classroomId,
      userId: req.user.id
    })

    res.status(500).json({
      success: false,
      message: 'Failed to retrieve classroom quizzes',
      error: process.env.NODE_ENV === 'development' ? error.message : 'Internal server error'
    })
  }
}