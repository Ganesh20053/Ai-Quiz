import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import User from '../models/User.js';
import { validateEmail, validatePassword } from '../utils/validateInput.js';
import { sendEmail, sendStudentCredentialsEmail } from '../utils/emailService.js';
import { logAuth, logUser, logError } from '../config/logger.js';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

// Generate JWT token with role information
const generateToken = (user) => {
  return jwt.sign(
    {
      id: user._id,
      email: user.email,
      role: user.role,
      name: user.name
    },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
};

// Generate reset token
const generateResetToken = () => {
  return crypto.randomBytes(32).toString('hex');
};

// Register new user
export const register = async (req, res) => {
  try {
    const { name, email, password, role = 'student', phone, studentId, rollNo, grade } = req.body;

    // Validation
    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Name, email, and password are required'
      });
    }

    if (!validateEmail(email)) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid email address'
      });
    }

    if (!validatePassword(password)) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters long'
      });
    }

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'User with this email already exists'
      });
    }

    // Role-specific validation
    if (role === 'student') {
      if (studentId) {
        const existingStudent = await User.findOne({ studentId });
        if (existingStudent) {
          return res.status(400).json({
            success: false,
            message: 'Student ID already exists'
          });
        }
      }
      
      if (rollNo) {
        const existingRollNo = await User.findOne({ rollNo });
        if (existingRollNo) {
          return res.status(400).json({
            success: false,
            message: 'Roll number already exists'
          });
        }
      }
    }

    // Hash password
    const saltRounds = 12;
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    // Create user object based on role
    const userData = {
      name: name.trim(),
      email: email.toLowerCase().trim(),
      password: hashedPassword,
      role,
      phone: phone?.trim(),
      lastLogin: new Date()
    };

    // Add role-specific fields
    if (role === 'student') {
      userData.studentId = studentId?.trim();
      userData.rollNo = rollNo?.trim();
      userData.grade = grade?.trim();
    }

    // Create new user
    const newUser = new User(userData);
    await newUser.save();

    // Generate token
    const token = generateToken(newUser);

    // Send welcome email
    try {
      await sendEmail({
        to: newUser.email,
        subject: 'Welcome to Quiz App!',
        template: 'welcome',
        data: {
          name: newUser.name,
          role: newUser.role
        }
      });
    } catch (emailError) {
      console.error('Failed to send welcome email:', emailError);
      // Don't fail registration if email fails
    }

    logAuth('REGISTER', newUser._id, newUser.email, true, { role: newUser.role });

    // Return success response
    res.status(201).json({
      success: true,
      message: 'User registered successfully',
      data: {
        token,
        user: newUser.toSafeObject()
      }
    });

  } catch (error) {
    logError('Registration failed', error, { email: req.body.email });
    console.error('Registration error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error during registration'
    });
  }
};

// Create student (for staff use)
export const createStudent = async (req, res) => {
  try {
    const { name, email, rollNo, grade, isDisabled = false } = req.body;
    const staffId = req.user.id;

    // Validation
    if (!name || !email) {
      return res.status(400).json({
        success: false,
        message: 'Name and email are required'
      });
    }

    if (!validateEmail(email)) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid email address'
      });
    }

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'User with this email already exists'
      });
    }

    // Check if roll number already exists
    if (rollNo) {
      const existingRollNo = await User.findOne({ rollNo });
      if (existingRollNo) {
        return res.status(400).json({
          success: false,
          message: 'Roll number already exists'
        });
      }
    }

    // Generate unique password
    const generateUniquePassword = () => {
      const chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
      const specialChars = '!@#$%&*';
      let password = '';

      // Add at least one uppercase letter
      password += chars.charAt(Math.floor(Math.random() * 26));
      // Add at least one lowercase letter
      password += chars.charAt(Math.floor(Math.random() * 26) + 26);
      // Add at least one number
      password += chars.charAt(Math.floor(Math.random() * 10) + 52);
      // Add at least one special character
      password += specialChars.charAt(Math.floor(Math.random() * specialChars.length));

      // Fill the rest with random characters (total length: 8-12)
      const remainingLength = Math.floor(Math.random() * 5) + 4; // 4-8 more chars
      for (let i = 0; i < remainingLength; i++) {
        const allChars = chars + specialChars;
        password += allChars.charAt(Math.floor(Math.random() * allChars.length));
      }

      // Shuffle the password
      return password.split('').sort(() => Math.random() - 0.5).join('');
    };

    const uniquePassword = generateUniquePassword();
    const saltRounds = 12;
    const hashedPassword = await bcrypt.hash(uniquePassword, saltRounds);

    // Generate student ID if not provided
    const studentId = `STU${Date.now()}${Math.floor(Math.random() * 1000)}`;

    // Create new student
    const newStudent = new User({
      name: name.trim(),
      email: email.toLowerCase().trim(),
      password: hashedPassword,
      role: 'student',
      studentId,
      rollNo: rollNo?.trim(),
      grade: grade?.trim(),
      isDisabled, // Accessibility needs flag
      isActive: true, // All students should be active by default
      lastLogin: new Date()
    });

    await newStudent.save();

    // Send credentials email to all students (both regular and special needs)
    try {
      console.log('📧 About to send email with student data:', {
        name: newStudent.name,
        email: newStudent.email,
        studentId: newStudent.studentId,
        rollNo: newStudent.rollNo,
        passwordLength: uniquePassword.length
      });

      await sendStudentCredentialsEmail(newStudent, uniquePassword);
      console.log(`✅ Credentials email sent to ${newStudent.email} with unique password: ${uniquePassword}`);
    } catch (emailError) {
      console.error('Failed to send student credentials email:', emailError);
      // Don't fail student creation if email fails
    }

    logUser('CREATE_STUDENT', newStudent._id, newStudent.email, 'student', {
      createdBy: staffId,
      isDisabled,
      studentId,
      rollNo
    });

    res.status(201).json({
      success: true,
      message: 'Student created successfully and credentials sent via email',
      data: {
        id: newStudent._id,
        name: newStudent.name,
        email: newStudent.email,
        studentId: newStudent.studentId,
        rollNo: newStudent.rollNo,
        grade: newStudent.grade,
        isDisabled: newStudent.isDisabled,
        password: uniquePassword, // Always include password for staff reference
        emailSent: true
      }
    });

  } catch (error) {
    logError('Failed to create student', error, { 
      staffId: req.user.id,
      email: req.body.email 
    });
    res.status(500).json({
      success: false,
      message: 'Failed to create student',
      error: error.message
    });
  }
};

// Login user
export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Validation
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Email and password are required'
      });
    }

    if (!validateEmail(email)) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid email address'
      });
    }

    // Find user by email
    const user = await User.findOne({ email: email.toLowerCase().trim() });
    if (!user) {
      logAuth('LOGIN', null, email, false, { reason: 'User not found' });
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password'
      });
    }

    // Check if user account is active
    // Note: isDisabled refers to accessibility needs, not account status
    if (!user.isActive) {
      logAuth('LOGIN', user._id, user.email, false, { reason: 'Account deactivated' });
      return res.status(401).json({
        success: false,
        message: 'Account is deactivated. Please contact administrator.'
      });
    }

    // Verify password
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      logAuth('LOGIN', user._id, user.email, false, { reason: 'Invalid password' });
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password'
      });
    }

    // Update last login
    user.lastLogin = new Date();
    await user.save();

    // Generate token
    const token = generateToken(user);

    // Send login notification email
    try {
      await sendEmail({
        to: user.email,
        subject: 'Login Notification - Quiz App',
        template: 'login-notification',
        data: {
          name: user.name,
          loginTime: new Date().toLocaleString(),
          ipAddress: req.ip || 'Unknown'
        }
      });
    } catch (emailError) {
      console.error('Failed to send login notification email:', emailError);
      // Don't fail login if email fails
    }

    logAuth('LOGIN', user._id, user.email, true, { role: user.role });

    // Return success response with role-specific redirect info
    const response = {
      success: true,
      message: 'Login successful',
      data: {
        token,
        user: user.toSafeObject()
      }
    };

    // Add redirect information based on role and accessibility needs
    switch (user.role) {
      case 'admin':
        response.redirectTo = '/admin/dashboard';
        break;
      case 'staff':
        response.redirectTo = '/staff/dashboard';
        break;
      case 'student':
        // Redirect disabled students directly to assignments/quiz page
        if (user.isDisabled) {
          response.redirectTo = '/student/assignments';
          response.isDisabledStudent = true;
          response.message = 'Welcome! Redirecting to your assignments with accessibility features enabled.';
        } else {
          response.redirectTo = '/student/dashboard';
        }
        break;
      default:
        response.redirectTo = '/student/dashboard';
    }

    res.json(response);

  } catch (error) {
    logError('Login failed', error, { email: req.body.email });
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error during login'
    });
  }
};

// Forgot password
export const forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;

    if (!email || !validateEmail(email)) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid email address'
      });
    }

    // Find user by email
    const user = await User.findOne({ email: email.toLowerCase().trim() });
    if (!user) {
      // Don't reveal if user exists or not for security
      return res.json({
        success: true,
        message: 'If an account with that email exists, a password reset link has been sent.'
      });
    }

    // Generate reset token
    const resetToken = generateResetToken();
    const resetTokenExpiry = new Date(Date.now() + 3600000); // 1 hour

    // Save reset token to user
    user.resetPasswordToken = resetToken;
    user.resetPasswordExpires = resetTokenExpiry;
    await user.save();

    // Create reset URL
    const resetUrl = `${process.env.FRONTEND_URL || 'http://localhost:3000'}/reset-password?token=${resetToken}`;

    // Send reset email
    try {
      await sendEmail({
        to: user.email,
        subject: 'Password Reset Request - Quiz App',
        template: 'password-reset',
        data: {
          name: user.name,
          resetUrl,
          expiryTime: '1 hour'
        }
      });

      logAuth('FORGOT_PASSWORD', user._id, user.email, true);

      res.json({
        success: true,
        message: 'If an account with that email exists, a password reset link has been sent.'
      });
    } catch (emailError) {
      console.error('Failed to send reset email:', emailError);
      
      // Clear reset token if email fails
      user.resetPasswordToken = undefined;
      user.resetPasswordExpires = undefined;
      await user.save();

      logError('Failed to send reset email', emailError, { userId: user._id });

      res.status(500).json({
        success: false,
        message: 'Failed to send reset email. Please try again later.'
      });
    }

  } catch (error) {
    logError('Forgot password failed', error, { email: req.body.email });
    console.error('Forgot password error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Reset password
export const resetPassword = async (req, res) => {
  try {
    const { token, newPassword } = req.body;

    if (!token || !newPassword) {
      return res.status(400).json({
        success: false,
        message: 'Token and new password are required'
      });
    }

    if (!validatePassword(newPassword)) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters long'
      });
    }

    // Find user by reset token
    const user = await User.findOne({
      resetPasswordToken: token,
      resetPasswordExpires: { $gt: Date.now() }
    });

    if (!user) {
      return res.status(400).json({
        success: false,
        message: 'Invalid or expired reset token'
      });
    }

    // Hash new password
    const saltRounds = 12;
    const hashedPassword = await bcrypt.hash(newPassword, saltRounds);

    // Update user password and clear reset token
    user.password = hashedPassword;
    user.resetPasswordToken = undefined;
    user.resetPasswordExpires = undefined;
    await user.save();

    // Send confirmation email
    try {
      await sendEmail({
        to: user.email,
        subject: 'Password Reset Successful - Quiz App',
        template: 'password-reset-success',
        data: {
          name: user.name,
          resetTime: new Date().toLocaleString()
        }
      });
    } catch (emailError) {
      console.error('Failed to send reset confirmation email:', emailError);
      // Don't fail reset if email fails
    }

    logAuth('RESET_PASSWORD', user._id, user.email, true);

    res.json({
      success: true,
      message: 'Password has been reset successfully'
    });

  } catch (error) {
    logError('Reset password failed', error);
    console.error('Reset password error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Get current user profile
export const getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password');
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    res.json({
      success: true,
      data: {
        user: user.toSafeObject()
      }
    });

  } catch (error) {
    logError('Get profile failed', error, { userId: req.user.id });
    console.error('Get profile error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Update user profile
export const updateProfile = async (req, res) => {
  try {
    const { name, phone, profilePicture } = req.body;
    const userId = req.user.id;

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Update allowed fields
    if (name) user.name = name.trim();
    if (phone) user.phone = phone.trim();
    if (profilePicture) user.profilePicture = profilePicture;

    await user.save();

    logUser('UPDATE_PROFILE', userId, user.email, user.role);

    res.json({
      success: true,
      message: 'Profile updated successfully',
      data: {
        user: user.toSafeObject()
      }
    });

  } catch (error) {
    logError('Update profile failed', error, { userId: req.user.id });
    console.error('Update profile error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Change password
export const changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const userId = req.user.id;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({
        success: false,
        message: 'Current password and new password are required'
      });
    }

    if (!validatePassword(newPassword)) {
      return res.status(400).json({
        success: false,
        message: 'New password must be at least 6 characters long'
      });
    }

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Verify current password
    const isCurrentPasswordValid = await bcrypt.compare(currentPassword, user.password);
    if (!isCurrentPasswordValid) {
      return res.status(401).json({
        success: false,
        message: 'Current password is incorrect'
      });
    }

    // Hash new password
    const saltRounds = 12;
    const hashedNewPassword = await bcrypt.hash(newPassword, saltRounds);
    user.password = hashedNewPassword;

    await user.save();

    // Send password change notification
    try {
      await sendEmail({
        to: user.email,
        subject: 'Password Changed - Quiz App',
        template: 'password-changed',
        data: {
          name: user.name,
          changeTime: new Date().toLocaleString()
        }
      });
    } catch (emailError) {
      console.error('Failed to send password change notification:', emailError);
      // Don't fail password change if email fails
    }

    logAuth('CHANGE_PASSWORD', userId, user.email, true);

    res.json({
      success: true,
      message: 'Password changed successfully'
    });

  } catch (error) {
    logError('Change password failed', error, { userId: req.user.id });
    console.error('Change password error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Logout (client-side token removal)
export const logout = async (req, res) => {
  try {
    logAuth('LOGOUT', req.user?.id, req.user?.email, true);
    
    // In a stateless JWT system, logout is handled client-side
    // You could implement a blacklist here if needed
    res.json({
      success: true,
      message: 'Logged out successfully'
    });
  } catch (error) {
    logError('Logout failed', error, { userId: req.user?.id });
    console.error('Logout error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Verify token
export const verifyToken = async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password');
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    res.json({
      success: true,
      data: {
        user: user.toSafeObject()
      }
    });

  } catch (error) {
    logError('Verify token failed', error, { userId: req.user.id });
    console.error('Verify token error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};
