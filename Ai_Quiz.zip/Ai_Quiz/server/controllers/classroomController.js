import Class from '../models/Class.js';
import User from '../models/User.js';
import Quiz from '../models/Quiz.js';
import QuizAssignment from '../models/QuizAssignment.js';
import { logClassroom, logError } from '../config/logger.js';
import { sendClassroomInvitationEmail } from '../utils/emailService.js';

// Generate unique class code
const generateClassCode = async () => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code;
  let isUnique = false;
  
  while (!isUnique) {
    code = '';
    for (let i = 0; i < 6; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    const existingClass = await Class.findOne({ classCode: code });
    if (!existingClass) {
      isUnique = true;
    }
  }
  
  return code;
};

// Create new classroom
export const createClassroom = async (req, res) => {
  try {
    const { 
      name, 
      subject, 
      description, 
      grade, 
      academicYear, 
      semester, 
      maxStudents,
      classType = 'regular',
      voiceSettings = {}
    } = req.body;
    const teacherId = req.user.id;

    // Generate unique class code
    const classCode = await generateClassCode();

    const newClassroom = new Class({
      name,
      subject,
      description,
      classCode,
      teacher: teacherId,
      grade,
      academicYear,
      semester,
      maxStudents: maxStudents || 50,
      classType,
      voiceSettings: {
        enabled: classType === 'disabled' || classType === 'mixed',
        autoReadQuestions: true,
        voiceCommands: true,
        speechRate: 0.9,
        voiceLanguage: 'en-US',
        ...voiceSettings
      }
    });

    await newClassroom.save();

    logClassroom('CREATE', newClassroom._id, teacherId, {
      name,
      subject,
      classCode,
      grade,
      classType
    });

    res.status(201).json({
      success: true,
      message: 'Classroom created successfully',
      data: {
        id: newClassroom._id,
        name: newClassroom.name,
        subject: newClassroom.subject,
        classCode: newClassroom.classCode,
        grade: newClassroom.grade,
        teacher: newClassroom.teacher,
        classType: newClassroom.classType,
        voiceSettings: newClassroom.voiceSettings
      }
    });
  } catch (error) {
    logError('Failed to create classroom', error, { userId: req.user.id });
    res.status(500).json({
      success: false,
      message: 'Failed to create classroom',
      error: error.message
    });
  }
};

// Get all classrooms for a teacher
export const getTeacherClassrooms = async (req, res) => {
  try {
    const teacherId = req.user.id;
    
    const classrooms = await Class.find({ teacher: teacherId })
      .populate('teacher', 'name email department')
      .populate('students.student', 'name email studentId rollNo isDisabled');

    // Group classrooms by type
    const regularClassrooms = classrooms.filter(c => c.classType === 'regular');
    const disabledClassrooms = classrooms.filter(c => c.classType === 'disabled');
    const mixedClassrooms = classrooms.filter(c => c.classType === 'mixed');

    logClassroom('GET_TEACHER_CLASSROOMS', null, teacherId, { 
      count: classrooms.length,
      regular: regularClassrooms.length,
      disabled: disabledClassrooms.length,
      mixed: mixedClassrooms.length
    });

    res.status(200).json({
      success: true,
      data: {
        all: classrooms,
        regular: regularClassrooms,
        disabled: disabledClassrooms,
        mixed: mixedClassrooms
      }
    });
  } catch (error) {
    logError('Failed to get teacher classrooms', error, { userId: req.user.id });
    res.status(500).json({
      success: false,
      message: 'Failed to get classrooms',
      error: error.message
    });
  }
};

// Get classroom by ID
export const getClassroomById = async (req, res) => {
  try {
    const { id } = req.params;
    const teacherId = req.user.id;

    const classroom = await Class.findOne({ _id: id, teacher: teacherId })
      .populate('teacher', 'name email department')
      .populate('students.student', 'name email studentId rollNo grade isDisabled');

    if (!classroom) {
      return res.status(404).json({
        success: false,
        message: 'Classroom not found'
      });
    }

    // Get students by type
    const regularStudents = classroom.getRegularStudents();
    const disabledStudents = classroom.getDisabledStudents();

    logClassroom('GET_BY_ID', classroom._id, teacherId);

    res.status(200).json({
      success: true,
      data: {
        ...classroom.toObject(),
        regularStudents,
        disabledStudents,
        studentStats: {
          total: classroom.studentCount,
          regular: regularStudents.length,
          disabled: disabledStudents.length
        }
      }
    });
  } catch (error) {
    logError('Failed to get classroom', error, { userId: req.user.id });
    res.status(500).json({
      success: false,
      message: 'Failed to get classroom',
      error: error.message
    });
  }
};

// Add students to classroom
export const addStudentsToClassroom = async (req, res) => {
  try {
    const { classroomId } = req.params;
    const { studentIds, studentType = 'regular' } = req.body;
    const teacherId = req.user.id;

    const classroom = await Class.findOne({ _id: classroomId, teacher: teacherId });
    if (!classroom) {
      return res.status(404).json({
        success: false,
        message: 'Classroom not found'
      });
    }

    const teacher = await User.findById(teacherId);
    const students = await User.find({ _id: { $in: studentIds }, role: 'student' });

    const addedStudents = [];
    const failedStudents = [];

    for (const student of students) {
      try {
        if (classroom.isStudentEnrolled(student._id)) {
          failedStudents.push({
            student: student._id,
            reason: 'Already enrolled'
          });
          continue;
        }

        if (classroom.isFull()) {
          failedStudents.push({
            student: student._id,
            reason: 'Classroom is full'
          });
          continue;
        }

        // Determine student type based on user's disabled status or provided type
        const finalStudentType = student.isDisabled ? 'disabled' : studentType;
        
        await classroom.addStudent(student._id, finalStudentType);
        addedStudents.push({
          ...student.toObject(),
          studentType: finalStudentType
        });

        // Send classroom invitation email
        try {
          await sendClassroomInvitationEmail(student, classroom, teacher);
        } catch (emailError) {
          console.error('Failed to send classroom invitation email:', emailError);
        }

      } catch (error) {
        failedStudents.push({
          student: student._id,
          reason: error.message
        });
      }
    }

    logClassroom('ADD_STUDENTS', classroom._id, teacherId, {
      addedCount: addedStudents.length,
      failedCount: failedStudents.length,
      studentType
    });

    res.status(200).json({
      success: true,
      message: 'Students added to classroom',
      data: {
        addedStudents: addedStudents.map(s => ({
          id: s._id,
          name: s.name,
          email: s.email,
          studentId: s.studentId,
          rollNo: s.rollNo,
          isDisabled: s.isDisabled,
          studentType: s.studentType
        })),
        failedStudents
      }
    });
  } catch (error) {
    logError('Failed to add students to classroom', error, { userId: req.user.id });
    res.status(500).json({
      success: false,
      message: 'Failed to add students to classroom',
      error: error.message
    });
  }
};

// Remove student from classroom
export const removeStudentFromClassroom = async (req, res) => {
  try {
    const { classroomId, studentId } = req.params;
    const teacherId = req.user.id;

    const classroom = await Class.findOne({ _id: classroomId, teacher: teacherId });
    if (!classroom) {
      return res.status(404).json({
        success: false,
        message: 'Classroom not found'
      });
    }

    await classroom.removeStudent(studentId);

    logClassroom('REMOVE_STUDENT', classroom._id, teacherId, { studentId });

    res.status(200).json({
      success: true,
      message: 'Student removed from classroom'
    });
  } catch (error) {
    logError('Failed to remove student from classroom', error, { userId: req.user.id });
    res.status(500).json({
      success: false,
      message: 'Failed to remove student from classroom',
      error: error.message
    });
  }
};

// Delete student completely from database
export const deleteStudentCompletely = async (req, res) => {
  try {
    const { classroomId, studentId } = req.params;
    const teacherId = req.user.id;

    // Verify classroom exists and belongs to teacher
    const classroom = await Class.findOne({ _id: classroomId, teacher: teacherId });
    if (!classroom) {
      return res.status(404).json({
        success: false,
        message: 'Classroom not found'
      });
    }

    // Get student info before deletion for logging
    const student = await User.findById(studentId);
    if (!student) {
      return res.status(404).json({
        success: false,
        message: 'Student not found'
      });
    }

    // Remove student from all classrooms first
    await Class.updateMany(
      { 'students.student': studentId },
      { $pull: { students: { student: studentId } } }
    );

    // Delete the student from the database
    await User.findByIdAndDelete(studentId);

    logClassroom('DELETE_STUDENT', classroom._id, teacherId, {
      studentId,
      studentName: student.name,
      studentEmail: student.email
    });

    res.status(200).json({
      success: true,
      message: 'Student deleted completely from database'
    });
  } catch (error) {
    logError('Failed to delete student completely', error, { userId: req.user.id });
    res.status(500).json({
      success: false,
      message: 'Failed to delete student completely',
      error: error.message
    });
  }
};

// Get students in a specific classroom
export const getClassroomStudents = async (req, res) => {
  try {
    const { classroomId } = req.params;
    const teacherId = req.user.id;

    console.log('Fetching students for classroom:', classroomId, 'teacher:', teacherId);

    // Verify classroom exists and belongs to teacher
    const classroom = await Class.findOne({ _id: classroomId, teacher: teacherId });

    if (!classroom) {
      console.log('Classroom not found');
      return res.status(404).json({
        success: false,
        message: 'Classroom not found'
      });
    }

    console.log('Classroom found, students count:', classroom.students?.length || 0);

    // If no students in classroom, return empty array
    if (!classroom.students || classroom.students.length === 0) {
      console.log('No students in classroom, returning empty array');
      return res.json({
        success: true,
        message: 'No students in classroom',
        data: {
          students: []
        }
      });
    }

    // Populate student data
    const populatedClassroom = await Class.findById(classroomId)
      .populate('students.student', 'name email grade isDisabled createdAt studentId rollNo');

    if (!populatedClassroom) {
      throw new Error('Failed to populate classroom data');
    }

    // Extract student data from the populated structure
    const students = [];
    for (const studentEntry of populatedClassroom.students) {
      if (studentEntry.student) {
        students.push({
          _id: studentEntry.student._id,
          name: studentEntry.student.name,
          email: studentEntry.student.email,
          grade: studentEntry.student.grade,
          isDisabled: studentEntry.student.isDisabled,
          studentId: studentEntry.student.studentId,
          rollNo: studentEntry.student.rollNo,
          createdAt: studentEntry.student.createdAt,
          studentType: studentEntry.studentType,
          joinedAt: studentEntry.joinedAt,
          isActive: studentEntry.isActive
        });
      }
    }

    console.log('Successfully processed students:', students.length);

    res.json({
      success: true,
      message: 'Students retrieved successfully',
      data: {
        students: students
      }
    });
  } catch (error) {
    console.error('Get classroom students error:', error);
    logError('Failed to get classroom students', error, {
      userId: req.user.id,
      classroomId: req.params.classroomId
    });
    res.status(500).json({
      success: false,
      message: 'Failed to get classroom students',
      error: process.env.NODE_ENV === 'development' ? error.message : 'Internal server error'
    });
  }
};

// Update classroom
export const updateClassroom = async (req, res) => {
  try {
    const { id } = req.params;
    const teacherId = req.user.id;
    const updateData = req.body;

    const classroom = await Class.findOne({ _id: id, teacher: teacherId });
    if (!classroom) {
      return res.status(404).json({
        success: false,
        message: 'Classroom not found'
      });
    }

    // Update allowed fields
    const allowedFields = [
      'name', 'subject', 'description', 'grade', 'academicYear', 
      'semester', 'maxStudents', 'schedule', 'settings', 'classType', 'voiceSettings'
    ];
    
    for (const field of allowedFields) {
      if (updateData[field] !== undefined) {
        classroom[field] = updateData[field];
      }
    }

    await classroom.save();

    logClassroom('UPDATE', classroom._id, teacherId, updateData);

    res.status(200).json({
      success: true,
      message: 'Classroom updated successfully',
      data: classroom
    });
  } catch (error) {
    logError('Failed to update classroom', error, { userId: req.user.id });
    res.status(500).json({
      success: false,
      message: 'Failed to update classroom',
      error: error.message
    });
  }
};

// Delete classroom
export const deleteClassroom = async (req, res) => {
  try {
    const { id } = req.params;
    const teacherId = req.user.id;

    const classroom = await Class.findOne({ _id: id, teacher: teacherId });
    if (!classroom) {
      return res.status(404).json({
        success: false,
        message: 'Classroom not found'
      });
    }

    await Class.findByIdAndDelete(id);

    logClassroom('DELETE', classroom._id, teacherId);

    res.status(200).json({
      success: true,
      message: 'Classroom deleted successfully'
    });
  } catch (error) {
    logError('Failed to delete classroom', error, { userId: req.user.id });
    res.status(500).json({
      success: false,
      message: 'Failed to delete classroom',
      error: error.message
    });
  }
};

// Get classroom analytics
export const getClassroomAnalytics = async (req, res) => {
  try {
    const { classroomId } = req.params;
    const teacherId = req.user.id;

    const classroom = await Class.findOne({ _id: classroomId, teacher: teacherId })
      .populate('students.student', 'name email studentId rollNo isDisabled');

    if (!classroom) {
      return res.status(404).json({
        success: false,
        message: 'Classroom not found'
      });
    }

    // Get quizzes for this classroom
    const quizzes = await Quiz.find({ classroom: classroomId });
    
    // Get assignments for this classroom
    const assignments = await QuizAssignment.find({ classroom: classroomId })
      .populate('quiz', 'title description');

    const regularStudents = classroom.getRegularStudents();
    const disabledStudents = classroom.getDisabledStudents();

    const analytics = {
      classroom: {
        id: classroom._id,
        name: classroom.name,
        subject: classroom.subject,
        classType: classroom.classType,
        totalStudents: classroom.studentCount,
        regularStudents: regularStudents.length,
        disabledStudents: disabledStudents.length
      },
      quizzes: {
        total: quizzes.length,
        published: quizzes.filter(q => q.status === 'published').length,
        draft: quizzes.filter(q => q.status === 'draft').length,
        archived: quizzes.filter(q => q.status === 'archived').length
      },
      assignments: {
        total: assignments.length,
        active: assignments.filter(a => a.status === 'active').length,
        paused: assignments.filter(a => a.status === 'paused').length,
        completed: assignments.filter(a => a.status === 'completed').length
      },
      studentPerformance: {
        averageScore: 0,
        completionRate: 0,
        topPerformers: [],
        strugglingStudents: []
      }
    };

    // Calculate performance metrics if there are submissions
    if (quizzes.length > 0) {
      const allSubmissions = quizzes.flatMap(q => q.submissions);
      if (allSubmissions.length > 0) {
        const totalScore = allSubmissions.reduce((sum, s) => sum + s.percentage, 0);
        analytics.studentPerformance.averageScore = Math.round(totalScore / allSubmissions.length);
        analytics.studentPerformance.completionRate = Math.round((allSubmissions.length / (classroom.studentCount * quizzes.length)) * 100);
      }
    }

    logClassroom('GET_ANALYTICS', classroom._id, teacherId);

    res.status(200).json({
      success: true,
      data: analytics
    });
  } catch (error) {
    logError('Failed to get classroom analytics', error, { userId: req.user.id });
    res.status(500).json({
      success: false,
      message: 'Failed to get classroom analytics',
      error: error.message
    });
  }
};

export const getClassroomStats = async (req, res) => {
  try {
    const teacherId = req.user.id;

    // Get all classrooms for the teacher
    const classrooms = await Class.find({ teacher: teacherId });
    
    // Get total students across all classrooms
    const totalStudents = classrooms.reduce((total, classroom) => {
      return total + (classroom.students?.length || 0);
    }, 0);

    // Get total classrooms
    const totalClassrooms = classrooms.length;

    // Get active quizzes (you might want to implement this based on your quiz model)
    const activeQuizzes = 0; // Placeholder - implement based on your quiz model

    // Get completed quizzes (you might want to implement this based on your quiz model)
    const completedQuizzes = 0; // Placeholder - implement based on your quiz model

    // Calculate average score (you might want to implement this based on your quiz submissions)
    const averageScore = 0; // Placeholder - implement based on your quiz submissions

    const stats = {
      totalStudents,
      totalClassrooms,
      activeQuizzes,
      completedQuizzes,
      averageScore
    };

    res.status(200).json({
      success: true,
      message: 'Dashboard stats retrieved successfully',
      data: stats
    });
  } catch (error) {
    logError('Failed to get classroom stats', error, { userId: req.user.id });
    res.status(500).json({
      success: false,
      message: 'Failed to get classroom stats',
      error: error.message
    });
  }
};
