import { logApi, logError, logInfo } from '../config/logger.js'
import Quiz from '../models/Quiz.js'
import Class from '../models/Class.js'
import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import pdfParse from 'pdf-parse';
import geminiAPILogger from '../utils/geminiLogger.js';
import quizOperationsLogger from '../utils/quizLogger.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Enhanced Gemini API configuration - Updated to use latest models
const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';
const GEMINI_VISION_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';

// Helper function to call Gemini API with comprehensive logging
const callGeminiAPI = async (prompt, isVision = false, requestContext = {}) => {
  const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
  if (!GEMINI_API_KEY) {
    throw new Error('Gemini API key not configured');
  }

  // Log request start
  const requestId = geminiAPILogger.logRequest({
    prompt,
    userId: requestContext.userId,
    classroomId: requestContext.classroomId,
    type: requestContext.type || 'quiz-generation'
  });

  const startTime = Date.now();
  const apiUrl = isVision ? GEMINI_VISION_API_URL : GEMINI_API_URL;

  const requestBody = {
    contents: [{
      parts: [{ text: prompt }]
    }],
    generationConfig: {
      temperature: 0.7,
      topK: 40,
      topP: 0.95,
      maxOutputTokens: 8192,
    },
    safetySettings: [
      {
        category: "HARM_CATEGORY_HARASSMENT",
        threshold: "BLOCK_MEDIUM_AND_ABOVE"
      },
      {
        category: "HARM_CATEGORY_HATE_SPEECH",
        threshold: "BLOCK_MEDIUM_AND_ABOVE"
      },
      {
        category: "HARM_CATEGORY_SEXUALLY_EXPLICIT",
        threshold: "BLOCK_MEDIUM_AND_ABOVE"
      },
      {
        category: "HARM_CATEGORY_DANGEROUS_CONTENT",
        threshold: "BLOCK_MEDIUM_AND_ABOVE"
      }
    ]
  };

  try {
    const response = await axios.post(
      `${apiUrl}?key=${GEMINI_API_KEY}`,
      requestBody,
      {
        headers: { 'Content-Type': 'application/json' },
        timeout: 30000 // 30 second timeout
      }
    );

    const responseTime = Date.now() - startTime;

    // Log successful response
    geminiAPILogger.logSuccess(requestId, response.data, responseTime);

    return response.data;

  } catch (error) {
    const responseTime = Date.now() - startTime;

    // Handle specific error types
    if (error.response?.status === 429) {
      const retryAfter = error.response.headers['retry-after'] || 60;
      geminiAPILogger.logRateLimit(requestId, retryAfter);
    } else if (error.response?.status === 403) {
      geminiAPILogger.logQuotaExceeded(requestId, error.response.data);
    } else {
      geminiAPILogger.logError(requestId, error, responseTime);
    }

    throw error;
  }
};

// Helper function to parse JSON from Gemini response with logging
const parseGeminiResponse = (response, requestId = null) => {
  const candidates = response?.candidates || [];
  let rawText = '';

  for (const candidate of candidates) {
    let text = candidate.content?.parts?.[0]?.text || '';
    rawText = text; // Store for logging

    // Log the raw response for debugging
    console.log('Raw Gemini Response:', text.substring(0, 500) + (text.length > 500 ? '...' : ''));

    // Clean the response text more thoroughly
    text = text
      .replace(/```json\s*/gi, '')
      .replace(/```\s*/g, '')
      .replace(/^[^{]*/, '') // Remove any text before the first {
      .replace(/[^}]*$/, '') // Remove any text after the last }
      .trim();

    // Try to parse as JSON
    try {
      const parsed = JSON.parse(text);
      return parsed;
    } catch (error) {
      // Try to extract JSON from text using more comprehensive regex
      const jsonMatches = [
        text.match(/\{[\s\S]*\}/), // Original match
        text.match(/\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}/g), // Nested objects
        text.match(/\{[\s\S]*?"questions"[\s\S]*?\}/), // Look for questions key
      ];

      for (const jsonMatch of jsonMatches) {
        if (jsonMatch) {
          try {
            const jsonText = Array.isArray(jsonMatch) ? jsonMatch[0] : jsonMatch;
            const parsed = JSON.parse(jsonText);
            return parsed;
          } catch (innerError) {
            continue;
          }
        }
      }
    }
  }

  // Log parsing error with more details
  if (requestId) {
    geminiAPILogger.logParsingError(requestId, rawText, new Error('No valid JSON found in response'));
  }

  console.error('Failed to parse Gemini response. Raw text:', rawText);
  throw new Error(`No valid JSON found in Gemini response. Raw response: ${rawText.substring(0, 200)}...`);
};

// Generate quiz questions using enhanced Gemini integration
export const generateQuizQuestions = async (req, res) => {
  try {
    logApi('POST /api/ai/generate-questions', req.body);

    const {
      topic,
      subject,
      difficulty = 'medium',
      questionCount = 10,
      questionType = 'multiple-choice',
      focusAreas = [],
      learningObjectives = '',
      bloomsLevel = 'mixed',
      contextType = 'academic'
    } = req.body;

    // Validation
    if (!topic || !subject) {
      return res.status(400).json({
        success: false,
        message: 'Topic and subject are required'
      });
    }

    if (questionCount < 1 || questionCount > 50) {
      return res.status(400).json({
        success: false,
        message: 'Question count must be between 1 and 50'
      });
    }

    // Build comprehensive prompt
    const focusAreasText = focusAreas.length > 0 ? `Focus Areas: ${focusAreas.join(', ')}` : '';

    const prompt = `Create ${questionCount} high-quality educational ${questionType} questions about "${topic}" in the subject of ${subject}.

SPECIFICATIONS:
- Difficulty Level: ${difficulty}
- Question Type: ${questionType}
- ${focusAreasText}
- Learning Objectives: ${learningObjectives || 'General understanding and application'}
- Bloom's Taxonomy Level: ${bloomsLevel}
- Context: ${contextType}

REQUIREMENTS:
1. Each question must be educationally sound and appropriate for ${difficulty} difficulty
2. For multiple choice questions, provide exactly 4 options (A, B, C, D)
3. Include detailed explanations for correct answers
4. Ensure questions test various cognitive levels
5. Make questions engaging and relevant to real-world applications
6. Vary question complexity within the difficulty level
7. Ensure cultural sensitivity and inclusivity

RESPONSE FORMAT:
Return ONLY a valid JSON object with this exact structure:
{
  "questions": [
    {
      "question": "Clear, well-formatted question text",
      "options": {
        "A": "First option",
        "B": "Second option",
        "C": "Third option",
        "D": "Fourth option"
      },
      "correctAnswer": "A",
      "explanation": "Detailed explanation of why this answer is correct",
      "difficulty": "${difficulty}",
      "topic": "${topic}",
      "bloomsLevel": "knowledge/comprehension/application/analysis/synthesis/evaluation",
      "points": 1
    }
  ]
}

Generate exactly ${questionCount} questions. Ensure the JSON is valid and properly formatted.`;

    const response = await callGeminiAPI(prompt);
    const parsedResponse = parseGeminiResponse(response);

    // Validate response structure
    if (!parsedResponse.questions || !Array.isArray(parsedResponse.questions)) {
      throw new Error('Invalid response structure from Gemini API');
    }

    logInfo(`Successfully generated ${parsedResponse.questions.length} questions for topic: ${topic}`);

    res.json({
      success: true,
      data: {
        questions: parsedResponse.questions,
        metadata: {
          topic,
          subject,
          difficulty,
          questionType,
          generatedAt: new Date().toISOString(),
          questionCount: parsedResponse.questions.length
        }
      }
    });

  } catch (error) {
    logError('Quiz question generation failed', error);

    // Return fallback questions
    const fallbackQuestions = generateFallbackQuestions(req.body);

    res.json({
      success: true,
      data: {
        questions: fallbackQuestions,
        metadata: {
          topic: req.body.topic || 'General Knowledge',
          subject: req.body.subject || 'General',
          difficulty: req.body.difficulty || 'medium',
          questionType: req.body.questionType || 'multiple-choice',
          generatedAt: new Date().toISOString(),
          questionCount: fallbackQuestions.length,
          fallback: true
        }
      },
      message: 'Using fallback questions due to AI service unavailability'
    });
  }
};

// Create a complete quiz with AI-generated questions
export const createAIQuiz = async (req, res) => {
  try {
    logApi('POST /api/ai/create-quiz', req.body);

    const {
      title,
      description,
      classroomId,
      subject,
      topic,
      difficulty,
      questionCount,
      questionTypes,
      settings
    } = req.body;

    // Validation
    if (!title || !classroomId || !topic) {
      return res.status(400).json({
        success: false,
        message: 'Title, classroom ID, and topic are required'
      });
    }

    // Generate questions first
    const questionsResponse = await generateQuizQuestions({
      body: {
        topic,
        subject,
        difficulty,
        questionCount,
        questionType: questionTypes?.[0] || 'multiple-choice'
      }
    }, { json: () => {} });

    // Create quiz in database
    const quiz = new Quiz({
      title,
      description,
      classroom: classroomId,
      subject,
      topic,
      difficulty,
      questions: questionsResponse.data.questions.map(q => ({
        question: q.question,
        type: q.type || 'multiple-choice',
        options: q.options,
        correctAnswer: q.correctAnswer,
        explanation: q.explanation,
        points: q.points || 1,
        difficulty: q.difficulty
      })),
      settings: settings || {
        timeLimit: 30,
        passingScore: 70,
        shuffleQuestions: true,
        showResults: true,
        showCorrectAnswers: true,
        allowRetake: false,
        maxAttempts: 1
      },
      aiGenerated: true,
      status: 'draft',
      createdBy: req.user.id
    });

    await quiz.save();

    logInfo(`AI quiz created successfully: ${quiz._id}`);

    res.status(201).json({
      success: true,
      data: quiz,
      message: 'AI quiz created successfully'
    });

  } catch (error) {
    logError('AI quiz creation failed', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create AI quiz',
      error: error.message
    });
  }
};

// Process syllabus and extract topics using Gemini
export const processSyllabus = async (req, res) => {
  const operationId = quizOperationsLogger.generateOperationId();

  try {
    logApi('POST /api/ai/process-syllabus', { fileInfo: req.file ? req.file.filename : 'no file' });

    let syllabusText = '';

    // Handle file upload or direct text
    if (req.file) {
      const filePath = req.file.path;
      const fileExtension = path.extname(req.file.originalname).toLowerCase();

      // Log syllabus processing start
      quizOperationsLogger.logSyllabusProcessing(operationId, {
        fileName: req.file.originalname,
        fileSize: req.file.size,
        fileType: fileExtension,
        userId: req.user?.id,
        classroomId: req.body.classroomId
      });

      // Read file content based on type
      if (fileExtension === '.txt') {
        syllabusText = fs.readFileSync(filePath, 'utf8');
      } else if (fileExtension === '.pdf') {
        try {
          // Process PDF file
          const pdfBuffer = fs.readFileSync(filePath);
          const pdfData = await pdfParse(pdfBuffer);
          syllabusText = pdfData.text;

          logInfo(`Successfully extracted text from PDF: ${pdfData.numpages} pages, ${syllabusText.length} characters`);
        } catch (pdfError) {
          logError('PDF processing failed', pdfError);
          return res.status(400).json({
            success: false,
            message: 'Failed to process PDF file. Please ensure it contains readable text or try uploading a text file instead.'
          });
        }
      } else if (fileExtension === '.doc' || fileExtension === '.docx') {
        return res.status(400).json({
          success: false,
          message: 'Word document processing not yet implemented. Please convert to PDF or text file, or paste the content directly.'
        });
      } else {
        return res.status(400).json({
          success: false,
          message: 'Unsupported file type. Please upload a .txt or .pdf file, or paste the content directly.'
        });
      }

      // Clean up uploaded file
      fs.unlinkSync(filePath);
    } else if (req.body.syllabusText) {
      syllabusText = req.body.syllabusText;

      // Log syllabus processing start for text input
      quizOperationsLogger.logSyllabusProcessing(operationId, {
        fileName: 'text-input',
        fileSize: syllabusText.length,
        fileType: 'text',
        textLength: syllabusText.length,
        userId: req.user?.id,
        classroomId: req.body.classroomId
      });
    } else {
      return res.status(400).json({
        success: false,
        message: 'Please provide syllabus content either as a file upload or text input'
      });
    }

    if (!syllabusText.trim()) {
      return res.status(400).json({
        success: false,
        message: 'Syllabus content is empty'
      });
    }

    // Create prompt for syllabus analysis
    const prompt = `Analyze the following syllabus content and extract key topics, learning objectives, and important concepts that can be used for quiz generation.

SYLLABUS CONTENT:
${syllabusText}

Please provide a comprehensive analysis in the following JSON format:
{
  "summary": "Brief summary of the course/syllabus",
  "subject": "Main subject area",
  "topics": [
    {
      "title": "Topic title",
      "description": "Detailed description of the topic",
      "subtopics": ["subtopic1", "subtopic2", "subtopic3"],
      "difficulty": "easy/medium/hard",
      "estimatedQuestions": 5,
      "learningObjectives": ["objective1", "objective2"],
      "keyTerms": ["term1", "term2", "term3"]
    }
  ],
  "overallDifficulty": "easy/medium/hard",
  "recommendedQuizTypes": ["multiple_choice", "true_false", "short_answer"],
  "totalEstimatedQuestions": 25,
  "prerequisites": ["prerequisite1", "prerequisite2"],
  "assessmentSuggestions": [
    {
      "type": "quiz",
      "topics": ["topic1", "topic2"],
      "questionCount": 10,
      "difficulty": "medium"
    }
  ]
}

Focus on extracting actionable information that can be used to generate meaningful quiz questions. Ensure all topics are clearly defined and have sufficient detail for question generation.`;

    let analysis;

    try {
      const response = await callGeminiAPI(prompt);
      analysis = parseGeminiResponse(response);

      // Validate response structure
      if (!analysis.topics || !Array.isArray(analysis.topics)) {
        throw new Error('Invalid syllabus analysis structure');
      }

      logInfo(`Successfully analyzed syllabus with ${analysis.topics.length} topics`);

      res.json({
        success: true,
        data: analysis,
        message: 'Syllabus analyzed successfully'
      });

    } catch (geminiError) {
      // If Gemini API fails, provide a smart fallback based on content analysis
      logError('Gemini API failed, using fallback analysis', geminiError);

      analysis = generateFallbackSyllabusAnalysis(syllabusText);

      res.json({
        success: true,
        data: analysis,
        message: 'Syllabus analyzed successfully (using fallback analysis due to API limitations)',
        fallback: true
      });
    }

  } catch (error) {
    logError('Syllabus processing failed', error);

    // Return fallback analysis
    const fallbackAnalysis = {
      summary: "Unable to analyze syllabus automatically. Please review the content manually.",
      subject: "General",
      topics: [
        {
          title: "General Topic 1",
          description: "Please review and edit this topic based on your syllabus content",
          subtopics: ["Subtopic A", "Subtopic B", "Subtopic C"],
          difficulty: "medium",
          estimatedQuestions: 5,
          learningObjectives: ["Understanding basic concepts", "Application of knowledge"],
          keyTerms: ["Term 1", "Term 2", "Term 3"]
        }
      ],
      overallDifficulty: "medium",
      recommendedQuizTypes: ["multiple-choice", "true-false"],
      totalEstimatedQuestions: 10,
      prerequisites: [],
      assessmentSuggestions: []
    };

    res.json({
      success: true,
      data: fallbackAnalysis,
      message: 'Using fallback analysis due to AI service unavailability',
      fallback: true
    });
  }
};

// Generate quiz from selected syllabus topics
export const generateQuizFromTopics = async (req, res) => {
  try {
    logApi('POST /api/ai/generate-from-topics', req.body);

    const {
      selectedTopics,
      questionCount = 10,
      difficulty = 'medium',
      questionType = 'multiple-choice',
      subject = 'General',
      language = 'english'
    } = req.body;

    if (!selectedTopics || !Array.isArray(selectedTopics) || selectedTopics.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Please select at least one topic'
      });
    }

    // Build comprehensive prompt from selected topics
    const topicsText = selectedTopics.map(topic =>
      `Topic: ${topic.title}
Description: ${topic.description}
Subtopics: ${topic.subtopics?.join(', ') || 'N/A'}
Key Terms: ${topic.keyTerms?.join(', ') || 'N/A'}
Learning Objectives: ${topic.learningObjectives?.join(', ') || 'N/A'}`
    ).join('\n\n');

    const languageInstruction = language === 'tamil'
      ? 'Generate all questions, options, and explanations in Tamil language. Use proper Tamil script and terminology.'
      : 'Generate all questions, options, and explanations in English language.';

    const prompt = `Create ${questionCount} high-quality ${questionType} questions based on the following syllabus topics:

${topicsText}

SPECIFICATIONS:
- Difficulty Level: ${difficulty}
- Question Type: ${questionType}
- Subject: ${subject}
- Language: ${language === 'tamil' ? 'Tamil' : 'English'}
- Distribute questions evenly across the selected topics
- Ensure questions align with the learning objectives mentioned

LANGUAGE REQUIREMENT:
${languageInstruction}

REQUIREMENTS:
1. Each question must be educationally sound and appropriate for ${difficulty} difficulty
2. For multiple choice questions, provide exactly 4 options (A, B, C, D)
3. Include detailed explanations for correct answers
4. Reference specific topics and subtopics in questions
5. Use key terms appropriately in context
6. Ensure questions test various cognitive levels
7. Make questions practical and application-oriented where possible
8. Maintain consistent language throughout (${language === 'tamil' ? 'Tamil' : 'English'})
9. Use culturally appropriate examples and context

RESPONSE FORMAT:
Return ONLY a valid JSON object with this exact structure:
{
  "quizTitle": "Comprehensive Quiz on Selected Topics",
  "description": "Quiz covering the selected syllabus topics",
  "questions": [
    {
      "question": "Clear, well-formatted question text",
      "options": {
        "A": "First option",
        "B": "Second option",
        "C": "Third option",
        "D": "Fourth option"
      },
      "correctAnswer": "A",
      "explanation": "Detailed explanation of why this answer is correct",
      "difficulty": "${difficulty}",
      "topic": "Specific topic this question relates to",
      "subtopic": "Specific subtopic if applicable",
      "bloomsLevel": "knowledge/comprehension/application/analysis/synthesis/evaluation",
      "points": 1
    }
  ]
}

Generate exactly ${questionCount} questions. Ensure the JSON is valid and properly formatted.`;

    const response = await callGeminiAPI(prompt);
    const quiz = parseGeminiResponse(response);

    // Validate response structure
    if (!quiz.questions || !Array.isArray(quiz.questions)) {
      throw new Error('Invalid quiz structure from Gemini API');
    }

    logInfo(`Successfully generated quiz from ${selectedTopics.length} topics with ${quiz.questions.length} questions`);

    res.json({
      success: true,
      data: quiz,
      message: 'Quiz generated successfully from selected topics'
    });

  } catch (error) {
    logError('Topic-based quiz generation failed', error);

    // Return fallback quiz
    const fallbackQuiz = {
      quizTitle: "Sample Quiz from Topics",
      description: "Fallback quiz due to AI service unavailability",
      questions: generateFallbackQuestions({
        questionCount: req.body.questionCount || 5,
        difficulty: req.body.difficulty || 'medium',
        topic: 'Selected Topics'
      })
    };

    res.json({
      success: true,
      data: fallbackQuiz,
      message: 'Using fallback quiz due to AI service unavailability',
      fallback: true
    });
  }
};

// Enhanced Gemini API endpoint with comprehensive logging
export const generateQuizWithGemini = async (req, res) => {
  const operationId = quizOperationsLogger.logQuizCreationStart({
    title: 'AI Generated Quiz',
    type: 'ai-generated',
    userId: req.user?.id,
    classroomId: req.body.classroomId,
    ...req.body
  });

  try {
    logApi('POST /api/ai/gemini', req.body);
    const { prompt } = req.body;

    if (!prompt) {
      quizOperationsLogger.logQuizCreationError(operationId, new Error('Prompt is required'), req.body);
      return res.status(400).json({
        success: false,
        message: 'Prompt is required.'
      });
    }

    // Log AI quiz generation process
    quizOperationsLogger.logAIQuizGeneration(operationId, {
      topic: req.body.topic || 'Unknown',
      subject: req.body.subject || 'General',
      difficulty: req.body.difficulty || 'medium',
      numQuestions: req.body.numQuestions || 5,
      questionType: req.body.questionType || 'multiple_choice',
      userId: req.user?.id,
      classroomId: req.body.classroomId
    });

    const startTime = Date.now();
    const response = await callGeminiAPI(prompt, false, {
      userId: req.user?.id,
      classroomId: req.body.classroomId,
      type: 'quiz-generation'
    });

    const result = parseGeminiResponse(response);
    const creationTime = Date.now() - startTime;

    // Log successful quiz creation
    quizOperationsLogger.logQuizCreationSuccess(operationId, {
      ...result,
      type: 'ai-generated',
      userId: req.user?.id,
      classroomId: req.body.classroomId
    }, creationTime);

    logInfo('Gemini API call successful');
    return res.status(200).json(result);

  } catch (error) {
    logError('Gemini API call failed', error);

    // Log quiz creation error
    quizOperationsLogger.logQuizCreationError(operationId, error, {
      type: 'ai-generated',
      userId: req.user?.id,
      classroomId: req.body.classroomId,
      ...req.body
    });

    // Check if it's an API key issue
    if (error.message.includes('API key not configured')) {
      return res.status(500).json({
        success: false,
        message: 'Gemini API key is not configured. Please set GEMINI_API_KEY in environment variables.',
        error: 'API_KEY_MISSING'
      });
    }

    // Check if it's an API error
    if (error.response?.status === 400) {
      return res.status(400).json({
        success: false,
        message: 'Invalid API request. Please check your Gemini API key.',
        error: 'INVALID_API_KEY'
      });
    }

    if (error.response?.status === 403) {
      return res.status(403).json({
        success: false,
        message: 'Gemini API access denied. Please check your API key permissions.',
        error: 'API_ACCESS_DENIED'
      });
    }

    // For other errors, provide more specific feedback
    return res.status(500).json({
      success: false,
      message: `Gemini API error: ${error.message}`,
      error: 'GEMINI_API_ERROR',
      details: error.response?.data || error.message
    });
  }
};

// Helper function to generate fallback syllabus analysis
function generateFallbackSyllabusAnalysis(syllabusText) {
  const text = syllabusText.toLowerCase();
  const lines = syllabusText.split('\n').filter(line => line.trim().length > 0);

  // Extract potential topics from headings and important lines
  const topics = [];
  const commonTopicKeywords = [
    'introduction', 'overview', 'fundamentals', 'basics', 'advanced',
    'chapter', 'unit', 'module', 'section', 'part', 'lesson',
    'theory', 'practical', 'application', 'implementation',
    'concepts', 'principles', 'methods', 'techniques', 'strategies'
  ];

  // Look for numbered sections, bullet points, or headings
  const topicPatterns = [
    /^\d+\.\s*(.+)$/,           // 1. Topic name
    /^[A-Z][A-Z\s]+$/,          // ALL CAPS headings
    /^[A-Z][a-z\s]+:$/,         // Title Case with colon
    /^\*\s*(.+)$/,              // * Bullet points
    /^-\s*(.+)$/,               // - Bullet points
    /^•\s*(.+)$/,               // • Bullet points
  ];

  lines.forEach((line, index) => {
    const trimmedLine = line.trim();

    // Skip very short lines
    if (trimmedLine.length < 5) return;

    // Check if line matches topic patterns
    for (const pattern of topicPatterns) {
      const match = trimmedLine.match(pattern);
      if (match) {
        const topicTitle = match[1] || match[0];
        if (topicTitle.length > 3 && topicTitle.length < 100) {
          topics.push({
            title: topicTitle.replace(/[^\w\s-]/g, '').trim(),
            description: `Learn about ${topicTitle.toLowerCase()}`,
            subtopics: extractSubtopics(lines, index),
            difficulty: 'medium',
            estimatedQuestions: Math.floor(Math.random() * 5) + 3,
            learningObjectives: [`Understand ${topicTitle.toLowerCase()}`, `Apply knowledge of ${topicTitle.toLowerCase()}`],
            keyTerms: extractKeyTerms(topicTitle)
          });
        }
        break;
      }
    }
  });

  // If no topics found, create generic ones based on content
  if (topics.length === 0) {
    const words = syllabusText.split(/\s+/).filter(word => word.length > 3);
    const wordFreq = {};
    words.forEach(word => {
      const cleanWord = word.toLowerCase().replace(/[^\w]/g, '');
      wordFreq[cleanWord] = (wordFreq[cleanWord] || 0) + 1;
    });

    const importantWords = Object.entries(wordFreq)
      .filter(([word, freq]) => freq > 2 && word.length > 4)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([word]) => word);

    importantWords.forEach((word, index) => {
      topics.push({
        title: word.charAt(0).toUpperCase() + word.slice(1),
        description: `Study of ${word} and related concepts`,
        subtopics: [`Basic ${word}`, `Advanced ${word}`, `Applications of ${word}`],
        difficulty: 'medium',
        estimatedQuestions: 5,
        learningObjectives: [`Understand ${word}`, `Apply ${word} concepts`],
        keyTerms: [word, `${word} theory`, `${word} practice`]
      });
    });
  }

  // Ensure we have at least one topic
  if (topics.length === 0) {
    topics.push({
      title: 'Course Content',
      description: 'General course content and concepts',
      subtopics: ['Basic Concepts', 'Key Principles', 'Practical Applications'],
      difficulty: 'medium',
      estimatedQuestions: 10,
      learningObjectives: ['Understand course concepts', 'Apply learned knowledge'],
      keyTerms: ['concepts', 'principles', 'applications']
    });
  }

  // Determine subject from content
  const subject = detectSubject(syllabusText);

  return {
    summary: `Course syllabus covering ${topics.length} main topics`,
    subject: subject,
    topics: topics.slice(0, 10), // Limit to 10 topics
    overallDifficulty: 'medium',
    recommendedQuizTypes: ['multiple-choice', 'true-false'],
    totalEstimatedQuestions: topics.reduce((sum, topic) => sum + topic.estimatedQuestions, 0),
    prerequisites: [],
    assessmentSuggestions: ['Regular quizzes', 'Practical exercises', 'Final assessment']
  };
}

// Helper function to extract subtopics
function extractSubtopics(lines, startIndex) {
  const subtopics = [];
  const maxLookAhead = 5;

  for (let i = startIndex + 1; i < Math.min(startIndex + maxLookAhead, lines.length); i++) {
    const line = lines[i].trim();
    if (line.match(/^\s*[-•*]\s*(.+)$/) && line.length < 80) {
      subtopics.push(line.replace(/^\s*[-•*]\s*/, '').trim());
    }
  }

  return subtopics.length > 0 ? subtopics : ['Basic concepts', 'Advanced topics', 'Practical applications'];
}

// Helper function to extract key terms
function extractKeyTerms(title) {
  const words = title.split(/\s+/).filter(word => word.length > 3);
  return words.slice(0, 3).map(word => word.toLowerCase());
}

// Helper function to detect subject
function detectSubject(text) {
  const subjectKeywords = {
    'Computer Science': ['programming', 'algorithm', 'software', 'computer', 'coding', 'development'],
    'Mathematics': ['equation', 'formula', 'theorem', 'calculus', 'algebra', 'geometry'],
    'Physics': ['force', 'energy', 'motion', 'quantum', 'mechanics', 'thermodynamics'],
    'Chemistry': ['molecule', 'reaction', 'compound', 'element', 'chemical', 'organic'],
    'Biology': ['cell', 'organism', 'genetics', 'evolution', 'anatomy', 'physiology'],
    'Business': ['management', 'marketing', 'finance', 'strategy', 'economics', 'business'],
    'Literature': ['poetry', 'novel', 'author', 'literary', 'writing', 'literature'],
    'History': ['historical', 'century', 'war', 'civilization', 'culture', 'ancient']
  };

  const lowerText = text.toLowerCase();
  let maxScore = 0;
  let detectedSubject = 'General Studies';

  Object.entries(subjectKeywords).forEach(([subject, keywords]) => {
    const score = keywords.reduce((sum, keyword) => {
      const regex = new RegExp(keyword, 'gi');
      const matches = lowerText.match(regex);
      return sum + (matches ? matches.length : 0);
    }, 0);

    if (score > maxScore) {
      maxScore = score;
      detectedSubject = subject;
    }
  });

  return detectedSubject;
}

// Helper function to generate fallback questions
function generateFallbackQuestions({ questionCount = 5, difficulty = 'medium', topic = 'General Knowledge' }) {
  const fallbackQuestions = [
    {
      question: 'What is the capital of France?',
      options: { A: 'Paris', B: 'London', C: 'Berlin', D: 'Madrid' },
      correctAnswer: 'A',
      explanation: 'Paris is the capital and largest city of France.',
      difficulty,
      topic,
      bloomsLevel: 'knowledge',
      points: 1
    },
    {
      question: 'Which planet is known as the Red Planet?',
      options: { A: 'Earth', B: 'Mars', C: 'Jupiter', D: 'Venus' },
      correctAnswer: 'B',
      explanation: 'Mars is called the Red Planet due to its reddish appearance caused by iron oxide on its surface.',
      difficulty,
      topic,
      bloomsLevel: 'knowledge',
      points: 1
    },
    {
      question: 'Who wrote "Romeo and Juliet"?',
      options: { A: 'Charles Dickens', B: 'Jane Austen', C: 'William Shakespeare', D: 'Mark Twain' },
      correctAnswer: 'C',
      explanation: 'William Shakespeare wrote the famous tragedy "Romeo and Juliet" in the early part of his career.',
      difficulty,
      topic,
      bloomsLevel: 'knowledge',
      points: 1
    },
    {
      question: 'What is 2 + 2?',
      options: { A: '3', B: '4', C: '5', D: '6' },
      correctAnswer: 'B',
      explanation: 'Basic addition: 2 + 2 equals 4.',
      difficulty,
      topic,
      bloomsLevel: 'knowledge',
      points: 1
    },
    {
      question: 'Which gas do plants absorb from the atmosphere during photosynthesis?',
      options: { A: 'Oxygen', B: 'Nitrogen', C: 'Carbon Dioxide', D: 'Hydrogen' },
      correctAnswer: 'C',
      explanation: 'Plants absorb carbon dioxide from the atmosphere and convert it into glucose during photosynthesis.',
      difficulty,
      topic,
      bloomsLevel: 'comprehension',
      points: 1
    }
  ];

  return fallbackQuestions.slice(0, questionCount);
}

// Test endpoint to verify Gemini API is working
export const testGeminiAPI = async (req, res) => {
  try {
    logApi('GET /api/ai/test-gemini');

    const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
    if (!GEMINI_API_KEY) {
      return res.status(500).json({
        success: false,
        message: 'Gemini API key not configured',
        configured: false
      });
    }

    // Simple test prompt
    const testPrompt = 'Generate a simple math question about addition. Return only: "What is 2 + 2?"';

    const response = await callGeminiAPI(testPrompt);
    const result = parseGeminiResponse(response);

    return res.status(200).json({
      success: true,
      message: 'Gemini API is working correctly',
      configured: true,
      testResponse: result
    });

  } catch (error) {
    logError('Gemini API test failed', error);

    return res.status(500).json({
      success: false,
      message: `Gemini API test failed: ${error.message}`,
      configured: true,
      error: error.response?.data || error.message
    });
  }
};
