import mongoose from 'mongoose'
import { logInfo, logError } from '../config/logger.js'

const classroomCollectionSchema = new mongoose.Schema({
  classroomId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Class',
    required: true,
    unique: true
  },
  collectionName: {
    type: String,
    required: true,
    unique: true
  },
  teacher: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  students: [{
    student: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    isDisabled: {
      type: Boolean,
      default: false
    },
    joinedAt: {
      type: Date,
      default: Date.now
    },
    lastAccess: {
      type: Date,
      default: Date.now
    }
  }],
  quizzes: [{
    quizId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Quiz'
    },
    assignedAt: {
      type: Date,
      default: Date.now
    },
    dueDate: Date,
    isActive: {
      type: Boolean,
      default: true
    },
    accessibleToDisabled: {
      type: Boolean,
      default: true
    }
  }],
  settings: {
    allowVoiceControl: {
      type: Boolean,
      default: true
    },
    autoReadQuestions: {
      type: Boolean,
      default: true
    },
    voiceCommands: {
      type: [String],
      default: ['next', 'previous', 'skip', 'repeat', 'answer a', 'answer b', 'answer c', 'answer d']
    }
  },
  isActive: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true
})

// Indexes
classroomCollectionSchema.index({ classroomId: 1 })
classroomCollectionSchema.index({ collectionName: 1 })
classroomCollectionSchema.index({ teacher: 1 })

// Method to create dynamic collection for classroom
classroomCollectionSchema.methods.createDynamicCollection = async function() {
  try {
    const db = mongoose.connection.db
    
    // Create the collection with specific options
    await db.createCollection(this.collectionName, {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: ["studentId", "quizId", "answers", "startedAt"],
          properties: {
            studentId: {
              bsonType: "objectId",
              description: "Student ID - required"
            },
            quizId: {
              bsonType: "objectId",
              description: "Quiz ID - required"
            },
            answers: {
              bsonType: "array",
              description: "Student answers - required"
            },
            startedAt: {
              bsonType: "date",
              description: "Quiz start time - required"
            },
            completedAt: {
              bsonType: "date",
              description: "Quiz completion time"
            },
            timeSpent: {
              bsonType: "int",
              description: "Time spent in minutes"
            },
            score: {
              bsonType: "int",
              description: "Quiz score"
            },
            percentage: {
              bsonType: "double",
              description: "Quiz percentage"
            },
            isDisabled: {
              bsonType: "bool",
              description: "Whether student is disabled"
            },
            voiceCommands: {
              bsonType: "array",
              description: "Voice commands used during quiz"
            },
            accessibilityLog: {
              bsonType: "array",
              description: "Accessibility interaction log"
            }
          }
        }
      }
    })

    // Create indexes for better performance
    await db.collection(this.collectionName).createIndex({ studentId: 1, quizId: 1 })
    await db.collection(this.collectionName).createIndex({ startedAt: 1 })
    await db.collection(this.collectionName).createIndex({ isDisabled: 1 })

    logInfo('Dynamic classroom collection created', {
      collectionName: this.collectionName,
      classroomId: this.classroomId
    })

    return true
  } catch (error) {
    logError('Failed to create dynamic collection', {
      error: error.message,
      collectionName: this.collectionName,
      classroomId: this.classroomId
    })
    throw error
  }
}

// Method to add student to classroom collection
classroomCollectionSchema.methods.addStudent = async function(studentId, isDisabled = false) {
  try {
    // Check if student already exists
    const existingStudent = this.students.find(s => s.student.toString() === studentId.toString())
    if (existingStudent) {
      throw new Error('Student already exists in classroom')
    }

    this.students.push({
      student: studentId,
      isDisabled,
      joinedAt: new Date(),
      lastAccess: new Date()
    })

    await this.save()

    logInfo('Student added to classroom collection', {
      studentId,
      classroomId: this.classroomId,
      isDisabled
    })

    return true
  } catch (error) {
    logError('Failed to add student to classroom collection', {
      error: error.message,
      studentId,
      classroomId: this.classroomId
    })
    throw error
  }
}

// Method to assign quiz to classroom
classroomCollectionSchema.methods.assignQuiz = async function(quizId, dueDate = null, accessibleToDisabled = true) {
  try {
    // Check if quiz already assigned
    const existingQuiz = this.quizzes.find(q => q.quizId.toString() === quizId.toString())
    if (existingQuiz) {
      throw new Error('Quiz already assigned to classroom')
    }

    this.quizzes.push({
      quizId,
      assignedAt: new Date(),
      dueDate,
      isActive: true,
      accessibleToDisabled
    })

    await this.save()

    logInfo('Quiz assigned to classroom collection', {
      quizId,
      classroomId: this.classroomId,
      accessibleToDisabled
    })

    return true
  } catch (error) {
    logError('Failed to assign quiz to classroom collection', {
      error: error.message,
      quizId,
      classroomId: this.classroomId
    })
    throw error
  }
}

// Method to get student submissions from dynamic collection
classroomCollectionSchema.methods.getStudentSubmissions = async function(studentId, quizId = null) {
  try {
    const db = mongoose.connection.db
    const collection = db.collection(this.collectionName)
    
    let query = { studentId: new mongoose.Types.ObjectId(studentId) }
    if (quizId) {
      query.quizId = new mongoose.Types.ObjectId(quizId)
    }

    const submissions = await collection.find(query).toArray()
    
    logInfo('Retrieved student submissions from dynamic collection', {
      studentId,
      quizId,
      submissionCount: submissions.length,
      collectionName: this.collectionName
    })

    return submissions
  } catch (error) {
    logError('Failed to get student submissions', {
      error: error.message,
      studentId,
      quizId,
      collectionName: this.collectionName
    })
    throw error
  }
}

// Method to save student submission to dynamic collection
classroomCollectionSchema.methods.saveStudentSubmission = async function(submissionData) {
  try {
    const db = mongoose.connection.db
    const collection = db.collection(this.collectionName)
    
    const submission = {
      ...submissionData,
      createdAt: new Date()
    }

    const result = await collection.insertOne(submission)
    
    logInfo('Student submission saved to dynamic collection', {
      submissionId: result.insertedId,
      studentId: submissionData.studentId,
      quizId: submissionData.quizId,
      collectionName: this.collectionName
    })

    return result.insertedId
  } catch (error) {
    logError('Failed to save student submission', {
      error: error.message,
      studentId: submissionData.studentId,
      quizId: submissionData.quizId,
      collectionName: this.collectionName
    })
    throw error
  }
}

// Method to get classroom statistics
classroomCollectionSchema.methods.getStatistics = async function() {
  try {
    const db = mongoose.connection.db
    const collection = db.collection(this.collectionName)
    
    const stats = {
      totalStudents: this.students.length,
      disabledStudents: this.students.filter(s => s.isDisabled).length,
      totalQuizzes: this.quizzes.length,
      activeQuizzes: this.quizzes.filter(q => q.isActive).length,
      totalSubmissions: 0,
      completedSubmissions: 0,
      averageScore: 0
    }

    // Get submission statistics
    const submissionStats = await collection.aggregate([
      {
        $group: {
          _id: null,
          totalSubmissions: { $sum: 1 },
          completedSubmissions: {
            $sum: { $cond: [{ $ne: ["$completedAt", null] }, 1, 0] }
          },
          averageScore: { $avg: "$percentage" }
        }
      }
    ]).toArray()

    if (submissionStats.length > 0) {
      stats.totalSubmissions = submissionStats[0].totalSubmissions
      stats.completedSubmissions = submissionStats[0].completedSubmissions
      stats.averageScore = Math.round(submissionStats[0].averageScore || 0)
    }

    return stats
  } catch (error) {
    logError('Failed to get classroom statistics', {
      error: error.message,
      classroomId: this.classroomId
    })
    throw error
  }
}

// Pre-save middleware to generate collection name
classroomCollectionSchema.pre('save', function(next) {
  if (this.isNew && !this.collectionName) {
    this.collectionName = `classroom_${this.classroomId}_${Date.now()}`
  }
  next()
})

export default mongoose.model('ClassroomCollection', classroomCollectionSchema) 