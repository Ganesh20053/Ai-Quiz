import mongoose from 'mongoose'

const quizAssignmentSchema = new mongoose.Schema({
  quiz: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Quiz',
    required: [true, 'Quiz is required']
  },
  classroom: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Class',
    required: [true, 'Classroom is required']
  },
  assignedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Assigner is required']
  },
  // Assignment type for different student types
  assignmentType: {
    type: String,
    enum: ['all', 'regular', 'disabled', 'custom'],
    default: 'all'
  },
  // Specific students if custom assignment
  assignedStudents: [{
    student: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    studentType: {
      type: String,
      enum: ['regular', 'disabled'],
      default: 'regular'
    },
    assignedAt: {
      type: Date,
      default: Date.now
    },
    isActive: {
      type: Boolean,
      default: true
    }
  }],
  // Assignment settings
  settings: {
    dueDate: {
      type: Date
    },
    timeLimit: {
      type: Number, // in minutes, overrides quiz time limit
      min: [1, 'Time limit must be at least 1 minute']
    },
    allowRetake: {
      type: Boolean,
      default: false
    },
    maxAttempts: {
      type: Number,
      default: 1,
      min: [1, 'Max attempts must be at least 1']
    },
    // Voice accessibility settings for disabled students
    voiceEnabled: {
      type: Boolean,
      default: false
    },
    autoReadQuestions: {
      type: Boolean,
      default: true
    },
    provideAudioFeedback: {
      type: Boolean,
      default: true
    },
    allowVoiceControl: {
      type: Boolean,
      default: false
    }
  },
  // Assignment status
  status: {
    type: String,
    enum: ['active', 'paused', 'completed', 'archived'],
    default: 'active'
  },
  // Assignment schedule
  scheduledFor: {
    type: Date
  },
  expiresAt: {
    type: Date
  },
  // Assignment instructions
  instructions: {
    type: String,
    trim: true,
    maxlength: [1000, 'Instructions cannot exceed 1000 characters']
  },
  // Assignment notifications
  notifications: {
    sendReminder: {
      type: Boolean,
      default: true
    },
    reminderDays: {
      type: Number,
      default: 1,
      min: [0, 'Reminder days cannot be negative']
    },
    sendCompletionNotification: {
      type: Boolean,
      default: true
    }
  }
}, {
  timestamps: true
})

// Indexes for better query performance
quizAssignmentSchema.index({ quiz: 1 })
quizAssignmentSchema.index({ classroom: 1 })
quizAssignmentSchema.index({ assignedBy: 1 })
quizAssignmentSchema.index({ status: 1 })
quizAssignmentSchema.index({ 'assignedStudents.student': 1 })
quizAssignmentSchema.index({ assignmentType: 1 })
quizAssignmentSchema.index({ scheduledFor: 1 })
quizAssignmentSchema.index({ expiresAt: 1 })

// Virtual for total assigned students
quizAssignmentSchema.virtual('totalAssignedStudents').get(function() {
  return this.assignedStudents.filter(student => student.isActive).length
})

// Virtual for disabled students count
quizAssignmentSchema.virtual('disabledStudentsCount').get(function() {
  return this.assignedStudents.filter(student => 
    student.isActive && student.studentType === 'disabled'
  ).length
})

// Virtual for regular students count
quizAssignmentSchema.virtual('regularStudentsCount').get(function() {
  return this.assignedStudents.filter(student => 
    student.isActive && student.studentType === 'regular'
  ).length
})

// Method to add student to assignment
quizAssignmentSchema.methods.addStudent = function(studentId, studentType = 'regular') {
  const existingStudent = this.assignedStudents.find(student => 
    student.student.toString() === studentId.toString()
  )
  
  if (existingStudent) {
    existingStudent.isActive = true
    existingStudent.studentType = studentType
  } else {
    this.assignedStudents.push({
      student: studentId,
      studentType,
      assignedAt: new Date(),
      isActive: true
    })
  }
  
  return this.save()
}

// Method to remove student from assignment
quizAssignmentSchema.methods.removeStudent = function(studentId) {
  const student = this.assignedStudents.find(student => 
    student.student.toString() === studentId.toString()
  )
  
  if (student) {
    student.isActive = false
    return this.save()
  }
  
  throw new Error('Student not found in assignment')
}

// Method to get active assigned students
quizAssignmentSchema.methods.getActiveStudents = function() {
  return this.assignedStudents.filter(student => student.isActive)
}

// Method to get disabled students
quizAssignmentSchema.methods.getDisabledStudents = function() {
  return this.assignedStudents.filter(student => 
    student.isActive && student.studentType === 'disabled'
  )
}

// Method to get regular students
quizAssignmentSchema.methods.getRegularStudents = function() {
  return this.assignedStudents.filter(student => 
    student.isActive && student.studentType === 'regular'
  )
}

// Method to check if student is assigned
quizAssignmentSchema.methods.isStudentAssigned = function(studentId) {
  return this.assignedStudents.some(student => 
    student.student.toString() === studentId.toString() && student.isActive
  )
}

// Method to check if student is disabled
quizAssignmentSchema.methods.isStudentDisabled = function(studentId) {
  const student = this.assignedStudents.find(student => 
    student.student.toString() === studentId.toString() && student.isActive
  )
  return student ? student.studentType === 'disabled' : false
}

// Method to enable voice accessibility
quizAssignmentSchema.methods.enableVoiceAccessibility = function() {
  this.settings.voiceEnabled = true
  this.settings.allowVoiceControl = true
  return this.save()
}

// Method to disable voice accessibility
quizAssignmentSchema.methods.disableVoiceAccessibility = function() {
  this.settings.voiceEnabled = false
  this.settings.allowVoiceControl = false
  return this.save()
}

// Method to pause assignment
quizAssignmentSchema.methods.pause = function() {
  this.status = 'paused'
  return this.save()
}

// Method to resume assignment
quizAssignmentSchema.methods.resume = function() {
  this.status = 'active'
  return this.save()
}

// Method to complete assignment
quizAssignmentSchema.methods.complete = function() {
  this.status = 'completed'
  return this.save()
}

// Method to archive assignment
quizAssignmentSchema.methods.archive = function() {
  this.status = 'archived'
  return this.save()
}

// Method to get assignment info without sensitive data
quizAssignmentSchema.methods.toSafeObject = function() {
  const assignmentObject = this.toObject()
  return assignmentObject
}

export default mongoose.model('QuizAssignment', quizAssignmentSchema) 