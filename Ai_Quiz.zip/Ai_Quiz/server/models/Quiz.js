// models/quizModel.js
import mongoose from 'mongoose';

const questionSchema = new mongoose.Schema({
  question: {
    type: String,
    required: true
  },
  type: {
    type: String,
    enum: ['multiple-choice', 'true-false', 'short-answer', 'essay'],
    default: 'multiple-choice'
  },
  options: [{
    text: String,
    isCorrect: {
      type: Boolean,
      default: false
    }
  }],
  correctAnswer: String,
  explanation: String,
  points: {
    type: Number,
    default: 1
  },
  difficulty: {
    type: String,
    enum: ['easy', 'medium', 'hard'],
    default: 'medium'
  }
});

const submissionSchema = new mongoose.Schema({
  student: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  answers: [{
    questionIndex: Number,
    answer: String,
    isCorrect: Boolean,
    points: Number
  }],
  totalScore: {
    type: Number,
    default: 0
  },
  percentage: {
    type: Number,
    default: 0
  },
  timeSpent: {
    type: Number, // in minutes
    default: 0
  },
  completedAt: {
    type: Date,
    default: Date.now
  },
  attemptNumber: {
    type: Number,
    default: 1
  }
});

const quizSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    trim: true
  },
  classroom: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Class',
    required: true
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  questions: [questionSchema],
  settings: {
    timeLimit: {
      type: Number,
      default: 30 // minutes
    },
    passingScore: {
      type: Number,
      default: 60 // percentage
    },
    allowRetake: {
      type: Boolean,
      default: false
    },
    maxAttempts: {
      type: Number,
      default: 1
    },
    shuffleQuestions: {
      type: Boolean,
      default: true
    },
    showResults: {
      type: Boolean,
      default: true
    },
    showCorrectAnswers: {
      type: Boolean,
      default: false
    },
    requirePassword: {
      type: Boolean,
      default: false
    },
    password: String
  },
  status: {
    type: String,
    enum: ['draft', 'published', 'archived'],
    default: 'draft'
  },
  subject: String,
  grade: String,
  isActive: {
    type: Boolean,
    default: true
  },
  submissions: [submissionSchema],
  aiGenerated: {
    type: Boolean,
    default: false
  },
  aiPrompt: String,
  scheduledFor: Date,
  expiresAt: Date,
  totalPoints: {
    type: Number,
    default: 0
  },
  questionCount: {
    type: Number,
    default: 0
  },
  averageScore: {
    type: Number,
    default: 0
  },
  completionRate: {
    type: Number,
    default: 0
  }
}, {
  timestamps: true
});

// Virtual for calculating total points
quizSchema.virtual('calculatedTotalPoints').get(function() {
  return this.questions.reduce((total, question) => total + (question.points || 1), 0);
});

// Virtual for calculating question count
quizSchema.virtual('calculatedQuestionCount').get(function() {
  return this.questions.length;
});

// Method to calculate quiz statistics
quizSchema.methods.getStatistics = function() {
  if (!this.submissions || this.submissions.length === 0) {
    return {
      totalSubmissions: 0,
      averageScore: 0,
      completionRate: 0,
      highestScore: 0,
      lowestScore: 0,
      totalPoints: this.calculatedTotalPoints,
      questionCount: this.calculatedQuestionCount
    };
  }

  const scores = this.submissions.map(sub => sub.percentage).filter(score => score !== null);
  const totalSubmissions = this.submissions.length;
  const averageScore = scores.length > 0 ? scores.reduce((a, b) => a + b, 0) / scores.length : 0;
  const highestScore = scores.length > 0 ? Math.max(...scores) : 0;
  const lowestScore = scores.length > 0 ? Math.min(...scores) : 0;

  return {
    totalSubmissions,
    averageScore: Math.round(averageScore * 100) / 100,
    completionRate: Math.round((totalSubmissions / this.submissions.length) * 100),
    highestScore: Math.round(highestScore * 100) / 100,
    lowestScore: Math.round(lowestScore * 100) / 100,
    totalPoints: this.calculatedTotalPoints,
    questionCount: this.calculatedQuestionCount
  };
};

// Pre-save middleware to update calculated fields
quizSchema.pre('save', function(next) {
  this.totalPoints = this.calculatedTotalPoints;
  this.questionCount = this.calculatedQuestionCount;
  
  // Calculate average score and completion rate
  if (this.submissions && this.submissions.length > 0) {
    const scores = this.submissions.map(sub => sub.percentage).filter(score => score !== null);
    this.averageScore = scores.length > 0 ? scores.reduce((a, b) => a + b, 0) / scores.length : 0;
    this.completionRate = (this.submissions.length / this.submissions.length) * 100;
  }
  
  next();
});

// Index for better query performance
quizSchema.index({ classroom: 1, createdBy: 1 });
quizSchema.index({ status: 1 });
quizSchema.index({ createdAt: -1 });

const Quiz = mongoose.model('Quiz', quizSchema);
export default Quiz;
