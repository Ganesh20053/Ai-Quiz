import mongoose from 'mongoose'

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Name is required'],
    trim: true,
    maxlength: [50, 'Name cannot exceed 50 characters']
  },
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
    lowercase: true,
    trim: true,
    match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Please enter a valid email']
  },
  password: {
    type: String,
    required: [true, 'Password is required'],
    minlength: [6, 'Password must be at least 6 characters']
  },
  role: {
    type: String,
    enum: ['admin', 'staff', 'student'],
    default: 'student',
    required: true
  },
  isActive: {
    type: Boolean,
    default: true
  },
  isDisabled: {
    type: Boolean,
    default: false
  },
  lastLogin: {
    type: Date,
    default: null
  },
  profilePicture: {
    type: String,
    default: null
  },
  phone: {
    type: String,
    trim: true
  },
  dateOfBirth: {
    type: Date
  },
  // For students
  studentId: {
    type: String,
    unique: true,
    sparse: true
  },
  rollNo: {
    type: String,
    unique: true,
    sparse: true
  },
  grade: {
    type: String
  },
  // For staff
  department: {
    type: String
  },
  employeeId: {
    type: String,
    unique: true,
    sparse: true
  },
  // For admin
  permissions: [{
    type: String
  }]
}, {
  timestamps: true
})

// Index for better query performance
userSchema.index({ email: 1, role: 1 })
userSchema.index({ studentId: 1 })
userSchema.index({ rollNo: 1 })
userSchema.index({ employeeId: 1 })
userSchema.index({ isDisabled: 1 })

// Virtual for full name
userSchema.virtual('fullName').get(function() {
  return this.name
})

// Method to check if user has specific role
userSchema.methods.hasRole = function(role) {
  return this.role === role
}

// Method to check if user has any of the given roles
userSchema.methods.hasAnyRole = function(roles) {
  return roles.includes(this.role)
}

// Method to check if user account is deactivated (not accessibility-related)
userSchema.methods.isAccountDeactivated = function() {
  return !this.isActive
}

// Method to check if user has accessibility needs
userSchema.methods.hasAccessibilityNeeds = function() {
  return this.isDisabled
}

// Method to get user info without sensitive data
userSchema.methods.toSafeObject = function() {
  const userObject = this.toObject()
  delete userObject.password
  return userObject
}

export default mongoose.model('User', userSchema)
