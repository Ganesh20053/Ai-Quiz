import mongoose from 'mongoose'

const classSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Class name is required'],
    trim: true,
    maxlength: [100, 'Class name cannot exceed 100 characters']
  },
  subject: {
    type: String,
    required: [true, 'Subject is required'],
    trim: true
  },
  description: {
    type: String,
    trim: true,
    maxlength: [500, 'Description cannot exceed 500 characters']
  },
  classCode: {
    type: String,
    required: [true, 'Class code is required'],
    unique: true,
    trim: true,
    uppercase: true
  },
  teacher: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Teacher is required']
  },
  // Separate collections for different student types
  students: [{
    student: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    joinedAt: {
      type: Date,
      default: Date.now
    },
    isActive: {
      type: Boolean,
      default: true
    },
    studentType: {
      type: String,
      enum: ['regular', 'disabled'],
      default: 'regular'
    }
  }],
  // Class type to determine if it's for disabled students
  classType: {
    type: String,
    enum: ['regular', 'disabled', 'mixed'],
    default: 'regular'
  },
  // Voice accessibility settings for disabled students
  voiceSettings: {
    enabled: {
      type: Boolean,
      default: false
    },
    autoReadQuestions: {
      type: Boolean,
      default: true
    },
    voiceCommands: {
      type: Boolean,
      default: true
    },
    speechRate: {
      type: Number,
      default: 0.9,
      min: 0.5,
      max: 2.0
    },
    voiceLanguage: {
      type: String,
      default: 'en-US'
    }
  },
  isActive: {
    type: Boolean,
    default: true
  },
  maxStudents: {
    type: Number,
    default: 50,
    min: [1, 'Minimum 1 student required'],
    max: [200, 'Maximum 200 students allowed']
  },
  grade: {
    type: String,
    required: [true, 'Grade is required']
  },
  academicYear: {
    type: String,
    required: [true, 'Academic year is required']
  },
  semester: {
    type: String,
    enum: ['1st', '2nd', '3rd', '4th', '5th', '6th', '7th', '8th'],
    required: [true, 'Semester is required']
  },
  schedule: {
    day: {
      type: String,
      enum: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    },
    time: {
      type: String
    },
    duration: {
      type: Number, // in minutes
      default: 60
    }
  },
  settings: {
    allowStudentInvites: {
      type: Boolean,
      default: false
    },
    requireApproval: {
      type: Boolean,
      default: true
    },
    allowAnonymousQuizzes: {
      type: Boolean,
      default: false
    },
    // Quiz settings for disabled students
    voiceQuizEnabled: {
      type: Boolean,
      default: false
    },
    autoAdvanceQuestions: {
      type: Boolean,
      default: true
    },
    provideAudioFeedback: {
      type: Boolean,
      default: true
    }
  }
}, {
  timestamps: true
})

// Index for better query performance
classSchema.index({ teacher: 1 })
classSchema.index({ classCode: 1 })
classSchema.index({ isActive: 1 })
classSchema.index({ 'students.student': 1 })
classSchema.index({ subject: 1, grade: 1 })
classSchema.index({ classType: 1 })

// Virtual for student count
classSchema.virtual('studentCount').get(function() {
  if (!this.students || !Array.isArray(this.students)) return 0
  return this.students.filter(student => student.isActive).length
})

// Virtual for disabled student count
classSchema.virtual('disabledStudentCount').get(function() {
  if (!this.students || !Array.isArray(this.students)) return 0
  return this.students.filter(student => student.isActive && student.studentType === 'disabled').length
})

// Virtual for regular student count
classSchema.virtual('regularStudentCount').get(function() {
  if (!this.students || !Array.isArray(this.students)) return 0
  return this.students.filter(student => student.isActive && student.studentType === 'regular').length
})

// Virtual for available spots
classSchema.virtual('availableSpots').get(function() {
  return this.maxStudents - this.studentCount
})

// Method to check if class is full
classSchema.methods.isFull = function() {
  return this.studentCount >= this.maxStudents
}

// Method to check if student is enrolled
classSchema.methods.isStudentEnrolled = function(studentId) {
  return this.students.some(student => 
    student.student.toString() === studentId.toString() && student.isActive
  )
}

// Method to check if student is disabled
classSchema.methods.isStudentDisabled = function(studentId) {
  const student = this.students.find(student => 
    student.student.toString() === studentId.toString() && student.isActive
  )
  return student ? student.studentType === 'disabled' : false
}

// Method to add student to class
classSchema.methods.addStudent = function(studentId, studentType = 'regular') {
  if (this.isFull()) {
    throw new Error('Class is full')
  }
  
  if (this.isStudentEnrolled(studentId)) {
    throw new Error('Student is already enrolled')
  }

  // Update class type if needed
  if (studentType === 'disabled' && this.classType === 'regular') {
    this.classType = 'mixed'
  } else if (studentType === 'regular' && this.classType === 'disabled') {
    this.classType = 'mixed'
  }
  
  this.students.push({
    student: studentId,
    joinedAt: new Date(),
    isActive: true,
    studentType
  })
  
  return this.save()
}

// Method to remove student from class
classSchema.methods.removeStudent = function(studentId) {
  const studentIndex = this.students.findIndex(student => 
    student.student.toString() === studentId.toString()
  )
  
  if (studentIndex === -1) {
    throw new Error('Student not found in class')
  }
  
  this.students[studentIndex].isActive = false
  return this.save()
}

// Method to get active students
classSchema.methods.getActiveStudents = function() {
  return this.students.filter(student => student.isActive)
}

// Method to get disabled students
classSchema.methods.getDisabledStudents = function() {
  return this.students.filter(student => student.isActive && student.studentType === 'disabled')
}

// Method to get regular students
classSchema.methods.getRegularStudents = function() {
  return this.students.filter(student => student.isActive && student.studentType === 'regular')
}

// Method to get class info without sensitive data
classSchema.methods.toSafeObject = function() {
  const classObject = this.toObject()
  return classObject
}

export default mongoose.model('Class', classSchema)
