import nodemailer from 'nodemailer';
import { emailTemplates } from './emailTemplates.js';
import { studentCredentialsTemplate } from './emailTemplates/studentCredentials.js';
import { classroomInvitationTemplate } from './emailTemplates/classroomInvitation.js';
import { logEmail } from '../config/logger.js';

// Create transporter
const createTransporter = () => {
  // Check if we have email configuration
  const hasEmailConfig = process.env.EMAIL_USER && (process.env.EMAIL_PASS || process.env.EMAIL_PASSWORD);

  // For development without email config, use Ethereal Email (fake SMTP)
  if (process.env.NODE_ENV === 'development' && !hasEmailConfig) {
    console.log('📧 Using Ethereal Email for development (fake SMTP)');
    return nodemailer.createTransport({
      host: 'smtp.ethereal.email',
      port: 587,
      secure: false,
      auth: {
        user: 'ethereal-user',
        pass: 'ethereal-pass'
      }
    });
  }

  // Use the configured email settings
  const emailConfig = {
    host: process.env.EMAIL_HOST || 'smtp.gmail.com',
    port: parseInt(process.env.EMAIL_PORT) || 587,
    secure: process.env.EMAIL_PORT === '465', // true for 465, false for other ports
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS || process.env.EMAIL_PASSWORD
    }
  };

  console.log('📧 Creating email transporter with config:', {
    host: emailConfig.host,
    port: emailConfig.port,
    secure: emailConfig.secure,
    user: emailConfig.auth.user,
    hasPassword: !!emailConfig.auth.pass
  });

  return nodemailer.createTransport(emailConfig);
};

// Send email function
export const sendEmail = async ({ to, subject, template, data }) => {
  try {
    // Check if email is configured
    const hasEmailConfig = process.env.EMAIL_USER && (process.env.EMAIL_PASS || process.env.EMAIL_PASSWORD);

    if (!hasEmailConfig) {
      console.log('📧 [DEV] Email would be sent (no config):', { to, subject, template });
      console.log('📧 [DEV] Email data:', data);

      // Generate the email content to show what would be sent
      const emailTemplate = template === 'student-credentials' ? studentCredentialsTemplate : emailTemplates[template];
      if (emailTemplate) {
        const textContent = emailTemplate.text(data);
        console.log('📧 [DEV] Email content that would be sent:');
        console.log('=' .repeat(50));
        console.log(textContent);
        console.log('=' .repeat(50));
      }

      return { messageId: 'dev-mode-skipped' };
    }

    console.log('📧 Attempting to send email to:', to);

    const transporter = createTransporter();

    // Get email template
    let emailTemplate;
    
    // Check new templates first
    if (template === 'student-credentials') {
      emailTemplate = studentCredentialsTemplate;
    } else if (template === 'classroom-invitation') {
      emailTemplate = classroomInvitationTemplate;
    } else {
      emailTemplate = emailTemplates[template];
    }
    
    if (!emailTemplate) {
      throw new Error(`Email template '${template}' not found`);
    }

    // Generate HTML content
    console.log('📧 Email template data:', data);
    const htmlContent = emailTemplate.html(data);
    const textContent = emailTemplate.text(data);
    console.log('📧 Generated email content preview:', textContent.substring(0, 200) + '...');

    // Email options
    const mailOptions = {
      from: process.env.EMAIL_FROM || process.env.EMAIL_USER || 'noreply@quizapp.com',
      to,
      subject,
      html: htmlContent,
      text: textContent
    };

    console.log('📧 Sending email with options:', {
      from: mailOptions.from,
      to: mailOptions.to,
      subject: mailOptions.subject
    });

    // Send email
    try {
      const info = await transporter.sendMail(mailOptions);

      logEmail('SEND', to, subject, true);

      console.log('✅ Email sent successfully:', {
        to,
        subject,
        messageId: info.messageId,
        response: info.response
      });

      // For development with Ethereal, log the preview URL
      if (process.env.NODE_ENV === 'development' && !hasEmailConfig) {
        console.log('📧 Email preview URL:', nodemailer.getTestMessageUrl(info));
      }

      return info;
    } catch (sendError) {
      console.error('❌ Failed to send email:', {
        error: sendError.message,
        code: sendError.code,
        command: sendError.command,
        to,
        subject
      });
      throw sendError;
    }

  } catch (error) {
    logEmail('SEND', to, subject, false, error);
    console.error('❌ Email send error:', error);
    throw error;
  }
};

// Send welcome email
export const sendWelcomeEmail = async (user) => {
  return sendEmail({
    to: user.email,
    subject: 'Welcome to Quiz App!',
    template: 'welcome',
    data: {
      name: user.name,
      role: user.role
    }
  });
};

// Send login notification
export const sendLoginNotification = async (user, loginData) => {
  return sendEmail({
    to: user.email,
    subject: 'Login Notification - Quiz App',
    template: 'login-notification',
    data: {
      name: user.name,
      loginTime: loginData.loginTime,
      ipAddress: loginData.ipAddress
    }
  });
};

// Send password reset email
export const sendPasswordResetEmail = async (user, resetUrl) => {
  return sendEmail({
    to: user.email,
    subject: 'Password Reset Request - Quiz App',
    template: 'password-reset',
    data: {
      name: user.name,
      resetUrl,
      expiryTime: '1 hour'
    }
  });
};

// Send password reset success email
export const sendPasswordResetSuccessEmail = async (user) => {
  return sendEmail({
    to: user.email,
    subject: 'Password Reset Successful - Quiz App',
    template: 'password-reset-success',
    data: {
      name: user.name,
      resetTime: new Date().toLocaleString()
    }
  });
};

// Send password change notification
export const sendPasswordChangeNotification = async (user) => {
  return sendEmail({
    to: user.email,
    subject: 'Password Changed - Quiz App',
    template: 'password-changed',
    data: {
      name: user.name,
      changeTime: new Date().toLocaleString()
    }
  });
};

// Send student credentials email
export const sendStudentCredentialsEmail = async (student, password) => {
  const emailData = {
    name: student.name,
    email: student.email,
    studentId: student.studentId,
    rollNo: student.rollNo,
    password: password
  };

  console.log('📧 Sending student credentials email with data:', emailData);

  return sendEmail({
    to: student.email,
    subject: 'Welcome to Quiz App - Your Account Details',
    template: 'student-credentials',
    data: emailData
  });
};

// Send classroom invitation email
export const sendClassroomInvitationEmail = async (student, classroom, teacher) => {
  return sendEmail({
    to: student.email,
    subject: 'Classroom Invitation - Quiz App',
    template: 'classroom-invitation',
    data: {
      studentName: student.name,
      classroomName: classroom.name,
      subject: classroom.subject,
      classCode: classroom.classCode,
      classroomId: classroom._id,
      teacherName: teacher.name,
      teacherEmail: teacher.email,
      department: teacher.department
    }
  });
};

// Send quiz assignment email
export const sendQuizAssignmentEmail = async (student, quiz, classroom, assignment) => {
  const isDisabled = student.isDisabled;
  const assignmentType = isDisabled ? 'voice-controlled' : 'regular';
  
  return sendEmail({
    to: student.email,
    subject: `New Quiz Assignment: ${quiz.title}`,
    template: 'quiz-assignment',
    data: {
      studentName: student.name,
      quizTitle: quiz.title,
      quizDescription: quiz.description,
      classroomName: classroom.name,
      subject: classroom.subject,
      assignmentType,
      instructions: assignment.instructions || 'Please complete this quiz by the due date.',
      dueDate: assignment.settings.dueDate ? new Date(assignment.settings.dueDate).toLocaleDateString() : 'No due date',
      timeLimit: assignment.settings.timeLimit || quiz.settings.timeLimit,
      allowRetake: assignment.settings.allowRetake,
      maxAttempts: assignment.settings.maxAttempts,
      voiceEnabled: assignment.settings.voiceEnabled,
      allowVoiceControl: assignment.settings.allowVoiceControl,
      isDisabled,
      assignmentId: assignment._id
    }
  });
};

// Send quiz completion notification
export const sendQuizCompletionNotification = async (student, quiz, score, percentage) => {
  return sendEmail({
    to: student.email,
    subject: `Quiz Completed: ${quiz.title}`,
    template: 'quiz-completion',
    data: {
      studentName: student.name,
      quizTitle: quiz.title,
      score,
      totalQuestions: quiz.questions.length,
      percentage,
      completionTime: new Date().toLocaleString(),
      isPassed: percentage >= (quiz.settings.passingScore || 60)
    }
  });
};

// Send quiz reminder email
export const sendQuizReminderEmail = async (student, quiz, classroom, assignment) => {
  return sendEmail({
    to: student.email,
    subject: `Reminder: Quiz Assignment - ${quiz.title}`,
    template: 'quiz-reminder',
    data: {
      studentName: student.name,
      quizTitle: quiz.title,
      classroomName: classroom.name,
      dueDate: assignment.settings.dueDate ? new Date(assignment.settings.dueDate).toLocaleDateString() : 'No due date',
      timeLimit: assignment.settings.timeLimit || quiz.settings.timeLimit,
      isDisabled: student.isDisabled,
      voiceEnabled: assignment.settings.voiceEnabled
    }
  });
};

// Test email function
export const testEmail = async () => {
  try {
    const testData = {
      name: 'Test User',
      role: 'student',
      loginTime: new Date().toLocaleString(),
      ipAddress: '127.0.0.1',
      resetUrl: 'http://localhost:3000/reset-password?token=test-token',
      expiryTime: '1 hour',
      resetTime: new Date().toLocaleString(),
      changeTime: new Date().toLocaleString()
    };

    console.log('🧪 Testing email functionality...');

    // Test welcome email
    await sendEmail({
      to: 'test@example.com',
      subject: 'Test Welcome Email',
      template: 'welcome',
      data: testData
    });

    console.log('✅ Email test completed successfully');

  } catch (error) {
    console.error('❌ Email test failed:', error);
    throw error;
  }
}; 