// Email templates for the Quiz App
import { quizAssignmentTemplate, quizCompletionTemplate, quizReminderTemplate } from './emailTemplates/quizAssignment.js';

export const emailTemplates = {
  // Welcome email template
  welcome: {
    html: (data) => `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Welcome to Quiz App</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
          .button { display: inline-block; background: #667eea; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
          .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🎉 Welcome to Quiz App!</h1>
          </div>
          <div class="content">
            <h2>Hello ${data.name}!</h2>
            <p>Welcome to Quiz App! We're excited to have you on board as a <strong>${data.role}</strong>.</p>
            
            <p>Here's what you can do with your account:</p>
            <ul>
              <li>Take interactive quizzes</li>
              <li>Track your progress</li>
              <li>Earn rewards and badges</li>
              <li>Connect with other learners</li>
            </ul>
            
            <p>Your account is now ready to use. You can start exploring the platform right away!</p>
            
            <a href="${process.env.FRONTEND_URL || 'http://localhost:3000'}" class="button">Get Started</a>
            
            <p>If you have any questions or need assistance, feel free to reach out to our support team.</p>
          </div>
          <div class="footer">
            <p>This email was sent to you because you registered for Quiz App.</p>
            <p>&copy; 2024 Quiz App. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `,
    text: (data) => `
Welcome to Quiz App!

Hello ${data.name}!

Welcome to Quiz App! We're excited to have you on board as a ${data.role}.

Here's what you can do with your account:
- Take interactive quizzes
- Track your progress
- Earn rewards and badges
- Connect with other learners

Your account is now ready to use. You can start exploring the platform right away!

Get started: ${process.env.FRONTEND_URL || 'http://localhost:3000'}

If you have any questions or need assistance, feel free to reach out to our support team.

This email was sent to you because you registered for Quiz App.
© 2024 Quiz App. All rights reserved.
    `
  },

  // Login notification template
  'login-notification': {
    html: (data) => `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login Notification - Quiz App</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #28a745; color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
          .info-box { background: #e9ecef; padding: 15px; border-radius: 5px; margin: 20px 0; }
          .button { display: inline-block; background: #28a745; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
          .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🔐 Login Notification</h1>
          </div>
          <div class="content">
            <h2>Hello ${data.name}!</h2>
            <p>We detected a new login to your Quiz App account.</p>
            
            <div class="info-box">
              <h3>Login Details:</h3>
              <p><strong>Time:</strong> ${data.loginTime}</p>
              <p><strong>IP Address:</strong> ${data.ipAddress}</p>
            </div>
            
            <p>If this was you, you can safely ignore this email. If you don't recognize this login, please take the following steps:</p>
            <ol>
              <li>Change your password immediately</li>
              <li>Enable two-factor authentication if available</li>
              <li>Contact our support team</li>
            </ol>
            
            <a href="${process.env.FRONTEND_URL || 'http://localhost:3000'}/login" class="button">Secure Your Account</a>
            
            <p>For your security, we recommend regularly updating your password and keeping your account information up to date.</p>
          </div>
          <div class="footer">
            <p>This email was sent to you because of a login to your Quiz App account.</p>
            <p>&copy; 2024 Quiz App. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `,
    text: (data) => `
Login Notification - Quiz App

Hello ${data.name}!

We detected a new login to your Quiz App account.

Login Details:
Time: ${data.loginTime}
IP Address: ${data.ipAddress}

If this was you, you can safely ignore this email. If you don't recognize this login, please take the following steps:

1. Change your password immediately
2. Enable two-factor authentication if available
3. Contact our support team

Secure your account: ${process.env.FRONTEND_URL || 'http://localhost:3000'}/login

For your security, we recommend regularly updating your password and keeping your account information up to date.

This email was sent to you because of a login to your Quiz App account.
© 2024 Quiz App. All rights reserved.
    `
  },

  // Password reset template
  'password-reset': {
    html: (data) => `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Password Reset Request - Quiz App</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #dc3545; color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
          .warning { background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 5px; margin: 20px 0; }
          .button { display: inline-block; background: #dc3545; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
          .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🔑 Password Reset Request</h1>
          </div>
          <div class="content">
            <h2>Hello ${data.name}!</h2>
            <p>We received a request to reset your password for your Quiz App account.</p>
            
            <div class="warning">
              <p><strong>⚠️ Important:</strong> This link will expire in ${data.expiryTime}. If you don't reset your password within this time, you'll need to request a new link.</p>
            </div>
            
            <p>Click the button below to reset your password:</p>
            
            <a href="${data.resetUrl}" class="button">Reset Password</a>
            
            <p>If the button doesn't work, copy and paste this link into your browser:</p>
            <p style="word-break: break-all; color: #666;">${data.resetUrl}</p>
            
            <p><strong>If you didn't request this password reset:</strong></p>
            <ul>
              <li>You can safely ignore this email</li>
              <li>Your password will remain unchanged</li>
              <li>If you're concerned about your account security, contact our support team</li>
            </ul>
          </div>
          <div class="footer">
            <p>This email was sent to you because of a password reset request for your Quiz App account.</p>
            <p>&copy; 2024 Quiz App. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `,
    text: (data) => `
Password Reset Request - Quiz App

Hello ${data.name}!

We received a request to reset your password for your Quiz App account.

⚠️ Important: This link will expire in ${data.expiryTime}. If you don't reset your password within this time, you'll need to request a new link.

Click the link below to reset your password:
${data.resetUrl}

If you didn't request this password reset:
- You can safely ignore this email
- Your password will remain unchanged
- If you're concerned about your account security, contact our support team

This email was sent to you because of a password reset request for your Quiz App account.
© 2024 Quiz App. All rights reserved.
    `
  },

  // Password reset success template
  'password-reset-success': {
    html: (data) => `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Password Reset Successful - Quiz App</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #28a745; color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
          .success-box { background: #d4edda; border: 1px solid #c3e6cb; padding: 15px; border-radius: 5px; margin: 20px 0; }
          .button { display: inline-block; background: #28a745; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
          .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>✅ Password Reset Successful</h1>
          </div>
          <div class="content">
            <h2>Hello ${data.name}!</h2>
            
            <div class="success-box">
              <p><strong>🎉 Success!</strong> Your password has been reset successfully.</p>
            </div>
            
            <p><strong>Reset Time:</strong> ${data.resetTime}</p>
            
            <p>Your new password is now active. You can use it to log in to your Quiz App account.</p>
            
            <a href="${process.env.FRONTEND_URL || 'http://localhost:3000'}/login" class="button">Login Now</a>
            
            <p><strong>Security Tips:</strong></p>
            <ul>
              <li>Use a strong, unique password</li>
              <li>Don't share your password with anyone</li>
              <li>Enable two-factor authentication if available</li>
              <li>Regularly update your password</li>
            </ul>
            
            <p>If you didn't reset your password, please contact our support team immediately.</p>
          </div>
          <div class="footer">
            <p>This email was sent to you because your password was reset for your Quiz App account.</p>
            <p>&copy; 2024 Quiz App. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `,
    text: (data) => `
Password Reset Successful - Quiz App

Hello ${data.name}!

🎉 Success! Your password has been reset successfully.

Reset Time: ${data.resetTime}

Your new password is now active. You can use it to log in to your Quiz App account.

Login now: ${process.env.FRONTEND_URL || 'http://localhost:3000'}/login

Security Tips:
- Use a strong, unique password
- Don't share your password with anyone
- Enable two-factor authentication if available
- Regularly update your password

If you didn't reset your password, please contact our support team immediately.

This email was sent to you because your password was reset for your Quiz App account.
© 2024 Quiz App. All rights reserved.
    `
  },

  // Password changed notification template
  'password-changed': {
    html: (data) => `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Password Changed - Quiz App</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #17a2b8; color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
          .info-box { background: #d1ecf1; border: 1px solid #bee5eb; padding: 15px; border-radius: 5px; margin: 20px 0; }
          .button { display: inline-block; background: #17a2b8; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
          .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🔐 Password Changed</h1>
          </div>
          <div class="content">
            <h2>Hello ${data.name}!</h2>
            <p>Your Quiz App account password has been successfully changed.</p>
            
            <div class="info-box">
              <h3>Change Details:</h3>
              <p><strong>Change Time:</strong> ${data.changeTime}</p>
            </div>
            
            <p>This change was made from your account settings. If you made this change, you can safely ignore this email.</p>
            
            <a href="${process.env.FRONTEND_URL || 'http://localhost:3000'}/login" class="button">Login with New Password</a>
            
            <p><strong>If you didn't change your password:</strong></p>
            <ul>
              <li>Contact our support team immediately</li>
              <li>Consider enabling two-factor authentication</li>
              <li>Review your account for any suspicious activity</li>
            </ul>
            
            <p>For your security, we recommend regularly updating your password and keeping your account information secure.</p>
          </div>
          <div class="footer">
            <p>This email was sent to you because your password was changed for your Quiz App account.</p>
            <p>&copy; 2024 Quiz App. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `,
    text: (data) => `
Password Changed - Quiz App

Hello ${data.name}!

Your Quiz App account password has been successfully changed.

Change Details:
Change Time: ${data.changeTime}

This change was made from your account settings. If you made this change, you can safely ignore this email.

Login with new password: ${process.env.FRONTEND_URL || 'http://localhost:3000'}/login

If you didn't change your password:
- Contact our support team immediately
- Consider enabling two-factor authentication
- Review your account for any suspicious activity

For your security, we recommend regularly updating your password and keeping your account information secure.

This email was sent to you because your password was changed for your Quiz App account.
© 2024 Quiz App. All rights reserved.
    `
  },

  // Quiz assignment template
  'quiz-assignment': quizAssignmentTemplate,

  // Quiz completion template
  'quiz-completion': quizCompletionTemplate,

  // Quiz reminder template
  'quiz-reminder': quizReminderTemplate
};
