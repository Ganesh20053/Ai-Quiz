import { geminiLogger, metricsLogger } from './logger.js';

class GeminiAPILogger {
  constructor() {
    this.requestCount = 0;
    this.errorCount = 0;
    this.totalResponseTime = 0;
    this.startTime = Date.now();
  }

  // Log API request start
  logRequest(requestData) {
    this.requestCount++;
    const requestId = this.generateRequestId();
    
    geminiLogger.info('Gemini API Request Started', {
      requestId,
      timestamp: new Date().toISOString(),
      prompt: requestData.prompt ? requestData.prompt.substring(0, 200) + '...' : 'No prompt',
      promptLength: requestData.prompt ? requestData.prompt.length : 0,
      userId: requestData.userId,
      classroomId: requestData.classroomId,
      requestType: requestData.type || 'quiz-generation',
      requestNumber: this.requestCount
    });

    return requestId;
  }

  // Log successful API response
  logSuccess(requestId, responseData, responseTime) {
    this.totalResponseTime += responseTime;
    
    geminiLogger.info('Gemini API Request Successful', {
      requestId,
      timestamp: new Date().toISOString(),
      responseTime: `${responseTime}ms`,
      responseSize: JSON.stringify(responseData).length,
      questionsGenerated: responseData.questions ? responseData.questions.length : 0,
      quizTitle: responseData.quizTitle || 'N/A',
      success: true
    });

    // Log metrics
    this.logMetrics('success', responseTime);
  }

  // Log API error
  logError(requestId, error, responseTime = 0) {
    this.errorCount++;
    
    geminiLogger.error('Gemini API Request Failed', {
      requestId,
      timestamp: new Date().toISOString(),
      error: error.message,
      errorCode: error.code || 'UNKNOWN',
      statusCode: error.response?.status,
      responseTime: responseTime ? `${responseTime}ms` : 'N/A',
      errorDetails: error.response?.data || error.stack,
      success: false
    });

    // Log metrics
    this.logMetrics('error', responseTime);
  }

  // Log API rate limiting
  logRateLimit(requestId, retryAfter) {
    geminiLogger.warn('Gemini API Rate Limited', {
      requestId,
      timestamp: new Date().toISOString(),
      retryAfter: `${retryAfter}s`,
      message: 'Request rate limited, will retry after specified time'
    });
  }

  // Log API quota exceeded
  logQuotaExceeded(requestId, quotaInfo) {
    geminiLogger.error('Gemini API Quota Exceeded', {
      requestId,
      timestamp: new Date().toISOString(),
      quotaInfo,
      message: 'API quota exceeded, requests will fail until quota resets'
    });
  }

  // Log response parsing issues
  logParsingError(requestId, rawResponse, parseError) {
    geminiLogger.error('Gemini Response Parsing Failed', {
      requestId,
      timestamp: new Date().toISOString(),
      rawResponse: rawResponse.substring(0, 500) + '...',
      parseError: parseError.message,
      message: 'Failed to parse Gemini API response into expected format'
    });
  }

  // Log fallback usage
  logFallback(requestId, reason, fallbackType) {
    geminiLogger.warn('Using Fallback Response', {
      requestId,
      timestamp: new Date().toISOString(),
      reason,
      fallbackType,
      message: 'Gemini API unavailable, using fallback response'
    });
  }

  // Log performance metrics
  logMetrics(type, responseTime) {
    const avgResponseTime = this.totalResponseTime / Math.max(this.requestCount - this.errorCount, 1);
    const errorRate = (this.errorCount / this.requestCount) * 100;
    const uptime = Date.now() - this.startTime;

    metricsLogger.info('Gemini API Metrics', {
      timestamp: new Date().toISOString(),
      type: 'gemini-api-metrics',
      totalRequests: this.requestCount,
      successfulRequests: this.requestCount - this.errorCount,
      errorCount: this.errorCount,
      errorRate: `${errorRate.toFixed(2)}%`,
      avgResponseTime: `${avgResponseTime.toFixed(2)}ms`,
      lastResponseTime: `${responseTime}ms`,
      uptime: `${Math.floor(uptime / 1000)}s`,
      requestType: type
    });
  }

  // Log daily summary
  logDailySummary() {
    const avgResponseTime = this.totalResponseTime / Math.max(this.requestCount - this.errorCount, 1);
    const errorRate = (this.errorCount / this.requestCount) * 100;

    geminiLogger.info('Daily Gemini API Summary', {
      timestamp: new Date().toISOString(),
      date: new Date().toDateString(),
      totalRequests: this.requestCount,
      successfulRequests: this.requestCount - this.errorCount,
      failedRequests: this.errorCount,
      errorRate: `${errorRate.toFixed(2)}%`,
      avgResponseTime: `${avgResponseTime.toFixed(2)}ms`,
      totalResponseTime: `${this.totalResponseTime}ms`
    });
  }

  // Generate unique request ID
  generateRequestId() {
    return `gemini_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Reset metrics (for daily reset)
  resetMetrics() {
    this.requestCount = 0;
    this.errorCount = 0;
    this.totalResponseTime = 0;
    this.startTime = Date.now();
  }
}

// Create singleton instance
const geminiAPILogger = new GeminiAPILogger();

// Schedule daily summary and reset
setInterval(() => {
  geminiAPILogger.logDailySummary();
  geminiAPILogger.resetMetrics();
}, 24 * 60 * 60 * 1000); // 24 hours

export default geminiAPILogger;
