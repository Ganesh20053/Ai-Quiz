// Email validation
export const validateEmail = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

// Password validation
export const validatePassword = (password) => {
  return password && password.length >= 6;
};

// Name validation
export const validateName = (name) => {
  return name && name.trim().length >= 2 && name.trim().length <= 50;
};

// Phone validation
export const validatePhone = (phone) => {
  const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
  return !phone || phoneRegex.test(phone.replace(/[\s\-\(\)]/g, ''));
};

// Student ID validation
export const validateStudentId = (studentId) => {
  return !studentId || (studentId && studentId.trim().length >= 3);
};

// Employee ID validation
export const validateEmployeeId = (employeeId) => {
  return !employeeId || (employeeId && employeeId.trim().length >= 3);
};

// Role validation
export const validateRole = (role) => {
  const validRoles = ['admin', 'staff', 'student'];
  return validRoles.includes(role);
}; 