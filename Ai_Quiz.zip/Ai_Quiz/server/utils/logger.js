import { createLogger, format, transports } from 'winston';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Ensure logs directory exists
const logsDir = path.join(__dirname, '../logs');
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
}

// Custom format for structured logging
const customFormat = format.combine(
  format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  format.errors({ stack: true }),
  format.json()
);

// Console format for development
const consoleFormat = format.combine(
  format.colorize(),
  format.timestamp({ format: 'HH:mm:ss' }),
  format.printf(({ timestamp, level, message, service, ...meta }) => {
    const metaStr = Object.keys(meta).length ? JSON.stringify(meta, null, 2) : '';
    const serviceStr = service ? `[${service}]` : '';
    return `${timestamp} ${level} ${serviceStr}: ${message} ${metaStr}`;
  })
);

// Base logger configuration
const baseLoggerConfig = {
  level: process.env.LOG_LEVEL || 'info',
  format: customFormat,
  defaultMeta: { service: 'quiz-app' },
  transports: [
    new transports.Console({
      format: consoleFormat,
      level: 'debug'
    }),
    new transports.File({
      filename: path.join(logsDir, 'error.log'),
      level: 'error',
      maxsize: 5242880, // 5MB
      maxFiles: 5
    }),
    new transports.File({
      filename: path.join(logsDir, 'combined.log'),
      maxsize: 5242880, // 5MB
      maxFiles: 5
    })
  ],
};

// Main application logger
const logger = createLogger(baseLoggerConfig);

// Gemini API specific logger
const geminiLogger = createLogger({
  ...baseLoggerConfig,
  defaultMeta: { service: 'gemini-api' },
  transports: [
    ...baseLoggerConfig.transports,
    new transports.File({
      filename: path.join(logsDir, 'gemini-api.log'),
      maxsize: 5242880, // 5MB
      maxFiles: 10
    })
  ]
});

// Quiz operations logger
const quizLogger = createLogger({
  ...baseLoggerConfig,
  defaultMeta: { service: 'quiz-operations' },
  transports: [
    ...baseLoggerConfig.transports,
    new transports.File({
      filename: path.join(logsDir, 'quiz-operations.log'),
      maxsize: 5242880, // 5MB
      maxFiles: 10
    })
  ]
});

// Performance metrics logger
const metricsLogger = createLogger({
  ...baseLoggerConfig,
  defaultMeta: { service: 'metrics' },
  transports: [
    new transports.File({
      filename: path.join(logsDir, 'metrics.log'),
      maxsize: 5242880, // 5MB
      maxFiles: 5
    })
  ]
});

export default logger;
export { geminiLogger, quizLogger, metricsLogger };
