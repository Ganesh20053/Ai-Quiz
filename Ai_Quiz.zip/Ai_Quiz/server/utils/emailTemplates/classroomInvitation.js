// Email template for classroom invitations
export const classroomInvitationTemplate = {
  html: (data) => `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Classroom Invitation - Quiz App</title>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #28a745 0%, #20c997 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
        .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
        .classroom-box { background: #d4edda; border: 2px solid #28a745; padding: 20px; border-radius: 8px; margin: 20px 0; }
        .classroom-item { background: white; padding: 10px; margin: 10px 0; border-radius: 5px; border-left: 4px solid #28a745; }
        .button { display: inline-block; background: #28a745; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
        .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
        .teacher-info { background: #e3f2fd; border: 1px solid #2196f3; padding: 15px; border-radius: 5px; margin: 20px 0; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>🎓 Classroom Invitation</h1>
          <p>You've been invited to join a classroom</p>
        </div>
        <div class="content">
          <h2>Hello ${data.studentName}!</h2>
          <p>You have been invited to join a classroom in Quiz App. Here are the details:</p>
          
          <div class="classroom-box">
            <h3>📚 Classroom Details:</h3>
            <div class="classroom-item">
              <strong>Classroom Name:</strong> ${data.classroomName}
            </div>
            <div class="classroom-item">
              <strong>Subject:</strong> ${data.subject}
            </div>
            <div class="classroom-item">
              <strong>Class Code:</strong> ${data.classCode}
            </div>
            <div class="classroom-item">
              <strong>Teacher:</strong> ${data.teacherName}
            </div>
          </div>
          
          <div class="teacher-info">
            <h4>👨‍🏫 Teacher Information:</h4>
            <p><strong>Name:</strong> ${data.teacherName}</p>
            <p><strong>Email:</strong> ${data.teacherEmail}</p>
            <p><strong>Department:</strong> ${data.department}</p>
          </div>
          
          <p>You can now access this classroom and participate in quizzes, assignments, and discussions.</p>
          
          <a href="${process.env.FRONTEND_URL || 'http://localhost:3000'}/classroom/${data.classroomId}" class="button">Join Classroom</a>
          
          <p><strong>What you can do in this classroom:</strong></p>
          <ul>
            <li>Take quizzes assigned by your teacher</li>
            <li>View your grades and progress</li>
            <li>Participate in discussions</li>
            <li>Access study materials</li>
            <li>Track your performance</li>
          </ul>
          
          <p>If you have any questions about this classroom, please contact your teacher or our support team.</p>
        </div>
        <div class="footer">
          <p>This email was sent to you because your teacher invited you to join a classroom in Quiz App.</p>
          <p>&copy; 2024 Quiz App. All rights reserved.</p>
        </div>
      </div>
    </body>
    </html>
  `,
  text: (data) => `
Classroom Invitation - Quiz App

Hello ${data.studentName}!

You have been invited to join a classroom in Quiz App. Here are the details:

📚 Classroom Details:
Classroom Name: ${data.classroomName}
Subject: ${data.subject}
Class Code: ${data.classCode}
Teacher: ${data.teacherName}

👨‍🏫 Teacher Information:
Name: ${data.teacherName}
Email: ${data.teacherEmail}
Department: ${data.department}

You can now access this classroom and participate in quizzes, assignments, and discussions.

Join classroom: ${process.env.FRONTEND_URL || 'http://localhost:3000'}/classroom/${data.classroomId}

What you can do in this classroom:
- Take quizzes assigned by your teacher
- View your grades and progress
- Participate in discussions
- Access study materials
- Track your performance

If you have any questions about this classroom, please contact your teacher or our support team.

This email was sent to you because your teacher invited you to join a classroom in Quiz App.
© 2024 Quiz App. All rights reserved.
  `
}; 