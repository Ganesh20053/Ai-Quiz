// Email template for sending student credentials
export const studentCredentialsTemplate = {
  html: (data) => `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Welcome to Quiz App - Your Account Details</title>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
        .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
        .credentials-box { background: #e3f2fd; border: 2px solid #2196f3; padding: 20px; border-radius: 8px; margin: 20px 0; }
        .credential-item { background: white; padding: 10px; margin: 10px 0; border-radius: 5px; border-left: 4px solid #2196f3; }
        .button { display: inline-block; background: #667eea; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
        .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
        .warning { background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 5px; margin: 20px 0; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>🎓 Welcome to Quiz App!</h1>
          <p>Your student account has been created</p>
        </div>
        <div class="content">
          <h2>Hello ${data.name || 'Student'}!</h2>
          <p>🎉 Welcome to Quiz App! Your student account has been successfully created by your teacher.</p>

          <div class="credentials-box">
            <h3>📋 Your Login Credentials:</h3>
            <div class="credential-item">
              <strong>Student ID:</strong> ${data.studentId || 'Not provided'}
            </div>
            <div class="credential-item">
              <strong>Email:</strong> ${data.email || 'Not provided'}
            </div>
            <div class="credential-item">
              <strong>Password:</strong> <code style="background: #f0f0f0; padding: 2px 6px; border-radius: 4px; font-family: monospace;">${data.password || 'Not provided'}</code>
            </div>
            <div class="credential-item">
              <strong>Roll Number:</strong> ${data.rollNo || 'Not assigned'}
            </div>
          </div>

          <div class="warning">
            <h3>🔐 Security Information:</h3>
            <ul>
              <li>Your password has been uniquely generated for security</li>
              <li><strong>Please change your password after your first login</strong></li>
              <li>Never share your login credentials with anyone</li>
              <li>Log out when using shared computers</li>
            </ul>
          </div>

          <div style="background: #e8f5e8; padding: 15px; border-radius: 8px; margin: 20px 0;">
            <h3>🚀 Getting Started:</h3>
            <ol>
              <li>Visit the login page</li>
              <li>Enter your email and password</li>
              <li>Change your password in profile settings</li>
              <li>Start taking quizzes assigned by your teachers</li>
            </ol>
          </div>
          
          <p>You can now access your account and start taking quizzes assigned by your teachers.</p>
          
          <a href="${process.env.FRONTEND_URL || 'http://localhost:3000'}/login" class="button">Login to Your Account</a>
          
          <p><strong>What you can do:</strong></p>
          <ul>
            <li>Take quizzes assigned by your teachers</li>
            <li>Track your progress and scores</li>
            <li>View your grades and feedback</li>
            <li>Participate in classroom activities</li>
          </ul>
          
          <p>If you have any questions or need assistance, please contact your teacher or our support team.</p>
        </div>
        <div class="footer">
          <p>This email was sent to you because your teacher created an account for you in Quiz App.</p>
          <p>&copy; 2024 Quiz App. All rights reserved.</p>
        </div>
      </div>
    </body>
    </html>
  `,
  text: (data) => `
Welcome to Quiz App - Your Account Details

Hello ${data.name || 'Student'}!

🎉 Welcome to Quiz App! Your student account has been successfully created by your teacher.

📋 Your Login Credentials:
Student ID: ${data.studentId || 'Not provided'}
Email: ${data.email || 'Not provided'}
Password: ${data.password || 'Not provided'}
Roll Number: ${data.rollNo || 'Not assigned'}

🔐 Security Information:
- Your password has been uniquely generated for security
- Please change your password after your first login
- Never share your login credentials with anyone
- Log out when using shared computers

🚀 Getting Started:
1. Visit: ${process.env.FRONTEND_URL || 'http://localhost:3000'}/login
2. Enter your email and password
3. Change your password in profile settings
4. Start taking quizzes assigned by your teachers

✨ What you can do:
- Take quizzes and assessments
- Track your progress and scores
- View detailed feedback and explanations
- Participate in classroom activities
- Monitor your academic performance

📞 Need Help?
If you have any questions or need assistance, please contact your teacher or our support team.

Thank you for joining Quiz App! We're excited to support your learning journey.

Best regards,
The Quiz App Team

This email was sent to you because your teacher created an account for you in Quiz App.
© 2024 Quiz App. All rights reserved.
  `
}; 