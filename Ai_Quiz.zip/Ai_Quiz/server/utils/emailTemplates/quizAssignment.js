export const quizAssignmentTemplate = {
  html: (data) => `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>New Quiz Assignment</title>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
        .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
        .quiz-info { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #667eea; }
        .voice-info { background: #e3f2fd; padding: 15px; border-radius: 8px; margin: 15px 0; border-left: 4px solid #2196f3; }
        .button { display: inline-block; padding: 12px 24px; background: #667eea; color: white; text-decoration: none; border-radius: 6px; margin: 10px 0; }
        .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
        .highlight { background: #fff3cd; padding: 10px; border-radius: 5px; border-left: 4px solid #ffc107; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>📚 New Quiz Assignment</h1>
          <p>Hello ${data.studentName}, you have a new quiz to complete!</p>
        </div>
        
        <div class="content">
          <div class="quiz-info">
            <h2>${data.quizTitle}</h2>
            <p><strong>Classroom:</strong> ${data.classroomName} (${data.subject})</p>
            <p><strong>Description:</strong> ${data.quizDescription || 'No description provided'}</p>
            <p><strong>Time Limit:</strong> ${data.timeLimit} minutes</p>
            <p><strong>Due Date:</strong> ${data.dueDate}</p>
            <p><strong>Max Attempts:</strong> ${data.maxAttempts}</p>
            ${data.allowRetake ? '<p><strong>✅ Retakes Allowed</strong></p>' : '<p><strong>❌ No Retakes</strong></p>'}
          </div>

          ${data.isDisabled ? `
            <div class="voice-info">
              <h3>🎤 Voice-Controlled Quiz</h3>
              <p>This quiz is designed for voice accessibility. You can:</p>
              <ul>
                <li>Use voice commands to navigate questions</li>
                <li>Answer questions by speaking your choice</li>
                <li>Control the quiz completely with your voice</li>
                <li>Get audio feedback for your answers</li>
              </ul>
              <p><strong>Voice Commands:</strong></p>
              <ul>
                <li>"Answer A/B/C/D" - Select an answer</li>
                <li>"Next" - Go to next question</li>
                <li>"Previous" - Go to previous question</li>
                <li>"Repeat" - Hear the question again</li>
                <li>"Finish" - Submit the quiz</li>
              </ul>
            </div>
          ` : ''}

          <div class="highlight">
            <h3>📝 Instructions</h3>
            <p>${data.instructions}</p>
          </div>

          <div style="text-align: center; margin: 30px 0;">
            <a href="${process.env.CLIENT_URL || 'http://localhost:3000'}/quiz/${data.assignmentId}" class="button">
              ${data.isDisabled ? '🎤 Start Voice-Controlled Quiz' : '📝 Start Quiz'}
            </a>
          </div>

          <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin: 20px 0;">
            <h4>💡 Tips for Success</h4>
            <ul>
              <li>Read all questions carefully before answering</li>
              <li>Manage your time wisely</li>
              ${data.isDisabled ? '<li>Speak clearly for voice recognition</li>' : ''}
              <li>Review your answers before submitting</li>
              <li>Contact your teacher if you need help</li>
            </ul>
          </div>
        </div>

        <div class="footer">
          <p>This email was sent from Quiz App</p>
          <p>If you have any questions, please contact your teacher</p>
        </div>
      </div>
    </body>
    </html>
  `,

  text: (data) => `
    New Quiz Assignment

    Hello ${data.studentName},

    You have a new quiz assignment to complete:

    Quiz: ${data.quizTitle}
    Classroom: ${data.classroomName} (${data.subject})
    Description: ${data.quizDescription || 'No description provided'}
    Time Limit: ${data.timeLimit} minutes
    Due Date: ${data.dueDate}
    Max Attempts: ${data.maxAttempts}
    Retakes Allowed: ${data.allowRetake ? 'Yes' : 'No'}

    ${data.isDisabled ? `
    VOICE-CONTROLLED QUIZ
    This quiz is designed for voice accessibility. You can:
    - Use voice commands to navigate questions
    - Answer questions by speaking your choice
    - Control the quiz completely with your voice
    - Get audio feedback for your answers

    Voice Commands:
    - "Answer A/B/C/D" - Select an answer
    - "Next" - Go to next question
    - "Previous" - Go to previous question
    - "Repeat" - Hear the question again
    - "Finish" - Submit the quiz
    ` : ''}

    Instructions: ${data.instructions}

    Start Quiz: ${process.env.CLIENT_URL || 'http://localhost:3000'}/quiz/${data.assignmentId}

    Tips for Success:
    - Read all questions carefully before answering
    - Manage your time wisely
    ${data.isDisabled ? '- Speak clearly for voice recognition' : ''}
    - Review your answers before submitting
    - Contact your teacher if you need help

    Best regards,
    Quiz App Team
  `
};

export const quizCompletionTemplate = {
  html: (data) => `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Quiz Completed</title>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #28a745 0%, #20c997 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
        .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
        .result { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center; }
        .score { font-size: 48px; font-weight: bold; color: ${data.isPassed ? '#28a745' : '#dc3545'}; }
        .status { font-size: 24px; color: ${data.isPassed ? '#28a745' : '#dc3545'}; margin: 10px 0; }
        .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>🎉 Quiz Completed!</h1>
          <p>Great job completing your quiz!</p>
        </div>
        
        <div class="content">
          <div class="result">
            <h2>${data.quizTitle}</h2>
            <div class="score">${data.percentage}%</div>
            <div class="status">${data.isPassed ? '✅ PASSED' : '❌ NEEDS IMPROVEMENT'}</div>
            <p><strong>Score:</strong> ${data.score} out of ${data.totalQuestions} questions</p>
            <p><strong>Completed:</strong> ${data.completionTime}</p>
          </div>

          <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin: 20px 0;">
            <h4>📊 Performance Summary</h4>
            <p>You answered ${data.score} out of ${data.totalQuestions} questions correctly.</p>
            ${data.isPassed ? 
              '<p style="color: #28a745; font-weight: bold;">🎉 Congratulations! You passed this quiz!</p>' :
              '<p style="color: #dc3545; font-weight: bold;">💪 Keep practicing to improve your score!</p>'
            }
          </div>

          <div style="text-align: center; margin: 30px 0;">
            <p>Your teacher will review your results and provide feedback if needed.</p>
          </div>
        </div>

        <div class="footer">
          <p>This email was sent from Quiz App</p>
          <p>Keep up the great work!</p>
        </div>
      </div>
    </body>
    </html>
  `,

  text: (data) => `
    Quiz Completed

    Hello ${data.studentName},

    Congratulations! You have completed the quiz: ${data.quizTitle}

    RESULTS:
    Score: ${data.score} out of ${data.totalQuestions} questions
    Percentage: ${data.percentage}%
    Status: ${data.isPassed ? 'PASSED' : 'NEEDS IMPROVEMENT'}
    Completed: ${data.completionTime}

    ${data.isPassed ? 
      '🎉 Congratulations! You passed this quiz!' :
      '💪 Keep practicing to improve your score!'
    }

    Your teacher will review your results and provide feedback if needed.

    Keep up the great work!

    Best regards,
    Quiz App Team
  `
};

export const quizReminderTemplate = {
  html: (data) => `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Quiz Reminder</title>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
        .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
        .reminder { background: #fff3cd; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #ffc107; }
        .quiz-info { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; }
        .button { display: inline-block; padding: 12px 24px; background: #ffc107; color: white; text-decoration: none; border-radius: 6px; margin: 10px 0; }
        .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>⏰ Quiz Reminder</h1>
          <p>Don't forget to complete your quiz!</p>
        </div>
        
        <div class="content">
          <div class="reminder">
            <h3>📝 Quiz Due Soon</h3>
            <p>This is a friendly reminder that you have a quiz assignment that needs to be completed.</p>
          </div>

          <div class="quiz-info">
            <h2>${data.quizTitle}</h2>
            <p><strong>Classroom:</strong> ${data.classroomName}</p>
            <p><strong>Due Date:</strong> ${data.dueDate}</p>
            <p><strong>Time Limit:</strong> ${data.timeLimit} minutes</p>
            ${data.isDisabled ? '<p><strong>🎤 Voice-Controlled Quiz</strong></p>' : ''}
          </div>

          <div style="text-align: center; margin: 30px 0;">
            <a href="${process.env.CLIENT_URL || 'http://localhost:3000'}/assignments" class="button">
              ${data.isDisabled ? '🎤 Complete Voice Quiz' : '📝 Complete Quiz'}
            </a>
          </div>

          <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin: 20px 0;">
            <h4>💡 Quick Tips</h4>
            <ul>
              <li>Set aside enough time to complete the quiz</li>
              <li>Find a quiet environment to focus</li>
              ${data.isDisabled ? '<li>Ensure your microphone is working properly</li>' : ''}
              <li>Read questions carefully before answering</li>
              <li>Review your answers before submitting</li>
            </ul>
          </div>
        </div>

        <div class="footer">
          <p>This email was sent from Quiz App</p>
          <p>Good luck with your quiz!</p>
        </div>
      </div>
    </body>
    </html>
  `,

  text: (data) => `
    Quiz Reminder

    Hello ${data.studentName},

    This is a friendly reminder that you have a quiz assignment that needs to be completed.

    Quiz: ${data.quizTitle}
    Classroom: ${data.classroomName}
    Due Date: ${data.dueDate}
    Time Limit: ${data.timeLimit} minutes
    ${data.isDisabled ? 'Type: Voice-Controlled Quiz' : ''}

    Complete Quiz: ${process.env.CLIENT_URL || 'http://localhost:3000'}/assignments

    Quick Tips:
    - Set aside enough time to complete the quiz
    - Find a quiet environment to focus
    ${data.isDisabled ? '- Ensure your microphone is working properly' : ''}
    - Read questions carefully before answering
    - Review your answers before submitting

    Good luck with your quiz!

    Best regards,
    Quiz App Team
  `
}; 