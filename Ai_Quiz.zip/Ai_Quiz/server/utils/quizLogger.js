import { quizLogger, metricsLogger } from './logger.js';

class QuizOperationsLogger {
  constructor() {
    this.quizCreationCount = 0;
    this.aiGeneratedCount = 0;
    this.syllabusBasedCount = 0;
    this.manualCount = 0;
    this.totalQuestions = 0;
    this.startTime = Date.now();
  }

  // Log quiz creation start
  logQuizCreationStart(quizData) {
    const operationId = this.generateOperationId();
    
    quizLogger.info('Quiz Creation Started', {
      operationId,
      timestamp: new Date().toISOString(),
      title: quizData.title,
      type: quizData.type || 'manual', // 'ai-generated', 'syllabus-based', 'manual'
      difficulty: quizData.difficulty,
      questionCount: quizData.questions ? quizData.questions.length : 0,
      classroomId: quizData.classroomId,
      userId: quizData.userId,
      subject: quizData.subject,
      topic: quizData.topic
    });

    return operationId;
  }

  // Log successful quiz creation
  logQuizCreationSuccess(operationId, quizData, creationTime) {
    this.quizCreationCount++;
    this.totalQuestions += quizData.questions ? quizData.questions.length : 0;

    // Track quiz type
    switch (quizData.type) {
      case 'ai-generated':
        this.aiGeneratedCount++;
        break;
      case 'syllabus-based':
        this.syllabusBasedCount++;
        break;
      default:
        this.manualCount++;
    }

    quizLogger.info('Quiz Creation Successful', {
      operationId,
      timestamp: new Date().toISOString(),
      quizId: quizData._id || quizData.id,
      title: quizData.title,
      type: quizData.type || 'manual',
      difficulty: quizData.difficulty,
      questionCount: quizData.questions ? quizData.questions.length : 0,
      creationTime: `${creationTime}ms`,
      classroomId: quizData.classroomId,
      userId: quizData.userId,
      success: true
    });

    // Log metrics
    this.logMetrics('creation-success', creationTime);
  }

  // Log quiz creation failure
  logQuizCreationError(operationId, error, quizData) {
    quizLogger.error('Quiz Creation Failed', {
      operationId,
      timestamp: new Date().toISOString(),
      error: error.message,
      errorCode: error.code || 'UNKNOWN',
      title: quizData?.title,
      type: quizData?.type || 'manual',
      classroomId: quizData?.classroomId,
      userId: quizData?.userId,
      errorDetails: error.stack,
      success: false
    });

    // Log metrics
    this.logMetrics('creation-error');
  }

  // Log AI quiz generation process
  logAIQuizGeneration(operationId, generationData) {
    quizLogger.info('AI Quiz Generation Process', {
      operationId,
      timestamp: new Date().toISOString(),
      topic: generationData.topic,
      subject: generationData.subject,
      difficulty: generationData.difficulty,
      requestedQuestions: generationData.numQuestions,
      questionType: generationData.questionType,
      focusAreas: generationData.focusAreas,
      learningObjectives: generationData.learningObjectives,
      includeExplanations: generationData.includeExplanations,
      userId: generationData.userId,
      classroomId: generationData.classroomId
    });
  }

  // Log syllabus processing
  logSyllabusProcessing(operationId, syllabusData) {
    quizLogger.info('Syllabus Processing Started', {
      operationId,
      timestamp: new Date().toISOString(),
      fileName: syllabusData.fileName,
      fileSize: syllabusData.fileSize,
      fileType: syllabusData.fileType,
      textLength: syllabusData.textLength,
      userId: syllabusData.userId,
      classroomId: syllabusData.classroomId
    });
  }

  // Log syllabus analysis results
  logSyllabusAnalysis(operationId, analysisResults) {
    quizLogger.info('Syllabus Analysis Completed', {
      operationId,
      timestamp: new Date().toISOString(),
      topicsFound: analysisResults.topics ? analysisResults.topics.length : 0,
      subject: analysisResults.subject,
      overallDifficulty: analysisResults.overallDifficulty,
      estimatedQuestions: analysisResults.totalEstimatedQuestions,
      analysisTime: analysisResults.processingTime
    });
  }

  // Log quiz editing operations
  logQuizEdit(quizId, editData) {
    const operationId = this.generateOperationId();
    
    quizLogger.info('Quiz Edit Operation', {
      operationId,
      timestamp: new Date().toISOString(),
      quizId,
      editType: editData.type, // 'question-edit', 'question-add', 'question-remove', 'settings-update'
      questionIndex: editData.questionIndex,
      changes: editData.changes,
      userId: editData.userId
    });

    return operationId;
  }

  // Log quiz assignment
  logQuizAssignment(quizId, assignmentData) {
    quizLogger.info('Quiz Assignment Created', {
      timestamp: new Date().toISOString(),
      quizId,
      classroomId: assignmentData.classroomId,
      assignedBy: assignmentData.userId,
      dueDate: assignmentData.dueDate,
      timeLimit: assignmentData.timeLimit,
      maxAttempts: assignmentData.maxAttempts,
      studentsCount: assignmentData.studentsCount
    });
  }

  // Log quiz attempt
  logQuizAttempt(attemptData) {
    quizLogger.info('Quiz Attempt Started', {
      timestamp: new Date().toISOString(),
      quizId: attemptData.quizId,
      studentId: attemptData.studentId,
      attemptNumber: attemptData.attemptNumber,
      timeLimit: attemptData.timeLimit,
      questionCount: attemptData.questionCount
    });
  }

  // Log quiz completion
  logQuizCompletion(completionData) {
    quizLogger.info('Quiz Attempt Completed', {
      timestamp: new Date().toISOString(),
      quizId: completionData.quizId,
      studentId: completionData.studentId,
      score: completionData.score,
      totalQuestions: completionData.totalQuestions,
      correctAnswers: completionData.correctAnswers,
      timeSpent: completionData.timeSpent,
      passed: completionData.passed
    });
  }

  // Log performance metrics
  logMetrics(type, operationTime = 0) {
    const uptime = Date.now() - this.startTime;
    const avgQuestionsPerQuiz = this.totalQuestions / Math.max(this.quizCreationCount, 1);

    metricsLogger.info('Quiz Operations Metrics', {
      timestamp: new Date().toISOString(),
      type: 'quiz-operations-metrics',
      totalQuizzes: this.quizCreationCount,
      aiGeneratedQuizzes: this.aiGeneratedCount,
      syllabusBasedQuizzes: this.syllabusBasedCount,
      manualQuizzes: this.manualCount,
      totalQuestions: this.totalQuestions,
      avgQuestionsPerQuiz: avgQuestionsPerQuiz.toFixed(2),
      uptime: `${Math.floor(uptime / 1000)}s`,
      operationType: type,
      operationTime: operationTime ? `${operationTime}ms` : 'N/A'
    });
  }

  // Log daily summary
  logDailySummary() {
    const avgQuestionsPerQuiz = this.totalQuestions / Math.max(this.quizCreationCount, 1);

    quizLogger.info('Daily Quiz Operations Summary', {
      timestamp: new Date().toISOString(),
      date: new Date().toDateString(),
      totalQuizzesCreated: this.quizCreationCount,
      aiGeneratedQuizzes: this.aiGeneratedCount,
      syllabusBasedQuizzes: this.syllabusBasedCount,
      manualQuizzes: this.manualCount,
      totalQuestionsCreated: this.totalQuestions,
      avgQuestionsPerQuiz: avgQuestionsPerQuiz.toFixed(2),
      aiGenerationRate: `${((this.aiGeneratedCount / Math.max(this.quizCreationCount, 1)) * 100).toFixed(2)}%`,
      syllabusUsageRate: `${((this.syllabusBasedCount / Math.max(this.quizCreationCount, 1)) * 100).toFixed(2)}%`
    });
  }

  // Generate unique operation ID
  generateOperationId() {
    return `quiz_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Reset metrics (for daily reset)
  resetMetrics() {
    this.quizCreationCount = 0;
    this.aiGeneratedCount = 0;
    this.syllabusBasedCount = 0;
    this.manualCount = 0;
    this.totalQuestions = 0;
    this.startTime = Date.now();
  }
}

// Create singleton instance
const quizOperationsLogger = new QuizOperationsLogger();

// Schedule daily summary and reset
setInterval(() => {
  quizOperationsLogger.logDailySummary();
  quizOperationsLogger.resetMetrics();
}, 24 * 60 * 60 * 1000); // 24 hours

export default quizOperationsLogger;
