import bcrypt from 'bcryptjs';
import User from '../models/User.js';
import { logUser } from '../config/logger.js';

// Seed data for testing
const seedUsers = [
  {
    name: 'Admin User',
    email: 'admin@quizapp.com',
    password: 'admin123',
    role: 'admin',
    employeeId: 'ADM001',
    department: 'Administration',
    isActive: true,
    isDisabled: false
  },
  {
    name: 'Staff User',
    email: 'staff@quizapp.com', 
    password: 'staff123',
    role: 'staff',
    employeeId: 'STF001',
    department: 'Computer Science',
    isActive: true,
    isDisabled: false
  },
  {
    name: 'John Smith',
    email: 'john.staff@quizapp.com',
    password: 'john123',
    role: 'staff',
    employeeId: 'STF002',
    department: 'Mathematics',
    isActive: true,
    isDisabled: false
  },
  {
    name: 'Sarah Johnson',
    email: 'sarah.staff@quizapp.com',
    password: 'sarah123',
    role: 'staff',
    employeeId: 'STF003',
    department: 'Physics',
    isActive: true,
    isDisabled: false
  },
  {
    name: 'Test Student',
    email: 'student@quizapp.com',
    password: 'student123',
    role: 'student',
    studentId: 'STU001',
    rollNo: '2024001',
    grade: '10th Grade',
    isActive: true,
    isDisabled: false
  },
  {
    name: 'Alex Johnson',
    email: 'disabled.student@quizapp.com',
    password: 'disabled123',
    role: 'student',
    studentId: 'STU002',
    rollNo: '2024002',
    grade: '10th Grade',
    isActive: true,
    isDisabled: true
  }
];

// Function to hash password
const hashPassword = async (password) => {
  const saltRounds = 12;
  return await bcrypt.hash(password, saltRounds);
};

// Function to seed users
export const seedUsersData = async () => {
  try {
    console.log('🌱 Starting user seed data...');

    for (const userData of seedUsers) {
      // Check if user already exists
      const existingUser = await User.findOne({ email: userData.email });
      
      if (existingUser) {
        console.log(`⚠️  User ${userData.email} already exists, skipping...`);
        continue;
      }

      // Hash password
      const hashedPassword = await hashPassword(userData.password);

      // Create user object
      const userObject = {
        name: userData.name,
        email: userData.email,
        password: hashedPassword,
        role: userData.role,
        isActive: userData.isActive,
        isDisabled: userData.isDisabled
      };

      // Add role-specific fields
      if (userData.role === 'admin' || userData.role === 'staff') {
        userObject.employeeId = userData.employeeId;
        userObject.department = userData.department;
      } else if (userData.role === 'student') {
        userObject.studentId = userData.studentId;
        userObject.rollNo = userData.rollNo;
        userObject.grade = userData.grade;
      }

      // Create user
      const newUser = new User(userObject);
      await newUser.save();

      logUser('CREATE', newUser._id, userData.email, userData.role, true);

      console.log(`✅ Created ${userData.role} user: ${userData.email}`);
      console.log(`   📧 Email: ${userData.email}`);
      console.log(`   🔑 Password: ${userData.password}`);
      console.log(`   👤 Role: ${userData.role}`);
      if (userData.role === 'admin' || userData.role === 'staff') {
        console.log(`   🏢 Department: ${userData.department}`);
        console.log(`   🆔 Employee ID: ${userData.employeeId}`);
      } else if (userData.role === 'student') {
        console.log(`   🎓 Grade: ${userData.grade}`);
        console.log(`   🆔 Student ID: ${userData.studentId}`);
        console.log(`   📋 Roll No: ${userData.rollNo}`);
      }
      console.log('   ──────────────────────────────────────');
    }

    console.log('🎉 User seed data completed successfully!');
    console.log('\n📋 Login Credentials Summary:');
    console.log('┌─────────────────────────────────────────────────────────────┐');
    console.log('│                    ADMIN USERS                              │');
    console.log('├─────────────────────────────────────────────────────────────┤');
    console.log('│ Email: admin@quizapp.com     │ Password: admin123          │');
    console.log('└─────────────────────────────────────────────────────────────┘');
    console.log('┌─────────────────────────────────────────────────────────────┐');
    console.log('│                    STAFF USERS                              │');
    console.log('├─────────────────────────────────────────────────────────────┤');
    console.log('│ Email: staff@quizapp.com     │ Password: staff123          │');
    console.log('│ Email: john.staff@quizapp.com│ Password: john123           │');
    console.log('│ Email: sarah.staff@quizapp.com│ Password: sarah123         │');
    console.log('└─────────────────────────────────────────────────────────────┘');
    console.log('┌─────────────────────────────────────────────────────────────┐');
    console.log('│                   STUDENT USERS                             │');
    console.log('├─────────────────────────────────────────────────────────────┤');
    console.log('│ Email: student@quizapp.com   │ Password: student123        │');
    console.log('└─────────────────────────────────────────────────────────────┘');

  } catch (error) {
    console.error('❌ Error seeding user data:', error);
    logUser('CREATE', null, 'seed-error', 'error', false, error);
    throw error;
  }
};

// Function to clear all users (for testing)
export const clearAllUsers = async () => {
  try {
    console.log('🗑️  Clearing all users...');
    await User.deleteMany({});
    console.log('✅ All users cleared successfully');
  } catch (error) {
    console.error('❌ Error clearing users:', error);
    throw error;
  }
};

// Function to get seed status
export const getSeedStatus = async () => {
  try {
    const adminCount = await User.countDocuments({ role: 'admin' });
    const staffCount = await User.countDocuments({ role: 'staff' });
    const studentCount = await User.countDocuments({ role: 'student' });
    const totalCount = await User.countDocuments();

    return {
      admin: adminCount,
      staff: staffCount,
      student: studentCount,
      total: totalCount
    };
  } catch (error) {
    console.error('❌ Error getting seed status:', error);
    throw error;
  }
};

// Function to display current users
export const displayCurrentUsers = async () => {
  try {
    console.log('📊 Current Users in Database:');
    console.log('┌─────────────────────────────────────────────────────────────┐');
    
    const users = await User.find({}).select('-password').sort({ role: 1, name: 1 });
    
    if (users.length === 0) {
      console.log('│                    No users found                          │');
    } else {
      users.forEach((user, index) => {
        const role = user.role.toUpperCase();
        const name = user.name.padEnd(20);
        const email = user.email.padEnd(25);
        const status = user.isActive ? '✅ Active' : '❌ Inactive';
        
        console.log(`│ ${index + 1}. ${role.padEnd(8)} │ ${name} │ ${email} │ ${status} │`);
      });
    }
    
    console.log('└─────────────────────────────────────────────────────────────┘');
    
    return users;
  } catch (error) {
    console.error('❌ Error displaying users:', error);
    throw error;
  }
};

// Main seed function
export const runSeed = async () => {
  try {
    console.log('🚀 Starting Quiz App Seed Data...');
    console.log('=====================================');
    
    await seedUsersData();
    
    console.log('\n📈 Seed Status:');
    const status = await getSeedStatus();
    console.log(`   👑 Admins: ${status.admin}`);
    console.log(`   👨‍🏫 Staff: ${status.staff}`);
    console.log(`   👨‍🎓 Students: ${status.student}`);
    console.log(`   📊 Total: ${status.total}`);
    
    console.log('\n🎯 Seed completed successfully!');
    console.log('💡 You can now login with the provided credentials.');
    
  } catch (error) {
    console.error('❌ Seed failed:', error);
    throw error;
  }
};

// Export default function
export default runSeed; 