import express from 'express'
import mongoose from 'mongoose'
import dotenv from 'dotenv'
import cors from 'cors'
import authRoutes from './routes/auth.js'
import adminRoutes from './routes/adminRoutes.js'
import classroomRoutes from './routes/classroomRoutes.js'
import aiRoutes from './routes/aiRoutes.js'
import quizRoutes from './routes/quizRoutes.js'
import syllabusRoutes from './routes/syllabusRoutes.js'
import staffClassroomRoutes from './routes/staffClassroomRoutes.js';
import logRoutes from './routes/logRoutes.js';
import { logApi, logInfo, logError, logWarn } from './config/logger.js'
import { runSeed, displayCurrentUsers, getSeedStatus } from './utils/seedData.js'

dotenv.config()
const app = express()

// Middleware
app.use(cors({
  origin: process.env.CORS_ORIGIN || 'http://localhost:3000',
  credentials: true
}))
app.use(express.json())

// Request logging middleware
app.use((req, res, next) => {
  const start = Date.now();
  
  res.on('finish', () => {
    const duration = Date.now() - start;
    const userId = req.user?.id || null;
    logApi(req.method, req.originalUrl, res.statusCode, duration, userId);
  });
  
  next();
});

// Routes
app.use('/api/auth', authRoutes)
app.use('/api/admin', adminRoutes)
app.use('/api/classroom', classroomRoutes)
app.use('/api/ai', aiRoutes)
app.use('/api/quizzes', quizRoutes)
app.use('/api/syllabus', syllabusRoutes)
app.use('/api/staff', staffClassroomRoutes);
app.use('/api/logs', logRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
  logInfo('Health check requested');
  res.json({ 
    status: 'OK', 
    message: 'Server is running',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development'
  })
})

// Seed data endpoints (for development only)
if (process.env.NODE_ENV === 'development') {
  // Run seed data
  app.post('/api/seed', async (req, res) => {
    try {
      logInfo('Seed data requested');
      await runSeed();
      const status = await getSeedStatus();
      res.json({
        success: true,
        message: 'Seed data created successfully',
        status
      });
    } catch (error) {
      logError('Seed data failed', error);
      res.status(500).json({
        success: false,
        message: 'Failed to create seed data',
        error: error.message
      });
    }
  });

  // Get current users
  app.get('/api/seed/status', async (req, res) => {
    try {
      const status = await getSeedStatus();
      const users = await displayCurrentUsers();
      res.json({
        success: true,
        status,
        users: users.map(user => ({
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          isActive: user.isActive,
          department: user.department,
          studentId: user.studentId,
          rollNo: user.rollNo,
          grade: user.grade
        }))
      });
    } catch (error) {
      logError('Get seed status failed', error);
      res.status(500).json({
        success: false,
        message: 'Failed to get seed status',
        error: error.message
      });
    }
  });
}

// 404 handler
app.use('*', (req, res) => {
  logError('Route not found', null, { 
    method: req.method, 
    url: req.originalUrl,
    ip: req.ip 
  });
  res.status(404).json({
    success: false,
    message: 'Route not found'
  });
});

// Global error handler
app.use((error, req, res, next) => {
  logError('Unhandled error', error, { 
    method: req.method, 
    url: req.originalUrl,
    userId: req.user?.id 
  });
  
  res.status(error.status || 500).json({
    success: false,
    message: error.message || 'Internal server error',
    ...(process.env.NODE_ENV === 'development' && { stack: error.stack })
  });
});

// Database connection
const connectDB = async () => {
  try {
    const mongoURI = process.env.MONGODB_URI || 'mongodb://localhost:27017/quiz-app'
    await mongoose.connect(mongoURI)
    logInfo('MongoDB connected successfully');
    
    // Start server after successful DB connection
    const PORT = process.env.PORT || 5000
    app.listen(PORT, () => {
      logInfo(`Server started successfully`, {
        port: PORT,
        environment: process.env.NODE_ENV || 'development',
        mongoURI: mongoURI.replace(/\/\/.*@/, '//***:***@') // Hide credentials in logs
      });
      
      console.log(`🚀 Server running on http://localhost:${PORT}`)
      console.log(`📊 Environment: ${process.env.NODE_ENV || 'development'}`)
    })
  } catch (err) {
    logError('Database connection failed', err);
    console.error('❌ DB Connection Failed:', err.message)
    process.exit(1)
  }
}

// Handle MongoDB connection events
mongoose.connection.on('error', (err) => {
  logError('MongoDB connection error', err);
  console.error('❌ MongoDB connection error:', err)
})

mongoose.connection.on('disconnected', () => {
  logWarn('MongoDB disconnected');
  console.log('⚠️ MongoDB disconnected')
})

mongoose.connection.on('reconnected', () => {
  logInfo('MongoDB reconnected');
  console.log('✅ MongoDB reconnected')
})

// Handle process termination
process.on('SIGINT', async () => {
  try {
    logInfo('Server shutting down...');
    await mongoose.connection.close()
    logInfo('MongoDB connection closed through app termination');
    console.log('✅ MongoDB connection closed through app termination')
    process.exit(0)
  } catch (err) {
    logError('Error closing MongoDB connection', err);
    console.error('❌ Error closing MongoDB connection:', err)
    process.exit(1)
  }
})

process.on('unhandledRejection', (reason, promise) => {
  logError('Unhandled Rejection', reason, { promise: promise.toString() });
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

process.on('uncaughtException', (error) => {
  logError('Uncaught Exception', error);
  console.error('Uncaught Exception:', error);
  process.exit(1);
});

// Start the application
connectDB()
