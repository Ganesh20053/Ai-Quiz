import mongoose from 'mongoose';
import User from './models/User.js';
import Class from './models/Class.js';
import Quiz from './models/Quiz.js';
import QuizAssignment from './models/QuizAssignment.js';

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/quiz-app';

async function setupDisabledStudent() {
  try {
    await mongoose.connect(MONGODB_URI);
    console.log('✅ Connected to MongoDB');
    
    // Find the disabled student
    const disabledStudent = await User.findOne({ email: 'disabled.student@quizapp.com' });
    if (!disabledStudent) {
      console.log('❌ Disabled student not found');
      return;
    }
    console.log('👤 Found disabled student:', disabledStudent.name);
    
    // Find a staff member
    const staff = await User.findOne({ role: 'staff' });
    if (!staff) {
      console.log('❌ No staff member found');
      return;
    }
    console.log('👨‍🏫 Found staff member:', staff.name);
    
    // Check if there's already a classroom
    let classroom = await Class.findOne({ teacher: staff._id });
    
    if (!classroom) {
      // Create a test classroom
      classroom = new Class({
        name: 'Accessible Learning Classroom',
        subject: 'General Studies',
        description: 'A classroom designed for accessible learning with voice control support',
        teacher: staff._id,
        classType: 'mixed', // Supports both regular and disabled students
        students: []
      });
      await classroom.save();
      console.log('🏫 Created new classroom:', classroom.name);
    } else {
      console.log('🏫 Found existing classroom:', classroom.name);
    }
    
    // Add disabled student to classroom if not already added
    const isStudentInClassroom = classroom.students.some(
      student => student.student.toString() === disabledStudent._id.toString()
    );
    
    if (!isStudentInClassroom) {
      classroom.students.push({
        student: disabledStudent._id,
        studentType: 'disabled',
        joinedAt: new Date(),
        isActive: true
      });
      await classroom.save();
      console.log('✅ Added disabled student to classroom');
    } else {
      console.log('✅ Disabled student already in classroom');
    }
    
    // Check if there's a quiz
    let quiz = await Quiz.findOne({ createdBy: staff._id });
    
    if (!quiz) {
      // Create a test quiz
      quiz = new Quiz({
        title: 'Accessible Mathematics Quiz',
        description: 'A mathematics quiz optimized for voice control and accessibility',
        subject: 'Mathematics',
        difficulty: 'beginner',
        timeLimit: 30,
        createdBy: staff._id,
        questions: [
          {
            questionText: 'What is 2 plus 2?',
            questionType: 'multiple-choice',
            options: [
              { text: '3', isCorrect: false },
              { text: '4', isCorrect: true },
              { text: '5', isCorrect: false },
              { text: '6', isCorrect: false }
            ],
            points: 10,
            explanation: 'Two plus two equals four.'
          },
          {
            questionText: 'What is 5 times 3?',
            questionType: 'multiple-choice',
            options: [
              { text: '15', isCorrect: true },
              { text: '12', isCorrect: false },
              { text: '18', isCorrect: false },
              { text: '20', isCorrect: false }
            ],
            points: 10,
            explanation: 'Five times three equals fifteen.'
          },
          {
            questionText: 'What is 10 minus 4?',
            questionType: 'multiple-choice',
            options: [
              { text: '5', isCorrect: false },
              { text: '6', isCorrect: true },
              { text: '7', isCorrect: false },
              { text: '8', isCorrect: false }
            ],
            points: 10,
            explanation: 'Ten minus four equals six.'
          }
        ],
        settings: {
          allowRetake: true,
          maxAttempts: 3,
          showResults: true,
          randomizeQuestions: false,
          voiceEnabled: true,
          autoReadQuestions: true,
          provideAudioFeedback: true,
          allowVoiceControl: true
        },
        status: 'published'
      });
      await quiz.save();
      console.log('📝 Created new quiz:', quiz.title);
    } else {
      console.log('📝 Found existing quiz:', quiz.title);
    }
    
    // Check if there's already an assignment
    let assignment = await QuizAssignment.findOne({
      quiz: quiz._id,
      classroom: classroom._id,
      'assignedStudents.student': disabledStudent._id
    });
    
    if (!assignment) {
      // Create quiz assignment for disabled student
      assignment = new QuizAssignment({
        quiz: quiz._id,
        classroom: classroom._id,
        assignedBy: staff._id,
        assignmentType: 'disabled',
        assignedStudents: [{
          student: disabledStudent._id,
          studentType: 'disabled',
          assignedAt: new Date(),
          isActive: true
        }],
        settings: {
          dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
          timeLimit: 45, // Extended time for disabled students
          allowRetake: true,
          maxAttempts: 5,
          voiceEnabled: true,
          autoReadQuestions: true,
          provideAudioFeedback: true,
          allowVoiceControl: true
        },
        instructions: 'This quiz is optimized for voice control. You can navigate and answer using voice commands.',
        status: 'active'
      });
      await assignment.save();
      console.log('📋 Created quiz assignment for disabled student');
    } else {
      console.log('📋 Assignment already exists for disabled student');
    }
    
    console.log('\n🎉 Setup complete!');
    console.log('📊 Summary:');
    console.log('  - Student:', disabledStudent.name, '(', disabledStudent.email, ')');
    console.log('  - Classroom:', classroom.name);
    console.log('  - Quiz:', quiz.title);
    console.log('  - Assignment ID:', assignment._id);
    console.log('\n✅ The disabled student should now see quiz assignments!');
    
    await mongoose.connection.close();
    
  } catch (error) {
    console.error('❌ Error:', error);
  }
}

setupDisabledStudent();
