import express from 'express'
import { authenticateToken, requireRole } from '../middleware/authMiddleware.js'
import { uploadSyllabus, handleUploadError } from '../middleware/upload.js'
import {
  generateQuizQuestions,
  createAIQuiz,
  generateQuizWithGemini,
  processSyllabus,
  generateQuizFromTopics,
  testGeminiAPI
} from '../controllers/aiController.js'

const router = express.Router()

// Generate quiz questions using AI
router.post('/generate-questions', authenticateToken, requireRole('staff'), generateQuizQuestions)

// Create a complete quiz with AI-generated questions
router.post('/create-quiz', authenticateToken, requireRole('staff'), createAIQuiz)

// Generate quiz endpoint (alias for create-quiz)
router.post('/generate-quiz', authenticateToken, requireRole('staff'), createAIQuiz)

// Add Gemini quiz generation endpoint
router.post('/gemini', authenticateToken, requireRole('staff'), generateQuizWithGemini)

// Syllabus processing endpoints
router.post('/process-syllabus',
  authenticateToken,
  requireRole('staff'),
  uploadSyllabus,
  handleUploadError,
  processSyllabus
)

// Generate quiz from selected topics
router.post('/generate-from-topics', authenticateToken, requireRole('staff'), generateQuizFromTopics)

// Test Gemini API endpoint
router.get('/test-gemini', authenticateToken, requireRole('staff'), testGeminiAPI)

export default router