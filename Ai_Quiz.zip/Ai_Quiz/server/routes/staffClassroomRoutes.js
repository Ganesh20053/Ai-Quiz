import express from 'express';
import { authenticateToken, requireRole } from '../middleware/authMiddleware.js';
import Quiz from '../models/Quiz.js';
import Class from '../models/Class.js'; // Import the classroom model

const router = express.Router();

// GET /api/staff/classrooms/:classroomId/quizzes
router.get('/classrooms/:classroomId/quizzes', authenticateToken, requireRole('staff'), async (req, res) => {
  try {
    const { classroomId } = req.params;
    // Check if classroom exists
    const classroom = await Class.findById(classroomId);
    if (!classroom) {
      return res.status(404).json({ message: 'Classroom not found' });
    }
    const quizzes = await Quiz.find({ classroom: classroomId });
    res.json({ quizzes });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch quizzes', error: error.message });
  }
});

export default router; 