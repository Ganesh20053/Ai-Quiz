import express from 'express';
import { authenticateToken, requireRole } from '../middleware/authMiddleware.js';
import multer from 'multer';
import path from 'path';

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/syllabus/');
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['application/pdf', 'text/plain', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only PDF, TXT, and DOCX files are allowed.'), false);
    }
  },
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit
  }
});

// Check if syllabus exists for a classroom
router.get('/:classroomId/exists', authenticateToken, requireRole('staff'), async (req, res) => {
  try {
    const { classroomId } = req.params;
    
    // For now, return false since we don't have a syllabus model yet
    // This can be enhanced when syllabus functionality is fully implemented
    res.json({
      success: true,
      data: {
        exists: false,
        syllabus: null
      }
    });
  } catch (error) {
    console.error('Error checking syllabus existence:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to check syllabus existence'
    });
  }
});

// Upload syllabus
router.post('/upload', authenticateToken, requireRole('staff'), upload.single('syllabus'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No file uploaded'
      });
    }

    const { classroomId } = req.body;
    
    if (!classroomId) {
      return res.status(400).json({
        success: false,
        message: 'Classroom ID is required'
      });
    }

    // For now, return success with file info
    // This can be enhanced to actually process and store syllabus data
    res.json({
      success: true,
      data: {
        filename: req.file.filename,
        originalName: req.file.originalname,
        size: req.file.size,
        mimetype: req.file.mimetype,
        classroomId: classroomId,
        uploadedBy: req.user.id,
        uploadedAt: new Date()
      },
      message: 'Syllabus uploaded successfully'
    });
  } catch (error) {
    console.error('Error uploading syllabus:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to upload syllabus'
    });
  }
});

// Get syllabus for a classroom
router.get('/:classroomId', authenticateToken, requireRole('staff'), async (req, res) => {
  try {
    const { classroomId } = req.params;
    
    // For now, return empty data since we don't have a syllabus model yet
    res.json({
      success: true,
      data: {
        syllabus: null,
        exists: false
      }
    });
  } catch (error) {
    console.error('Error getting syllabus:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get syllabus'
    });
  }
});

// Delete syllabus
router.delete('/:classroomId', authenticateToken, requireRole('staff'), async (req, res) => {
  try {
    const { classroomId } = req.params;
    
    // For now, return success since we don't have a syllabus model yet
    res.json({
      success: true,
      message: 'Syllabus deleted successfully'
    });
  } catch (error) {
    console.error('Error deleting syllabus:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete syllabus'
    });
  }
});

export default router; 