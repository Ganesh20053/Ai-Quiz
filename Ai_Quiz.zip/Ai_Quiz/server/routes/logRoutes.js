import express from 'express';
import { authenticateToken, requireRole } from '../middleware/authMiddleware.js';
import {
  getLogStats,
  getRecentLogs,
  getGeminiMetrics,
  getQuizMetrics
} from '../controllers/logController.js';

const router = express.Router();

// Get log statistics (admin only)
router.get('/stats', authenticateToken, requireRole('admin'), getLogStats);

// Get recent log entries (admin only)
router.get('/recent', authenticateToken, requireRole('admin'), getRecentLogs);

// Get Gemini API metrics (staff and admin)
router.get('/gemini-metrics', authenticateToken, requireRole('staff'), getGeminiMetrics);

// Get quiz operations metrics (staff and admin)
router.get('/quiz-metrics', authenticateToken, requireRole('staff'), getQuizMetrics);

export default router;
