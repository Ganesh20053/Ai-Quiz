import express from 'express';
import { 
  getAllStaff, 
  addStaff, 
  updateStaff, 
  deleteStaff, 
  getDashboardStats 
} from '../controllers/adminController.js';
import { authenticateToken, requireRole } from '../middleware/authMiddleware.js';

const router = express.Router();

// All routes require authentication and admin role
router.use(authenticateToken);
router.use(requireRole('admin'));

// Get dashboard stats
router.get('/dashboard/stats', getDashboardStats);

// Staff management routes
router.get('/staff', getAllStaff);
router.post('/staff', addStaff);
router.put('/staff/:id', updateStaff);
router.delete('/staff/:id', deleteStaff);

export default router;
