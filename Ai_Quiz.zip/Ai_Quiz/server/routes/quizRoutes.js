import express from 'express'
import { authenticateToken, requireRole } from '../middleware/authMiddleware.js'
import {
  getTeacherQuizzes,
  getQuizById,
  createQuiz,
  updateQuiz,
  deleteQuiz,
  publishQuiz,
  archiveQuiz,
  getQuizStatistics,
  getClassroomQuizzes
} from '../controllers/quizController.js'

const router = express.Router()

// Get all quizzes for a teacher
router.get('/teacher', authenticateToken, requireRole('staff'), getTeacherQuizzes)

// Get quizzes for a specific classroom
router.get('/classroom/:classroomId', authenticateToken, requireRole('staff'), getClassroomQuizzes)

// Get a specific quiz by ID
router.get('/:quizId', authenticateToken, requireRole('staff'), getQuizById)

// Create a new quiz
router.post('/', authenticateToken, requireRole('staff'), createQuiz)

// Update a quiz
router.put('/:quizId', authenticateToken, requireRole('staff'), updateQuiz)

// Delete a quiz
router.delete('/:quizId', authenticateToken, requireRole('staff'), deleteQuiz)

// Publish a quiz
router.patch('/:quizId/publish', authenticateToken, requireRole('staff'), publishQuiz)

// Archive a quiz
router.patch('/:quizId/archive', authenticateToken, requireRole('staff'), archiveQuiz)

// Get quiz statistics
router.get('/:quizId/statistics', authenticateToken, requireRole('staff'), getQuizStatistics)

export default router
