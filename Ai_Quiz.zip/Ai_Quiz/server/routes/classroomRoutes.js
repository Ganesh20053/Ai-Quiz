import express from 'express';
import {
  createClassroom,
  getTeacherClassrooms,
  getClassroomById,
  addStudentsToClassroom,
  removeStudentFromClassroom,
  deleteStudentCompletely,
  getClassroomStudents,
  updateClassroom,
  deleteClassroom,
  getClassroomAnalytics,
  getClassroomStats
} from '../controllers/classroomController.js';
import {
  createQuizAssignment,
  getClassroomAssignments,
  getAllTeacherAssignments,
  getAllTeacherAssignmentsWithStats,
  getAssignmentById,
  updateAssignment,
  deleteAssignment,
  getStudentAssignments,
  submitQuizForAssignment
} from '../controllers/quizAssignmentController.js';
import { authenticateToken, requireRole } from '../middleware/authMiddleware.js';

const router = express.Router();

// Health check route
router.get('/health', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Classroom routes are working',
    timestamp: new Date().toISOString()
  });
});

// Simple test route without authentication
router.get('/test', async (req, res) => {
  try {
    const { default: QuizAssignment } = await import('../models/QuizAssignment.js');
    const count = await QuizAssignment.countDocuments();
    res.status(200).json({
      success: true,
      message: 'Database connection working',
      assignmentCount: count,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Database connection failed',
      error: error.message
    });
  }
});

// Student routes (must come before staff middleware)
router.get('/student/assignments', authenticateToken, requireRole('student'), getStudentAssignments);
router.post('/assignments/:assignmentId/submit', authenticateToken, requireRole('student'), submitQuizForAssignment);

// Assignment access route - accessible by both students and staff
router.get('/assignments/:assignmentId', authenticateToken, getAssignmentById);

// Debug route to check all assignments (temporary)
router.get('/debug/assignments', authenticateToken, async (req, res) => {
  try {
    const QuizAssignment = (await import('../models/QuizAssignment.js')).default;
    const assignments = await QuizAssignment.find({})
      .populate('quiz', 'title')
      .populate('classroom', 'name')
      .populate('assignedBy', 'name email')
      .limit(10);

    res.json({
      success: true,
      count: assignments.length,
      assignments: assignments.map(a => ({
        id: a._id,
        quiz: a.quiz?.title,
        classroom: a.classroom?.name,
        assignedBy: a.assignedBy?.name,
        status: a.status,
        assignedStudents: a.assignedStudents.length,
        assignedStudentsDetails: a.assignedStudents.map(s => ({
          student: s.student,
          isActive: s.isActive,
          studentType: s.studentType
        })),
        createdAt: a.createdAt
      }))
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Debug route to check student's classrooms
router.get('/debug/student-classrooms', authenticateToken, requireRole('student'), async (req, res) => {
  try {
    const Class = (await import('../models/Class.js')).default;
    const studentId = req.user.id;

    const classrooms = await Class.find({
      'students.student': studentId
    }).populate('teacher', 'name email');

    res.json({
      success: true,
      studentId,
      count: classrooms.length,
      classrooms: classrooms.map(c => ({
        id: c._id,
        name: c.name,
        teacher: c.teacher?.name,
        totalStudents: c.students.length,
        studentInClass: c.students.find(s => s.student.toString() === studentId.toString()),
        activeStudents: c.students.filter(s => s.isActive).length
      }))
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Debug route to check specific assignment
router.get('/debug/assignment/:assignmentId', authenticateToken, async (req, res) => {
  try {
    const { assignmentId } = req.params;
    const QuizAssignment = (await import('../models/QuizAssignment.js')).default;
    
    const assignment = await QuizAssignment.findById(assignmentId)
      .populate('quiz', 'title')
      .populate('classroom', 'name')
      .populate('assignedBy', 'name email')
      .populate('assignedStudents.student', 'name email _id');

    if (!assignment) {
      return res.status(404).json({
        success: false,
        message: 'Assignment not found'
      });
    }

    res.json({
      success: true,
      currentUser: {
        id: req.user.id,
        name: req.user.name,
        role: req.user.role
      },
      assignment: {
        id: assignment._id,
        quiz: assignment.quiz?.title,
        classroom: assignment.classroom?.name,
        assignedBy: assignment.assignedBy?.name,
        assignmentType: assignment.assignmentType,
        status: assignment.status,
        totalAssignedStudents: assignment.assignedStudents.length,
        assignedStudents: assignment.assignedStudents.map(s => ({
          studentId: s.student._id.toString(),
          studentName: s.student.name,
          studentEmail: s.student.email,
          isActive: s.isActive,
          studentType: s.studentType,
          assignedAt: s.assignedAt
        })),
        isCurrentUserAssigned: assignment.assignedStudents.some(
          s => s.student._id.toString() === req.user.id.toString() && s.isActive
        )
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// All remaining routes require authentication and staff role
router.use(authenticateToken);
router.use(requireRole('staff'));

// Classroom management routes
router.post('/', createClassroom);
router.get('/', getTeacherClassrooms);

// Classroom analytics and stats (must come before /:id routes)
router.get('/stats', getClassroomStats);

// Classroom-specific routes
router.get('/:id', getClassroomById);
router.put('/:id', updateClassroom);
router.delete('/:id', deleteClassroom);

// Student management in classrooms
router.post('/:classroomId/students', addStudentsToClassroom);
router.delete('/:classroomId/students/:studentId', removeStudentFromClassroom);
router.delete('/:classroomId/students/:studentId/permanent', deleteStudentCompletely);
router.get('/:classroomId/students', getClassroomStudents);

// Classroom analytics and stats
router.get('/:classroomId/analytics', getClassroomAnalytics);

// Quiz assignment routes
// Get all assignments for the teacher (must come before specific routes)
router.get('/assignments/with-stats', getAllTeacherAssignmentsWithStats);
router.get('/assignments', getAllTeacherAssignments);

router.post('/:classroomId/assign-quiz', (req, res, next) => {
  console.log('🎯 assign-quiz route hit!');
  console.log('📍 Params:', req.params);
  console.log('📝 Body:', req.body);
  next();
}, createQuizAssignment);
router.get('/:classroomId/assignments', getClassroomAssignments);
router.put('/assignments/:assignmentId', updateAssignment);
router.delete('/assignments/:assignmentId', deleteAssignment);

// Debug route to check all assignments
router.get('/debug/all-assignments', async (req, res) => {
  try {
    const { default: QuizAssignment } = await import('../models/QuizAssignment.js');

    const assignments = await QuizAssignment.find({})
      .populate('quiz', 'title description')
      .populate('classroom', 'name subject')
      .populate('assignedBy', 'name email');

    res.status(200).json({
      success: true,
      count: assignments.length,
      data: assignments
    });
  } catch (error) {
    console.error('Error fetching all assignments:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch assignments',
      error: error.message
    });
  }
});

// Debug route to check assignment without auth (for testing)
router.get('/debug/assignment-no-auth/:assignmentId', async (req, res) => {
  try {
    const { assignmentId } = req.params;
    const QuizAssignment = (await import('../models/QuizAssignment.js')).default;
    
    const assignment = await QuizAssignment.findById(assignmentId)
      .populate('quiz', 'title')
      .populate('classroom', 'name')
      .populate('assignedBy', 'name email')
      .populate('assignedStudents.student', 'name email _id');

    if (!assignment) {
      return res.status(404).json({
        success: false,
        message: 'Assignment not found'
      });
    }

    res.json({
      success: true,
      assignment: {
        id: assignment._id,
        quiz: assignment.quiz?.title,
        classroom: assignment.classroom?.name,
        assignedBy: assignment.assignedBy?.name,
        assignmentType: assignment.assignmentType,
        status: assignment.status,
        totalAssignedStudents: assignment.assignedStudents.length,
        assignedStudents: assignment.assignedStudents.map(s => ({
          studentId: s.student._id.toString(),
          studentName: s.student.name,
          studentEmail: s.student.email,
          isActive: s.isActive,
          studentType: s.studentType,
          assignedAt: s.assignedAt
        }))
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Debug route to create test assignment (no auth required for testing)
router.post('/debug/create-simple-assignment', async (req, res) => {
  try {
    const { default: QuizAssignment } = await import('../models/QuizAssignment.js');
    const { default: Quiz } = await import('../models/Quiz.js');
    const { default: Class } = await import('../models/Class.js');
    const { default: User } = await import('../models/User.js');

    console.log('🧪 Creating simple test assignment...');

    // Find any quiz, classroom, and users
    const quiz = await Quiz.findOne();
    const classroom = await Class.findOne();
    const teacher = await User.findOne({ role: 'staff' });
    const student = await User.findOne({ role: 'student' });

    console.log('📊 Found:', {
      quiz: quiz ? quiz.title : 'none',
      classroom: classroom ? classroom.name : 'none',
      teacher: teacher ? teacher.name : 'none',
      student: student ? student.name : 'none'
    });

    if (!quiz || !classroom || !teacher || !student) {
      return res.status(404).json({
        success: false,
        message: 'Missing required data for testing',
        found: {
          quiz: !!quiz,
          classroom: !!classroom,
          teacher: !!teacher,
          student: !!student
        }
      });
    }

    // Create simple test assignment
    const testAssignment = new QuizAssignment({
      quiz: quiz._id,
      classroom: classroom._id,
      assignedBy: teacher._id,
      assignmentType: 'all',
      assignedStudents: [{
        student: student._id,
        studentType: 'regular',
        assignedAt: new Date(),
        isActive: true
      }],
      settings: {
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
        timeLimit: 30,
        allowRetake: false,
        maxAttempts: 1
      },
      status: 'active'
    });

    await testAssignment.save();
    console.log('✅ Test assignment created:', testAssignment._id);

    res.status(201).json({
      success: true,
      message: 'Simple test assignment created',
      data: {
        id: testAssignment._id,
        quiz: quiz.title,
        classroom: classroom.name,
        student: student.name
      }
    });
  } catch (error) {
    console.error('❌ Error creating simple test assignment:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create simple test assignment',
      error: error.message
    });
  }
});

// Debug route to create test assignment (with auth)
router.post('/debug/create-test-assignment', async (req, res) => {
  try {
    const { default: QuizAssignment } = await import('../models/QuizAssignment.js');
    const { default: Quiz } = await import('../models/Quiz.js');
    const { default: Class } = await import('../models/Class.js');

    // Find any quiz and classroom
    const quiz = await Quiz.findOne();
    const classroom = await Class.findOne();

    if (!quiz || !classroom) {
      return res.status(404).json({
        success: false,
        message: 'No quiz or classroom found for testing'
      });
    }

    // Create test assignment
    const testAssignment = new QuizAssignment({
      quiz: quiz._id,
      classroom: classroom._id,
      assignedBy: req.user.id,
      assignmentType: 'all',
      assignedStudents: classroom.students.map(student => ({
        student: student.student,
        studentType: student.studentType,
        assignedAt: new Date(),
        isActive: true
      })),
      settings: {
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
        timeLimit: 30,
        allowRetake: false,
        maxAttempts: 1
      },
      status: 'active'
    });

    await testAssignment.save();

    res.status(201).json({
      success: true,
      message: 'Test assignment created',
      data: testAssignment
    });
  } catch (error) {
    console.error('Error creating test assignment:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create test assignment',
      error: error.message
    });
  }
});



export default router;
