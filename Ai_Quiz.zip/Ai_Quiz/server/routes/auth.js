import express from 'express';
import {
  register,
  login,
  forgotPassword,
  resetPassword,
  getProfile,
  updateProfile,
  changePassword,
  logout,
  verifyToken,
  createStudent
} from '../controllers/authController.js';
import { authenticateToken, requireRole } from '../middleware/authMiddleware.js';
import User from '../models/User.js';
import { sendEmail } from '../utils/emailService.js';

const router = express.Router();

// Public routes
router.post('/register', register);
router.post('/login', login);
router.post('/forgot-password', forgotPassword);
router.post('/reset-password', resetPassword);
router.post('/logout', logout);

// Protected routes
router.get('/profile', authenticateToken, getProfile);
router.put('/profile', authenticateToken, updateProfile);
router.put('/change-password', authenticateToken, changePassword);
router.get('/verify', authenticateToken, verifyToken);

// Test email endpoint (for debugging)
router.post('/test-email', authenticateToken, requireRole('staff'), async (req, res) => {
  try {
    const { email } = req.body;
    const testEmail = email || req.user.email || 'test@example.com';

    console.log('📧 Testing email to:', testEmail);

    await sendEmail({
      to: testEmail,
      subject: 'Test Email from Quiz App',
      template: 'student-credentials',
      data: {
        name: 'Test Student',
        email: testEmail,
        studentId: 'TEST123',
        rollNo: 'TEST-001',
        password: 'TestPassword123!'
      }
    });

    res.json({
      success: true,
      message: `Test email sent successfully to ${testEmail}`
    });
  } catch (error) {
    console.error('Test email failed:', error);
    res.status(500).json({
      success: false,
      message: 'Test email failed',
      error: error.message
    });
  }
});

// Staff routes - Student management
router.post('/students', authenticateToken, requireRole('staff'), createStudent);
router.get('/students', authenticateToken, requireRole('staff'), async (req, res) => {
  try {
    const students = await User.find({ role: 'student' })
      .select('-password -resetPasswordToken -resetPasswordExpires')
      .sort({ createdAt: -1 }); // Sort by newest first

    res.json({
      success: true,
      data: students
    });
  } catch (error) {
    console.error('Get students error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Admin routes
router.get('/users', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const users = await User.find({}).select('-password -resetPasswordToken -resetPasswordExpires');
    
    res.json({
      success: true,
      data: { users }
    });
  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

export default router;
