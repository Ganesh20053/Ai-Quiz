import mongoose from 'mongoose';
import User from './models/User.js';
import Class from './models/Class.js';
import Quiz from './models/Quiz.js';
import QuizAssignment from './models/QuizAssignment.js';

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/quiz-app';

async function fixDisabledStudent() {
  try {
    await mongoose.connect(MONGODB_URI);
    console.log('✅ Connected to MongoDB');
    
    // Find the disabled student
    const disabledStudent = await User.findOne({ email: 'disabled.student@quizapp.com' });
    if (!disabledStudent) {
      console.log('❌ Disabled student not found');
      return;
    }
    console.log('👤 Found disabled student:', disabledStudent.name, disabledStudent._id);
    
    // Find existing classroom
    const classroom = await Class.findOne().populate('teacher');
    if (!classroom) {
      console.log('❌ No classroom found');
      return;
    }
    console.log('🏫 Found classroom:', classroom.name, 'ID:', classroom._id);
    
    // Check if student is already in classroom
    const isInClassroom = classroom.students.some(
      s => s.student.toString() === disabledStudent._id.toString()
    );
    
    if (!isInClassroom) {
      // Add student to classroom
      classroom.students.push({
        student: disabledStudent._id,
        studentType: 'disabled',
        joinedAt: new Date(),
        isActive: true
      });
      await classroom.save();
      console.log('✅ Added disabled student to classroom');
    } else {
      console.log('✅ Student already in classroom');
    }
    
    // Find existing quiz
    const quiz = await Quiz.findOne({ status: 'published' });
    if (!quiz) {
      console.log('❌ No published quiz found');
      return;
    }
    console.log('📝 Found quiz:', quiz.title, 'ID:', quiz._id);
    
    // Check if assignment already exists
    let assignment = await QuizAssignment.findOne({
      quiz: quiz._id,
      classroom: classroom._id,
      'assignedStudents.student': disabledStudent._id
    });
    
    if (!assignment) {
      // Create new assignment
      assignment = new QuizAssignment({
        quiz: quiz._id,
        classroom: classroom._id,
        assignedBy: classroom.teacher,
        assignmentType: 'disabled',
        assignedStudents: [{
          student: disabledStudent._id,
          studentType: 'disabled',
          assignedAt: new Date(),
          isActive: true
        }],
        settings: {
          dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
          timeLimit: 45,
          allowRetake: true,
          maxAttempts: 5,
          voiceEnabled: true,
          autoReadQuestions: true,
          provideAudioFeedback: true,
          allowVoiceControl: true
        },
        instructions: 'Voice-controlled quiz for accessibility',
        status: 'active'
      });
      await assignment.save();
      console.log('✅ Created assignment:', assignment._id);
    } else {
      console.log('✅ Assignment already exists:', assignment._id);
    }
    
    // Verify the setup
    console.log('\n🔍 Verification:');
    
    // Check classroom enrollment
    const updatedClassroom = await Class.findById(classroom._id);
    const studentInClass = updatedClassroom.students.find(
      s => s.student.toString() === disabledStudent._id.toString()
    );
    console.log('  - Student in classroom:', !!studentInClass, studentInClass?.isActive);
    
    // Check assignment
    const assignments = await QuizAssignment.find({
      'assignedStudents.student': disabledStudent._id,
      status: 'active'
    }).populate('quiz', 'title').populate('classroom', 'name');
    
    console.log('  - Active assignments:', assignments.length);
    assignments.forEach(a => {
      console.log(`    - ${a.quiz.title} in ${a.classroom.name}`);
    });
    
    console.log('\n🎉 Setup complete! Disabled student should now see assignments.');
    
    await mongoose.connection.close();
    
  } catch (error) {
    console.error('❌ Error:', error);
  }
}

fixDisabledStudent();
