// config/logger.js
import { createLogger, transports, format } from 'winston';
import path from 'path';
import { fileURLToPath } from 'url';

// Handle __dirname in ESModules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Custom format for better readability
const customFormat = format.combine(
  format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  format.errors({ stack: true }),
  format.colorize(),
  format.printf(({ timestamp, level, message, stack, ...meta }) => {
    let log = `[${timestamp}] ${level.toUpperCase()}: ${message}`;
    
    // Add metadata if present
    if (Object.keys(meta).length > 0) {
      log += ` | ${JSON.stringify(meta)}`;
    }
    
    // Add stack trace if present
    if (stack) {
      log += `\n${stack}`;
    }
    
    return log;
  })
);

// Create logs directory if it doesn't exist
import fs from 'fs';
const logsDir = path.join(__dirname, '../logs');
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
}

const logger = createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: customFormat,
  transports: [
    // Console transport with colors
    new transports.Console({
      format: format.combine(
        format.colorize(),
        format.simple()
      )
    }),
    
    // File transport for all logs
    new transports.File({ 
      filename: path.join(logsDir, 'combined.log'),
      format: format.combine(
        format.uncolorize(),
        format.simple()
      )
    }),
    
    // Separate file for errors
    new transports.File({ 
      filename: path.join(logsDir, 'error.log'),
      level: 'error',
      format: format.combine(
        format.uncolorize(),
        format.simple()
      )
    }),
    
    // Separate file for API requests
    new transports.File({ 
      filename: path.join(logsDir, 'api.log'),
      format: format.combine(
        format.uncolorize(),
        format.simple()
      )
    })
  ]
});

// Helper functions for different log types
export const logInfo = (message, meta = {}) => {
  logger.info(message, meta);
};

export const logError = (message, error = null, meta = {}) => {
  if (error) {
    meta.error = error.message;
    meta.stack = error.stack;
  }
  logger.error(message, meta);
};

export const logWarn = (message, meta = {}) => {
  logger.warn(message, meta);
};

export const logDebug = (message, meta = {}) => {
  logger.debug(message, meta);
};

export const logApi = (method, url, statusCode, responseTime, userId = null) => {
  logger.info(`API ${method} ${url} - ${statusCode} (${responseTime}ms)`, {
    type: 'API_REQUEST',
    method,
    url,
    statusCode,
    responseTime,
    userId
  });
};

export const logAuth = (action, userId, email, success, details = {}) => {
  logger.info(`AUTH ${action} - ${success ? 'SUCCESS' : 'FAILED'}`, {
    type: 'AUTH',
    action,
    userId,
    email,
    success,
    ...details
  });
};

export const logEmail = (action, to, subject, success, error = null) => {
  logger.info(`EMAIL ${action} - ${success ? 'SENT' : 'FAILED'}`, {
    type: 'EMAIL',
    action,
    to,
    subject,
    success,
    error: error?.message
  });
};

export const logUser = (action, userId, email, role, details = {}) => {
  logger.info(`USER ${action}`, {
    type: 'USER',
    action,
    userId,
    email,
    role,
    ...details
  });
};

export const logClassroom = (action, classroomId, staffId, details = {}) => {
  logger.info(`CLASSROOM ${action}`, {
    type: 'CLASSROOM',
    action,
    classroomId,
    staffId,
    ...details
  });
};

export default logger;
