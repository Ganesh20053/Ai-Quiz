import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import User from './models/User.js';

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/quiz-app';

async function testDisabledStudentLogin() {
  try {
    await mongoose.connect(MONGODB_URI);
    console.log('✅ Connected to MongoDB');
    
    // Find the disabled student
    const user = await User.findOne({ email: 'disabled.student@quizapp.com' });
    if (!user) {
      console.log('❌ Disabled student not found');
      return;
    }
    
    console.log('👤 Found user:', {
      name: user.name,
      email: user.email,
      role: user.role,
      isActive: user.isActive,
      isDisabled: user.isDisabled,
      studentId: user.studentId
    });
    
    // Test password verification
    const testPassword = 'disabled123';
    const isPasswordValid = await bcrypt.compare(testPassword, user.password);
    
    console.log('🔐 Password test:', {
      testPassword,
      isValid: isPasswordValid
    });
    
    // Test login conditions
    console.log('🔍 Login conditions:', {
      isActive: user.isActive,
      isDisabled: user.isDisabled,
      shouldAllowLogin: user.isActive && isPasswordValid
    });
    
    if (user.isActive && isPasswordValid) {
      console.log('✅ Login should work!');
    } else {
      console.log('❌ Login will fail because:');
      if (!user.isActive) console.log('  - Account is not active');
      if (!isPasswordValid) console.log('  - Password is invalid');
    }
    
    await mongoose.connection.close();
    
  } catch (error) {
    console.error('❌ Error:', error);
  }
}

testDisabledStudentLogin();
