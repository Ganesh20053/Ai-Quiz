# Quiz App - Complete Learning Management System

A comprehensive quiz application with role-based access control, classroom management, and automated email notifications.

## 🚀 Features Implemented

### 🔐 Authentication & User Management
- **Role-based Access Control**: Admin, Staff, and Student roles
- **Secure Authentication**: JWT-based authentication with password hashing
- **Password Management**: Reset password functionality with email notifications
- **User Registration**: Default student registration with role assignment

### 👨‍💼 Admin Dashboard
- **Staff Management**: Add, update, and delete staff members
- **System Analytics**: Dashboard statistics and user overview
- **User Monitoring**: Track all users and their activities
- **System Logs**: Comprehensive logging for all operations

### 👨‍🏫 Staff Dashboard
- **Student Management**: Add students with email, roll number, and disabled status
- **Classroom Creation**: Create and manage virtual classrooms
- **Student Enrollment**: Add students to classrooms with automatic email invitations
- **Quiz Management**: Create and assign quizzes to students
- **Grade Management**: Track and update student grades

### 🎓 Student Dashboard
- **Personal Dashboard**: View quizzes, progress, and achievements
- **Quiz Taking**: Interactive quiz interface
- **Progress Tracking**: Monitor performance and scores
- **Profile Management**: Update personal information
- **Logout Functionality**: Secure logout with session management

### 📧 Email System
- **Welcome Emails**: Automatic welcome emails for new users
- **Student Credentials**: Email with login credentials when staff adds students
- **Classroom Invitations**: Email notifications when students are added to classrooms
- **Password Reset**: Secure password reset via email
- **Login Notifications**: Security alerts for account access

### 📊 Comprehensive Logging
- **API Request Logging**: Track all API calls with response times
- **Authentication Logging**: Monitor login attempts and user actions
- **Email Logging**: Track email sending success/failure
- **User Activity Logging**: Monitor user actions and system events
- **Error Logging**: Detailed error tracking with stack traces

## 🏗️ Architecture

### Frontend (React + Redux)
```
Client/
├── src/
│   ├── components/          # Reusable UI components
│   ├── features/           # Feature-based organization
│   │   ├── auth/          # Authentication features
│   │   ├── student/       # Student-specific features
│   │   └── classroom/     # Classroom management
│   ├── pages/             # Page components
│   ├── store/             # Redux store configuration
│   └── utils/             # Utility functions
```

### Backend (Node.js + Express + MongoDB)
```
server/
├── controllers/           # Business logic controllers
├── models/               # MongoDB schemas
├── routes/               # API route definitions
├── middleware/           # Custom middleware
├── utils/                # Utility functions
│   └── emailTemplates/   # Email template system
└── config/               # Configuration files
```

## 🛠️ Installation & Setup

### Prerequisites
- Node.js (v16 or higher)
- MongoDB (v4.4 or higher)
- npm or yarn

### Backend Setup
```bash
cd server
npm install
cp .env.example .env
# Configure your environment variables
npm run dev
```

### Frontend Setup
```bash
cd Client
npm install
cp .env.example .env
# Configure your environment variables
npm run dev
```

### Environment Variables

#### Backend (.env)
```env
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb://localhost:27017/quiz-app
JWT_SECRET=your-secret-key
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=your-email-password
EMAIL_SERVICE=gmail
FRONTEND_URL=http://localhost:3000
```

#### Frontend (.env)
```env
VITE_API_URL=http://localhost:5000/api
VITE_APP_NAME=Quiz App
```

## 📋 API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `POST /api/auth/forgot-password` - Password reset request
- `POST /api/auth/reset-password` - Password reset
- `POST /api/auth/students` - Create student (Staff only)

### Admin Routes
- `GET /api/admin/dashboard/stats` - Dashboard statistics
- `GET /api/admin/staff` - Get all staff members
- `POST /api/admin/staff` - Add new staff member
- `PUT /api/admin/staff/:id` - Update staff member
- `DELETE /api/admin/staff/:id` - Delete staff member

### Classroom Routes
- `POST /api/classrooms` - Create classroom
- `GET /api/classrooms` - Get teacher's classrooms
- `GET /api/classrooms/:id` - Get classroom details
- `PUT /api/classrooms/:id` - Update classroom
- `DELETE /api/classrooms/:id` - Delete classroom
- `POST /api/classrooms/:id/students` - Add students to classroom
- `DELETE /api/classrooms/:id/students/:studentId` - Remove student

## 🔧 Key Features Implementation

### 1. Student Creation by Staff
- Staff can add students with email, roll number, and grade
- Default password (123) is generated automatically
- Email with credentials is sent to non-disabled students
- Disabled students option for special cases

### 2. Classroom Management
- Staff can create virtual classrooms
- Unique class codes are generated automatically
- Students can be added to classrooms
- Email invitations are sent when students are added

### 3. Email Template System
- Modular email template system
- Separate templates for different email types
- HTML and text versions for all emails
- Professional styling and branding

### 4. Comprehensive Logging
- Winston-based logging system
- Separate log files for different types
- API request/response logging
- Error tracking with stack traces
- User activity monitoring

### 5. Role-Based Access Control
- Admin: Full system access, staff management
- Staff: Student management, classroom creation
- Student: Quiz taking, profile management

## 📧 Email Templates

### Student Credentials Email
- Welcome message with account details
- Student ID, email, password, and roll number
- Security reminder to change password
- Professional styling with branding

### Classroom Invitation Email
- Classroom details and teacher information
- Class code and subject information
- Direct link to join classroom
- Teacher contact information

## 🔒 Security Features

- JWT-based authentication
- Password hashing with bcrypt
- Role-based access control
- Input validation and sanitization
- CORS configuration
- Rate limiting (can be added)
- Secure password reset flow

## 📊 Logging System

### Log Types
- **API Logs**: All HTTP requests with response times
- **Auth Logs**: Login attempts, registrations, password changes
- **Email Logs**: Email sending success/failure
- **User Logs**: User creation, updates, deletions
- **Classroom Logs**: Classroom operations
- **Error Logs**: All errors with stack traces

### Log Files
- `combined.log` - All logs
- `error.log` - Error logs only
- `api.log` - API request logs

## 🚀 Deployment

### Production Setup
1. Set `NODE_ENV=production`
2. Configure production MongoDB
3. Set up email service credentials
4. Configure CORS for production domain
5. Set up SSL certificates
6. Configure environment variables

### Docker Deployment (Optional)
```dockerfile
# Dockerfile example
FROM node:16-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 5000
CMD ["npm", "start"]
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📝 License

This project is licensed under the MIT License.

## 🆘 Support

For support and questions:
- Create an issue in the repository
- Check the documentation
- Review the logs for debugging

## 🔄 Future Enhancements

- Real-time notifications
- Advanced analytics dashboard
- Mobile app development
- Integration with external LMS
- Advanced quiz types
- Video conferencing integration
- Payment integration for premium features

---

**Built with ❤️ using React, Node.js, Express, and MongoDB** 